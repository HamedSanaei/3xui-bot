using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using Adminbot.Domain;
using Adminbot.Domain.Logging;
using Adminbot.Utils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

/// <summary>
/// Selects retry semantics for one XUI v3 HTTP request.
/// </summary>
public enum XuiV3RequestRetryMode
{
    /// <summary>Retry transient failures because the request only reads panel state and has no side effect.</summary>
    ReadOnly,

    /// <summary>Retry only when the caller guarantees that replaying the same mutation is provider-idempotent.</summary>
    IdempotentMutation,

    /// <summary>Send exactly once because a timeout may hide a committed non-idempotent panel mutation.</summary>
    NoAutomaticRetry
}

/// <summary>
/// Classifies one XUI v3 logical operation so the transport can decide whether an interactive Telegram lane needs a
/// bounded overall wall-clock budget in addition to the provider-oriented per-attempt timeout and retry policy.
/// </summary>
/// <remarks>
/// <para>
/// <see cref="ForegroundRead"/> designates user-facing read-only panel operations where the Telegram user is waiting
/// (account lists, account search, account detail reloads, navigation reads, safe renewal target discovery before any
/// mutation). Such requests receive ONE overall wall-clock budget that spans every attempt, every backoff delay, and
/// response reading. When the budget expires no further retry starts and the request fails with a typed
/// <see cref="XuiV3ForegroundReadTimeoutException"/> so the caller can release the Telegram lane with a short retry
/// message.
/// </para>
/// <para>
/// <see cref="BackgroundRead"/> is the default for ordinary read-only calls (expiry/reminder scans, reconciliation,
/// recovery workers, maintenance). Those keep the existing provider-oriented timeout and transient retry budget
/// because a background lane is not waiting interactively.
/// </para>
/// <para>
/// <see cref="IdempotentMutation"/> and <see cref="NoAutomaticRetryMutation"/> document mutation callers. They never
/// receive a foreground budget and never make a non-idempotent mutation retryable: <see cref="NoAutomaticRetryMutation"/>
/// maps to exactly one HTTP attempt exactly like <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
/// </para>
/// </remarks>
public enum XuiV3RequestExecutionPolicy
{
    /// <summary>
    /// Read-only background/recovery call with the provider-oriented timeout and transient retry policy unchanged.
    /// </summary>
    BackgroundRead,

    /// <summary>
    /// Read-only user-facing call bounded by one overall wall-clock budget across all attempts and backoff.
    /// </summary>
    ForegroundRead,

    /// <summary>
    /// Mutating call that may retry only when replaying the same mutation is provider-idempotent.
    /// </summary>
    IdempotentMutation,

    /// <summary>
    /// Mutating call sent exactly once because a timeout may hide a committed non-idempotent panel mutation.
    /// </summary>
    NoAutomaticRetryMutation
}

/// <summary>
/// Raised when a <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> XUI v3 logical request exhausts its overall
/// wall-clock budget before a successful response. The Telegram lane is released when this escapes to the handler.
/// </summary>
/// <remarks>
/// This type extends <see cref="TimeoutException"/> so generic Telegram handlers classify it as an external timeout
/// and show a user-safe retry message. It deliberately carries no panel URL, token, endpoint, response body, or stack
/// details, so rendering this exception to Telegram can never leak provider secrets.
/// </remarks>
public sealed class XuiV3ForegroundReadTimeoutException : TimeoutException
{
    /// <summary>
    /// Creates the typed foreground timeout with the overall budget that expired.
    /// </summary>
    /// <param name="budget">
    /// The overall wall-clock budget in effect for the read. Exposed only as a duration, never as a panel secret.
    /// </param>
    public XuiV3ForegroundReadTimeoutException(TimeSpan budget)
        : base($"XUI v3 foreground read exceeded its overall {budget.TotalSeconds:0} second budget.")
    {
        Budget = budget;
    }

    /// <summary>Gets the overall wall-clock budget that expired for this foreground read.</summary>
    public TimeSpan Budget { get; }
}

/// <summary>
/// Provides authenticated XUI v3 panel operations and normalized bot-facing account results.
/// </summary>
/// <remarks>
/// Public API methods receive server credentials from trusted runtime configuration. Panel URLs, bearer tokens,
/// request paths containing email/SubId, response bodies, and returned proxy configurations are sensitive. Callers
/// that deliver configurations must opt out of identifier-bearing retry logs and must never expose these values in
/// Telegram callbacks or customer-visible logs.
/// </remarks>
public class ApiServicev3
{
    private const int DefaultXuiV3TimeoutSeconds = 60;
    private const int DefaultXuiV3TransientRetryCount = 3;
    private const int DefaultXuiV3TransientRetryBaseDelayMs = 1500;
    private const int DefaultXuiV3TransientRetryMaxDelayMs = 12000;

    private static readonly JsonSerializerSettings JsonSettings = new JsonSerializerSettings
    {
        NullValueHandling = NullValueHandling.Ignore
    };

    /// <summary>
    /// Recommended overall wall-clock budget for one foreground XUI v3 read. The whole logical request — every
    /// attempt, all backoff, and response reading — must finish inside this window. Production default: 12 seconds.
    /// </summary>
    public static readonly TimeSpan DefaultForegroundReadOverallBudget = TimeSpan.FromSeconds(12);

    /// <summary>
    /// Hard upper bound for the overall foreground XUI v3 read budget. A foreground logical read is capped at
    /// 15 seconds regardless of configuration so a single interactive Telegram lane can never be held by backend
    /// retry policy for a provider-oriented timeout.
    /// </summary>
    public static readonly TimeSpan ForegroundReadOverallHardCap = TimeSpan.FromSeconds(15);

    /// <summary>
    /// Detects whether a panel can answer the v3 API. If a version is forced on ServerInfo or configuration,
    /// that value wins. Otherwise it probes the v3 clients endpoint with Bearer auth, then falls back to v2 cookie auth.
    /// </summary>
    public static async Task<XuiPanelApiVersion> DetectPanelVersionAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        var appConfig = configuration.Get<AppConfig>() ?? new AppConfig();
        var forced = (serverInfo.ApiVersion ?? appConfig.XuiApiVersionMode ?? "auto").Trim().ToLowerInvariant();

        if (serverInfo.PanelMajorVersion >= 3 || forced == "v3" || forced == "3")
            return XuiPanelApiVersion.V3;

        if (serverInfo.PanelMajorVersion > 0 && serverInfo.PanelMajorVersion < 3 || forced == "v2" || forced == "2")
            return XuiPanelApiVersion.V2;

        try
        {
            var response = await GetClientsAsync(serverInfo, configuration, cancellationToken);
            if (response.Success)
                return XuiPanelApiVersion.V3;
        }
        catch
        {
            // v3 probe failed; cookie probe below decides whether the old API is still usable.
        }

        try
        {
            var cookie = await ApiService.LoginAndGetSessionCookie(serverInfo);
            if (!string.IsNullOrWhiteSpace(cookie))
                return XuiPanelApiVersion.V2;
        }
        catch
        {
        }

        return XuiPanelApiVersion.Unknown;
    }

    /// <summary>
    /// Creates a user account after automatic API version detection. v2 calls the existing ApiService;
    /// v3 uses Bearer auth and the first matching/mapped inbound IDs.
    /// </summary>
    public static async Task<XuiV3AccountCreationResult> CreateUserAccountAutoAsync(
        AccountDto accountDto,
        IConfiguration configuration,
        XuiV3CreateAccountOptions options = null,
        CancellationToken cancellationToken = default)
    {
        var version = await DetectPanelVersionAsync(accountDto.ServerInfo, configuration, cancellationToken);
        if (version == XuiPanelApiVersion.V2)
        {
            var ok = await ApiService.CreateUserAccount(accountDto);
            return new XuiV3AccountCreationResult
            {
                Success = ok,
                ApiVersion = version,
                Email = ok ? accountDto.TelegramUserId.ToString() : null
            };
        }

        if (version != XuiPanelApiVersion.V3)
        {
            return new XuiV3AccountCreationResult
            {
                Success = false,
                ApiVersion = version,
                Message = "Could not detect a usable 3X-UI API version."
            };
        }

        return await CreateUserAccountAsync(accountDto, configuration, options, cancellationToken);
    }

    /// <summary>
    /// Creates a v3 client and attaches it to one or more inbounds.
    /// The inbound IDs must be supplied explicitly through options.InboundIds.
    /// </summary>
    /// <param name="accountDto">Required detached account request and panel descriptor; never log its credentials.</param>
    /// <param name="configuration">Runtime transport configuration containing private panel authentication.</param>
    /// <param name="options">Creation options; durable business keys make repeated calls GET-only recovery.</param>
    /// <param name="cancellationToken">Cancellation of reservation, the single POST, and read-back calls.</param>
    /// <returns>A verified creation result or a safe failure. Ambiguous results never authorize another POST.</returns>
    /// <remarks>Client identity is persisted before POST when a durable operation key is supplied. No SQLite transaction spans HTTP.</remarks>
    public static async Task<XuiV3AccountCreationResult> CreateUserAccountAsync(
        AccountDto accountDto,
        IConfiguration configuration,
        XuiV3CreateAccountOptions options = null,
        CancellationToken cancellationToken = default)
    {
        options ??= new XuiV3CreateAccountOptions();
        var client = BuildClientPayload(accountDto, options);
        if (string.IsNullOrWhiteSpace(options.OperationKey))
            return await CreateUserAccountCoreAsync(accountDto, configuration, options, client, cancellationToken);
        if (options.OperationStore == null) throw new InvalidOperationException("Durable creation requires its operation store.");
        var inbounds = options.InboundIds?.Distinct().Order().ToList() ?? new List<int>();
        if (inbounds.Count == 0) throw new InvalidOperationException("No inbound IDs were provided for the v3 account.");
        var reservation = await options.OperationStore.ReserveAsync(new XuiV3CreationOperation
        {
            OperationKey = options.OperationKey,
            TelegramUserId = accountDto.TelegramUserId,
            PanelKey = XuiV3LinkChangeOperationStore.BuildPanelKey(accountDto.ServerInfo),
            ClientJson = JsonConvert.SerializeObject(client), InboundIdsJson = JsonConvert.SerializeObject(inbounds),
            BusinessParametersJson = JsonConvert.SerializeObject(new
            {
                accountDto.TotoalGB, accountDto.SelectedPeriod, options.TrafficGb, options.TrafficBytes,
                options.DurationDays, options.LimitIp, options.UseVisionFlow, options.StartExpiryAfterFirstUse, options.PriceToman
            }),
            AuthorizedByKey = options.AuthorizedByKey,
            CreatedAtUtc = DateTime.UtcNow
        }, cancellationToken);
        client = JsonConvert.DeserializeObject<XuiV3ClientPayload>(reservation.Operation.ClientJson);
        XuiV3AccountCreationResult result;
        if (reservation.Operation.Outcome == XuiV3CreationOutcome.Applied)
        {
            // Durable positive proof survives an unavailable follow-up GET; return the reserved known account.
            var knownGb = options.TrafficGb > 0 ? options.TrafficGb : Convert.ToInt32(accountDto.TotoalGB);
            var knownBytes = options.TrafficBytes > 0 ? options.TrafficBytes : ApiService.ConvertGBToBytes(knownGb);
            return await BuildAccountCreationResultFromKnownClientAsync(accountDto, configuration, client, null,
                inbounds, knownGb, knownBytes, options, null, cancellationToken);
        }
        if (reservation.Operation.Outcome == XuiV3CreationOutcome.DefinitiveRejected)
            return new XuiV3AccountCreationResult { Success = false, ApiVersion = XuiPanelApiVersion.V3,
                Message = XuiV3UserSafeError.ForAccountCreation("creation definitively rejected") };
        if (reservation.MayCreate && await options.OperationStore.TryStartPostAsync(options.OperationKey, cancellationToken))
        {
            try
            {
                result = await CreateUserAccountCoreAsync(accountDto, configuration, options, client, cancellationToken);
            }
            finally
            {
                // If no authoritative outcome was committed, every interruption stays GET-only. This token is
                // independent of a cancelled HTTP request, and a failed save still leaves PostStarted safely blocking.
                using var persistence = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                await options.OperationStore.MarkFailureAsync(options.OperationKey, XuiV3CreationOutcome.Ambiguous, persistence.Token);
            }
        }
        else
        {
            // Absence after a timeout does not prove that a previous POST will never commit. Never issue another add.
            var trafficGb = options.TrafficGb > 0 ? options.TrafficGb : Convert.ToInt32(accountDto.TotoalGB);
            var trafficBytes = options.TrafficBytes > 0 ? options.TrafficBytes : ApiService.ConvertGBToBytes(trafficGb);
            result = await TryRecoverCreatedClientAsync(accountDto, configuration, client, inbounds, trafficGb,
                trafficBytes, options, null, cancellationToken) ?? new XuiV3AccountCreationResult
                {
                    Success = false, ApiVersion = XuiPanelApiVersion.V3, Email = client.Email,
                    Message = XuiV3UserSafeError.ForAccountCreation("creation result requires reconciliation")
                };
        }
        if (result.Success) await options.OperationStore.MarkAppliedAsync(options.OperationKey, cancellationToken);
        return result;
    }

    /// <summary>Performs the single authorized addClient and the existing safe read-back recovery sequence.</summary>
    /// <param name="accountDto">Detached account request and authenticated panel descriptor.</param>
    /// <param name="configuration">Private transport configuration.</param>
    /// <param name="options">Validated creation options.</param>
    /// <param name="client">Exact generated or durably reserved client identity, never regenerated during recovery.</param>
    /// <param name="cancellationToken">Cancellation of external calls and local state persistence.</param>
    /// <returns>Verified creation or safe ambiguous/failed result; callers must not blindly retry creation.</returns>
    /// <remarks>NoAutomaticRetry remains the addClient transport boundary; only GETs resolve uncertain outcomes.</remarks>
    private static async Task<XuiV3AccountCreationResult> CreateUserAccountCoreAsync(
        AccountDto accountDto, IConfiguration configuration, XuiV3CreateAccountOptions options,
        XuiV3ClientPayload client, CancellationToken cancellationToken)
    {
        options ??= new XuiV3CreateAccountOptions();

        var inboundIds = options.InboundIds?.Distinct().ToList() ?? new List<int>();
        if (inboundIds.Count == 0)
            throw new InvalidOperationException("No inbound IDs were provided for the v3 account.");

        var trafficGb = options.TrafficGb > 0 ? options.TrafficGb : Convert.ToInt32(accountDto.TotoalGB);
        var trafficBytes = options.TrafficBytes > 0 ? options.TrafficBytes : ApiService.ConvertGBToBytes(trafficGb);
        XuiV3ApiResponse<JToken> response;
        try
        {
            response = await AddClientAsync(
                accountDto.ServerInfo,
                configuration,
                new XuiV3ClientCreateRequest { Client = client, InboundIds = inboundIds },
                cancellationToken);
        }
        catch (Exception ex) when (IsTransientXuiTransportException(ex, cancellationToken))
        {
            var recovered = await TryRecoverCreatedClientAsync(
                accountDto,
                configuration,
                client,
                inboundIds,
                trafficGb,
                trafficBytes,
                options,
                responseObj: null,
                cancellationToken);

            return recovered ?? BuildTransientCreationFailure(configuration, client.Email, ex);
        }
        catch (XuiV3ApiException ex) when (CouldIndicateExistingClient(ex))
        {
            var recovered = await TryRecoverCreatedClientAsync(
                accountDto,
                configuration,
                client,
                inboundIds,
                trafficGb,
                trafficBytes,
                options,
                responseObj: null,
                cancellationToken);

            if (recovered != null)
                return recovered;

            throw;
        }

        if (!response.Success)
        {
            // Only explicit validation failures known to precede mutation are terminal. Arbitrary success=false
            // messages (including duplicate and internal errors) are not proof that no partial commit occurred.
            if (IsDefinitiveCreationRejection(response.Msg) && options.OperationStore != null && !string.IsNullOrWhiteSpace(options.OperationKey))
                await options.OperationStore.MarkFailureAsync(options.OperationKey, XuiV3CreationOutcome.DefinitiveRejected, cancellationToken);
            if (CouldIndicateExistingClient(response.Msg))
            {
                var recovered = await TryRecoverCreatedClientAsync(
                    accountDto,
                    configuration,
                    client,
                    inboundIds,
                    trafficGb,
                    trafficBytes,
                    options,
                    response.Obj,
                    cancellationToken);

                if (recovered != null)
                    return recovered;
            }

            return new XuiV3AccountCreationResult
            {
                Success = false,
                ApiVersion = XuiPanelApiVersion.V3,
                Email = client.Email,
                Message = XuiV3UserSafeError.ForAccountCreation(response.Msg)
            };
        }

        // Authoritative add success proves application even when subsequent GET/link retrieval fails.
        if (options.OperationStore != null && !string.IsNullOrWhiteSpace(options.OperationKey))
            await options.OperationStore.MarkAppliedAsync(options.OperationKey, cancellationToken);
        try
        {
            return await BuildAccountCreationResultAsync(
                accountDto,
                configuration,
                client,
                inboundIds,
                trafficGb,
                trafficBytes,
                options,
                response.Obj,
                cancellationToken);
        }
        catch (Exception ex) when (IsTransientXuiTransportException(ex, cancellationToken) || ex is XuiV3ApiException)
        {
            // POST success is authoritative; optional read-back failure cannot turn it into failed provisioning.
            return await BuildAccountCreationResultFromKnownClientAsync(accountDto, configuration, client, null,
                inboundIds, trafficGb, trafficBytes, options, response.Obj, cancellationToken);
        }
    }

    /// <summary>
    /// Builds the final account creation result after the panel has accepted the add-client request.
    /// </summary>
    /// <param name="accountDto">
    /// Bot-facing account request that contains the Telegram owner id, target panel, selected service, period, and
    /// user-facing traffic values.
    /// </param>
    /// <param name="configuration">Application configuration used for XUI v3 API timeout, retry, and token settings.</param>
    /// <param name="client">The client payload that was submitted to 3x-ui.</param>
    /// <param name="inboundIds">The active XUI inbound ids that the client was attached to.</param>
    /// <param name="trafficGb">Display traffic limit in GB for the bot message and saved state.</param>
    /// <param name="trafficBytes">Traffic limit in bytes that was sent to the panel.</param>
    /// <param name="options">Resolved creation options that control duration, status persistence, and metadata.</param>
    /// <param name="responseObj">Raw successful add-client API response from the panel, stored for diagnostics.</param>
    /// <param name="cancellationToken">Cancellation token for follow-up panel reads and optional state persistence.</param>
    /// <returns>
    /// A successful creation result using the real panel client when it can be read, including the real UUID and subId.
    /// </returns>
    /// <remarks>
    /// The add-client endpoint can succeed while later reads are slow after a 3x-ui update. This method is deliberately
    /// separated from the add step so callers can retry/recover the read side without sending another add request.
    /// </remarks>
    private static async Task<XuiV3AccountCreationResult> BuildAccountCreationResultAsync(
        AccountDto accountDto,
        IConfiguration configuration,
        XuiV3ClientPayload client,
        List<int> inboundIds,
        int trafficGb,
        long trafficBytes,
        XuiV3CreateAccountOptions options,
        JToken responseObj,
        CancellationToken cancellationToken)
    {
        var panelClientResponse = await GetClientAsync(accountDto.ServerInfo, configuration, client.Email, cancellationToken);
        var panelClient = panelClientResponse.Success && panelClientResponse.Obj != null
            ? panelClientResponse.Obj
            : null;

        return await BuildAccountCreationResultFromKnownClientAsync(
            accountDto,
            configuration,
            client,
            panelClient,
            inboundIds,
            trafficGb,
            trafficBytes,
            options,
            responseObj,
            cancellationToken);
    }

    /// <summary>
    /// Builds a creation result from a panel client that is already known or has just been recovered by email.
    /// </summary>
    /// <param name="accountDto">Original bot account request that owns the saved state and subscription base link.</param>
    /// <param name="configuration">Application configuration used for XUI v3 link lookup.</param>
    /// <param name="client">Submitted client payload used as a fallback when the panel omits a field.</param>
    /// <param name="panelClient">Client row read back from the panel, or <c>null</c> when only add-client success is known.</param>
    /// <param name="inboundIds">Inbound ids that were selected from the active service plan.</param>
    /// <param name="trafficGb">Traffic amount in GB shown to the Telegram user.</param>
    /// <param name="trafficBytes">Traffic amount in bytes stored in the result for downstream sync and logs.</param>
    /// <param name="options">Creation options that control whether legacy user state is saved.</param>
    /// <param name="responseObj">Raw successful add-client response, when available.</param>
    /// <param name="cancellationToken">Cancellation token for optional link lookup and state persistence.</param>
    /// <returns>
    /// A successful creation result. The config link may be <c>null</c> when link retrieval fails after the account row
    /// is already confirmed on the panel.
    /// </returns>
    /// <remarks>
    /// Link lookup is best-effort once the panel client has been confirmed. Returning the real panel UUID is more
    /// important than failing the whole purchase because the link endpoint timed out.
    /// </remarks>
    private static async Task<XuiV3AccountCreationResult> BuildAccountCreationResultFromKnownClientAsync(
        AccountDto accountDto,
        IConfiguration configuration,
        XuiV3ClientPayload client,
        XuiV3Client panelClient,
        List<int> inboundIds,
        int trafficGb,
        long trafficBytes,
        XuiV3CreateAccountOptions options,
        JToken responseObj,
        CancellationToken cancellationToken)
    {
        XuiV3ApiResponse<List<string>> links = null;
        try
        {
            links = await GetClientLinksAsync(accountDto.ServerInfo, configuration, client.Email, cancellationToken);
        }
        catch (Exception ex) when (IsTransientXuiTransportException(ex, cancellationToken) || ex is XuiV3ApiException)
        {
            Console.WriteLine($"[XUIv3] Optional creation link lookup failed. ErrorType={ex.GetType().Name}");
        }

        var configLink = links?.Obj?.FirstOrDefault();
        var linkUuid = TryExtractUuidFromConfigLink(configLink, out var extractedUuid) ? extractedUuid : null;
        var subLink = BuildSubscriptionLink(accountDto.ServerInfo, FirstNonWhiteSpace(panelClient?.SubId, client.SubId, client.Email));

        if (options.SaveUserStatus)
        {
            var userStateStore = UserStateStore.ForConfiguredDatabase();
            await userStateStore.SaveUserStatus(new User
            {
                Id = accountDto.TelegramUserId,
                ConfigLink = configLink,
                Email = client.Email,
                SubLink = subLink,
                SelectedCountry = accountDto.SelectedCountry,
                SelectedPeriod = accountDto.SelectedPeriod,
                TotoalGB = accountDto.TotoalGB,
                Type = accountDto.AccType,
                AccountCounter = accountDto.AccountCounter
            });
        }

        return new XuiV3AccountCreationResult
        {
            Success = true,
            ApiVersion = XuiPanelApiVersion.V3,
            Email = panelClient?.Email ?? client.Email,
            Uuid = FirstNonWhiteSpace(panelClient?.Uuid, linkUuid, client.Uuid),
            SubId = FirstNonWhiteSpace(panelClient?.SubId, client.SubId),
            ConfigLink = configLink,
            SubLink = subLink,
            TrafficGb = trafficGb,
            TrafficBytes = trafficBytes,
            // 3x-ui 3.4.x may return top-level expiryTime as zero while exposing the actual value in traffic or extra.
            // Resolve all panel representations before falling back to the payload that created this client.
            ExpiryTime = ResolveCreatedClientExpiryTime(panelClient, client),
            DurationDays = options.DurationDays,
            Comment = FirstNonWhiteSpace(panelClient?.Comment, client.Comment),
            InboundIds = inboundIds,
            RawResponse = responseObj
        };
    }

    /// <summary>
    /// Resolves the effective expiry value for a newly created XUI v3 client from all panel response shapes.
    /// </summary>
    /// <param name="panelClient">
    /// Nullable client row read back after creation; null uses the submitted expiry after authoritative POST success. Version 3.4.x may expose its effective expiry in nested traffic
    /// or extension data while leaving the inherited top-level value at zero.
    /// </param>
    /// <param name="submittedClient">
    /// Original payload sent to the panel. Its expiry is used only when the panel response does not expose a non-zero
    /// expiry value, preserving a normal fixed-date account from being displayed as unlimited.
    /// </param>
    /// <returns>
    /// The effective Unix-millisecond expiry timestamp, a negative first-use duration, or zero only when both panel
    /// and submitted payload genuinely represent an unlimited account.
    /// </returns>
    /// <remarks>
    /// This helper affects only the user-facing creation result. It does not change the expiry persisted by 3x-ui.
    /// </remarks>
    private static long ResolveCreatedClientExpiryTime(XuiV3Client panelClient, XuiV3ClientPayload submittedClient)
    {
        if (panelClient != null && panelClient.ExpiryTime != 0)
            return panelClient.ExpiryTime;

        var trafficExpiryTime = panelClient?.Traffic?.ExpiryTime ?? 0;
        if (trafficExpiryTime != 0)
            return trafficExpiryTime;

        var extraExpiryTime = ReadClientExtraLong(panelClient, "expiryTime", "expiry_time", "expiry");
        if (extraExpiryTime != 0)
            return extraExpiryTime;

        return submittedClient?.ExpiryTime ?? 0;
    }

    /// <summary>
    /// Reads a long-valued field from the extension data returned by one XUI v3 client response.
    /// </summary>
    /// <param name="client">Panel client whose extension JSON should be inspected. Null clients return zero.</param>
    /// <param name="keys">Candidate JSON property names in priority order.</param>
    /// <returns>The first parseable non-zero value, or zero when no candidate property is available.</returns>
    /// <remarks>
    /// 3x-ui response compatibility varies by panel version, so expiry fields must not rely on one fixed JSON shape.
    /// </remarks>
    private static long ReadClientExtraLong(XuiV3Client client, params string[] keys)
    {
        if (client?.Extra == null || keys == null)
            return 0;

        foreach (var key in keys)
        {
            if (string.IsNullOrWhiteSpace(key) || !client.Extra.TryGetValue(key, out var token) || token == null)
                continue;

            if (token.Type == JTokenType.Integer && token.Value<long>() != 0)
                return token.Value<long>();

            if (long.TryParse(token.ToString(), out var parsed) && parsed != 0)
                return parsed;
        }

        return 0;
    }

    /// <summary>
    /// Attempts to recover a successful creation result by reading the client email after a transient add/read failure.
    /// </summary>
    /// <param name="accountDto">Original account request containing the target XUI server and Telegram owner id.</param>
    /// <param name="configuration">Application configuration for XUI v3 retries and authentication.</param>
    /// <param name="client">Client payload whose email is used as the idempotency key on the panel.</param>
    /// <param name="inboundIds">Inbound ids selected for the account creation attempt.</param>
    /// <param name="trafficGb">Traffic amount in GB that should be reported if recovery succeeds.</param>
    /// <param name="trafficBytes">Traffic amount in bytes that should be reported if recovery succeeds.</param>
    /// <param name="options">Creation options used for state persistence and metadata.</param>
    /// <param name="responseObj">Raw add-client response, when the add call completed before the later failure.</param>
    /// <param name="cancellationToken">Cancellation token for the recovery lookup.</param>
    /// <returns>
    /// A successful creation result when the panel contains the client; otherwise <c>null</c> so the caller can return a
    /// controlled transient failure without creating a duplicate account.
    /// </returns>
    /// <remarks>
    /// This is the duplicate-protection path for ambiguous network failures. It never sends another add-client request;
    /// it only reads the panel by email and builds the result from the existing row.
    /// </remarks>
    private static async Task<XuiV3AccountCreationResult> TryRecoverCreatedClientAsync(
        AccountDto accountDto,
        IConfiguration configuration,
        XuiV3ClientPayload client,
        List<int> inboundIds,
        int trafficGb,
        long trafficBytes,
        XuiV3CreateAccountOptions options,
        JToken responseObj,
        CancellationToken cancellationToken)
    {
        try
        {
            var panelClientResponse = await GetClientAsync(accountDto.ServerInfo, configuration, client.Email, cancellationToken);
            if (!panelClientResponse.Success || !MatchesReservedCreation(client, panelClientResponse.Obj)
                || !inboundIds.All(id => panelClientResponse.Obj.InboundIds.Contains(id)))
                return null;
            if (options.OperationStore != null && !string.IsNullOrWhiteSpace(options.OperationKey))
                await options.OperationStore.MarkAppliedAsync(options.OperationKey, cancellationToken);
            Console.WriteLine("[XUIv3] Creation recovered by identity-safe read-back.");
            return await BuildAccountCreationResultFromKnownClientAsync(
                accountDto,
                configuration,
                client,
                panelClientResponse.Obj,
                inboundIds,
                trafficGb,
                trafficBytes,
                options,
                responseObj,
                cancellationToken);
        }
        catch (Exception ex) when (IsTransientXuiTransportException(ex, cancellationToken) || ex is XuiV3ApiException)
        {
            Console.WriteLine($"[XUIv3] Creation read-back inconclusive. ErrorType={ex.GetType().Name}");
            return null;
        }
    }

    /// <summary>
    /// Creates a user-facing failed creation result for a transient XUI v3 transport error.
    /// </summary>
    /// <param name="configuration">
    /// Application configuration used to write the complete masked diagnostic file entry for this final transient
    /// failure. The value comes from the active runtime configuration passed into account creation.
    /// </param>
    /// <param name="email">Generated account email that was being created.</param>
    /// <param name="exception">Transient transport exception observed while talking to the panel.</param>
    /// <returns>
    /// A failed account creation result that does not expose panel secrets and can be shown by bot flows as a retryable
    /// panel problem.
    /// </returns>
    /// <remarks>
    /// Returning a normal result object prevents a network glitch from escaping to Telegram polling and stopping the
    /// active receiver. The full transport exception is also written to the daily diagnostic file because this static
    /// service does not receive an injected application logger.
    /// </remarks>
    private static XuiV3AccountCreationResult BuildTransientCreationFailure(
        IConfiguration configuration,
        string email,
        Exception exception)
    {
        Console.WriteLine($"[XUIv3] Creation transport outcome uncertain. ErrorType={exception.GetType().Name}");
        return new XuiV3AccountCreationResult
        {
            Success = false,
            ApiVersion = XuiPanelApiVersion.V3,
            Email = email,
            Message = XuiV3UserSafeError.TemporaryAccountCreationFailureMessage
        };
    }

    /// <summary>
    /// Checks whether an add-client response may mean the previous ambiguous attempt already created the same email.
    /// </summary>
    /// <param name="exception">XUI v3 API exception thrown by the add-client endpoint.</param>
    /// <returns>
    /// <c>true</c> when the response status/body looks like a duplicate-client response that should be verified by
    /// reading the client by email; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This is not a retry rule. It is an idempotency guard used only after add-client returns an existing-client style
    /// response, which can happen when a previous transport failure hid a successful server-side creation.
    /// </remarks>
    private static bool CouldIndicateExistingClient(XuiV3ApiException exception)
    {
        if (exception == null)
            return false;

        return exception.StatusCode == 409 || CouldIndicateExistingClient(exception.ResponseBody);
    }

    /// <summary>
    /// Checks whether a panel message appears to describe an already existing client/email.
    /// </summary>
    /// <param name="message">Response message or body returned by 3x-ui.</param>
    /// <returns><c>true</c> when the message contains common duplicate-client wording; otherwise <c>false</c>.</returns>
    private static bool CouldIndicateExistingClient(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("already", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("exist", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("duplicate", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("重复", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("تکراری", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>Recognizes only explicit pre-mutation validation failures, never duplicate or arbitrary API failure text.</summary>
    /// <param name="message">Private provider response used only for classification; never logged.</param>
    /// <returns>True for the narrowly supported validation responses; all unrecognized errors stay ambiguous.</returns>
    /// <remarks>Transport status alone, absence, timeout and elapsed time are never proof of rejection.</remarks>
    internal static bool IsDefinitiveCreationRejection(string message) => message != null && new[] { "empty payload", "client email is required", "at least one inbound is required" }
            .Any(validation => message.Trim().Equals(validation, StringComparison.Ordinal)
                || message.Trim().EndsWith(": " + validation, StringComparison.Ordinal));

    /// <summary>Verifies recovered identity without treating an unrelated same-email client as this creation.</summary>
    /// <param name="reserved">Required private identity persisted before POST.</param>
    /// <param name="found">Nullable panel read-back; credentials must not be displayed or logged.</param>
    /// <returns>True only for exact email, subscription identity and Telegram owner matches; a reserved UUID must also match.</returns>
    /// <remarks>Missing or conflicting identity leaves the reservation unresolved; no replacement POST is allowed.</remarks>
    internal static bool MatchesReservedCreation(XuiV3ClientPayload reserved, XuiV3Client found) => found != null
        && !string.IsNullOrWhiteSpace(reserved.Email) && !string.IsNullOrWhiteSpace(reserved.SubId)
        && string.Equals(reserved.Email, found.Email, StringComparison.Ordinal)
        && (string.IsNullOrWhiteSpace(reserved.Uuid) || string.Equals(reserved.Uuid, found.Uuid, StringComparison.Ordinal))
        && reserved.TgId == found.TgId
        && string.Equals(reserved.SubId, found.SubId, StringComparison.Ordinal);

    /// <summary>POST /login. Cookie-based UI login. Bearer-token callers do not need this method.</summary>
    public static Task<XuiV3ApiResponse<JToken>> LoginAsync(
        ServerInfo serverInfo,
        string twoFactorCode = null,
        CancellationToken cancellationToken = default)
    {
        var body = new
        {
            username = serverInfo.Username,
            password = serverInfo.Password,
            twoFactorCode
        };

        return SendAsync<JToken>(serverInfo, null, HttpMethod.Post, "/login", body, false, cancellationToken);
    }

    /// <summary>POST /logout. Clears a cookie session. API-token callers normally do not need this.</summary>
    public static Task<XuiV3ApiResponse<JToken>> LogoutAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        return SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/logout", null, true, cancellationToken);
    }

    /// <summary>GET /csrf-token. Browser session helper. Bearer-token API calls skip CSRF.</summary>
    public static async Task<string> GetCsrfTokenAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        var response = await SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/csrf-token", null, true, cancellationToken);
        return response.Obj?.Type == JTokenType.String ? response.Obj.Value<string>() : response.Obj?.ToString();
    }

    /// <summary>POST /getTwoFactorEnable. Checks whether OTP is required for cookie login.</summary>
    public static async Task<bool> GetTwoFactorEnabledAsync(
        ServerInfo serverInfo,
        IConfiguration configuration = null,
        CancellationToken cancellationToken = default)
    {
        var response = await SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/getTwoFactorEnable", null, false, cancellationToken);
        return response.Obj?.Value<bool>() == true;
    }

    /// <summary>GET /panel/api/inbounds/list. Lists full inbounds with settings, streamSettings, sniffing and clientStats.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3Inbound>>> GetInboundsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3Inbound>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/inbounds/list", null, true, cancellationToken);

    /// <summary>GET /panel/api/inbounds/list/slim. Lists inbounds with smaller client payloads for picker/list screens.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3Inbound>>> GetInboundsSlimAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3Inbound>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/inbounds/list/slim", null, true, cancellationToken);

    /// <summary>GET /panel/api/inbounds/options. Lightweight inbound options for dropdowns and attach pickers.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3InboundOption>>> GetInboundOptionsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3InboundOption>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/inbounds/options", null, true, cancellationToken);

    /// <summary>GET /panel/api/inbounds/get/{id}. Gets a single inbound by numeric ID.</summary>
    public static Task<XuiV3ApiResponse<XuiV3Inbound>> GetInboundAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<XuiV3Inbound>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/inbounds/get/{id}", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/inbounds/add. Creates an inbound. Body can include nested JSON settings and streamSettings.
    /// </summary>
    /// <remarks>
    /// Creating an inbound is a non-idempotent mutation, so transient failures are not automatically replayed; the
    /// request is sent exactly once with <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> AddInboundAsync(ServerInfo serverInfo, IConfiguration configuration, XuiV3Inbound inbound, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/inbounds/add", inbound, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/api/inbounds/del/{id}. Deletes an inbound and its client stats rows.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteInboundAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/del/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/bulkDel. Deletes many inbounds in one call.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkDeleteInboundsAsync(ServerInfo serverInfo, IConfiguration configuration, IEnumerable<int> ids, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/inbounds/bulkDel", new { ids = ids?.ToList() ?? new List<int>() }, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/inbounds/import. Imports an inbound JSON blob exported from a panel.
    /// </summary>
    /// <remarks>
    /// Importing an inbound creates panel state and is non-idempotent, so the request is sent exactly once with
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> ImportInboundAsync(ServerInfo serverInfo, IConfiguration configuration, object importPayload, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/inbounds/import", importPayload, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/api/inbounds/update/{id}. Replaces an inbound configuration.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateInboundAsync(ServerInfo serverInfo, IConfiguration configuration, int id, XuiV3Inbound inbound, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/update/{id}", inbound, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/setEnable/{id}. Toggles only the inbound enable flag.</summary>
    public static Task<XuiV3ApiResponse<JToken>> SetInboundEnabledAsync(ServerInfo serverInfo, IConfiguration configuration, int id, bool enable, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/setEnable/{id}", new { enable }, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/{id}/resetTraffic. Resets traffic counters for one inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ResetInboundTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/{id}/resetTraffic", null, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/resetAllTraffics. Resets traffic counters for every inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ResetAllInboundTrafficsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/inbounds/resetAllTraffics", null, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/{id}/delAllClients. Removes all clients from one inbound but keeps the inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteAllInboundClientsAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/{id}/delAllClients", null, true, cancellationToken);

    /// <summary>GET /panel/api/inbounds/{id}/fallbacks. Lists fallback rules for a master inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetInboundFallbacksAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/inbounds/{id}/fallbacks", null, true, cancellationToken);

    /// <summary>POST /panel/api/inbounds/{id}/fallbacks. Replaces all fallback rules for a master inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ReplaceInboundFallbacksAsync(ServerInfo serverInfo, IConfiguration configuration, int id, object fallbacks, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/inbounds/{id}/fallbacks", fallbacks, true, cancellationToken);

    /// <summary>GET /panel/api/clients/list. Lists every client with inbound IDs and traffic data.</summary>
    /// <param name="serverInfo">Panel descriptor supplying base URL, root path, and bearer token.</param>
    /// <param name="configuration">Runtime timeout, retry, and foreground-budget configuration.</param>
    /// <param name="cancellationToken">Token that cancels the read; cancelled reads never retry.</param>
    /// <param name="executionPolicy">
    /// Execution boundary for this call. Pass <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> for any
    /// user-facing interactive read (account lists, search, detail reloads, renewal target discovery) so the whole
    /// logical request is bounded by one overall wall-clock budget. The default keeps the provider-oriented timeout
    /// and transient retry budget for background/recovery readers.
    /// </param>
    /// <returns>The panel response envelope as a client list; callers must check <c>Success</c>.</returns>
    /// <remarks>
    /// <see cref="XuiV3ForegroundReadTimeoutException"/> is thrown when a foreground read exceeds its overall budget;
    /// no further retry is started and the handler must release the Telegram lane.
    /// </remarks>
    public static Task<XuiV3ApiResponse<List<XuiV3Client>>> GetClientsAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        CancellationToken cancellationToken = default,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
        => SendAsync<List<XuiV3Client>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/clients/list", null, true, cancellationToken, executionPolicy: executionPolicy);

    /// <summary>GET /panel/api/clients/list/paged. Server-side filtering, sorting and paging for clients.</summary>
    /// <param name="serverInfo">Panel descriptor supplying base URL, root path, and bearer token.</param>
    /// <param name="configuration">Runtime timeout, retry, and foreground-budget configuration.</param>
    /// <param name="query">Paging, search, filter, protocol, sort, and order options.</param>
    /// <param name="cancellationToken">Token that cancels the read; cancelled reads never retry.</param>
    /// <param name="executionPolicy">
    /// Execution boundary; pass <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> for interactive reads so the
    /// whole logical request is bounded by one overall wall-clock budget.
    /// </param>
    /// <returns>The paged panel response envelope; callers must check <c>Success</c>.</returns>
    public static Task<XuiV3ApiResponse<JToken>> GetClientsPagedAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        XuiV3ClientPageQuery query,
        CancellationToken cancellationToken = default,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        var queryValues = new Dictionary<string, string>
        {
            ["page"] = query?.Page.ToString() ?? "1",
            ["pageSize"] = query?.PageSize.ToString() ?? "25",
            ["search"] = query?.Search ?? "",
            ["filter"] = query?.Filter ?? "",
            ["protocol"] = query?.Protocol ?? "",
            ["sort"] = query?.Sort ?? "",
            ["order"] = query?.Order ?? ""
        };

        return SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/clients/list/paged", null, true, cancellationToken, queryValues, executionPolicy: executionPolicy);
    }

    /// <summary>
    /// Fetches one current XUI client detail row by its exact panel email.
    /// </summary>
    /// <param name="serverInfo">
    /// Authenticated XUI v3 panel descriptor. Its URL and token must remain in trusted server-side memory.
    /// </param>
    /// <param name="configuration">Runtime timeout, authentication, and read-only retry configuration.</param>
    /// <param name="email">
    /// Exact client email obtained from an already authorized or complete-list panel row. It is escaped as one URL
    /// segment and must not be accepted directly from an unverified callback or written to operational logs.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the authenticated detail request and permitted retry delay.</param>
    /// <param name="suppressIdentifierBearingRetryLogs">
    /// <c>true</c> to issue one GET attempt without shared retry diagnostics because the URI contains a private email;
    /// <c>false</c> to retain the existing bounded read-only retries for established callers.
    /// </param>
    /// <returns>
    /// The panel response envelope containing the current client, or an unsuccessful envelope that callers must
    /// classify. The returned UUID, SubId, comment, and extension fields are sensitive and must not be logged.
    /// </returns>
    /// <remarks>
    /// Calls <c>GET /panel/api/clients/get/{email}</c> and never mutates panel state. Reminder enrichment passes
    /// <paramref name="suppressIdentifierBearingRetryLogs"/> as <c>true</c>; all existing callers keep their prior
    /// retry behavior through the default value.
    /// </remarks>
    /// <example>
    /// <code>
    /// var response = await ApiServicev3.GetClientAsync(
    ///     serverInfo,
    ///     configuration,
    ///     authorizedClient.Email,
    ///     cancellationToken,
    ///     suppressIdentifierBearingRetryLogs: true);
    /// </code>
    /// </example>
    /// <exception cref="XuiV3ApiException">Thrown when the panel returns an unsuccessful HTTP status.</exception>
    /// <exception cref="OperationCanceledException">Thrown when <paramref name="cancellationToken"/> is cancelled.</exception>
    public static async Task<XuiV3ApiResponse<XuiV3Client>> GetClientAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        CancellationToken cancellationToken = default,
        bool suppressIdentifierBearingRetryLogs = false)
    {
        var response = await SendAsync<JToken>(
            serverInfo,
            configuration,
            HttpMethod.Get,
            $"/panel/api/clients/get/{EscapePath(email)}",
            null,
            true,
            cancellationToken,
            retryMode: suppressIdentifierBearingRetryLogs
                ? XuiV3RequestRetryMode.NoAutomaticRetry
                : XuiV3RequestRetryMode.ReadOnly);

        return NormalizeClientDetailResponse(response);
    }

    /// <summary>
    /// Normalizes direct and nested 3x-ui client-detail envelopes into one detached client snapshot.
    /// </summary>
    /// <param name="response">
    /// Authenticated response returned by <c>GET /panel/api/clients/get/{email}</c>. Its object may be either the
    /// client itself or a wrapper containing <c>client</c> plus top-level <c>inboundIds</c>. The response can contain
    /// UUID, SubId, comment, and other private account data and must never be logged or exposed directly.
    /// </param>
    /// <returns>
    /// A new response envelope whose object is the normalized client. An unsuccessful panel envelope stays
    /// unsuccessful. A successful but malformed payload becomes an unsuccessful, identifier-free result with no
    /// client so callers fail closed instead of comparing an empty object with an authorized list row.
    /// </returns>
    /// <remarks>
    /// Current 3x-ui releases return <c>obj.client</c> and keep inbound membership in <c>obj.inboundIds</c>, while
    /// older compatible deployments may return the client directly in <c>obj</c>. This method performs no HTTP call,
    /// panel mutation, persistence, wallet operation, tenant operation, or logging. Numeric id, email, UUID, and SubId
    /// are not synthesized; downstream identity checks remain authoritative.
    /// </remarks>
    /// <example>
    /// <code>
    /// var normalized = NormalizeClientDetailResponse(rawResponse);
    /// if (normalized.Success)
    ///     use(normalized.Obj);
    /// </code>
    /// </example>
    internal static XuiV3ApiResponse<XuiV3Client> NormalizeClientDetailResponse(
        XuiV3ApiResponse<JToken> response)
    {
        if (response?.Success != true)
        {
            return new XuiV3ApiResponse<XuiV3Client>
            {
                Success = false,
                Msg = response?.Msg
            };
        }

        var payload = response.Obj;
        XuiV3Client client = null;
        try
        {
            if (payload is JObject wrapper &&
                wrapper.GetValue("client", StringComparison.OrdinalIgnoreCase) is JObject nestedClient)
            {
                client = nestedClient.ToObject<XuiV3Client>();
                if (client != null &&
                    wrapper.GetValue("inboundIds", StringComparison.OrdinalIgnoreCase) is JArray inboundIds)
                {
                    client.InboundIds = inboundIds
                        .Values<int>()
                        .Where(id => id > 0)
                        .Distinct()
                        .ToList();
                }

                if (client != null &&
                    client.Traffic == null &&
                    wrapper.GetValue("traffic", StringComparison.OrdinalIgnoreCase) is JObject traffic)
                {
                    client.Traffic = traffic.ToObject<XuiV3ClientTraffic>();
                }
            }
            else if (payload != null && payload.Type is not JTokenType.Null and not JTokenType.Undefined)
            {
                client = payload.ToObject<XuiV3Client>();
            }
        }
        catch (Exception ex) when (ex is JsonException or InvalidOperationException or ArgumentException or FormatException or OverflowException)
        {
            // Parsing failures are intentionally collapsed into the identifier-free malformed result below. Raw panel
            // payloads and embedded client credentials must never appear in operational or Telegram logs.
            client = null;
        }

        if (client == null || string.IsNullOrWhiteSpace(client.Email))
        {
            return new XuiV3ApiResponse<XuiV3Client>
            {
                Success = false,
                Msg = "Client detail response did not contain a client identity."
            };
        }

        return new XuiV3ApiResponse<XuiV3Client>
        {
            Success = true,
            Msg = response.Msg,
            Obj = client
        };
    }

    /// <summary>
    /// POST /panel/api/clients/add. Creates a client and attaches it to one or more inbounds.
    /// </summary>
    /// <param name="serverInfo">Target XUI v3 panel descriptor containing endpoint and authentication metadata.</param>
    /// <param name="configuration">Runtime timeout and retry configuration.</param>
    /// <param name="request">Client payload plus the inbound ids the client must be attached to.</param>
    /// <param name="cancellationToken">Token that cancels the panel request.</param>
    /// <returns>The panel add-client response envelope. A failed response must not be replayed by the caller.</returns>
    /// <remarks>
    /// This endpoint is a non-idempotent mutation: a timeout can hide a committed server-side creation, so the request
    /// is sent exactly once (<see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>). Ambiguous failures must be resolved
    /// by reading the panel back by email through the creation recovery path instead of re-sending the mutation, which
    /// would otherwise risk duplicate clients for one purchase.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> AddClientAsync(ServerInfo serverInfo, IConfiguration configuration, XuiV3ClientCreateRequest request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(
            serverInfo,
            configuration,
            HttpMethod.Post,
            "/panel/api/clients/add",
            request,
            true,
            cancellationToken,
            retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>
    /// POST /panel/api/clients/bulkCreate. Creates many clients in one request.
    /// </summary>
    /// <param name="serverInfo">Target XUI v3 panel descriptor containing endpoint and authentication metadata.</param>
    /// <param name="configuration">Runtime timeout and retry configuration.</param>
    /// <param name="requests">Client payloads that must each be created and attached to their inbound ids.</param>
    /// <param name="cancellationToken">Token that cancels the panel request.</param>
    /// <returns>The panel bulk-create response envelope. A failed response must not be replayed by the caller.</returns>
    /// <remarks>
    /// Bulk creation is a non-idempotent mutation with no provider idempotency key. It is sent exactly once
    /// (<see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>) so a timeout cannot hide a partially committed batch and
    /// be replayed into duplicate clients.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> BulkCreateClientsAsync(ServerInfo serverInfo, IConfiguration configuration, IEnumerable<XuiV3ClientCreateRequest> requests, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(
            serverInfo,
            configuration,
            HttpMethod.Post,
            "/panel/api/clients/bulkCreate",
            requests?.ToList() ?? new List<XuiV3ClientCreateRequest>(),
            true,
            cancellationToken,
            retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>
    /// Replaces an XUI v3 client row by email while normalizing legacy extension fields that newer panel versions
    /// validate more strictly.
    /// </summary>
    /// <param name="serverInfo">
    /// The configured XUI panel endpoint and authentication settings that own the client. The value must identify a
    /// reachable v3 panel and must not be written to user-facing messages or logs with its secrets.
    /// </param>
    /// <param name="configuration">
    /// Application configuration used to resolve the request timeout, retry policy, and v3 API token. It must be the
    /// active runtime configuration and is never serialized into the panel request.
    /// </param>
    /// <param name="email">
    /// The existing XUI client email used by the v3 API as the update path identifier. This is an account identifier,
    /// not a Telegram username; it must be non-empty and is URL-escaped before the external request.
    /// </param>
    /// <param name="client">
    /// The complete replacement payload assembled from the current panel client. Ownership, UUID, password, subId,
    /// traffic, expiry, and panel-specific fields must already be preserved by the caller. The payload is copied before
    /// transport so normalizing <c>allowedIPs</c> does not mutate the caller's tracked client object.
    /// </param>
    /// <param name="cancellationToken">
    /// A token that cancels the XUI HTTP request when the Telegram update or background operation is stopped.
    /// </param>
    /// <param name="retryMode">
    /// Retry semantics selected by the caller. Link identity changes must pass
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/> because a timeout can hide a committed update.
    /// </param>
    /// <returns>
    /// The panel response after the update attempt. A failed response means the panel rejected or could not process the
    /// update; callers must not assume a renewal, link change, or account-state update was persisted.
    /// </returns>
    /// <remarks>
    /// 3x-ui 3.4.x requires <c>client.allowedIPs</c> to be a JSON string array. Older panel responses can expose the
    /// same extension field as a string inside <see cref="XuiV3ClientPayload.Extra"/>. Renewals previously copied that
    /// raw value back to the panel, causing Go to reject it with an unmarshalling error. This shared boundary converts
    /// only that legacy field to an array, so every update path receives the fix without dropping unrelated panel data.
    /// </remarks>
    /// <example>
    /// <code>
    /// var response = await ApiServicev3.UpdateClientAsync(
    ///     serverInfo,
    ///     configuration,
    ///     client.Email,
    ///     renewal.Payload,
    ///     cancellationToken);
    /// </code>
    /// </example>
    public static Task<XuiV3ApiResponse<JToken>> UpdateClientAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        XuiV3ClientPayload client,
        CancellationToken cancellationToken = default,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.IdempotentMutation)
        => SendAsync<JToken>(
            serverInfo,
            configuration,
            HttpMethod.Post,
            $"/panel/api/clients/update/{EscapePath(email)}",
            PrepareClientUpdatePayload(client),
            true,
            cancellationToken,
            retryMode: retryMode);

    /// <summary>
    /// Creates an isolated v3 update payload using the request contract expected by 3x-ui 3.4.x and normalizes a
    /// legacy <c>allowedIPs</c> extension value into the required JSON string-array shape.
    /// </summary>
    /// <param name="client">
    /// The source client payload built from an XUI panel response. It may contain arbitrary panel extension data;
    /// a null value is allowed only to preserve the prior API behavior of sending a null request body.
    /// </param>
    /// <returns>
    /// A detached JSON object suitable for the update endpoint, or null when <paramref name="client"/> is null.
    /// The UUID is emitted as <c>id</c>, while response-only aliases such as <c>uuid</c> are omitted. The source payload
    /// and its extension-data dictionary remain unchanged.
    /// </returns>
    /// <remarks>
    /// The global clients read API returns a database record whose protocol UUID is named <c>uuid</c>, but the update
    /// controller binds the request to 3x-ui's wire client model where that same protocol UUID is named <c>id</c>.
    /// Sending <c>uuid</c> therefore causes 3x-ui 3.4.x to preserve the old credential. This boundary deliberately
    /// separates those two contracts. The copy also retains password, auth/security extension fields, Telegram id,
    /// subId, flow, group, reverse, and access-control data so updates do not erase unrelated account settings.
    /// </remarks>
    /// <example>
    /// <code>
    /// var requestBody = PrepareClientUpdatePayload(client);
    /// // requestBody["id"] contains the protocol UUID; requestBody has no "uuid" property.
    /// </code>
    /// </example>
    private static JObject PrepareClientUpdatePayload(XuiV3ClientPayload client)
    {
        if (client == null)
            return null;

        var extra = client.Extra == null
            ? null
            : client.Extra.ToDictionary(
                pair => pair.Key,
                pair => pair.Value?.DeepClone(),
                StringComparer.Ordinal);

        NormalizeAllowedIpsExtension(extra);

        // `id` is the protocol UUID in model.Client request bodies. It is not the numeric ClientRecord id returned
        // by GET /clients/get and /clients/list. Remove stale response aliases before adding the credential value.
        RemoveExtensionKey(extra, "id");
        RemoveExtensionKey(extra, "uuid");

        var detached = new XuiV3ClientPayload
        {
            Email = client.Email,
            Password = client.Password,
            TotalGB = client.TotalGB,
            ExpiryTime = client.ExpiryTime,
            TgId = client.TgId,
            LimitIp = client.LimitIp,
            Enable = client.Enable,
            SubId = client.SubId,
            Flow = client.Flow,
            Comment = client.Comment,
            Group = client.Group,
            Reverse = client.Reverse?.DeepClone(),
            Extra = extra
        };

        var requestBody = JObject.FromObject(detached, JsonSerializer.Create(JsonSettings));
        requestBody.Remove("uuid");
        if (!string.IsNullOrWhiteSpace(client.Uuid))
            requestBody["id"] = client.Uuid.Trim();
        return requestBody;
    }

    /// <summary>
    /// Removes every extension-data entry whose name matches a typed or transport-only JSON property.
    /// </summary>
    /// <param name="extra">
    /// Detached extension data copied from a panel response. Null is allowed and results in no operation.
    /// </param>
    /// <param name="key">
    /// Case-insensitive JSON property name to remove. The value must be a known typed or response-only field and must
    /// never be derived from untrusted user text.
    /// </param>
    /// <remarks>
    /// Json.NET extension data can otherwise emit duplicate identity properties. For client updates this is especially
    /// dangerous because response <c>id</c> is numeric while request <c>id</c> is the protocol UUID.
    /// </remarks>
    private static void RemoveExtensionKey(IDictionary<string, JToken> extra, string key)
    {
        if (extra == null || string.IsNullOrWhiteSpace(key))
            return;

        foreach (var matchingKey in extra.Keys
                     .Where(candidate => string.Equals(candidate, key, StringComparison.OrdinalIgnoreCase))
                     .ToList())
        {
            extra.Remove(matchingKey);
        }
    }

    /// <summary>
    /// Normalizes the optional XUI <c>allowedIPs</c> extension in a detached payload dictionary.
    /// </summary>
    /// <param name="extra">
    /// Detached extension data copied from an XUI client payload. The dictionary may be null or may contain arbitrary
    /// keys returned by different 3x-ui versions. This method only changes keys whose name equals
    /// <c>allowedIPs</c> without regard to casing.
    /// </param>
    /// <remarks>
    /// Current 3x-ui parses <c>allowedIPs</c> as <c>[]string</c>. A previous panel may return a comma-separated string
    /// or a JSON-array string, so this method removes every casing variant and writes one canonical JSON array. Keeping
    /// the conversion at the outgoing API boundary avoids changing the historical panel object held by renewal logic.
    /// </remarks>
    private static void NormalizeAllowedIpsExtension(IDictionary<string, JToken> extra)
    {
        if (extra == null)
            return;

        var matchingKeys = extra.Keys
            .Where(key => string.Equals(key, "allowedIPs", StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (matchingKeys.Count == 0)
            return;

        var source = matchingKeys
            .Select(key => extra[key])
            .FirstOrDefault(token => token != null && token.Type != JTokenType.Null);

        foreach (var key in matchingKeys)
            extra.Remove(key);

        // 3x-ui 3.4.x unmarshals this field into Go []string, so a legacy raw string must never be forwarded.
        extra["allowedIPs"] = new JArray(ReadAllowedIpValues(source));
    }

    /// <summary>
    /// Extracts individual IP or CIDR entries from an XUI extension token without validating the network syntax.
    /// </summary>
    /// <param name="source">
    /// The raw <c>allowedIPs</c> token returned by a panel. It may be a JSON array, a JSON-array string, a
    /// comma/newline/semicolon-separated string, or null when the legacy field was empty.
    /// </param>
    /// <returns>
    /// Distinct non-empty textual entries in their original order. The collection can be empty, which serializes as
    /// an empty JSON array and means the panel receives no explicit IP restrictions from this field.
    /// </returns>
    /// <remarks>
    /// This helper deliberately preserves values rather than attempting to decide whether they are valid IPv4, IPv6,
    /// or CIDR expressions. The panel remains the authority for semantic validation; the bot only fixes the JSON type
    /// mismatch that otherwise rejects renewals before panel validation can run.
    /// </remarks>
    private static IReadOnlyList<string> ReadAllowedIpValues(JToken source)
    {
        if (source == null || source.Type == JTokenType.Null)
            return Array.Empty<string>();

        IEnumerable<string> values;
        if (source is JArray array)
        {
            values = array
                .Where(item => item != null && item.Type != JTokenType.Null)
                .Select(item => item.ToString().Trim());
        }
        else
        {
            var raw = source.ToString().Trim();
            if (raw.StartsWith("[", StringComparison.Ordinal))
            {
                try
                {
                    var parsed = JArray.Parse(raw);
                    values = parsed
                        .Where(item => item != null && item.Type != JTokenType.Null)
                        .Select(item => item.ToString().Trim());
                }
                catch (JsonReaderException)
                {
                    values = SplitAllowedIpValues(raw);
                }
            }
            else
            {
                values = SplitAllowedIpValues(raw);
            }
        }

        return values
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Distinct(StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>
    /// Splits a legacy textual allowed-IP value into its individual entries.
    /// </summary>
    /// <param name="raw">
    /// The raw string returned by an older panel response. It may contain comma, semicolon, carriage-return, or
    /// newline separators and may be empty.
    /// </param>
    /// <returns>
    /// Candidate IP or CIDR entries with surrounding whitespace removed. The result can be empty.
    /// </returns>
    /// <remarks>
    /// This method is used only after a JSON-array parse was not applicable. It keeps the normalizer compatible with
    /// legacy panel values such as <c>1.2.3.4, 5.6.7.8</c> without changing their contents.
    /// </remarks>
    private static IEnumerable<string> SplitAllowedIpValues(string raw)
        => (raw ?? string.Empty).Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(value => value.Trim());

    /// <summary>Fetches a client, changes its enable flag, then updates it through the v3 API.</summary>
    public static Task<XuiV3ApiResponse<JToken>> SetClientEnabledAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        bool enable,
        CancellationToken cancellationToken = default)
        => SetClientEnabledAsync(serverInfo, configuration, email, enable, null, cancellationToken);

    /// <summary>Fetches a client, changes only its enable flag, and preserves ownership and other client fields.</summary>
    public static async Task<XuiV3ApiResponse<JToken>> SetClientEnabledAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        bool enable,
        long? expectedOwnerTelegramUserId,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            return new XuiV3ApiResponse<JToken>
            {
                Success = false,
                Msg = "Client email is required."
            };
        }

        email = email.Trim();
        var clientResponse = await GetClientAsync(serverInfo, configuration, email, cancellationToken);
        if (!clientResponse.Success || clientResponse.Obj == null)
        {
            return new XuiV3ApiResponse<JToken>
            {
                Success = false,
                Msg = clientResponse.Msg ?? "Client was not found."
            };
        }

        var client = clientResponse.Obj;
        XuiV3Client listClient = null;
        var clientsResponse = await GetClientsAsync(serverInfo, configuration, cancellationToken);
        if (clientsResponse.Success && clientsResponse.Obj != null)
        {
            listClient = clientsResponse.Obj.FirstOrDefault(item =>
                EmailEquals(item.Email, email) ||
                (client.Id > 0 && item.Id == client.Id));
        }

        var source = listClient ?? client;
        var resolvedEmail = FirstNonWhiteSpace(client.Email, source.Email, email).Trim();
        var resolvedSubId = FirstNonWhiteSpace(client.SubId, source.SubId, resolvedEmail).Trim();
        var resolvedTgId = ResolveClientTelegramUserId(client, listClient, expectedOwnerTelegramUserId);

        var updatePayload = new XuiV3ClientPayload
        {
            Email = resolvedEmail,
            TotalGB = source.TotalGB,
            ExpiryTime = source.ExpiryTime,
            TgId = resolvedTgId,
            LimitIp = source.LimitIp,
            Enable = enable,
            SubId = resolvedSubId,
            Flow = FirstNonWhiteSpace(client.Flow, source.Flow),
            Comment = FirstNonWhiteSpace(client.Comment, source.Comment),
            Group = FirstNonWhiteSpace(client.Group, source.Group),
            Reverse = client.Reverse ?? source.Reverse,
            Uuid = FirstNonWhiteSpace(client.Uuid, source.Uuid),
            Password = FirstNonWhiteSpace(client.Password, source.Password),
            Extra = client.Extra ?? source.Extra
        };

        return await UpdateClientAsync(serverInfo, configuration, email, updatePayload, cancellationToken);
    }

    private static long ResolveClientTelegramUserId(
        XuiV3Client primaryClient,
        XuiV3Client listClient,
        long? expectedOwnerTelegramUserId)
    {
        if (primaryClient?.TgId > 0)
            return primaryClient.TgId;

        if (listClient?.TgId > 0)
            return listClient.TgId;

        var metadata = TryReadClientMetadata(primaryClient?.Comment) ??
                       TryReadClientMetadata(listClient?.Comment);
        if (metadata?.TelegramUserId > 0)
            return metadata.TelegramUserId;

        return expectedOwnerTelegramUserId.GetValueOrDefault();
    }

    private static XuiV3ClientMetadata TryReadClientMetadata(string comment)
    {
        if (string.IsNullOrWhiteSpace(comment))
            return null;

        try
        {
            return JsonConvert.DeserializeObject<XuiV3ClientMetadata>(comment);
        }
        catch
        {
            return null;
        }
    }

    private static string FirstNonWhiteSpace(params string[] values)
    {
        foreach (var value in values)
        {
            if (!string.IsNullOrWhiteSpace(value))
                return value;
        }

        return null;
    }

    private static bool EmailEquals(string left, string right)
    {
        return string.Equals(
            (left ?? string.Empty).Trim(),
            (right ?? string.Empty).Trim(),
            StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>POST /panel/api/clients/del/{email}. Deletes one client from every attached inbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteClientAsync(ServerInfo serverInfo, IConfiguration configuration, string email, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/del/{EscapePath(email)}", null, true, cancellationToken);

    /// <summary>
    /// Deletes a detached XUI client record while preserving traffic rows that may still be needed by a renamed client.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel that owns the client record.</param>
    /// <param name="configuration">Runtime authentication, timeout, and retry configuration.</param>
    /// <param name="email">
    /// Exact old XUI email of the detached orphan. The caller must first prove that this email belongs to a different
    /// numeric client record and has no attached inbound.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the external HTTP request.</param>
    /// <param name="retryMode">
    /// Replay policy for the delete. Durable link-change recovery passes <c>NoAutomaticRetry</c> and verifies absence
    /// with a read-back after any ambiguous transport result.
    /// </param>
    /// <returns>The panel response for the deletion attempt; callers must still verify that the old email is absent.</returns>
    /// <remarks>
    /// The <c>keepTraffic=1</c> query is essential during identity replacement. It removes only the stale client record
    /// and leaves historical counters intact until the renamed client has been fully verified.
    /// </remarks>
    /// <example>
    /// <code>
    /// var response = await ApiServicev3.DeleteClientPreservingTrafficAsync(
    ///     serverInfo,
    ///     configuration,
    ///     oldEmail,
    ///     cancellationToken,
    ///     XuiV3RequestRetryMode.NoAutomaticRetry);
    /// </code>
    /// </example>
    public static Task<XuiV3ApiResponse<JToken>> DeleteClientPreservingTrafficAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        CancellationToken cancellationToken = default,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.NoAutomaticRetry)
        => SendAsync<JToken>(
            serverInfo,
            configuration,
            HttpMethod.Post,
            $"/panel/api/clients/del/{EscapePath(email)}",
            null,
            true,
            cancellationToken,
            query: new Dictionary<string, string> { ["keepTraffic"] = "1" },
            retryMode: retryMode);

    /// <summary>POST /panel/api/clients/bulkDel. Deletes many clients by email.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkDeleteClientsAsync(ServerInfo serverInfo, IConfiguration configuration, IEnumerable<string> emails, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/bulkDel", new { emails = emails?.ToList() ?? new List<string>() }, true, cancellationToken);

    /// <summary>Attaches an existing XUI client to selected inbound ids.</summary>
    /// <param name="serverInfo">Panel that owns the client.</param>
    /// <param name="configuration">Runtime timeout, authentication, and retry configuration.</param>
    /// <param name="email">Current XUI client email used as the endpoint identifier.</param>
    /// <param name="inboundIds">Positive panel inbound ids to attach; an empty sequence performs no useful change.</param>
    /// <param name="cancellationToken">Token that cancels the external request.</param>
    /// <param name="retryMode">Replay policy; durable link-change recovery passes <c>NoAutomaticRetry</c>.</param>
    /// <returns>The panel response; callers must read back membership after an ambiguous response.</returns>
    public static Task<XuiV3ApiResponse<JToken>> AttachClientAsync(ServerInfo serverInfo, IConfiguration configuration, string email, IEnumerable<int> inboundIds, CancellationToken cancellationToken = default, XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.IdempotentMutation)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/{EscapePath(email)}/attach", new { inboundIds = inboundIds?.ToList() ?? new List<int>() }, true, cancellationToken, retryMode: retryMode);

    /// <summary>Detaches an XUI client from selected inbounds without deleting the client.</summary>
    /// <param name="serverInfo">Panel that owns the client.</param>
    /// <param name="configuration">Runtime timeout, authentication, and retry configuration.</param>
    /// <param name="email">Current XUI client email used as the endpoint identifier.</param>
    /// <param name="inboundIds">Positive panel inbound ids to detach.</param>
    /// <param name="cancellationToken">Token that cancels the external request.</param>
    /// <param name="retryMode">Replay policy; durable link-change recovery passes <c>NoAutomaticRetry</c>.</param>
    /// <returns>The panel response; callers must read back membership after an ambiguous response.</returns>
    public static Task<XuiV3ApiResponse<JToken>> DetachClientAsync(ServerInfo serverInfo, IConfiguration configuration, string email, IEnumerable<int> inboundIds, CancellationToken cancellationToken = default, XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.IdempotentMutation)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/{EscapePath(email)}/detach", new { inboundIds = inboundIds?.ToList() ?? new List<int>() }, true, cancellationToken, retryMode: retryMode);

    /// <summary>POST /panel/api/clients/bulkAttach. Attaches many existing clients to many inbounds.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkAttachClientsAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/bulkAttach", request, true, cancellationToken);

    /// <summary>POST /panel/api/clients/bulkDetach. Detaches many clients from many inbounds.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkDetachClientsAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/bulkDetach", request, true, cancellationToken);

    /// <summary>POST /panel/api/clients/bulkAdjust. Shifts expiry and/or quota for many clients.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkAdjustClientsAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/bulkAdjust", request, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/clients/resetTraffic/{email}. Authoritatively resets every usage source for one client.
    /// </summary>
    /// <param name="serverInfo">Panel that owns the client record, its inbounds, and its traffic rows.</param>
    /// <param name="configuration">Runtime timeout, authentication, and retry configuration.</param>
    /// <param name="email">
    /// Stable XUI client email. The panel resolves the owning <c>ClientRecord</c> by this value and fails when no record
    /// exists, so a detached email cannot be reset.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the external request.</param>
    /// <returns>
    /// The panel response. A success means the panel already disabled-and-re-enabled bookkeeping; callers must still
    /// read the client back before treating any derived state as settled.
    /// </returns>
    /// <remarks>
    /// Proved against upstream 3x-ui v3.7.0 and v3.4.2 source. <c>ClientService.ResetTrafficByEmail</c>:
    /// <list type="number">
    /// <item>loads the client record and resolves every inbound the client is attached to;</item>
    /// <item><b>auto-enables a disabled client</b> by writing <c>enable = true</c> through the normal update path, logging
    /// and continuing when that write fails;</item>
    /// <item>then calls <c>InboundService.ResetClientTraffic</c> per inbound (or <c>ResetClientTrafficByEmail</c> when the
    /// client has no inbound), which zeroes <c>client_traffics.up/down</c>, forces <c>enable = true</c>, deletes every
    /// master-pushed <c>client_global_traffics</c> row, deletes every <c>node_client_traffics</c> row, bumps the inbound's
    /// <c>last_traffic_reset_time</c>, and marks remote nodes dirty.</item>
    /// </list>
    ///
    /// Two consequences are contractual and must never be assumed away:
    /// <list type="bullet">
    /// <item><b>The client is left enabled.</b> A caller that needs a disabled client must disable it again afterwards and
    /// prove that state by read-back; it must not assume the reset preserved a disabled flag.</item>
    /// <item><b>This is the only operation that clears all usage sources.</b> <see cref="UpdateClientTrafficAsync"/> cannot
    /// substitute for it on a panel that receives master-pushed global traffic or hosts remote nodes, because those rows
    /// survive a counter write and are re-overlaid onto reads.</item>
    /// </list>
    /// The operation is value-idempotent: replaying it after an ambiguous response converges on the same zeroed, enabled
    /// state and cannot double-count usage.
    /// </remarks>
    /// <example>
    /// <code>
    /// var reset = await ApiServicev3.ResetClientTrafficAsync(serverInfo, configuration, email, cancellationToken);
    /// if (!reset.Success)
    ///     return; // no Telegram request was made by this call; safe to retry later
    ///
    /// var traffic = await ApiServicev3.GetClientTrafficAsync(serverInfo, configuration, email, cancellationToken);
    /// // Up == 0 and Down == 0 prove counters were cleared; the client is enabled by contract.
    /// </code>
    /// </example>
    public static Task<XuiV3ApiResponse<JToken>> ResetClientTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, string email, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/resetTraffic/{EscapePath(email)}", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/bulkResetTraffic. Resets traffic for many clients.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkResetClientTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, IEnumerable<string> emails, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/bulkResetTraffic", new { emails = emails?.ToList() ?? new List<string>() }, true, cancellationToken);

    /// <summary>POST /panel/api/clients/resetAllTraffics. Resets all client traffic counters globally.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ResetAllClientTrafficsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/resetAllTraffics", null, true, cancellationToken);

    /// <summary>Writes absolute upload and download counters for one XUI client.</summary>
    /// <param name="serverInfo">Panel that owns the client and traffic row.</param>
    /// <param name="configuration">Runtime timeout, authentication, and retry configuration.</param>
    /// <param name="email">
    /// Current XUI client email used by the traffic endpoint. The email is the client's stable identity in the panel and
    /// is the key of the single shared <c>client_traffics</c> row, not a per-inbound row.
    /// </param>
    /// <param name="up">Absolute uploaded bytes to store; must be non-negative. This is a value, not a delta.</param>
    /// <param name="down">Absolute downloaded bytes to store; must be non-negative. This is a value, not a delta.</param>
    /// <param name="cancellationToken">Token that cancels the external request.</param>
    /// <param name="retryMode">Replay policy; link-change repair disables blind retries and verifies by read-back.</param>
    /// <returns>The panel response; a timeout is ambiguous and must not be interpreted as counters being reset.</returns>
    /// <remarks>
    /// Proved against upstream 3x-ui v3.7.0/v3.4.2 source. The handler
    /// (<c>ClientController.updateTrafficByEmail</c>) binds a JSON body of
    /// <c>{ "upload": &lt;int64&gt;, "download": &lt;int64&gt; }</c> and forwards it to
    /// <c>InboundService.UpdateClientTrafficByEmail</c>, which performs a single
    /// <c>UPDATE client_traffics SET up = ?, down = ? WHERE email = ?</c>.
    ///
    /// Because the panel binds only those two field names, a request that spelled them <c>up</c>/<c>down</c> would be
    /// accepted with HTTP 200 while both counters were written as zero. The wire body is therefore declared with
    /// explicit JSON property names so a future rename cannot silently reintroduce that silent data loss.
    ///
    /// This endpoint is deliberately narrow. It does NOT change the client's enable flag, does NOT delete
    /// master-pushed <c>client_global_traffics</c> rows, does NOT delete <c>node_client_traffics</c> rows, and does not
    /// touch the Xray runtime or any inbound settings. A read after writing zero can therefore still report the
    /// master-pushed overlay, because read paths raise <c>up</c>/<c>down</c> to the maximum of fresh global rows. Use
    /// <see cref="ResetClientTrafficAsync"/> when an authoritative reset of every usage source is required.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> UpdateClientTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, string email, long up, long down, CancellationToken cancellationToken = default, XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.IdempotentMutation)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/updateTraffic/{EscapePath(email)}", new XuiV3TrafficUpdateRequest { Upload = up, Download = down }, true, cancellationToken, retryMode: retryMode);

    /// <summary>POST /panel/api/clients/delDepleted. Deletes clients whose traffic quota is exhausted.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteDepletedClientsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/delDepleted", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/clearIps/{email}. Clears the recorded IP list for one client.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ClearClientIpsAsync(ServerInfo serverInfo, IConfiguration configuration, string email, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/clearIps/{EscapePath(email)}", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/ips/{email}. Lists source IPs for one client.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetClientIpsAsync(ServerInfo serverInfo, IConfiguration configuration, string email, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/clients/ips/{EscapePath(email)}", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/onlines. Lists currently online client emails.</summary>
    public static Task<XuiV3ApiResponse<List<string>>> GetOnlineClientsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<string>>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/onlines", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/onlinesByNode. Lists online emails grouped by reporting node.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetOnlineClientsByNodeAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/onlinesByNode", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/lastOnline. Returns email to last-seen unix timestamp map.</summary>
    public static Task<XuiV3ApiResponse<Dictionary<string, long>>> GetLastOnlineClientsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<Dictionary<string, long>>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/lastOnline", null, true, cancellationToken);

    /// <summary>POST /panel/api/clients/activeInbounds. Returns inbound tags that carried traffic recently.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetActiveInboundsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/activeInbounds", null, true, cancellationToken);

    /// <summary>GET /panel/api/clients/traffic/{email}. Gets traffic counters for one client.</summary>
    public static Task<XuiV3ApiResponse<XuiV3ClientTraffic>> GetClientTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, string email, CancellationToken cancellationToken = default)
        => SendAsync<XuiV3ClientTraffic>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/clients/traffic/{EscapePath(email)}", null, true, cancellationToken);

    /// <summary>
    /// Gets every protocol configuration URL for one client email across the inbounds attached by the XUI panel.
    /// </summary>
    /// <param name="serverInfo">
    /// Authenticated XUI v3 panel connection settings. The bearer token, private URL, and credentials must never be
    /// written to Telegram or customer-visible logs.
    /// </param>
    /// <param name="configuration">Runtime application configuration used for HTTP timeouts and read-only retries.</param>
    /// <param name="email">
    /// Exact panel client email/name obtained from a previously authorized client record. It is escaped as one URL
    /// path segment and must not be accepted directly from an unverified Telegram callback.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the authenticated panel request and bounded retries.</param>
    /// <param name="suppressIdentifierBearingRetryLogs">
    /// <c>true</c> to perform one attempt without the shared retry diagnostics because the path contains a private
    /// email; <c>false</c> to preserve the existing read-only retry behavior used by account-creation recovery.
    /// </param>
    /// <returns>
    /// A normalized response envelope whose object is an ordered list of raw VLESS, VMess, Trojan, Shadowsocks,
    /// Hysteria, or other supported protocol URLs. Both a raw JSON array and the standard panel envelope are accepted.
    /// The list may be null or empty when the client has no enabled inbound configuration. Callers must treat every
    /// returned URL as sensitive customer data.
    /// </returns>
    /// <remarks>
    /// Calls <c>GET /panel/api/clients/links/{email}</c>. This read-only endpoint is suitable as a fallback when a
    /// client's subscription id is unavailable or the subscription-link endpoint cannot produce configurations.
    /// Configuration-delivery callers must pass <c>suppressIdentifierBearingRetryLogs: true</c> and must not log the
    /// request URI, response body, email-to-link mapping, or returned URLs.
    /// </remarks>
    /// <example>
    /// <code>
    /// var response = await ApiServicev3.GetClientLinksAsync(
    ///     serverInfo,
    ///     configuration,
    ///     client.Email,
    ///     cancellationToken,
    ///     suppressIdentifierBearingRetryLogs: true);
    /// </code>
    /// </example>
    /// <exception cref="XuiV3ApiException">Thrown when the panel returns an unsuccessful HTTP status.</exception>
    /// <exception cref="InvalidDataException">Thrown when a successful response has an unsupported JSON shape.</exception>
    /// <exception cref="OperationCanceledException">Thrown when <paramref name="cancellationToken"/> is cancelled.</exception>
    public static Task<XuiV3ApiResponse<List<string>>> GetClientLinksAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string email,
        CancellationToken cancellationToken = default,
        bool suppressIdentifierBearingRetryLogs = false)
        => SendSensitiveStringListAsync(
            serverInfo,
            configuration,
            $"/panel/api/clients/links/{EscapePath(email)}",
            cancellationToken,
            suppressIdentifierBearingRetryLogs);

    /// <summary>
    /// Gets every protocol configuration URL represented by one XUI subscription id without base64 wrapping.
    /// </summary>
    /// <param name="serverInfo">
    /// Authenticated XUI v3 panel connection settings. The bearer token, private URL, and credentials must remain in
    /// trusted server-side memory and diagnostics only.
    /// </param>
    /// <param name="configuration">Runtime application configuration used for HTTP timeouts and read-only retries.</param>
    /// <param name="subId">
    /// Exact private subscription identifier loaded from an ownership-verified XUI client. It is escaped as one path
    /// segment and must never be placed in Telegram callback data or operational log properties.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the authenticated panel request and bounded retries.</param>
    /// <param name="suppressIdentifierBearingRetryLogs">
    /// <c>true</c> to perform one attempt without the shared retry diagnostics because the path contains private SubId;
    /// <c>false</c> to allow the normal read-only retry diagnostics.
    /// </param>
    /// <returns>
    /// A normalized response envelope whose object is an ordered list of protocol URLs matching the subscription.
    /// Both the documented raw JSON array and the standard panel envelope are accepted. The list may be null or empty
    /// when no enabled client/inbound contributes a configuration. Returned values are sensitive and may be exposed
    /// only to the verified account owner.
    /// </returns>
    /// <remarks>
    /// Calls <c>GET /panel/api/clients/subLinks/{subId}</c>. Callers should fall back to
    /// <see cref="GetClientLinksAsync"/> when SubId is missing, the endpoint fails, or the normalized list is empty.
    /// Configuration-delivery callers must pass <c>suppressIdentifierBearingRetryLogs: true</c> and must not log
    /// SubId, the request URI, panel response body, or any returned proxy URL.
    /// </remarks>
    /// <example>
    /// <code>
    /// var response = await ApiServicev3.GetClientSubLinksAsync(
    ///     serverInfo,
    ///     configuration,
    ///     client.SubId,
    ///     cancellationToken,
    ///     suppressIdentifierBearingRetryLogs: true);
    /// </code>
    /// </example>
    /// <exception cref="XuiV3ApiException">Thrown when the panel returns an unsuccessful HTTP status.</exception>
    /// <exception cref="InvalidDataException">Thrown when a successful response has an unsupported JSON shape.</exception>
    /// <exception cref="OperationCanceledException">Thrown when <paramref name="cancellationToken"/> is cancelled.</exception>
    public static Task<XuiV3ApiResponse<List<string>>> GetClientSubLinksAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string subId,
        CancellationToken cancellationToken = default,
        bool suppressIdentifierBearingRetryLogs = false)
        => SendSensitiveStringListAsync(
            serverInfo,
            configuration,
            $"/panel/api/clients/subLinks/{EscapePath(subId)}",
            cancellationToken,
            suppressIdentifierBearingRetryLogs);

    /// <summary>
    /// Sends a sensitive read-only string-list request and normalizes either a raw JSON array or panel envelope.
    /// </summary>
    /// <param name="serverInfo">Authenticated XUI v3 panel settings used only for the outgoing request.</param>
    /// <param name="configuration">Runtime timeout and retry configuration for the authenticated HTTP read.</param>
    /// <param name="relativePath">
    /// Fully escaped panel-relative path containing a private client email or SubId. It must never be logged or shown
    /// to a Telegram user.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the authenticated HTTP read.</param>
    /// <param name="suppressIdentifierBearingRetryLogs">
    /// Whether to disable automatic retries whose shared diagnostics would include <paramref name="relativePath"/>.
    /// </param>
    /// <returns>
    /// A normalized successful envelope for a raw JSON array, or the panel-provided envelope when the response uses
    /// the standard <c>success/msg/obj</c> shape. The returned URLs remain sensitive customer configuration data.
    /// </returns>
    /// <remarks>
    /// Configuration-delivery callers set <paramref name="suppressIdentifierBearingRetryLogs"/> to <c>true</c> because
    /// the shared retry pipeline writes request URIs to private diagnostics, while this path contains email/SubId.
    /// Existing account-creation callers retain read-only retries for backward compatibility.
    /// </remarks>
    /// <exception cref="InvalidDataException">
    /// Thrown when a successful HTTP response is neither a JSON string array nor a valid XUI response envelope.
    /// No response body or request path is included in the exception message.
    /// </exception>
    /// <exception cref="XuiV3ApiException">Thrown when the panel returns an unsuccessful HTTP status.</exception>
    /// <exception cref="OperationCanceledException">Thrown when <paramref name="cancellationToken"/> is cancelled.</exception>
    /// <example>
    /// <code>
    /// var response = await SendSensitiveStringListAsync(
    ///     serverInfo,
    ///     configuration,
    ///     escapedPrivatePath,
    ///     cancellationToken,
    ///     suppressIdentifierBearingRetryLogs: true);
    /// </code>
    /// </example>
    private static async Task<XuiV3ApiResponse<List<string>>> SendSensitiveStringListAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string relativePath,
        CancellationToken cancellationToken,
        bool suppressIdentifierBearingRetryLogs)
    {
        var raw = await SendRawAsync(
            serverInfo,
            configuration,
            HttpMethod.Get,
            relativePath,
            body: null,
            authenticate: true,
            cancellationToken: cancellationToken,
            query: null,
            retryMode: suppressIdentifierBearingRetryLogs
                ? XuiV3RequestRetryMode.NoAutomaticRetry
                : XuiV3RequestRetryMode.ReadOnly);

        return ParseSensitiveStringListResponse(raw);
    }

    /// <summary>
    /// Parses a successful sensitive string-list response without retaining its body in an exception message.
    /// </summary>
    /// <param name="raw">
    /// Raw UTF-8 JSON returned by the authenticated links or subLinks endpoint. It may be a direct string array or a
    /// standard XUI response envelope and must never be logged.
    /// </param>
    /// <returns>
    /// A normalized successful envelope for a raw array, or the deserialized provider envelope for object responses.
    /// URL order and casing are preserved for later owner-only delivery.
    /// </returns>
    /// <remarks>
    /// This parser does not trim or deduplicate URLs; presentation code owns that policy. Invalid data produces only a
    /// fixed diagnostic message so configuration content cannot leak through exception rendering.
    /// </remarks>
    /// <exception cref="InvalidDataException">
    /// Thrown when <paramref name="raw"/> is invalid JSON or uses an unsupported top-level shape.
    /// </exception>
    /// <example>
    /// <code>
    /// var response = ParseSensitiveStringListResponse("[\"vless://sample\"]");
    /// </code>
    /// </example>
    private static XuiV3ApiResponse<List<string>> ParseSensitiveStringListResponse(string raw)
    {
        JToken token;
        try
        {
            token = JToken.Parse(raw);
        }
        catch (JsonException ex)
        {
            throw new InvalidDataException("XUI v3 string-list response was not valid JSON.", ex);
        }

        if (token.Type == JTokenType.Array)
        {
            return new XuiV3ApiResponse<List<string>>
            {
                Success = true,
                Obj = token.ToObject<List<string>>() ?? new List<string>()
            };
        }

        if (token.Type != JTokenType.Object)
            throw new InvalidDataException("XUI v3 string-list response did not use a supported JSON shape.");

        return token.ToObject<XuiV3ApiResponse<List<string>>>()
               ?? throw new InvalidDataException("XUI v3 string-list response envelope was empty.");
    }

    /// <summary>GET /panel/api/clients/groups. Lists client groups with member counts.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3ClientGroup>>> GetClientGroupsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3ClientGroup>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/clients/groups", null, true, cancellationToken);

    /// <summary>GET /panel/api/clients/groups/{name}/emails. Lists emails in one group.</summary>
    public static Task<XuiV3ApiResponse<List<string>>> GetClientGroupEmailsAsync(ServerInfo serverInfo, IConfiguration configuration, string name, CancellationToken cancellationToken = default)
        => SendAsync<List<string>>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/clients/groups/{EscapePath(name)}/emails", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/clients/groups/create. Creates a placeholder group.
    /// </summary>
    /// <remarks>
    /// Group creation is a non-idempotent mutation, so the request is sent exactly once with
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> CreateClientGroupAsync(ServerInfo serverInfo, IConfiguration configuration, string name, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/groups/create", new { name }, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/api/clients/groups/delete. Deletes a group and clears that label from clients.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteClientGroupAsync(ServerInfo serverInfo, IConfiguration configuration, string name, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/groups/delete", new { name }, true, cancellationToken);

    /// <summary>POST /panel/api/clients/groups/rename. Renames a group.</summary>
    public static Task<XuiV3ApiResponse<JToken>> RenameClientGroupAsync(ServerInfo serverInfo, IConfiguration configuration, string oldName, string newName, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/groups/rename", new { oldName, newName }, true, cancellationToken);

    /// <summary>POST /panel/api/clients/groups/bulkAdd. Adds many clients to one group.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkAddClientsToGroupAsync(ServerInfo serverInfo, IConfiguration configuration, string group, IEnumerable<string> emails, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/groups/bulkAdd", new { group, emails = emails?.ToList() ?? new List<string>() }, true, cancellationToken);

    /// <summary>POST /panel/api/clients/groups/bulkRemove. Clears the group label on many clients.</summary>
    public static Task<XuiV3ApiResponse<JToken>> BulkRemoveClientsFromGroupAsync(ServerInfo serverInfo, IConfiguration configuration, IEnumerable<string> emails, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/clients/groups/bulkRemove", new { emails = emails?.ToList() ?? new List<string>() }, true, cancellationToken);

    /// <summary>GET /panel/api/nodes/list. Lists configured remote nodes.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3Node>>> GetNodesAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3Node>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/nodes/list", null, true, cancellationToken);

    /// <summary>GET /panel/api/nodes/get/{id}. Gets one node by ID.</summary>
    public static Task<XuiV3ApiResponse<XuiV3Node>> GetNodeAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<XuiV3Node>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/nodes/get/{id}", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/nodes/add. Registers a remote node with URL and API token.
    /// </summary>
    /// <remarks>
    /// Node registration creates panel state and is non-idempotent, so the request is sent exactly once with
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> AddNodeAsync(ServerInfo serverInfo, IConfiguration configuration, XuiV3Node node, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/nodes/add", node, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/api/nodes/update/{id}. Replaces a node connection definition.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateNodeAsync(ServerInfo serverInfo, IConfiguration configuration, int id, XuiV3Node node, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/nodes/update/{id}", node, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/del/{id}. Deletes a remote node.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteNodeAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/nodes/del/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/setEnable/{id}. Pauses or resumes node sync.</summary>
    public static Task<XuiV3ApiResponse<JToken>> SetNodeEnabledAsync(ServerInfo serverInfo, IConfiguration configuration, int id, bool enable, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/nodes/setEnable/{id}", new { enable }, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/probe/{id}. Probes a saved node and refreshes cached health data.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ProbeNodeAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/nodes/probe/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/test. Probes a node definition without saving it.</summary>
    public static Task<XuiV3ApiResponse<JToken>> TestNodeAsync(ServerInfo serverInfo, IConfiguration configuration, XuiV3Node node, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/nodes/test", node, true, cancellationToken);

    /// <summary>GET /panel/api/nodes/history/{id}/{metric}/{bucket}. Gets node metric history.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNodeHistoryAsync(ServerInfo serverInfo, IConfiguration configuration, int id, string metric, string bucket, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/nodes/history/{id}/{EscapePath(metric)}/{EscapePath(bucket)}", null, true, cancellationToken);

    /// <summary>GET /panel/api/nodes/webCert/{id}. Gets node web TLS cert/key paths.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNodeWebCertAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/nodes/webCert/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/certFingerprint. Reads an HTTPS certificate fingerprint without verifying it.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNodeCertificateFingerprintAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/nodes/certFingerprint", request, true, cancellationToken);

    /// <summary>POST /panel/api/nodes/updatePanel. Triggers the official panel updater on selected nodes.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateNodesPanelAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/nodes/updatePanel", request, true, cancellationToken);

    /// <summary>GET /panel/api/custom-geo/list. Lists custom GeoIP/GeoSite sources.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3CustomGeoSource>>> GetCustomGeoSourcesAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3CustomGeoSource>>(serverInfo, configuration, HttpMethod.Get, "/panel/api/custom-geo/list", null, true, cancellationToken);

    /// <summary>GET /panel/api/custom-geo/aliases. Lists aliases usable in routing rules.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetCustomGeoAliasesAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/custom-geo/aliases", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/custom-geo/add. Adds a custom geo source URL.
    /// </summary>
    /// <remarks>
    /// Adding a geo source creates panel state and is non-idempotent, so the request is sent exactly once with
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> AddCustomGeoSourceAsync(ServerInfo serverInfo, IConfiguration configuration, XuiV3CustomGeoSource source, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/custom-geo/add", source, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/api/custom-geo/update/{id}. Replaces a custom geo source.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateCustomGeoSourceAsync(ServerInfo serverInfo, IConfiguration configuration, int id, XuiV3CustomGeoSource source, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/custom-geo/update/{id}", source, true, cancellationToken);

    /// <summary>POST /panel/api/custom-geo/delete/{id}. Deletes a custom geo source and cached file.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteCustomGeoSourceAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/custom-geo/delete/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/custom-geo/download/{id}. Downloads one custom geo source now.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DownloadCustomGeoSourceAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/custom-geo/download/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/api/custom-geo/update-all. Downloads every custom geo source.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateAllCustomGeoSourcesAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/custom-geo/update-all", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/backuptotgbot. Sends a DB backup to configured Telegram chats.
    /// </summary>
    /// <remarks>
    /// The backup action has a real side effect on Telegram and is non-idempotent, so the request is sent exactly once
    /// with <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/> instead of replaying a duplicate backup message.
    /// </remarks>
    public static Task<XuiV3ApiResponse<JToken>> BackupToTelegramBotAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/backuptotgbot", null, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>GET /panel/api/server/status. Real-time machine and Xray status.</summary>
    public static Task<XuiV3ApiResponse<XuiV3ServerStatus>> GetServerStatusAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<XuiV3ServerStatus>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/status", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/history/{metric}/{bucket}. Aggregated server metric history.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetServerHistoryAsync(ServerInfo serverInfo, IConfiguration configuration, string metric, string bucket, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/server/history/{EscapePath(metric)}/{EscapePath(bucket)}", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/cpuHistory/{bucket}. Legacy CPU history endpoint.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetServerCpuHistoryAsync(ServerInfo serverInfo, IConfiguration configuration, string bucket, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/server/cpuHistory/{EscapePath(bucket)}", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getConfigJson. Returns the assembled active Xray config JSON.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetServerConfigJsonAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getConfigJson", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getDb. Downloads the SQLite database as bytes.</summary>
    public static Task<byte[]> GetDatabaseBackupAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendBytesAsync(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getDb", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getNewUUID. Generates a UUID v4.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewUuidAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getNewUUID", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getNewX25519Cert. Generates a Reality X25519 keypair.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewX25519CertificateAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getNewX25519Cert", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getNewVlessEnc. Generates VLESS encryption auth options.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewVlessEncryptionAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getNewVlessEnc", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getNewmlkem768. Generates an ML-KEM-768 keypair.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewMlKem768Async(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getNewmlkem768", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getNewmldsa65. Generates an ML-DSA-65 keypair.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewMlDsa65Async(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getNewmldsa65", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/getNewEchCert. Generates an ECH keypair and config list for an SNI.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetNewEchCertificateAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/server/getNewEchCert", request, true, cancellationToken);

    /// <summary>GET /panel/api/server/getPanelUpdateInfo. Checks whether a newer 3x-ui release exists.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetPanelUpdateInfoAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getPanelUpdateInfo", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getWebCertFiles. Returns panel web TLS certificate/key paths.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetWebCertificateFilesAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getWebCertFiles", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/getXrayVersion. Lists Xray versions available for install.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayVersionsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/getXrayVersion", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/installXray/{version}. Downloads and installs a selected Xray version.</summary>
    public static Task<XuiV3ApiResponse<JToken>> InstallXrayAsync(ServerInfo serverInfo, IConfiguration configuration, string version, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/server/installXray/{EscapePath(version)}", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/restartXrayService. Reloads Xray with the current config.</summary>
    public static Task<XuiV3ApiResponse<JToken>> RestartXrayServiceAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/server/restartXrayService", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/stopXrayService. Stops Xray immediately.</summary>
    public static Task<XuiV3ApiResponse<JToken>> StopXrayServiceAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/server/stopXrayService", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/updateGeofile. Refreshes default GeoIP/GeoSite files.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateGeofileAsync(ServerInfo serverInfo, IConfiguration configuration, object request = null, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/server/updateGeofile", request, true, cancellationToken);

    /// <summary>POST /panel/api/server/updateGeofile/{fileName}. Refreshes a single geo file.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateGeofileAsync(ServerInfo serverInfo, IConfiguration configuration, string fileName, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/server/updateGeofile/{EscapePath(fileName)}", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/updatePanel. Self-updates the panel.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdatePanelAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/api/server/updatePanel", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/logs/{count}. Returns the last N panel log lines.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetPanelLogsAsync(ServerInfo serverInfo, IConfiguration configuration, int count, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/server/logs/{count}", null, true, cancellationToken);

    /// <summary>POST /panel/api/server/xraylogs/{count}. Returns the last N Xray log lines.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayLogsAsync(ServerInfo serverInfo, IConfiguration configuration, int count, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/api/server/xraylogs/{count}", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/api/server/importDB. Restores the panel DB from a local SQLite file path.
    /// </summary>
    /// <param name="serverInfo">Target XUI v3 panel descriptor containing endpoint and authentication metadata.</param>
    /// <param name="configuration">Runtime timeout and retry configuration.</param>
    /// <param name="dbFilePath">Absolute path of the local SQLite database file to upload.</param>
    /// <param name="cancellationToken">Token that cancels the multipart upload.</param>
    /// <returns>The panel import response envelope.</returns>
    /// <remarks>
    /// Restoring a database overwrites panel state and is non-idempotent, so the upload is sent exactly once with
    /// <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/>; a timeout must never trigger a blind second import.
    /// </remarks>
    public static async Task<XuiV3ApiResponse<JToken>> ImportDatabaseAsync(ServerInfo serverInfo, IConfiguration configuration, string dbFilePath, CancellationToken cancellationToken = default)
    {
        var fileName = Path.GetFileName(dbFilePath);
        var raw = await SendRawWithRetryAsync(
            serverInfo,
            configuration,
            HttpMethod.Post,
            "/panel/api/server/importDB",
            async token =>
            {
                var content = new MultipartFormDataContent();
                content.Add(new ByteArrayContent(await File.ReadAllBytesAsync(dbFilePath, token)), "db", fileName);
                return content;
            },
            true,
            cancellationToken,
            query: null,
            requestBodyForLog: "<multipart-db-content>",
            retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);
        return JsonConvert.DeserializeObject<XuiV3ApiResponse<JToken>>(raw) ?? new XuiV3ApiResponse<JToken>();
    }

    /// <summary>GET /panel/api/server/xrayMetricsState. Returns whether Xray metrics are enabled and reachable.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayMetricsStateAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/xrayMetricsState", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/xrayMetricsHistory/{metric}/{bucket}. Gets Xray runtime metric history.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayMetricsHistoryAsync(ServerInfo serverInfo, IConfiguration configuration, string metric, string bucket, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/server/xrayMetricsHistory/{EscapePath(metric)}/{EscapePath(bucket)}", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/xrayObservatory. Gets the latest Xray observatory snapshot.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayObservatoryAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/api/server/xrayObservatory", null, true, cancellationToken);

    /// <summary>GET /panel/api/server/xrayObservatoryHistory/{tag}/{bucket}. Gets observatory history for one outbound tag.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayObservatoryHistoryAsync(ServerInfo serverInfo, IConfiguration configuration, string tag, string bucket, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, $"/panel/api/server/xrayObservatoryHistory/{EscapePath(tag)}/{EscapePath(bucket)}", null, true, cancellationToken);

    /// <summary>POST /panel/setting/all. Returns the full settings JSON.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetAllSettingsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/all", null, true, cancellationToken);

    /// <summary>POST /panel/setting/defaultSettings. Returns computed default settings.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetDefaultSettingsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/defaultSettings", null, true, cancellationToken);

    /// <summary>GET /panel/setting/getDefaultJsonConfig. Returns built-in default Xray JSON config.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetDefaultJsonConfigAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/setting/getDefaultJsonConfig", null, true, cancellationToken);

    /// <summary>POST /panel/setting/update. Persists every panel setting at once.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateSettingsAsync(ServerInfo serverInfo, IConfiguration configuration, object settings, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/update", settings, true, cancellationToken);

    /// <summary>POST /panel/setting/updateUser. Changes panel admin username and password.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdatePanelUserAsync(ServerInfo serverInfo, IConfiguration configuration, string username, string password, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/updateUser", new { username, password }, true, cancellationToken);

    /// <summary>POST /panel/setting/restartPanel. Restarts the 3x-ui process after a short grace period.</summary>
    public static Task<XuiV3ApiResponse<JToken>> RestartPanelAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/restartPanel", null, true, cancellationToken);

    /// <summary>GET /panel/setting/apiTokens. Lists API token metadata. Plain token values are not returned.</summary>
    public static Task<XuiV3ApiResponse<List<XuiV3ApiTokenInfo>>> GetApiTokensAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<List<XuiV3ApiTokenInfo>>(serverInfo, configuration, HttpMethod.Get, "/panel/setting/apiTokens", null, true, cancellationToken);

    /// <summary>
    /// POST /panel/setting/apiTokens/create. Creates a Bearer token. The plaintext token is returned only once.
    /// </summary>
    /// <remarks>
    /// Token creation is non-idempotent and the plaintext is returned only once, so the request is sent exactly once
    /// with <see cref="XuiV3RequestRetryMode.NoAutomaticRetry"/> to avoid losing or duplicating credentials.
    /// </remarks>
    public static Task<XuiV3ApiResponse<XuiV3ApiTokenCreated>> CreateApiTokenAsync(ServerInfo serverInfo, IConfiguration configuration, string name, CancellationToken cancellationToken = default)
        => SendAsync<XuiV3ApiTokenCreated>(serverInfo, configuration, HttpMethod.Post, "/panel/setting/apiTokens/create", new { name }, true, cancellationToken, retryMode: XuiV3RequestRetryMode.NoAutomaticRetry);

    /// <summary>POST /panel/setting/apiTokens/delete/{id}. Permanently deletes an API token.</summary>
    public static Task<XuiV3ApiResponse<JToken>> DeleteApiTokenAsync(ServerInfo serverInfo, IConfiguration configuration, int id, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/setting/apiTokens/delete/{id}", null, true, cancellationToken);

    /// <summary>POST /panel/setting/apiTokens/setEnabled/{id}. Enables or disables an API token.</summary>
    public static Task<XuiV3ApiResponse<JToken>> SetApiTokenEnabledAsync(ServerInfo serverInfo, IConfiguration configuration, int id, bool enabled, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/setting/apiTokens/setEnabled/{id}", new { enabled }, true, cancellationToken);

    /// <summary>POST /panel/xray/. Returns Xray template, inbound tags, reverse tags and outbound test URL.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXraySettingsAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/xray/", null, true, cancellationToken);

    /// <summary>GET /panel/xray/getDefaultJsonConfig. Returns built-in default Xray config.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayDefaultJsonConfigAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/xray/getDefaultJsonConfig", null, true, cancellationToken);

    /// <summary>GET /panel/xray/getOutboundsTraffic. Returns traffic counters for every outbound.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetOutboundsTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/xray/getOutboundsTraffic", null, true, cancellationToken);

    /// <summary>GET /panel/xray/getXrayResult. Returns recent Xray stdout/stderr output.</summary>
    public static Task<XuiV3ApiResponse<JToken>> GetXrayResultAsync(ServerInfo serverInfo, IConfiguration configuration, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Get, "/panel/xray/getXrayResult", null, true, cancellationToken);

    /// <summary>POST /panel/xray/update. Saves Xray JSON config and optional outbound test URL as form fields.</summary>
    public static Task<XuiV3ApiResponse<JToken>> UpdateXrayConfigAsync(ServerInfo serverInfo, IConfiguration configuration, string xraySetting, string outboundTestUrl = null, CancellationToken cancellationToken = default)
    {
        var fields = new Dictionary<string, string> { ["xraySetting"] = xraySetting ?? "" };
        if (!string.IsNullOrWhiteSpace(outboundTestUrl))
            fields["outboundTestUrl"] = outboundTestUrl;

        return SendFormAsync<JToken>(serverInfo, configuration, "/panel/xray/update", fields, cancellationToken);
    }

    /// <summary>POST /panel/xray/warp/{action}. Runs Warp action: data, del, config, reg or license.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ManageWarpAsync(ServerInfo serverInfo, IConfiguration configuration, string action, object request = null, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/xray/warp/{EscapePath(action)}", request, true, cancellationToken);

    /// <summary>POST /panel/xray/nord/{action}. Runs NordVPN action: countries, servers, reg, setKey, data or del.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ManageNordAsync(ServerInfo serverInfo, IConfiguration configuration, string action, object request = null, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, $"/panel/xray/nord/{EscapePath(action)}", request, true, cancellationToken);

    /// <summary>POST /panel/xray/resetOutboundsTraffic. Resets traffic counters for an outbound tag.</summary>
    public static Task<XuiV3ApiResponse<JToken>> ResetOutboundTrafficAsync(ServerInfo serverInfo, IConfiguration configuration, string tag, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/xray/resetOutboundsTraffic", new { tag }, true, cancellationToken);

    /// <summary>POST /panel/xray/testOutbound. Tests an outbound JSON configuration.</summary>
    public static Task<XuiV3ApiResponse<JToken>> TestOutboundAsync(ServerInfo serverInfo, IConfiguration configuration, object request, CancellationToken cancellationToken = default)
        => SendAsync<JToken>(serverInfo, configuration, HttpMethod.Post, "/panel/xray/testOutbound", request, true, cancellationToken);

    /// <summary>GET /{subPath}{subid}. Returns base64 subscription text from the subscription server.</summary>
    public static Task<string> GetSubscriptionAsync(ServerInfo serverInfo, string subId, string subPath = "sub/", CancellationToken cancellationToken = default)
        => SendSubscriptionRawAsync(serverInfo, subPath, subId, "text/plain", cancellationToken);

    /// <summary>GET /{jsonPath}{subid}. Returns JSON subscription array from the subscription server.</summary>
    public static async Task<JToken> GetJsonSubscriptionAsync(ServerInfo serverInfo, string subId, string jsonPath = "json/", CancellationToken cancellationToken = default)
    {
        var raw = await SendSubscriptionRawAsync(serverInfo, jsonPath, subId, "application/json", cancellationToken);
        return JToken.Parse(raw);
    }

    /// <summary>GET /{clashPath}{subid}. Returns Clash/Mihomo YAML subscription from the subscription server.</summary>
    public static Task<string> GetClashSubscriptionAsync(ServerInfo serverInfo, string subId, string clashPath = "clash/", CancellationToken cancellationToken = default)
        => SendSubscriptionRawAsync(serverInfo, clashPath, subId, "text/yaml", cancellationToken);

    /// <summary>GET /ws. Builds the websocket URI. Bearer auth is not supported by this endpoint; use session cookie auth.</summary>
    public static Uri BuildWebSocketUri(ServerInfo serverInfo)
    {
        var panelUri = BuildPanelUri(serverInfo, "/ws", null);
        var builder = new UriBuilder(panelUri)
        {
            Scheme = panelUri.Scheme == "https" ? "wss" : "ws"
        };
        return builder.Uri;
    }

    /// <summary>
    /// Sends one JSON XUI v3 request and deserializes the standard panel response envelope.
    /// </summary>
    /// <typeparam name="T">Type expected in the response <c>obj</c> field.</typeparam>
    /// <param name="serverInfo">Target panel descriptor containing endpoint and authentication metadata.</param>
    /// <param name="configuration">Runtime timeout and retry configuration.</param>
    /// <param name="method">HTTP method required by the panel endpoint.</param>
    /// <param name="relativePath">Panel-relative API path; it must not contain secrets.</param>
    /// <param name="body">Optional JSON request body.</param>
    /// <param name="authenticate">Whether bearer or session authentication is required.</param>
    /// <param name="cancellationToken">Token that cancels the request and any permitted retry delay.</param>
    /// <param name="query">Optional query values encoded into the request URI.</param>
    /// <param name="retryMode">Replay semantics; non-idempotent mutations must use <c>NoAutomaticRetry</c>.</param>
    /// <param name="executionPolicy">
    /// Execution boundary for the logical request. <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> applies one
    /// overall wall-clock budget across every attempt, backoff, and response read and raises
    /// <see cref="XuiV3ForegroundReadTimeoutException"/> on expiry. <see cref="XuiV3RequestExecutionPolicy.IdempotentMutation"/>
    /// and <see cref="XuiV3RequestExecutionPolicy.NoAutomaticRetryMutation"/> derive the retry mode when no explicit
    /// <paramref name="retryMode"/> is supplied. The default respects the supplied <paramref name="retryMode"/>.
    /// </param>
    /// <returns>The deserialized XUI response envelope.</returns>
    /// <remarks>
    /// A successful HTTP status can still contain <c>success=false</c>; callers remain responsible for checking the
    /// panel envelope. Exceptions retain endpoint detail only for private diagnostics and must not be shown to users.
    /// </remarks>
    public static async Task<XuiV3ApiResponse<T>> SendAsync<T>(
        ServerInfo serverInfo,
        IConfiguration configuration,
        HttpMethod method,
        string relativePath,
        object body = null,
        bool authenticate = true,
        CancellationToken cancellationToken = default,
        IDictionary<string, string> query = null,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.ReadOnly,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        var raw = await SendRawAsync(serverInfo, configuration, method, relativePath, body, authenticate, cancellationToken, query, EffectiveRetryMode(retryMode, executionPolicy), executionPolicy);
        var result = JsonConvert.DeserializeObject<XuiV3ApiResponse<T>>(raw);
        if (result == null)
            throw new XuiV3ApiException(method.ToString(), BuildPanelUri(serverInfo, relativePath, query).ToString(), 0, raw, null);

        return result;
    }

    private static async Task<XuiV3ApiResponse<T>> SendFormAsync<T>(
        ServerInfo serverInfo,
        IConfiguration configuration,
        string relativePath,
        IDictionary<string, string> fields,
        CancellationToken cancellationToken,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        var safeFields = fields ?? new Dictionary<string, string>();
        var raw = await SendRawWithRetryAsync(
            serverInfo,
            configuration,
            HttpMethod.Post,
            relativePath,
            _ => Task.FromResult<HttpContent>(new FormUrlEncodedContent(safeFields)),
            true,
            cancellationToken,
            query: null,
            requestBodyForLog: "<form-content>",
            executionPolicy: executionPolicy);
        return JsonConvert.DeserializeObject<XuiV3ApiResponse<T>>(raw) ?? new XuiV3ApiResponse<T>();
    }

    private static async Task<byte[]> SendBytesAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        HttpMethod method,
        string relativePath,
        object body,
        bool authenticate,
        CancellationToken cancellationToken,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        var uri = BuildPanelUri(serverInfo, relativePath, null);
        return await SendWithRetryAsync(
            configuration,
            method,
            uri,
            async (attemptToken) =>
            {
                using var httpClient = CreateHttpClient(configuration);
                using var content = BuildContent(body);
                using var request = BuildRequest(method, uri, content, serverInfo, configuration, authenticate);
                using var response = await httpClient.SendAsync(request, attemptToken);
                var bytes = await response.Content.ReadAsByteArrayAsync(attemptToken);

                if (!response.IsSuccessStatusCode)
                {
                    var text = Encoding.UTF8.GetString(bytes);
                    throw new XuiV3ApiException(method.ToString(), uri.ToString(), (int)response.StatusCode, text, SerializeBodyForLog(body));
                }

                return bytes;
            },
            cancellationToken,
            XuiV3RequestRetryMode.ReadOnly,
            executionPolicy);
    }

    /// <summary>
    /// Sends one XUI v3 request and retries transient transport or gateway failures with bounded backoff.
    /// </summary>
    /// <param name="serverInfo">Target XUI panel configuration that provides base URL, root path, and bearer token.</param>
    /// <param name="configuration">Application configuration containing timeout and retry settings.</param>
    /// <param name="method">HTTP method used by the XUI endpoint.</param>
    /// <param name="relativePath">Panel-relative path, without duplicating the root path.</param>
    /// <param name="contentFactory">
    /// Factory that creates a fresh HTTP content object for each attempt. This is required because <see cref="HttpContent"/>
    /// instances cannot be safely re-sent after a failed attempt.
    /// </param>
    /// <param name="authenticate">Whether the request should include the XUI v3 bearer token.</param>
    /// <param name="cancellationToken">Cancellation token for the active Telegram update or background operation.</param>
    /// <param name="query">Optional query string values for endpoints that support filtering or paging.</param>
    /// <param name="requestBodyForLog">Sanitized request body label used only in exceptions; never include tokens here.</param>
    /// <param name="retryMode">Replay policy that limits transient retries for ambiguous mutations.</param>
    /// <returns>The response body as UTF-8 text when the panel returns a successful status code.</returns>
    /// <remarks>
    /// HTTP 400/401/403/404/422 responses are treated as panel/business failures and are not retried. HTTP 429 and
    /// gateway 5xx responses are retried because 3x-ui 3.4.x panels can temporarily stall under account creation load.
    /// </remarks>
    private static Task<string> SendRawWithRetryAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        HttpMethod method,
        string relativePath,
        Func<CancellationToken, Task<HttpContent>> contentFactory,
        bool authenticate,
        CancellationToken cancellationToken,
        IDictionary<string, string> query = null,
        string requestBodyForLog = null,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.ReadOnly,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        var uri = BuildPanelUri(serverInfo, relativePath, query);
        return SendWithRetryAsync(
            configuration,
            method,
            uri,
            async (attemptToken) =>
            {
                using var httpClient = CreateHttpClient(configuration);
                using var content = contentFactory == null ? null : await contentFactory(attemptToken);
                using var request = BuildRequest(method, uri, content, serverInfo, configuration, authenticate);
                using var response = await httpClient.SendAsync(request, attemptToken);
                var responseText = await response.Content.ReadAsStringAsync(attemptToken);

                if (!response.IsSuccessStatusCode)
                    throw new XuiV3ApiException(method.ToString(), uri.ToString(), (int)response.StatusCode, responseText, requestBodyForLog);

                return responseText;
            },
            cancellationToken,
            retryMode,
            executionPolicy);
    }

    /// <summary>
    /// Executes an XUI v3 HTTP operation with retry semantics shared by JSON, form, and byte-response endpoints.
    /// </summary>
    /// <typeparam name="T">Response type produced by the supplied HTTP operation.</typeparam>
    /// <param name="configuration">Application configuration that supplies retry count and delay settings.</param>
    /// <param name="method">HTTP method being sent, used for retry diagnostics.</param>
    /// <param name="uri">Fully built XUI panel request URI. It must not include bearer tokens or other secrets.</param>
    /// <param name="operation">
    /// Factory that sends exactly one HTTP attempt and returns the parsed response data.
    /// </param>
    /// <param name="cancellationToken">Cancellation token that stops retries when the Telegram update is cancelled.</param>
    /// <param name="retryMode">Replay policy; <c>NoAutomaticRetry</c> forces exactly one HTTP attempt.</param>
    /// <param name="executionPolicy">
    /// Execution boundary. <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> adds ONE overall wall-clock budget
    /// spanning all attempts, all backoff, and response reading; on expiry a typed
    /// <see cref="XuiV3ForegroundReadTimeoutException"/> is raised and no further retry starts.
    /// </param>
    /// <returns>The value returned by the first successful HTTP attempt.</returns>
    /// <remarks>
    /// Retry attempts stay out of the private Telegram logger channel, but are written with full exception details to
    /// the daily diagnostic file so transient panel problems remain reviewable without channel noise.
    /// When an <see cref="XuiOperationTiming"/> scope is active, the complete logical request—including retry attempts
    /// and configured backoff—is accumulated as panel API time. Calls made outside an operation scope remain unmeasured
    /// and retain their previous behavior.
    ///
    /// Foreground budget shape:
    /// The budget is NOT per attempt. The whole logical request (attempt + backoff + response read) must finish inside
    /// one window, so a 12-second budget with four configured retries cannot turn into 48 seconds of lane stall. The
    /// effective budget is clamped to <see cref="ForegroundReadOverallHardCap"/> so deployment configuration can never
    /// raise an interactive read above 15 seconds.
    /// </remarks>
    private static async Task<T> SendWithRetryAsync<T>(
        IConfiguration configuration,
        HttpMethod method,
        Uri uri,
        Func<CancellationToken, Task<T>> operation,
        CancellationToken cancellationToken,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.ReadOnly,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        // Attribute the complete logical request to the closed-vocabulary foreground stage when this is an interactive
        // read. Background workers execute without a latency scope, so the measurement is a no-op for them and their
        // behavior is unchanged.
        using var stageMeasurement = executionPolicy == XuiV3RequestExecutionPolicy.ForegroundRead
            ? (TelegramUpdateLatencyScope.Current?.Measure(TelegramUpdateStage.XuiRead) ?? default)
            : default;

        // One measurement covers the complete logical request, including every retry and retry delay. The ambient
        // operation scope is bot-update-local, so concurrent customer operations cannot mix their API durations.
        using var panelMeasurement = XuiOperationTiming.BeginCurrentPanelCall();
        var appConfig = configuration?.Get<AppConfig>() ?? new AppConfig();
        var retryCount = appConfig.XuiV3TransientRetryCount < 0
            ? DefaultXuiV3TransientRetryCount
            : appConfig.XuiV3TransientRetryCount;
        var maxAttempts = retryMode == XuiV3RequestRetryMode.NoAutomaticRetry
            ? 1
            : Math.Max(1, retryCount + 1);
        Exception lastException = null;
        using var foregroundBudget = executionPolicy == XuiV3RequestExecutionPolicy.ForegroundRead
            ? CancellationTokenSource.CreateLinkedTokenSource(cancellationToken)
            : null;
        if (foregroundBudget != null)
            foregroundBudget.CancelAfter(ResolveForegroundReadOverallBudget(appConfig));

        try
        {
            for (var attempt = 1; attempt <= maxAttempts; attempt++)
            {
                var attemptToken = foregroundBudget?.Token ?? cancellationToken;
                attemptToken.ThrowIfCancellationRequested();
                try
                {
                    return await operation(attemptToken);
                }
                catch (Exception ex) when (ShouldRetryXuiRequest(ex, attemptToken, attempt, maxAttempts))
                {
                    lastException = ex;
                    var delay = GetXuiRetryDelay(appConfig, attempt);
                    var transport = BuildTransportDiagnostic(ex, retryMode);
                    Console.WriteLine(
                        $"[XUIv3] transient API failure; retrying. attempt={attempt}/{maxAttempts}, method={method}, uri={uri}, delayMs={delay.TotalMilliseconds:0}, error={ex.Message}");
                    DailyErrorFileLoggerProvider.WriteExternalDiagnostic(
                        configuration,
                        LogLevel.Warning,
                        nameof(ApiServicev3),
                        $"XUI v3 transient request failure; retrying. attempt={attempt}/{maxAttempts}, method={method}, uri={uri}, delayMs={delay.TotalMilliseconds:0}, {transport}",
                        ex);
                    await Task.Delay(delay, attemptToken);
                }
                catch (Exception ex)
                {
                    var transport = BuildTransportDiagnostic(ex, retryMode);
                    // The Telegram-facing exception message is intentionally redacted. Keep the full endpoint and
                    // provider details only in the private daily diagnostic file. Every attempt owns and disposes its
                    // handler, and Connection: close disables reuse, so a TLS record-integrity failure already discards
                    // the failed connection. NoAutomaticRetry mutations still surface after this one attempt.
                    DailyErrorFileLoggerProvider.WriteExternalDiagnostic(
                        configuration,
                        LogLevel.Error,
                        nameof(ApiServicev3),
                        $"XUI v3 request failed after retry policy. attempt={attempt}/{maxAttempts}, method={method}, uri={uri}, {transport}",
                        ex);
                    throw;
                }
            }

            throw lastException ?? new InvalidOperationException("XUI v3 request failed without an exception.");
        }
        catch (OperationCanceledException) when (IsForegroundReadBudgetExpired(foregroundBudget, cancellationToken))
        {
            // The overall foreground window expired while the caller's own lane token is still live: surface the typed
            // outcome so the handler stops retrying and releases the Telegram lane with a user-safe retry message.
            throw new XuiV3ForegroundReadTimeoutException(ResolveForegroundReadOverallBudget(appConfig));
        }
    }

    /// <summary>
    /// Resolves the configured overall foreground XUI read budget, clamped to the documented hard cap.
    /// </summary>
    /// <param name="appConfig">Runtime application settings; a missing or non-positive value keeps the default.</param>
    /// <returns>
    /// The overall wall-clock budget for one foreground logical read, never exceeding
    /// <see cref="ForegroundReadOverallHardCap"/> and never below one millisecond.
    /// </returns>
    /// <remarks>
    /// The configured value is expressed in fractional seconds so tests can inject sub-second budgets deterministically.
    /// A null configuration, or one whose <see cref="AppConfig.XuiV3ForegroundReadTimeoutSeconds"/> is absent, zero, or
    /// negative, falls back to <see cref="DefaultForegroundReadOverallBudget"/> rather than to a near-zero window.
    /// </remarks>
    public static TimeSpan ResolveForegroundReadOverallBudget(AppConfig appConfig)
    {
        // Fall back to the documented default whenever configuration cannot supply a positive budget, so a missing or
        // misconfigured value can never collapse an interactive read into an immediate timeout.
        var configuredSeconds = appConfig?.XuiV3ForegroundReadTimeoutSeconds ?? 0;
        var seconds = configuredSeconds > 0 ? configuredSeconds : DefaultForegroundReadOverallBudget.TotalSeconds;
        var clamped = Math.Clamp(seconds * 1000.0, 1.0, ForegroundReadOverallHardCap.TotalMilliseconds);
        return TimeSpan.FromMilliseconds(clamped);
    }

    /// <summary>
    /// Detects whether a foreground-read budget, and not the caller's own cancellation, triggered a cancellation.
    /// </summary>
    /// <param name="foregroundBudget">Nullable linked source created only for <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/>.</param>
    /// <param name="callerToken">The caller's own lane token; its state distinguishes budget expiry from shutdown.</param>
    /// <returns>
    /// <c>true</c> only when the foreground budget source exists, its token is cancelled, and the caller's own token
    /// is still live; otherwise <c>false</c> so the original cancellation propagates.
    /// </returns>
    private static bool IsForegroundReadBudgetExpired(CancellationTokenSource foregroundBudget, CancellationToken callerToken)
        => foregroundBudget != null && foregroundBudget.Token.IsCancellationRequested && !callerToken.IsCancellationRequested;

    /// <summary>
    /// Derives the transport retry mode implied by an execution policy when the caller did not supply an explicit mode.
    /// </summary>
    /// <param name="retryMode">Explicit retry mode supplied by the caller.</param>
    /// <param name="executionPolicy">Execution policy governing the logical request.</param>
    /// <returns>
    /// The explicit <paramref name="retryMode"/> for the default policy, otherwise the retry mode implied by
    /// <paramref name="executionPolicy"/>.
    /// </returns>
    /// <remarks>
    /// <see cref="XuiV3RequestExecutionPolicy.ForegroundRead"/> and <see cref="XuiV3RequestExecutionPolicy.BackgroundRead"/>
    /// both imply <c>ReadOnly</c>; <see cref="XuiV3RequestExecutionPolicy.IdempotentMutation"/> implies
    /// <c>IdempotentMutation</c>; <see cref="XuiV3RequestExecutionPolicy.NoAutomaticRetryMutation"/> implies
    /// <c>NoAutomaticRetry</c>. Existing mutable callers that pass an explicit <paramref name="retryMode"/> and keep the
    /// default policy keep their current semantics exactly.
    /// </remarks>
    private static XuiV3RequestRetryMode EffectiveRetryMode(XuiV3RequestRetryMode retryMode, XuiV3RequestExecutionPolicy executionPolicy)
    {
        if (executionPolicy == XuiV3RequestExecutionPolicy.BackgroundRead)
            return retryMode;
        return executionPolicy == XuiV3RequestExecutionPolicy.IdempotentMutation
            ? XuiV3RequestRetryMode.IdempotentMutation
            : executionPolicy == XuiV3RequestExecutionPolicy.NoAutomaticRetryMutation
                ? XuiV3RequestRetryMode.NoAutomaticRetry
                : XuiV3RequestRetryMode.ReadOnly;
    }

    /// <summary>
    /// Serializes an optional JSON body and delegates one raw XUI request to the central retry transport.
    /// </summary>
    /// <param name="serverInfo">Target XUI panel descriptor.</param>
    /// <param name="configuration">Runtime timeout and retry settings.</param>
    /// <param name="method">HTTP method for the endpoint.</param>
    /// <param name="relativePath">Panel-relative API path.</param>
    /// <param name="body">Optional object serialized as JSON for each attempt.</param>
    /// <param name="authenticate">Whether authentication headers are required.</param>
    /// <param name="cancellationToken">Token that cancels the request.</param>
    /// <param name="query">Optional query values.</param>
    /// <param name="retryMode">Replay policy; ambiguous link mutations use <c>NoAutomaticRetry</c>.</param>
    /// <param name="executionPolicy">Execution boundary that may add an overall budget for interactive reads.</param>
    /// <returns>Successful UTF-8 response body.</returns>
    private static async Task<string> SendRawAsync(
        ServerInfo serverInfo,
        IConfiguration configuration,
        HttpMethod method,
        string relativePath,
        object body,
        bool authenticate,
        CancellationToken cancellationToken,
        IDictionary<string, string> query = null,
        XuiV3RequestRetryMode retryMode = XuiV3RequestRetryMode.ReadOnly,
        XuiV3RequestExecutionPolicy executionPolicy = XuiV3RequestExecutionPolicy.BackgroundRead)
    {
        return await SendRawWithRetryAsync(
            serverInfo,
            configuration,
            method,
            relativePath,
            _ => Task.FromResult(BuildContent(body)),
            authenticate,
            cancellationToken,
            query,
            SerializeBodyForLog(body),
            retryMode,
            executionPolicy);
    }

    /// <summary>
    /// Downloads one raw subscription representation while contributing its HTTP duration to the current XUI audit.
    /// </summary>
    /// <param name="serverInfo">
    /// XUI server descriptor supplying the subscription base URL. Authentication secrets are resolved internally and
    /// must never be embedded in log output.
    /// </param>
    /// <param name="pathPrefix">Configured relative subscription path such as <c>sub/</c> or <c>clash/</c>.</param>
    /// <param name="subId">Required panel subscription identifier. It is sensitive and must never be logged.</param>
    /// <param name="accept">HTTP Accept media type expected by the caller.</param>
    /// <param name="cancellationToken">Token that cancels the outbound subscription request.</param>
    /// <returns>The raw UTF-8 response body; it may be empty when the panel returns an empty successful response.</returns>
    /// <remarks>
    /// The complete request is measured only when a surrounding <see cref="XuiOperationTiming"/> scope exists. This
    /// method does not create an operation scope by itself, so read-only subscription requests outside audited account
    /// activities do not produce timing logs.
    /// </remarks>
    /// <exception cref="ArgumentException">Thrown when the configured base URL or path cannot form a valid URI.</exception>
    /// <exception cref="HttpRequestException">Thrown when the subscription endpoint returns an unsuccessful response.</exception>
    private static async Task<string> SendSubscriptionRawAsync(
        ServerInfo serverInfo,
        string pathPrefix,
        string subId,
        string accept,
        CancellationToken cancellationToken)
    {
        using var panelMeasurement = XuiOperationTiming.BeginCurrentPanelCall();
        var baseUrl = string.IsNullOrWhiteSpace(serverInfo.SubLinkUrl)
            ? serverInfo.Url
            : serverInfo.SubLinkUrl;

        var normalizedBase = baseUrl.TrimEnd('/') + "/";
        var normalizedPath = (pathPrefix ?? "sub/").Trim('/');
        var uri = new Uri(normalizedBase + normalizedPath + "/" + EscapePath(subId));

        using var httpClient = new HttpClient();
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Headers.TryAddWithoutValidation("Accept", accept);
        using var response = await httpClient.SendAsync(request, cancellationToken);
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new XuiV3ApiException("GET", uri.ToString(), (int)response.StatusCode, raw, null);

        return raw;
    }

    private static HttpClient CreateHttpClient(IConfiguration configuration)
    {
        var appConfig = configuration?.Get<AppConfig>() ?? new AppConfig();
        var timeoutSeconds = appConfig.XuiV3RequestTimeoutSeconds <= 0 ? DefaultXuiV3TimeoutSeconds : appConfig.XuiV3RequestTimeoutSeconds;
        return new HttpClient { Timeout = TimeSpan.FromSeconds(timeoutSeconds) };
    }

    /// <summary>
    /// Determines whether a failed XUI v3 HTTP attempt is safe to retry.
    /// </summary>
    /// <param name="exception">
    /// Exception thrown by one HTTP attempt. It may be a provider response wrapped in <see cref="XuiV3ApiException"/>
    /// or a transport exception such as <see cref="HttpRequestException"/>.
    /// </param>
    /// <param name="cancellationToken">
    /// Cancellation token for the active Telegram update. Cancelled shutdown operations are not treated as retryable.
    /// </param>
    /// <param name="attempt">The 1-based attempt number that just failed.</param>
    /// <param name="maxAttempts">Maximum number of attempts allowed for this request.</param>
    /// <returns>
    /// <c>true</c> when another attempt should be made; otherwise <c>false</c> so the original error is surfaced.
    /// </returns>
    /// <remarks>
    /// HTTP 429 and gateway 5xx errors are retryable. Normal 3x-ui API validation/auth/not-found errors are not,
    /// because retrying them can hide a real configuration or business-rule problem.
    /// </remarks>
    private static bool ShouldRetryXuiRequest(Exception exception, CancellationToken cancellationToken, int attempt, int maxAttempts)
    {
        if (attempt >= maxAttempts || cancellationToken.IsCancellationRequested)
            return false;

        if (exception is XuiV3ApiException apiException)
            return IsTransientXuiStatusCode(apiException.StatusCode);

        return IsTransientXuiTransportException(exception, cancellationToken);
    }

    /// <summary>
    /// Detects transient network and TLS failures that can happen while the bot talks to the XUI v3 panel.
    /// </summary>
    /// <param name="exception">Exception thrown by an XUI v3 request or by a follow-up read after account creation.</param>
    /// <param name="cancellationToken">Cancellation token for the active operation; shutdown cancellations are ignored.</param>
    /// <returns>
    /// <c>true</c> for retryable transport failures such as timeout, DNS/socket failure, TLS bad record MAC, gateway
    /// failure, or connection reset; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// 3x-ui 3.4.x panels can be slow after add-client operations. Treating these failures as transient prevents one
    /// failed panel read from escaping to Telegram polling and stopping an owned or tenant bot receiver.
    /// </remarks>
    public static bool IsTransientXuiTransportException(Exception exception, CancellationToken cancellationToken = default)
    {
        if (exception == null || cancellationToken.IsCancellationRequested)
            return false;

        if (exception is TimeoutException or TaskCanceledException or OperationCanceledException)
            return true;

        if (exception is XuiV3ApiException apiException)
            return IsTransientXuiStatusCode(apiException.StatusCode);

        foreach (var current in FlattenExceptionChain(exception))
        {
            if (current is HttpRequestException httpRequestException)
            {
                if (httpRequestException.StatusCode.HasValue &&
                    IsTransientXuiStatusCode((int)httpRequestException.StatusCode.Value))
                {
                    return true;
                }

                return true;
            }

            if (current is IOException or SocketException)
                return true;

            var message = current.Message ?? string.Empty;
            if (ContainsTransientXuiTransportMarker(message))
                return true;
        }

        return false;
    }

    /// <summary>
    /// Detects the OpenSSL TLS record-integrity failure observed on XUI add/update responses.
    /// </summary>
    /// <param name="exception">Root transport exception; nested IOException/OpenSSL exceptions are inspected.</param>
    /// <returns><c>true</c> when any nested message contains bad-record-MAC or equivalent decryption markers.</returns>
    /// <remarks>
    /// This classifier is diagnostic only. It never makes a mutation retryable. The transport already uses one new
    /// handler per attempt plus <c>Connection: close</c>, so the failed connection is disposed and the next independent
    /// request gets a fresh connection without replaying the current add/update mutation.
    /// </remarks>
    /// <example><code>if (ApiServicev3.IsTlsRecordIntegrityFailure(ex)) markOutcomeAmbiguous();</code></example>
    public static bool IsTlsRecordIntegrityFailure(Exception exception)
    {
        return FlattenExceptionChain(exception).Any(current =>
        {
            var message = current.Message ?? string.Empty;
            return message.Contains("decryption failed", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("bad record mac", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("SSL_ERROR_SSL", StringComparison.OrdinalIgnoreCase) &&
                   message.Contains("decrypt", StringComparison.OrdinalIgnoreCase);
        });
    }

    /// <summary>Builds a sanitized transport-policy diagnostic for private failure logs.</summary>
    /// <param name="exception">Failed HTTP attempt exception.</param>
    /// <param name="retryMode">Replay policy controlling whether another logical attempt is permitted.</param>
    /// <returns>
    /// Protocol, reuse, handler-lifetime, retry-policy, and TLS-integrity labels without URL, token, body, or identity.
    /// </returns>
    /// <remarks>
    /// A TLS record failure occurs before an HTTP response version exists; other exceptions report not-captured.
    /// The caller separately logs the sanitized endpoint path under existing private diagnostics policy.
    /// </remarks>
    private static string BuildTransportDiagnostic(Exception exception, XuiV3RequestRetryMode retryMode)
    {
        var tlsRecordIntegrityFailure = IsTlsRecordIntegrityFailure(exception);
        return string.Join(", ", new[]
        {
            "requestVersion=1.1",
            "versionPolicy=exact",
            "responseVersion=" + (tlsRecordIntegrityFailure ? "unavailable-before-http" : "not-captured"),
            "connectionReuse=false",
            "connectionClose=true",
            "handlerScope=single-attempt",
            "failedHandlerDisposed=true",
            "tlsRecordIntegrityFailure=" + tlsRecordIntegrityFailure.ToString().ToLowerInvariant(),
            "retryMode=" + retryMode
        });
    }

    /// <summary>
    /// Checks whether an HTTP status code represents a temporary panel or gateway failure.
    /// </summary>
    /// <param name="statusCode">Numeric HTTP status code returned by 3x-ui or the proxy in front of it.</param>
    /// <returns>
    /// <c>true</c> for HTTP 408, 429, 502, 503, 504, and Cloudflare 520-527 gateway failures; otherwise
    /// <c>false</c>. Business 4xx errors are intentionally excluded.
    /// </returns>
    private static bool IsTransientXuiStatusCode(int statusCode)
    {
        return statusCode == 408 ||
               statusCode == 429 ||
               statusCode == 502 ||
               statusCode == 503 ||
               statusCode == 504 ||
               statusCode is >= 520 and <= 527;
    }

    /// <summary>
    /// Looks for common transport error fragments emitted by .NET, OpenSSL, proxies, and Telegram-hosted Linux builds.
    /// </summary>
    /// <param name="message">Exception message from any level of the exception chain.</param>
    /// <returns><c>true</c> when the text describes a retryable transport failure.</returns>
    private static bool ContainsTransientXuiTransportMarker(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("HttpClient.Timeout", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("request timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("decryption failed", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("bad record mac", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("SSL_ERROR_SSL", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("connection reset", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("forcibly closed", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("broken pipe", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("No such host", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("Name or service not known", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("Bad Gateway", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("gateway timeout", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("service unavailable", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Calculates the bounded exponential backoff delay for a retry attempt.
    /// </summary>
    /// <param name="appConfig">Runtime configuration containing XUI v3 retry delay settings.</param>
    /// <param name="failedAttempt">The 1-based attempt number that just failed.</param>
    /// <returns>A delay between the configured base and maximum retry delay.</returns>
    private static TimeSpan GetXuiRetryDelay(AppConfig appConfig, int failedAttempt)
    {
        var baseDelay = appConfig.XuiV3TransientRetryBaseDelayMs <= 0
            ? DefaultXuiV3TransientRetryBaseDelayMs
            : appConfig.XuiV3TransientRetryBaseDelayMs;
        var maxDelay = appConfig.XuiV3TransientRetryMaxDelayMs <= 0
            ? DefaultXuiV3TransientRetryMaxDelayMs
            : appConfig.XuiV3TransientRetryMaxDelayMs;
        var multiplier = Math.Pow(2, Math.Max(0, failedAttempt - 1));
        var delayMs = Math.Min(maxDelay, baseDelay * multiplier);
        return TimeSpan.FromMilliseconds(delayMs);
    }

    /// <summary>
    /// Enumerates an exception and all nested inner exceptions from outermost to innermost.
    /// </summary>
    /// <param name="exception">Root exception caught from an XUI v3 request or Telegram update handler.</param>
    /// <returns>An enumerable containing the root exception followed by its inner exceptions.</returns>
    private static IEnumerable<Exception> FlattenExceptionChain(Exception exception)
    {
        for (var current = exception; current != null; current = current.InnerException)
            yield return current;
    }

    /// <summary>
    /// Creates fresh HTTP content for a request attempt from a JSON body or prebuilt content.
    /// </summary>
    /// <param name="body">
    /// Request body object. JSON objects are serialized into a new <see cref="StringContent"/> for every attempt.
    /// Prebuilt <see cref="HttpContent"/> values should only be used by non-retried legacy callers.
    /// </param>
    /// <returns>A disposable HTTP content object, or <c>null</c> for body-less requests.</returns>
    private static HttpContent BuildContent(object body)
    {
        if (body is HttpContent httpContent)
            return httpContent;

        return body == null
            ? null
            : new StringContent(SerializeBody(body), Encoding.UTF8, "application/json");
    }

    /// <summary>
    /// Serializes a request body for exception diagnostics without exposing bearer tokens.
    /// </summary>
    /// <param name="body">The request body object passed to an XUI v3 API helper.</param>
    /// <returns>A JSON string, a content placeholder, or <c>null</c> when no body was sent.</returns>
    private static string SerializeBodyForLog(object body)
    {
        return body is HttpContent ? "<http-content>" : SerializeBody(body);
    }

    /// <summary>Builds one authenticated HTTP/1.1 request with connection reuse explicitly disabled.</summary>
    /// <param name="method">Panel endpoint HTTP method.</param>
    /// <param name="uri">Fully resolved panel URI; it may contain an account path and must remain private.</param>
    /// <param name="content">Fresh per-attempt content, or null for a bodyless request.</param>
    /// <param name="serverInfo">Panel descriptor containing the bearer-token source.</param>
    /// <param name="configuration">Fallback bearer-token configuration.</param>
    /// <param name="authenticate">Whether to attach panel authentication.</param>
    /// <returns>A caller-owned request that must be disposed after its single send.</returns>
    /// <remarks>
    /// Exact HTTP/1.1 plus <c>Connection: close</c> makes connection behavior deterministic for the affected reverse
    /// proxy and prevents a TLS record-integrity failure from leaving a reusable connection in the application.
    /// </remarks>
    private static HttpRequestMessage BuildRequest(
        HttpMethod method,
        Uri uri,
        HttpContent content,
        ServerInfo serverInfo,
        IConfiguration configuration,
        bool authenticate)
    {
        var request = new HttpRequestMessage(method, uri);
        request.Version = HttpVersion.Version11;
        request.VersionPolicy = HttpVersionPolicy.RequestVersionExact;
        request.Headers.ConnectionClose = true;

        if (authenticate)
        {
            var token = ResolveBearerToken(serverInfo, configuration);
            if (!string.IsNullOrWhiteSpace(token))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", StripBearerPrefix(token));
        }

        if (content != null)
            request.Content = content;

        return request;
    }

    private static Uri BuildPanelUri(ServerInfo serverInfo, string relativePath, IDictionary<string, string> query)
    {
        if (serverInfo == null)
            throw new ArgumentNullException(nameof(serverInfo));
        if (string.IsNullOrWhiteSpace(serverInfo.Url))
            throw new InvalidOperationException("ServerInfo.Url is required.");

        var baseUrl = serverInfo.Url.TrimEnd('/');
        var rootPath = (serverInfo.RootPath ?? "").Trim('/');
        var path = string.IsNullOrWhiteSpace(relativePath) ? "/" : relativePath;
        if (!path.StartsWith("/"))
            path = "/" + path;

        if (!string.IsNullOrWhiteSpace(rootPath) &&
            !path.StartsWith("/" + rootPath + "/", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(path, "/" + rootPath, StringComparison.OrdinalIgnoreCase))
        {
            path = "/" + rootPath + path;
        }

        var queryString = BuildQueryString(query);
        return new Uri(baseUrl + path + queryString);
    }

    private static string BuildQueryString(IDictionary<string, string> query)
    {
        if (query == null || query.Count == 0)
            return "";

        var parts = query
            .Where(kv => kv.Value != null)
            .Select(kv => $"{Uri.EscapeDataString(kv.Key)}={Uri.EscapeDataString(kv.Value)}");
        return "?" + string.Join("&", parts);
    }

    private static string ResolveBearerToken(ServerInfo serverInfo, IConfiguration configuration)
    {
        var appConfig = configuration?.Get<AppConfig>();
        return !string.IsNullOrWhiteSpace(serverInfo.ApiToken)
            ? serverInfo.ApiToken
            : appConfig?.XuiV3ApiToken;
    }

    private static string StripBearerPrefix(string token)
    {
        const string prefix = "Bearer ";
        return token.Trim().StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? token.Trim().Substring(prefix.Length)
            : token.Trim();
    }

    private static string SerializeBody(object body)
    {
        return body == null ? null : JsonConvert.SerializeObject(body, JsonSettings);
    }

    private static string EscapePath(string value)
    {
        return Uri.EscapeDataString(value ?? "");
    }

    /// <summary>
    /// Builds the client object that is sent to the XUI v3 <c>addClient</c> API.
    /// </summary>
    /// <param name="accountDto">
    /// User-facing account request from the bot flow. It supplies Telegram owner id, selected period, service key,
    /// traffic fallback, generated email counter, and target panel information.
    /// </param>
    /// <param name="options">
    /// Resolved v3 creation options from the purchase service, including traffic bytes, duration, IP limit, comment
    /// metadata, subscription id override, and first-use-expiry behavior.
    /// </param>
    /// <returns>
    /// A panel payload with traffic limit in bytes, expiry time in milliseconds, Telegram id, subscription id, and JSON
    /// comment metadata. The UUID is intentionally left to 3x-ui so the returned result can use the panel's real value.
    /// </returns>
    /// <remarks>
    /// After the add request succeeds, <see cref="CreateUserAccountAsync"/> reads the client back from the panel and
    /// exposes that real panel UUID through <see cref="XuiV3AccountCreationResult.Uuid"/>. Do not generate an arbitrary
    /// UUID here, because the Gozargah website sync must match the account actually stored in 3x-ui.
    /// </remarks>
    private static XuiV3ClientPayload BuildClientPayload(AccountDto accountDto, XuiV3CreateAccountOptions options)
    {
        var trafficGb = options.TrafficGb > 0 ? options.TrafficGb : Convert.ToInt32(accountDto.TotoalGB);
        var trafficBytes = options.TrafficBytes > 0 ? options.TrafficBytes : ApiService.ConvertGBToBytes(trafficGb);
        var durationDays = options.DurationDays
            ?? ApiService.ConvertPeriodToDays(accountDto.SelectedPeriod);

        var email = string.IsNullOrWhiteSpace(options.Email)
            ? AccountGenerator.GenerateRandomAccountName()
            : options.Email;

        if (accountDto.AccountCounter > 0)
            email += "_" + accountDto.AccountCounter;

        var expiryTime = durationDays <= 0
            ? 0
            : DateTimeOffset.UtcNow.AddDays(durationDays).ToUnixTimeMilliseconds();

        if (options.StartExpiryAfterFirstUse && durationDays > 0)
            expiryTime = -(long)TimeSpan.FromDays(durationDays).TotalMilliseconds;

        return new XuiV3ClientPayload
        {
            Email = email,
            TotalGB = trafficBytes,
            ExpiryTime = expiryTime,
            TgId = accountDto.TelegramUserId,
            LimitIp = options.LimitIp,
            Enable = true,
            SubId = string.IsNullOrWhiteSpace(options.SubId) ? email : options.SubId,
            Flow = options.UseVisionFlow ? "xtls-rprx-vision" : null,
            Comment = options.Comment
        };
    }

    /// <summary>
    /// Extracts the real panel UUID from a direct VLESS or VMess link returned by 3x-ui.
    /// </summary>
    /// <param name="configLink">
    /// Direct configuration link returned by <c>GetClientLinksAsync</c>. VLESS links store the UUID before
    /// <c>@</c>; VMess links store it in the decoded JSON <c>id</c> field.
    /// </param>
    /// <param name="uuid">Extracted UUID when the method returns <c>true</c>; otherwise <c>null</c>.</param>
    /// <returns><c>true</c> when a valid UUID was found in the panel-generated link; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// This is a fallback for panels that omit <c>uuid</c> from the client lookup response but still return a valid
    /// direct config link. The value is panel-derived and must not be replaced with a locally generated UUID.
    /// </remarks>
    private static bool TryExtractUuidFromConfigLink(string configLink, out string uuid)
    {
        uuid = null;
        if (string.IsNullOrWhiteSpace(configLink))
            return false;

        var value = configLink.Trim();
        if (value.StartsWith("vless://", StringComparison.OrdinalIgnoreCase))
        {
            var rest = value["vless://".Length..];
            var atIndex = rest.IndexOf('@');
            if (atIndex > 0 && Guid.TryParse(rest[..atIndex], out var parsed))
            {
                uuid = parsed.ToString();
                return true;
            }
        }

        if (value.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase))
        {
            var encoded = value["vmess://".Length..].Trim();
            try
            {
                encoded = encoded.PadRight(encoded.Length + ((4 - encoded.Length % 4) % 4), '=');
                var json = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
                var token = JObject.Parse(json);
                var candidate = token["id"]?.ToString();
                if (Guid.TryParse(candidate, out var parsed))
                {
                    uuid = parsed.ToString();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        return false;
    }

    public static string BuildSubscriptionLink(ServerInfo serverInfo, string subId)
    {
        if (serverInfo == null || string.IsNullOrWhiteSpace(subId))
            return null;

        if (!string.IsNullOrWhiteSpace(serverInfo.SubLinkUrl))
            return serverInfo.SubLinkUrl.TrimEnd('/') + "/" + subId;

        if (string.IsNullOrWhiteSpace(serverInfo.Url))
            return null;

        var baseUrl = serverInfo.Url.TrimEnd('/');
        var rootPath = (serverInfo.RootPath ?? string.Empty).Trim('/');
        var subPath = string.IsNullOrWhiteSpace(rootPath)
            ? "sub"
            : rootPath + "/sub";

        return baseUrl + "/" + subPath + "/" + EscapePath(subId);
    }
}

public enum XuiPanelApiVersion
{
    Unknown = 0,
    V2 = 2,
    V3 = 3
}

public class XuiV3ApiResponse<T>
{
    [JsonProperty("success")]
    public bool Success { get; set; }

    [JsonProperty("msg")]
    public string Msg { get; set; }

    [JsonProperty("obj")]
    public T Obj { get; set; }
}

/// <summary>
/// Represents a failed XUI v3 HTTP request while keeping its public exception message free of panel secrets.
/// </summary>
/// <remarks>
/// <see cref="RequestUri"/>, <see cref="ResponseBody"/>, and <see cref="RequestBody"/> are internal diagnostic data
/// and must never be sent to Telegram users. The base <see cref="Exception.Message"/> deliberately contains only
/// the status code and method so accidental user-facing exception rendering cannot disclose the private panel host,
/// root path, endpoint, response, token, cookie, or request payload.
/// </remarks>
public class XuiV3ApiException : Exception
{
    /// <summary>HTTP method used by the failed panel request.</summary>
    public string RequestMethod { get; }

    /// <summary>
    /// Full private panel request URI retained only for internal diagnostics. Never expose this value to Telegram.
    /// </summary>
    public string RequestUri { get; }

    /// <summary>Numeric HTTP status code, or zero when no HTTP response was received.</summary>
    public int StatusCode { get; }

    /// <summary>Raw panel/proxy response retained only for internal diagnostics.</summary>
    public string ResponseBody { get; }

    /// <summary>Sanitized request body snapshot retained only for internal diagnostics.</summary>
    public string RequestBody { get; }

    /// <summary>
    /// Creates a redacted XUI v3 request exception with separate internal diagnostic properties.
    /// </summary>
    /// <param name="requestMethod">HTTP method used for the failed request.</param>
    /// <param name="requestUri">
    /// Full private panel URI. It is required for internal diagnostics but must never be displayed to Telegram users.
    /// </param>
    /// <param name="statusCode">HTTP response status, or zero for a transport failure without a response.</param>
    /// <param name="responseBody">Raw provider response retained internally; it may be empty.</param>
    /// <param name="requestBody">Sanitized request snapshot retained internally; it may be empty.</param>
    /// <remarks>
    /// Log diagnostic properties only to trusted operational sinks. User-facing code must call
    /// <see cref="XuiV3UserSafeError.ForAccountCreation(Exception)"/> instead of rendering this exception.
    /// </remarks>
    public XuiV3ApiException(string requestMethod, string requestUri, int statusCode, string responseBody, string requestBody)
        : base($"XUI v3 request failed with HTTP status {statusCode} for {requestMethod}.")
    {
        RequestMethod = requestMethod;
        RequestUri = requestUri;
        StatusCode = statusCode;
        ResponseBody = responseBody;
        RequestBody = requestBody;
    }
}

/// <summary>Resolved provisioning inputs and private persistence dependencies for one XUI v3 account.</summary>
/// <remarks>OperationKey identifies the business intent. Mutable display identifiers never replace its durable reservation.</remarks>
public class XuiV3CreateAccountOptions
{
    /// <summary>Optional stable purchase/order-account key; repeated invocations become GET-only recovery.</summary>
    public string OperationKey { get; set; }
    /// <summary>Required durable reservation store when OperationKey is provided; never serialized or logged.</summary>
    [JsonIgnore]
    public XuiV3CreationOperationStore OperationStore { get; set; }
    /// <summary>
    /// Optional durable identity of the explicit event that authorized a tenant retry generation; persisted on the
    /// reservation and reused only for replay detection. Restricted non-secret value, never customer text.
    /// </summary>
    public string AuthorizedByKey { get; set; }
    /// <summary>Optional nonnegative confirmed catalog price in toman, included in immutable intent comparison; no debit is performed here.</summary>
    public long? PriceToman { get; set; }
    /// <summary>Required positive x-ui inbound identifiers belonging to the selected panel.</summary>
    public IEnumerable<int> InboundIds { get; set; }
    /// <summary>Whether to persist delivery state for the active bot and Telegram owner after creation.</summary>
    public bool SaveUserStatus { get; set; } = true;
    /// <summary>Display quota in GB; zero uses the account request fallback.</summary>
    public int TrafficGb { get; set; }
    /// <summary>Authoritative quota in bytes when positive; otherwise derived from GB.</summary>
    public long TrafficBytes { get; set; }
    /// <summary>Lifetime in whole days; null uses the legacy selected-period value, and zero means unlimited.</summary>
    public int? DurationDays { get; set; }
    /// <summary>Panel IP/device limit; zero leaves the panel's unlimited convention.</summary>
    public int LimitIp { get; set; }
    /// <summary>Optional exact account email; a generated name is durably reserved when absent.</summary>
    public string Email { get; set; }
    /// <summary>Optional private subscription identifier; never log it or include it in diagnostic metadata.</summary>
    public string SubId { get; set; }
    /// <summary>Private ownership and plan JSON sent as the panel comment.</summary>
    public string Comment { get; set; }
    /// <summary>Whether to request the Vision flow for the created client.</summary>
    public bool UseVisionFlow { get; set; }
    /// <summary>Whether the panel should start the duration on first use using its negative-millisecond convention.</summary>
    public bool StartExpiryAfterFirstUse { get; set; }
}

/// <summary>
/// Result returned after the bot creates one XUI v3 client on the configured 3x-ui panel.
/// </summary>
/// <remarks>
/// The object is used both for Telegram delivery and for downstream integrations such as tenant order
/// fulfillment and the Gozargah site sync outbox. Values come from the panel payload that was accepted by
/// 3x-ui, so callers may safely use <see cref="Email"/>, <see cref="Uuid"/>, and <see cref="SubId"/> as
/// idempotency keys for external systems after <see cref="Success"/> is <c>true</c>.
/// </remarks>
public class XuiV3AccountCreationResult
{
    /// <summary>
    /// Indicates whether 3x-ui accepted the client creation request.
    /// </summary>
    public bool Success { get; set; }

    /// <summary>
    /// API version used for the successful or failed panel operation.
    /// </summary>
    public XuiPanelApiVersion ApiVersion { get; set; }

    /// <summary>
    /// Fixed user-safe result message suitable for Telegram. Raw panel responses and exception messages must never
    /// be assigned to this property.
    /// </summary>
    public string Message { get; set; }

    /// <summary>
    /// XUI client email/name generated by the bot and used as the main account identifier.
    /// </summary>
    public string Email { get; set; }

    /// <summary>
    /// UUID assigned to the XUI client. This value is required by VLESS links and by website sync payloads.
    /// </summary>
    public string Uuid { get; set; }

    /// <summary>
    /// Subscription id attached to the client. When empty, callers usually fall back to <see cref="Email"/>.
    /// </summary>
    public string SubId { get; set; }

    /// <summary>
    /// Direct configuration link returned or built for the created account.
    /// </summary>
    public string ConfigLink { get; set; }

    /// <summary>
    /// Subscription URL that can be sent to the Telegram user.
    /// </summary>
    public string SubLink { get; set; }

    /// <summary>
    /// Traffic allowance in gigabytes for display and audit metadata.
    /// </summary>
    public int TrafficGb { get; set; }

    /// <summary>
    /// Traffic allowance in bytes as sent to the 3x-ui panel.
    /// </summary>
    public long TrafficBytes { get; set; }

    /// <summary>
    /// Expiry timestamp in milliseconds, or a negative first-use duration for unlimited accounts.
    /// </summary>
    public long ExpiryTime { get; set; }

    /// <summary>
    /// Duration in days selected by the user, or <c>null</c> when the plan does not have a fixed day count.
    /// </summary>
    public int? DurationDays { get; set; }

    /// <summary>
    /// JSON comment stored on the XUI client. It contains bot, user, service, plan, and audit metadata.
    /// </summary>
    public string Comment { get; set; }

    /// <summary>
    /// XUI inbound ids used when attaching the client to the panel.
    /// </summary>
    public List<int> InboundIds { get; set; } = new List<int>();

    /// <summary>
    /// Raw panel response retained for diagnostics. Do not expose this value directly to Telegram users.
    /// </summary>
    public JToken RawResponse { get; set; }
}

public class XuiV3ClientCreateRequest
{
    [JsonProperty("client")]
    public XuiV3ClientPayload Client { get; set; }

    [JsonProperty("inboundIds")]
    public List<int> InboundIds { get; set; } = new List<int>();
}

public class XuiV3ClientPayload
{
    [JsonProperty("email")]
    public string Email { get; set; }

    /// <summary>
    /// Protocol UUID read from the global clients API's <c>uuid</c> response property.
    /// </summary>
    /// <remarks>
    /// This is an internal canonical property. Before an update request is sent,
    /// <see cref="ApiServicev3.UpdateClientAsync"/> maps it to the 3x-ui wire-client property <c>id</c>; it must not be
    /// serialized directly as <c>uuid</c> in an update body.
    /// </remarks>
    [JsonProperty("uuid")]
    public string Uuid { get; set; }

    [JsonProperty("password")]
    public string Password { get; set; }

    [JsonProperty("totalGB")]
    public long TotalGB { get; set; }

    [JsonProperty("expiryTime")]
    public long ExpiryTime { get; set; }

    [JsonProperty("tgId")]
    public long TgId { get; set; }

    [JsonProperty("limitIp")]
    public int LimitIp { get; set; }

    [JsonProperty("enable")]
    public bool Enable { get; set; } = true;

    [JsonProperty("subId")]
    public string SubId { get; set; }

    [JsonProperty("flow")]
    public string Flow { get; set; }

    [JsonProperty("comment")]
    public string Comment { get; set; }

    [JsonProperty("group")]
    public string Group { get; set; }

    [JsonProperty("reverse")]
    public JToken Reverse { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3Client : XuiV3ClientPayload
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("inboundIds")]
    public List<int> InboundIds { get; set; } = new List<int>();

    [JsonProperty("traffic")]
    public XuiV3ClientTraffic Traffic { get; set; }
}

public class XuiV3ClientTraffic
{
    [JsonProperty("email")]
    public string Email { get; set; }

    [JsonProperty("up")]
    public long Up { get; set; }

    [JsonProperty("down")]
    public long Down { get; set; }

    [JsonProperty("total")]
    public long Total { get; set; }

    [JsonProperty("totalGB")]
    public long TotalGB { get; set; }

    [JsonProperty("expiryTime")]
    public long ExpiryTime { get; set; }

    [JsonProperty("enable")]
    public bool Enable { get; set; }
}

public class XuiV3ClientPageQuery
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 25;
    public string Search { get; set; }
    public string Filter { get; set; }
    public string Protocol { get; set; }
    public string Sort { get; set; }
    public string Order { get; set; }
}

public class XuiV3ClientGroup
{
    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("count")]
    public int Count { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3Inbound
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("userId")]
    public int UserId { get; set; }

    [JsonProperty("up")]
    public long Up { get; set; }

    [JsonProperty("down")]
    public long Down { get; set; }

    [JsonProperty("total")]
    public long Total { get; set; }

    [JsonProperty("remark")]
    public string Remark { get; set; }

    [JsonProperty("enable")]
    public bool Enable { get; set; } = true;

    [JsonProperty("expiryTime")]
    public long ExpiryTime { get; set; }

    [JsonProperty("listen")]
    public string Listen { get; set; }

    [JsonProperty("port")]
    public int Port { get; set; }

    [JsonProperty("protocol")]
    public string Protocol { get; set; }

    [JsonProperty("settings")]
    public JToken Settings { get; set; }

    [JsonProperty("streamSettings")]
    public JToken StreamSettings { get; set; }

    [JsonProperty("tag")]
    public string Tag { get; set; }

    [JsonProperty("sniffing")]
    public JToken Sniffing { get; set; }

    [JsonProperty("clientStats")]
    public JToken ClientStats { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3InboundOption
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("remark")]
    public string Remark { get; set; }

    [JsonProperty("protocol")]
    public string Protocol { get; set; }

    [JsonProperty("port")]
    public int Port { get; set; }

    [JsonProperty("tlsFlowCapable")]
    public bool TlsFlowCapable { get; set; }
}

public class XuiV3Node
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("remark")]
    public string Remark { get; set; }

    [JsonProperty("scheme")]
    public string Scheme { get; set; } = "https";

    [JsonProperty("address")]
    public string Address { get; set; }

    [JsonProperty("port")]
    public int Port { get; set; }

    [JsonProperty("basePath")]
    public string BasePath { get; set; } = "/";

    [JsonProperty("apiToken")]
    public string ApiToken { get; set; }

    [JsonProperty("enable")]
    public bool Enable { get; set; } = true;

    [JsonProperty("allowPrivateAddress")]
    public bool AllowPrivateAddress { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3CustomGeoSource
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("type")]
    public string Type { get; set; }

    [JsonProperty("alias")]
    public string Alias { get; set; }

    [JsonProperty("url")]
    public string Url { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3ServerStatus
{
    [JsonProperty("cpu")]
    public decimal Cpu { get; set; }

    [JsonProperty("mem")]
    public XuiV3SizePair Mem { get; set; }

    [JsonProperty("swap")]
    public XuiV3SizePair Swap { get; set; }

    [JsonProperty("disk")]
    public XuiV3SizePair Disk { get; set; }

    [JsonProperty("netIO")]
    public XuiV3NetIo NetIO { get; set; }

    [JsonProperty("xray")]
    public XuiV3XrayState Xray { get; set; }

    [JsonProperty("tcpCount")]
    public int TcpCount { get; set; }

    [JsonProperty("load")]
    public JToken Load { get; set; }

    [JsonExtensionData]
    public IDictionary<string, JToken> Extra { get; set; }
}

public class XuiV3SizePair
{
    [JsonProperty("current")]
    public long Current { get; set; }

    [JsonProperty("total")]
    public long Total { get; set; }
}

public class XuiV3NetIo
{
    [JsonProperty("up")]
    public long Up { get; set; }

    [JsonProperty("down")]
    public long Down { get; set; }
}

public class XuiV3XrayState
{
    [JsonProperty("state")]
    public string State { get; set; }

    [JsonProperty("version")]
    public string Version { get; set; }
}

public class XuiV3ApiTokenInfo
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("enabled")]
    public bool Enabled { get; set; }

    [JsonProperty("createdAt")]
    public long CreatedAt { get; set; }
}

public class XuiV3ApiTokenCreated : XuiV3ApiTokenInfo
{
    [JsonProperty("token")]
    public string Token { get; set; }
}

/// <summary>
/// Exact JSON body accepted by <c>POST /panel/api/clients/updateTraffic/{email}</c>.
/// </summary>
/// <remarks>
/// Proved against upstream 3x-ui v3.7.0/v3.4.2 <c>ClientController.updateTrafficByEmail</c>, which binds struct
/// fields tagged <c>json:"upload"</c> and <c>json:"download"</c>. Every property carries an explicit
/// <see cref="JsonPropertyAttribute" /> so a future C# rename cannot silently change the wire contract: the panel ignores
/// unknown fields and would answer HTTP 200 while storing zero, which is data loss rather than an error.
///
/// Both values are absolute counters, not deltas, and this endpoint changes nothing except the single shared
/// <c>client_traffics</c> row selected by email.
/// </remarks>
internal sealed class XuiV3TrafficUpdateRequest
{
    /// <summary>Absolute uploaded byte counter to store in <c>client_traffics.up</c>.</summary>
    [JsonProperty("upload")]
    public long Upload { get; set; }

    /// <summary>Absolute downloaded byte counter to store in <c>client_traffics.down</c>.</summary>
    [JsonProperty("download")]
    public long Download { get; set; }
}
