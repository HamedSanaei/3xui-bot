using System.Text.RegularExpressions;
using System.Diagnostics;
using Adminbot.Domain;
using Adminbot.Utils;

using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

using System.Globalization;
using System;
using System.Text;

using Adminbot.Domain.Logging;
using Newtonsoft.Json.Linq;

/// <summary>
/// Shared Telegram update dispatcher for owned brand bots and tenant storefront bots.
/// </summary>
/// <remarks>
/// The class still contains the legacy single-bot business flows, but multi-instance runtime now enters it through
/// <see cref="DispatchUpdateAsync"/> with a <see cref="BotRuntimeContext"/>. The current bot context selects the
/// correct token, brand config, mandatory-join channels, support account, payment return URLs, and bot-scoped user state.
/// </remarks>
public partial class TelegramBotService
{
    private const string BroadcastAudienceAll = "all";
    private const string BroadcastAudienceCustomers = "customers";
    private const string BroadcastAudienceColleagues = "colleagues";
    private const int MaxAccountInfoMessagesPerRequest = 5;

    /// <summary>
    /// Reply-keyboard entry that opens the global super-admin panel inside an owned bot.
    /// </summary>
    /// <remarks>
    /// This is privileged high-priority navigation: it must be routed before every stale XUI/customer/renewal/
    /// colleague sub-flow and never depends on service plans, panels, payments, or other stateful handlers.
    /// </remarks>
    private const string AdminPanelEntryAction = "🗽 Admin";

    /// <summary>Fixed Persian greeting shown when the super-admin panel opens.</summary>
    private const string AdminPanelGreetingText = "پنل مدیریت";

    /// <summary>
    /// Reply-keyboard escape that returns a super-admin from any owned-bot admin panel back to the main menu.
    /// </summary>
    private const string AdminMenuExitAction = "📑 Menu";

    /// <summary>Legacy English greeting shown when the owned-bot main menu is returned to.</summary>
    private const string MainMenuGreetingText = "Main Menu:";

    /// <summary>
    /// Panel label that promotes a user to colleague (modifies only <c>CredUser.IsColleague</c>).
    /// </summary>
    /// <remarks>The action never changes the configuration-controlled <c>AdminsUserIds</c> allow-list.</remarks>
    private const string PromoteColleagueAction = "🤝 همکار کردن کاربر";

    /// <summary>
    /// Panel label that demotes a colleague back to a normal customer (modifies only <c>CredUser.IsColleague</c>).
    /// </summary>
    /// <remarks>The action never changes the configuration-controlled <c>AdminsUserIds</c> allow-list.</remarks>
    private const string DemoteColleagueAction = "👤 لغو همکاری کاربر";

    /// <summary>
    /// Reply-keyboard action that starts the super-admin manual phone verification flow for an owned-bot user.
    /// </summary>
    private const string AdminVerifyPhoneAction = "📱 تایید دستی شماره تلفن";

    /// <summary>
    /// Reply-keyboard action that shows usage for the seven most recent completed Tehran days.
    /// </summary>
    private const string AdminWeeklyUsageAction = "📊 آمار هفتگی";

    /// <summary>
    /// Reply-keyboard action that shows usage for the thirty most recent completed Tehran days.
    /// </summary>
    private const string AdminMonthlyUsageAction = "📈 آمار ماهانه";

    /// <summary>
    /// Reply-keyboard action that opens the super-admin live payment-gateway switch panel.
    /// </summary>
    private const string AdminPaymentGatewayAction = "⚙️ مدیریت درگاه‌ها";

    /// <summary>
    /// Conversation-state step that waits for the target user's numeric Telegram id.
    /// </summary>
    private const string AdminPhoneUserIdStep = "admin-phone-user-id";

    /// <summary>
    /// Conversation-state step prefix that waits for an international or local phone number.
    /// </summary>
    private const string AdminPhoneNumberStep = "admin-phone-number";

    /// <summary>
    /// Conversation-state step prefix that waits for the super-admin's final confirmation.
    /// </summary>
    private const string AdminPhoneConfirmationStep = "admin-phone-confirm";

    /// <summary>
    /// Positive confirmation label used only by the manual phone verification flow.
    /// </summary>
    private const string ConfirmAdminPhoneButton = "✅ تایید شماره تلفن";

    /// <summary>
    /// Cancellation label used only by the manual phone verification flow.
    /// </summary>
    private const string CancelAdminPhoneButton = "❌ انصراف";

    /// <summary>
    /// Owned-wallet HooshPay action label with its displayed customer fee and its rial-payment marker.
    /// </summary>
    /// <remarks>
    /// The trailing <c>| ریالی</c> marker tells the customer this gateway settles in Iranian tomans. The gateway name,
    /// emoji, and fee text are preserved exactly as before; only the marker was appended. This constant is also compared
    /// against the customer's reply-keyboard text, so both the button and the match must stay in sync.
    /// </remarks>
    private const string HooshPayGatewayAction = "⚡ هوش‌پی آنی | کارمزد ۱۵٪ | ریالی";

    /// <summary>
    /// Owned-wallet Tetraminator action label with its displayed customer fee and its rial-payment marker.
    /// </summary>
    private const string TetraminatorGatewayAction = "⚡ تترامیناتور آنی | کارمزد ۱۲٪ | ریالی";

    /// <summary>
    /// Owned-wallet UniquePay action label with its displayed gateway fee and its rial-payment marker.
    /// </summary>
    private const string UniquePayGatewayAction = "⚡ یونیک‌پی آنی | کارمزد ۱۲٪ | ریالی";

    /// <summary>
    /// Owned-wallet AtlasPay action label with its card-to-card wording and its rial-payment marker.
    /// </summary>
    private const string AtlasPayGatewayAction = "💳 اطلس‌پی | کارت‌به‌کارت آنی | ریالی";

    /// <summary>
    /// Owned-wallet NOWPayments (cryptocurrency) action label with its displayed zero-fee policy.
    /// </summary>
    /// <remarks>
    /// Deliberately carries no <c>ریالی</c> marker: it settles in cryptocurrency, not Iranian tomans. Do not add the
    /// rial marker here even if other gateway labels change.
    /// </remarks>
    private const string CryptoGatewayAction = "⚡ ارز دیجیتال آنی | کارمزد ۰٪";

    /// <summary>
    /// Bot-scoped callback that abandons an insufficient-balance purchase or renewal and opens the owned-wallet charge flow.
    /// </summary>
    internal const string WalletChargeShortcutCallback = "wallet:charge";

    /// <summary>Customer-facing label shown below owned purchase and renewal insufficient-balance messages.</summary>
    internal const string WalletChargeShortcutLabel = "💰 افزایش موجودی کیف پول";

    private readonly ITelegramBotClient _botClient;
    private readonly UserWorkflowStore _workflow;
    /// <summary>Independent bot/user state operations; no EF context is retained by the store.</summary>
    private readonly UserStateStore _state;
    private readonly CredentialsStore _credentialsDbContext;
    private readonly IConfiguration _configuration;
    private readonly AppConfig _appConfig;
    private readonly ILogger<TelegramBotService> _logger;
    private BroadcastManager _broadcastManager;
    private readonly NowPayments _nowPayments;
    private readonly NowPaymentsSettlementService _nowPaymentsSettlementService;
    private readonly HooshPay _hooshPay;
    private readonly HooshPaySettlementService _hooshPaySettlementService;
    private readonly Tetraminator _tetraminator;
    private readonly TetraminatorSettlementService _tetraminatorSettlementService;
    private readonly UniquePay _uniquePay;
    private readonly UniquePayReconciliationHostedService _uniquePayReconciliation;
    private readonly AtlasPay _atlasPay;
    private readonly AtlasPayReconciliationHostedService _atlasPayReconciliation;
    private readonly IPaymentGatewayAvailability _gatewayAvailability;
    private readonly IClientDownloadAvailability _clientDownloadAvailability;
    private readonly IClientReleaseService _clientReleaseService;
    private readonly XuiV3PurchaseService _xuiV3PurchaseService;
    private readonly XuiV3BotFlowService _xuiV3BotFlowService;
    private readonly XuiV3PurchaseSessionStore _xuiV3PurchaseSessionStore;
    private readonly XuiV3AdminFlowService _xuiV3AdminFlowService;
    private readonly TenantBotService _tenantBotService;
    private readonly SalesAssistantService _salesAssistantService;
    private readonly UserActivityLogService _userActivityLog;
    private readonly UsageAnalyticsService _usageAnalyticsService;
    private readonly UsageReportChartRenderer _usageReportChartRenderer;
    private readonly WalletLedgerService _walletLedgerService;
    /// <summary>Global owned-bot referral engine used by start links, dashboards, and legacy Zibal settlement.</summary>
    private readonly ReferralService _referralService;
    private readonly OwnedBotNotificationService _ownedBotNotificationService;
    private readonly GozargahSiteApiClient _gozargahSiteApiClient;
    private readonly GozargahSiteSyncService _gozargahSiteSyncService;
    private readonly BotRegistry _botRegistry;
    private readonly BotRuntimeStatusStore _botRuntimeStatusStore;
    private readonly BotContextAccessor _botContextAccessor;

    /// <summary>
    /// Immutable latency budgets for UX-only Telegram interactions (callback acknowledgement and mandatory-join
    /// membership verification). Injected so timeout behaviour can be proven by tests without waiting the real
    /// production budgets, while production always uses <see cref="TelegramInteractionTimeouts.Production"/>.
    /// </summary>
    private readonly TelegramInteractionTimeouts _interactionTimeouts;
    private ITelegramBotClient ActiveBotClient => _botContextAccessor.Current?.Client ?? _botClient;
    private BotInstanceConfig CurrentBot => _botContextAccessor.Current?.Config;
    private IEnumerable<string> CurrentChannelIds => CurrentBot != null
        ? CurrentBot.ChannelIds ?? Enumerable.Empty<string>()
        : _appConfig.ChannelIds ?? Enumerable.Empty<string>();
    /// <summary>
    /// Gets the support contact configured for the currently handling owned bot.
    /// </summary>
    /// <remarks>
    /// A resolved runtime bot owns its own support setting. An empty value must remain empty instead of silently
    /// falling back to the default brand, because showing another brand's support account is customer-facingly wrong.
    /// The legacy application setting is used only when no multi-bot runtime context exists.
    /// </remarks>
    private string CurrentSupportAccount => CurrentBot != null
        ? CurrentBot.SupportAccount
        : _appConfig.SupportAccount;
    private string[] CurrentIosTutorial => CurrentBot?.IosTutorial ?? _appConfig.IosTutorial;
    private string[] CurrentAndroidTutorial => CurrentBot?.AndroidTutorial ?? _appConfig.AndroidTutorial;
    private string[] CurrentWindowsTutorial => CurrentBot?.WindowsTutorial ?? _appConfig.WindowsTutorial;
    private string CurrentNowPaymentsSuccessUrl => CurrentBot?.BuildTelegramStartUrl("payment_success") ?? _appConfig.NowpaymentSuccessUrl;
    private string CurrentNowPaymentsCancelUrl => CurrentBot?.BuildTelegramStartUrl("payment_cancel") ?? _appConfig.NowpaymentCancelUrl;
    private string CurrentHooshPayReturnUrl => CurrentBot?.BuildTelegramStartUrl("payment_success") ?? _appConfig.HooshPayReturnUrl;

    /// <summary>
    /// Refreshes the shared credentials role from the Gozargah website before owned-bot pricing is shown.
    /// </summary>
    /// <param name="credUser">
    /// Shared credentials profile of the Telegram user currently interacting with an owned bot. The instance is updated
    /// in memory when the website lookup promotes the database row to colleague.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the website lookup and credentials database update.</param>
    /// <returns>A task that completes after the optional role refresh has finished.</returns>
    /// <remarks>
    /// Tenant storefronts are excluded because their customer prices are controlled by the tenant owner's storefront
    /// settings. Owned bots sell directly for the platform, so an existing non-banned Gozargah website user receives
    /// colleague pricing immediately.
    /// </remarks>
    private async Task RefreshOwnedBotColleagueRoleFromGozargahAsync(CredUser credUser, CancellationToken cancellationToken)
    {
        var botType = CurrentBot?.Type ?? BotInstanceTypes.Owned;
        if (!string.Equals(botType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
            return;

        await _gozargahSiteSyncService.PromoteToColleagueIfConnectedSiteUserAsync(credUser, cancellationToken);
    }

    /// <summary>
    /// Creates the shared Telegram service and wires all existing bot flows plus the tenant storefront flow.
    /// </summary>
    /// <param name="botClient">Default bot client kept for legacy single-bot hosted-service compatibility.</param>
    /// <param name="stateStore">Factory-backed state reader/writer isolated by runtime bot id and Telegram user id.</param>
    /// <param name="dbContext">Runtime database that stores bot-scoped conversation state and payment metadata.</param>
    /// <param name="credentialsDb">Shared credentials database that stores profiles, wallet balances, and roles.</param>
    /// <param name="configuration">Application configuration.</param>
    /// <param name="logger">Service logger.</param>
    /// <param name="broadcastManager">Broadcast manager used by super-admin broadcast flows.</param>
    /// <param name="nowPayments">NOWPayments API client.</param>
    /// <param name="nowPaymentsSettlementService">NOWPayments wallet settlement service.</param>
    /// <param name="hooshPay">HooshPay API client.</param>
    /// <param name="hooshPaySettlementService">HooshPay wallet settlement service.</param>
    /// <param name="tetraminator">Tetraminator API client used for rial invoice creation and authoritative inquiry.</param>
    /// <param name="tetraminatorSettlementService">Idempotent Tetraminator owned-wallet settlement service.</param>
    /// <param name="uniquePay">UniquePay client used only for non-retried invoice creation.</param>
    /// <param name="uniquePayReconciliation">
    /// Shared authoritative UniquePay inquiry coordinator reused by customer check buttons.
    /// </param>
    /// <param name="gatewayAvailability">
    /// Live global gateway switches used by every button and hard invoice-creation guard.
    /// </param>
    /// <param name="xuiV3PurchaseService">Shared XuiV3 purchase/account creation service.</param>
    /// <param name="xuiV3BotFlowService">Regular user XuiV3 purchase and account-management flow.</param>
    /// <param name="xuiV3PurchaseSessionStore">
    /// Bot-scoped in-memory purchase selection store. It is cleared when a main-menu command cancels an unfinished
    /// customer flow, preventing stale plan selections from resuming after the referral dashboard is shown.
    /// </param>
    /// <param name="xuiV3AdminFlowService">Super-admin XuiV3 management flow.</param>
    /// <param name="tenantBotService">Tenant storefront owner and customer flow service.</param>
    /// <param name="salesAssistantService">Tenant receipt and colleague notification assistant flow.</param>
    /// <param name="userActivityLog">File-based user activity logger.</param>
    /// <param name="usageAnalyticsService">
    /// Shared completed-day usage aggregator used by super-admin and tenant-owner statistics.
    /// </param>
    /// <param name="usageReportChartRenderer">
    /// High-resolution line-chart renderer used to send weekly and monthly super-admin usage reports as PNG photos.
    /// </param>
    /// <param name="walletLedgerService">Append-only users.db ledger writer for every wallet mutation.</param>
    /// <param name="ownedBotNotificationService">
    /// Best-effort notifier used to reach users through the owned bots they have previously started.
    /// </param>
    /// <param name="gozargahSiteApiClient">Gozargah website API client used to show colleague site wallet status.</param>
    /// <param name="gozargahSiteSyncService">
    /// Gozargah website sync service used to auto-promote connected website users before owned-bot pricing is shown.
    /// </param>
    /// <param name="botRegistry">Runtime registry used to list configured owned, assistant, and tenant bots.</param>
    /// <param name="botRuntimeStatusStore">
    /// Process-local receiver status store used by the super-admin bot status screen.
    /// </param>
    /// <param name="botContextAccessor">Async-local current bot context accessor.</param>
    /// <param name="referralService">
    /// Global owned-bot referral service used by start payloads, user reporting, and final legacy Zibal settlement.
    /// </param>
    /// <param name="interactionTimeouts">
    /// Optional immutable budgets for UX-only Telegram interactions. When null the production budgets are used:
    /// two seconds for callback acknowledgement and one overall five-second budget for mandatory-join
    /// membership verification. Tests pass millisecond values so bounded-timeout behaviour is deterministic and
    /// fast; production dependency injection supplies the shared <see cref="TelegramInteractionTimeouts.Production"/>
    /// instance. This value is never read from configuration, so a deployment cannot raise it back to the
    /// pathological default Telegram HTTP timeout.
    /// </param>
    /// <remarks>
    /// The service belongs to one execution/request scope. Conversation and financial stores create independent
    /// users.db contexts through their factories. Runtime bot identity always comes from <see cref="BotContextAccessor"/>
    /// so support, activity attribution, and Telegram delivery remain scoped to the active owned or tenant bot.
    /// </remarks>
    public TelegramBotService(
        ITelegramBotClient botClient,
        UserWorkflowStore dbContext,
        UserStateStore stateStore,
        CredentialsStore credentialsDb,
        IConfiguration configuration,
        ILogger<TelegramBotService> logger,
        BroadcastManager broadcastManager,
        NowPayments nowPayments,
        NowPaymentsSettlementService nowPaymentsSettlementService,
        HooshPay hooshPay,
        HooshPaySettlementService hooshPaySettlementService,
        Tetraminator tetraminator,
        TetraminatorSettlementService tetraminatorSettlementService,
        UniquePay uniquePay,
        UniquePayReconciliationHostedService uniquePayReconciliation,
        AtlasPay atlasPay,
        AtlasPayReconciliationHostedService atlasPayReconciliation,
        IPaymentGatewayAvailability gatewayAvailability,
        IClientDownloadAvailability clientDownloadAvailability,
        IClientReleaseService clientReleaseService,
        XuiV3PurchaseService xuiV3PurchaseService,
        XuiV3BotFlowService xuiV3BotFlowService,
        XuiV3PurchaseSessionStore xuiV3PurchaseSessionStore,
        XuiV3AdminFlowService xuiV3AdminFlowService,
        TenantBotService tenantBotService,
        SalesAssistantService salesAssistantService,
        UserActivityLogService userActivityLog,
        UsageAnalyticsService usageAnalyticsService,
        UsageReportChartRenderer usageReportChartRenderer,
        WalletLedgerService walletLedgerService,
        OwnedBotNotificationService ownedBotNotificationService,
        GozargahSiteApiClient gozargahSiteApiClient,
        GozargahSiteSyncService gozargahSiteSyncService,
        BotRegistry botRegistry,
        BotRuntimeStatusStore botRuntimeStatusStore,
        BotContextAccessor botContextAccessor,
        ReferralService referralService,
        TelegramInteractionTimeouts interactionTimeouts = null)
    {
        _botClient = botClient;
        _workflow = dbContext;
        _state = stateStore;
        _credentialsDbContext = credentialsDb;
        _configuration = configuration;
        _appConfig = _configuration.Get<AppConfig>();
        _logger = logger;
        _broadcastManager = broadcastManager;
        _nowPayments = nowPayments;
        _nowPaymentsSettlementService = nowPaymentsSettlementService;
        _hooshPay = hooshPay;
        _hooshPaySettlementService = hooshPaySettlementService;
        _tetraminator = tetraminator;
        _tetraminatorSettlementService = tetraminatorSettlementService;
        _uniquePay = uniquePay;
        _uniquePayReconciliation = uniquePayReconciliation;
        _atlasPay = atlasPay;
        _atlasPayReconciliation = atlasPayReconciliation;
        _gatewayAvailability = gatewayAvailability;
        _clientDownloadAvailability = clientDownloadAvailability;
        _clientReleaseService = clientReleaseService;
        _xuiV3PurchaseService = xuiV3PurchaseService;
        _xuiV3BotFlowService = xuiV3BotFlowService;
        _xuiV3PurchaseSessionStore = xuiV3PurchaseSessionStore;
        _xuiV3AdminFlowService = xuiV3AdminFlowService;
        _tenantBotService = tenantBotService;
        _salesAssistantService = salesAssistantService;
        _userActivityLog = userActivityLog;
        _usageAnalyticsService = usageAnalyticsService;
        _usageReportChartRenderer = usageReportChartRenderer;
        _walletLedgerService = walletLedgerService;
        _ownedBotNotificationService = ownedBotNotificationService;
        _gozargahSiteApiClient = gozargahSiteApiClient;
        _gozargahSiteSyncService = gozargahSiteSyncService;
        _botRegistry = botRegistry;
        _botRuntimeStatusStore = botRuntimeStatusStore;
        _botContextAccessor = botContextAccessor;
        _referralService = referralService;
        _interactionTimeouts = interactionTimeouts ?? TelegramInteractionTimeouts.Production;
    }

    /// <summary>
    /// Processes one update for a specific bot runtime context.
    /// </summary>
    /// <param name="botClient">Telegram client that received the update.</param>
    /// <param name="update">Telegram update to dispatch.</param>
    /// <param name="botContext">Current bot configuration and client for this update.</param>
    /// <param name="cancellationToken">Cancellation token from Telegram polling.</param>
    /// <returns>A task that completes when the update is fully handled.</returns>
    public async Task DispatchUpdateAsync(
        ITelegramBotClient botClient,
        Update update,
        BotRuntimeContext botContext,
        CancellationToken cancellationToken)
    {
        using (_botContextAccessor.Push(botContext))
        {
            await HandleUpdateAsync(botClient, update, cancellationToken);
        }
    }

    /// <summary>
    /// Wraps core update handling with activity-log error capture and non-fatal delivery handling.
    /// </summary>
    /// <param name="botClient">Telegram client that should answer the update.</param>
    /// <param name="update">Telegram update being processed.</param>
    /// <param name="cancellationToken">Cancellation token from polling.</param>
    /// <returns>A task completing after handling; timeouts and non-delivery failures propagate to a terminal scheduler receipt.</returns>
    /// <remarks>
    /// Telegram can throw per-user delivery errors when a customer blocks an owned bot, tenant bot, or assistant bot.
    /// It can also raise transient request timeouts while sending a reply. Those errors are logged as skipped
    /// deliveries and are not rethrown, so the polling loop does not treat one unreachable chat or one slow Telegram
    /// request as a receiver failure. A Telegram 429 rate limit is likewise swallowed after backing off for
    /// Telegram's <c>RetryAfter</c> window; rethrowing it would terminate the receiver, and reporting it back through
    /// the Telegram logger channel would amplify the rate-limit storm. All other exceptions are still logged and
    /// rethrown for durable failure classification. External side-effect ambiguity remains in its business operation after the best-effort customer notice.
    /// </remarks>
    private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        try
        {
            await HandleUpdateCoreAsync(botClient, update, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            var credUser = GetCreduserFromUpdate(update);
            if (ex is TelegramForegroundDeliveryTimeoutException foregroundDeliveryTimeout)
            {
                // Interactive UX delivery only. The message may or may not have been accepted by Telegram before the
                // budget expired, so it is deliberately never re-sent here: a duplicate navigation reply is worse than
                // a missing one, and the customer can press the button again to generate a fresh update. The lane is
                // released promptly and the update finishes as a stable non-error outcome.
                await _userActivityLog.LogWarningAsync(
                    "handle_update_foreground_delivery_timeout",
                    credUser,
                    IsSuperAdminUser(credUser?.TelegramUserId ?? 0),
                    new Dictionary<string, object>
                    {
                        ["updateType"] = update?.Type.ToString() ?? "unknown",
                        ["requestKind"] = foregroundDeliveryTimeout.RequestKind,
                        ["budgetSeconds"] = foregroundDeliveryTimeout.Budget.TotalSeconds,
                        ["botId"] = BotContextAccessor.CurrentBotId ?? string.Empty
                    },
                    cancellationToken);

                _logger.LogWarning(
                    "Telegram foreground delivery exceeded its interactive budget; the update was released without resending. botId={BotId}, userId={UserId}, requestKind={RequestKind}, budgetSeconds={BudgetSeconds}",
                    BotContextAccessor.CurrentBotId,
                    credUser?.TelegramUserId,
                    foregroundDeliveryTimeout.RequestKind,
                    foregroundDeliveryTimeout.Budget.TotalSeconds);
                return;
            }

            if (TelegramRateLimitPolicy.IsRateLimited(ex))
            {
                var retryDelay = TelegramRateLimitPolicy.GetRetryDelay(ex);
                await _userActivityLog.LogWarningAsync(
                    "handle_update_rate_limited",
                    credUser,
                    IsSuperAdminUser(credUser?.TelegramUserId ?? 0),
                    new Dictionary<string, object>
                    {
                        ["updateType"] = update?.Type.ToString() ?? "unknown",
                        ["telegramError"] = ex.Message ?? string.Empty,
                        ["botId"] = BotContextAccessor.CurrentBotId ?? string.Empty
                    },
                    cancellationToken);

                _logger.LogWarning(
                    "Telegram update handling rate limited; backing off before the next update. botId={BotId}, userId={UserId}, chatId={ChatId}, retryAfterSeconds={RetryAfterSeconds}",
                    BotContextAccessor.CurrentBotId,
                    credUser?.TelegramUserId,
                    update?.Message?.Chat.Id ?? update?.CallbackQuery?.Message?.Chat.Id,
                    retryDelay.TotalSeconds);

                try
                {
                    await Task.Delay(retryDelay, cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    // Receiver shutdown while waiting for the rate-limit window is the normal stop path.
                }

                return;
            }

            if (IsUserDeliveryPollingError(ex))
            {
                await _userActivityLog.LogWarningAsync(
                    "handle_update_delivery_skipped",
                    credUser,
                    IsSuperAdminUser(credUser?.TelegramUserId ?? 0),
                    new Dictionary<string, object>
                    {
                        ["updateType"] = update?.Type.ToString() ?? "unknown",
                        ["telegramError"] = ex.Message ?? string.Empty,
                        ["botId"] = BotContextAccessor.CurrentBotId ?? string.Empty
                    },
                    cancellationToken);

                _logger.LogWarning(
                    "Telegram update delivery skipped because the chat is unreachable. botId={BotId}, userId={UserId}, chatId={ChatId}, telegramError={TelegramError}",
                    BotContextAccessor.CurrentBotId,
                    credUser?.TelegramUserId,
                    update?.Message?.Chat.Id ?? update?.CallbackQuery?.Message?.Chat.Id,
                    ex.Message);
                return;
            }

            if (IsExternalOperationTimeout(ex, cancellationToken))
            {
                await _userActivityLog.LogWarningAsync(
                    "handle_update_external_timeout",
                    credUser,
                    IsSuperAdminUser(credUser?.TelegramUserId ?? 0),
                    new Dictionary<string, object>
                    {
                        ["updateType"] = update?.Type.ToString() ?? "unknown",
                        ["timeoutError"] = ex.Message ?? string.Empty,
                        ["botId"] = BotContextAccessor.CurrentBotId ?? string.Empty
                    },
                    cancellationToken);

                _logger.LogWarning(
                    ex,
                    "Telegram update external operation timed out. botId={BotId}, userId={UserId}, chatId={ChatId}",
                    BotContextAccessor.CurrentBotId,
                    credUser?.TelegramUserId,
                    update?.Message?.Chat.Id ?? update?.CallbackQuery?.Message?.Chat.Id);

                await SendBestEffortTimeoutMessageAsync(botClient, update, cancellationToken);
                throw;
            }

            await _userActivityLog.LogErrorAsync(
                "handle_update_failed",
                ex,
                credUser,
                IsSuperAdminUser(credUser?.TelegramUserId ?? 0),
                new Dictionary<string, object>
                {
                    ["updateType"] = update?.Type.ToString() ?? "unknown"
                },
                cancellationToken);
            await SendBestEffortFailureMessageAsync(botClient, update, cancellationToken);
            throw;
        }
    }

    /// <summary>
    /// Clears transient conversation data for one Telegram user in the currently active bot runtime.
    /// </summary>
    /// <param name="telegramUserId">
    /// Positive Telegram user id taken from the incoming message sender. The active <see cref="BotContextAccessor"/>
    /// supplies the owned or tenant bot id that scopes both state stores.
    /// </param>
    /// <param name="cancellationToken">
    /// Polling cancellation token checked before the users.db operation. The legacy state API does not accept a token,
    /// so cancellation requested during its short serialized write is observed by the outer update handler afterward.
    /// </param>
    /// <returns>A task that completes after persisted state is cleared and the in-memory XUI selection is removed.</returns>
    /// <remarks>
    /// This is a conversation cancellation, not a financial cancellation. It keeps credentials, wallet balances,
    /// ledger rows, payment records, tenant orders, referral relationships, XUI accounts, free-trial timestamps, and
    /// long-lived counters unchanged. Both stores are bot-scoped, so resetting one storefront does not affect the same
    /// Telegram user in another bot. The method may create an empty bot-state row when none existed, matching the
    /// established <see cref="UserDbContext.ClearUserStatus(User)"/> behavior.
    /// </remarks>
    /// <example>
    /// <code>
    /// await ResetCurrentBotConversationAsync(message.From.Id, cancellationToken);
    /// </code>
    /// </example>
    /// <exception cref="ArgumentOutOfRangeException">
    /// Thrown when <paramref name="telegramUserId"/> is zero or negative, which indicates the caller did not use a
    /// Telegram update sender id.
    /// </exception>
    /// <exception cref="OperationCanceledException">
    /// Thrown when <paramref name="cancellationToken"/> is already cancelled before the users.db write starts.
    /// </exception>
    private async Task ResetCurrentBotConversationAsync(long telegramUserId, CancellationToken cancellationToken)
    {
        if (telegramUserId <= 0)
            throw new ArgumentOutOfRangeException(nameof(telegramUserId), "A positive Telegram user id is required.");

        cancellationToken.ThrowIfCancellationRequested();
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        _xuiV3PurchaseSessionStore.Clear(telegramUserId);
    }

    /// <summary>
    /// Persists a colleague-role change for one profile and emits the durable role-change audit.
    /// </summary>
    /// <param name="target">
    /// Target profile whose <c>CredUser.IsColleague</c> the caller already updated in memory; only its
    /// <c>TelegramUserId</c> is used for the shared-profile store write.
    /// </param>
    /// <param name="makeColleague">
    /// <c>true</c> to promote the target to colleague; <c>false</c> to demote back to a normal customer.
    /// </param>
    /// <param name="actor">
    /// Configured super-admin performing the change; used only as the audit sender identity. Never the target when
    /// the two differ.
    /// </param>
    /// <param name="wasColleague">Prior stored role value captured before the change, used by the audit message.</param>
    /// <returns>A task completing after the shared-profile write and the durable audit emit finish.</returns>
    /// <remarks>
    /// This is the single role-toggle path behind the <c>🤝 همکار کردن کاربر</c> and <c>👤 لغو همکاری کاربر</c> panel
    /// actions. It writes only <c>CredUser.IsColleague</c> through the shared credentials store; the
    /// configuration-controlled <see cref="AppConfig.AdminsUserIds"/> allow-list is never read or written here, so a
    /// colleague toggle can never grant or revoke global super-admin authority.
    /// </remarks>
    private async Task ApplyColleagueRoleChangeAsync(
        CredUser target,
        bool makeColleague,
        Telegram.Bot.Types.User actor,
        bool wasColleague)
    {
        var roleChanged = await _credentialsDbContext.PromotOrDemote(target.TelegramUserId, makeColleague);
        if (roleChanged)
            LogAdminRoleChange(actor, target, wasColleague, isColleagueAfter: makeColleague);
    }

    /// <summary>
    /// Opens the global super-admin panel as privileged high-priority owned-bot navigation.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client of the active owned bot that received the message. Only the panel sender uses it; no XUI,
    /// service-plan, payment, or website dependency is touched by this route.
    /// </param>
    /// <param name="message">
    /// Incoming owned-bot message whose text must be exactly <see cref="AdminPanelEntryAction"/> and whose sender is
    /// a configured global super-admin.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the bot-scoped state reset and the Telegram send.</param>
    /// <returns>
    /// <c>true</c> only when the message was the Admin entry and the actor is a configured super-admin inside an
    /// owned bot (the panel was opened and state cleared); otherwise <c>false</c> so normal routing continues.
    /// </returns>
    /// <remarks>
    /// Called from the message router BEFORE <see cref="XuiV3AdminFlowService.TryHandleMessageAsync"/> and every other
    /// stateful customer/XUI/renewal/colleague handler. The route authorizes against the configuration-controlled
    /// <c>adminsUserIds</c> list only (a colleague or tenant owner is never enough), verifies the current bot is owned
    /// (tenant bots never expose this panel), clears the current BotId/user conversation (abandoning stale
    /// <c>xui-v3-admin</c>, purchase, renewal, and legacy sub-flow state for that bot only), and then sends the panel.
    /// A missing service-plan file or unavailable XUI panel cannot prevent the panel from opening because nothing
    /// outside this local route is evaluated. Role precedence is super-admin first: a super-admin who is also a
    /// colleague still receives only the super-admin keyboard, and <c>CredUser.IsColleague</c> is never modified.
    /// </remarks>
    /// <example><code>if (await TryHandleSuperAdminPanelEntryAsync(botClient, message, token)) return;</code></example>
    private async Task<bool> TryHandleSuperAdminPanelEntryAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (message?.From == null ||
            !string.Equals(message.Text, AdminPanelEntryAction, StringComparison.Ordinal))
            return false;

        // Authorization is configuration-controlled. CredUser.IsColleague and tenant ownership confer no admin power.
        if (!IsSuperAdminUser(message.From.Id))
            return false;

        // The global platform panel exists only inside owned bots; tenant and assistant contexts must not reach it.
        var botType = CurrentBot?.Type ?? BotContextAccessor.CurrentBotType;
        if (string.IsNullOrWhiteSpace(botType))
            botType = BotInstanceTypes.Owned;
        if (!string.Equals(botType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
            return false;

        // High-priority navigation: abandon any stale bot-scoped conversation (XUI admin/customer/renewal/purchase/
        // colleague sub-flow) for THIS bot+user before sending the panel. Zero service-plan/panel/payment work happens.
        await ResetCurrentBotConversationAsync(message.From.Id, cancellationToken);
        await SendAdminPanelAsync(botClient, message.Chat.Id, cancellationToken);
        return true;
    }

    /// <summary>
    /// Builds the exact super-admin panel greeting text and reply keyboard.
    /// </summary>
    /// <returns>
    /// The fixed Persian greeting and the full <see cref="GetAdminKeyboard"/> keyboard. The method performs zero
    /// service-plan, panel, payment, or website work and never throws when the plans file is missing.
    /// </returns>
    /// <remarks>
    /// Virtual so tests can capture the real production content without opening a Telegram network client.
    /// </remarks>
    internal virtual (string Text, ReplyKeyboardMarkup Markup) BuildAdminPanelContent() =>
        (AdminPanelGreetingText, GetAdminKeyboard());

    /// <summary>
    /// Sends the super-admin panel greeting with the full admin keyboard.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client of the active owned bot. The caller guarantees an owned-bot context; the default implementation
    /// only sends one local Telegram message and performs no external panel or catalog work.
    /// </param>
    /// <param name="chatId">Target private chat id of the configured super-admin.</param>
    /// <param name="cancellationToken">Cancellation token for the Telegram send.</param>
    /// <returns>A task completing after the greeting is sent.</returns>
    /// <remarks>
    /// Virtual so tests can capture sends without opening a network client. Production behavior is the one-line send
    /// below and must never grow panel, catalog, or payment dependencies.
    /// </remarks>
    internal virtual Task<Message> SendAdminPanelAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CancellationToken cancellationToken)
    {
        var content = BuildAdminPanelContent();
        return botClient.CustomSendTextMessageAsync(
            chatId: chatId,
            text: content.Text,
            replyMarkup: content.Markup,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Returns a configured super-admin from the admin panel back to the normal owned-bot main menu.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot; only the main-menu sender uses it.</param>
    /// <param name="message">Incoming owned-bot message whose text must be exactly <see cref="AdminMenuExitAction"/>.</param>
    /// <param name="cancellationToken">Cancellation token for the bot-scoped state reset and the Telegram send.</param>
    /// <returns>
    /// <c>true</c> only when the message was the panel menu exit and the actor is a configured super-admin inside an
    /// owned bot (state was cleared and the owned-bot main menu was shown); otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Evaluated at the same high-priority layer as the Admin entry, before any XUI/admin sub-flow can consume the
    /// text. The route clears only the current BotId/user conversation state; super-admin authorization (the
    /// configuration-controlled <c>adminsUserIds</c> list) is untouched.
    /// </remarks>
    private async Task<bool> TryHandleSuperAdminMenuExitAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (message?.From == null ||
            !string.Equals(message.Text, AdminMenuExitAction, StringComparison.Ordinal))
            return false;
        if (!IsSuperAdminUser(message.From.Id))
            return false;
        var botType = CurrentBot?.Type ?? BotContextAccessor.CurrentBotType;
        if (string.IsNullOrWhiteSpace(botType))
            botType = BotInstanceTypes.Owned;
        if (!string.Equals(botType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
            return false;

        await ResetCurrentBotConversationAsync(message.From.Id, cancellationToken);
        await SendMainMenuAsync(botClient, message.Chat.Id, cancellationToken);
        return true;
    }

    /// <summary>
    /// Sends the owned-bot main menu that a super-admin returns to after leaving the admin panel.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="chatId">Target private chat id of the configured super-admin.</param>
    /// <param name="cancellationToken">Cancellation token for the Telegram send.</param>
    /// <returns>A task completing after the main menu is sent.</returns>
    /// <remarks>Virtual so tests can capture the send without opening a network client.</remarks>
    internal virtual Task<Message> SendMainMenuAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CancellationToken cancellationToken) =>
        botClient.CustomSendTextMessageAsync(
            chatId: chatId,
            text: MainMenuGreetingText,
            replyMarkup: GetMainMenuKeyboard(),
            cancellationToken: cancellationToken);

    /// <summary>
    /// Routes callbacks and messages to tenant storefront flows, owned-wallet shortcuts, owner tenant configuration,
    /// user XuiV3 flows, super-admin flows, payment return handlers, and legacy menus while giving navigation reset
    /// commands priority over every conversation state machine.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client belonging to the active runtime bot that received the update. It is used only for that bot's
    /// callbacks, messages, membership checks, and menus.
    /// </param>
    /// <param name="update">
    /// Raw Telegram update from polling. Message sender ids are Telegram user ids; callback sender ids are never
    /// substituted from persisted state.
    /// </param>
    /// <param name="cancellationToken">Polling cancellation token for database, Telegram, payment, and XUI work.</param>
    /// <returns>A task that completes after the update is consumed or deliberately ignored.</returns>
    /// <remarks>
    /// Valid <c>/start</c> commands for owned and tenant bots, plus <c>/refresh</c> for owned bots, clear the current
    /// bot/user conversation row and in-memory XUI purchase selection immediately after activity logging. The reset
    /// happens before blocked-user and forced-join responses, but those access policies still decide whether a home
    /// menu can be displayed. Reset never mutates credentials, wallet balances, ledgers, payments, orders, referrals,
    /// XUI accounts, or another bot's state. Known payment and referral start payloads continue through their existing
    /// handlers after the transient reset.
    /// </remarks>
    /// <example>
    /// <code>
    /// await HandleUpdateCoreAsync(botClient, update, cancellationToken);
    /// </code>
    /// </example>
    private async Task HandleUpdateCoreAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        if (_salesAssistantService.IsAssistantBot)
        {
            await _salesAssistantService.TryHandleUpdateAsync(botClient, update, cancellationToken);
            return;
        }

        if (update.CallbackQuery is { } callbackQuery)
        {
            var callbackCredUser = await _credentialsDbContext.GetUserStatus(
                GetCreduserFromTelegramUser(callbackQuery.From, callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id));
            var callbackIsSuperAdmin = IsSuperAdminUser(callbackQuery.From.Id);

            await _userActivityLog.LogCallbackAsync(callbackQuery, callbackCredUser, callbackIsSuperAdmin, cancellationToken);

            if (!callbackIsSuperAdmin && callbackCredUser?.IsBlocked == true)
            {
                await SafeAnswerCallbackQueryAsync(botClient,
                    callbackQueryId: callbackQuery.Id,
                    text: "به علت تخلف مسدود شدید. لطفاً با پشتیبانی تلگرام پیام بدهید.",
                    showAlert: true,
                    cancellationToken: cancellationToken);
                return;
            }

            var callbackUserState = await _state.GetUserStatus(callbackQuery.From.Id);
            // Tenant storefront callbacks are isolated from the main bot purchase/account flows.
            if (string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase))
            {
                await _tenantBotService.TryHandleTenantUpdateAsync(botClient, update, callbackCredUser, callbackUserState, cancellationToken);
                return;
            }

            if (string.Equals(callbackQuery.Data, WalletChargeShortcutCallback, StringComparison.Ordinal))
            {
                await ProcessWalletChargeShortcutAsync(botClient, callbackQuery, cancellationToken);
                return;
            }

            // Owner callbacks configure a colleague storefront from inside the main brand bot.
            if (_tenantBotService.IsOwnerCallback(callbackQuery.Data))
            {
                await _tenantBotService.TryHandleOwnerCallbackAsync(botClient, callbackQuery, callbackCredUser, callbackUserState, cancellationToken);
                return;
            }

            if (callbackIsSuperAdmin && await _xuiV3AdminFlowService.TryHandleCallbackAsync(
                botClient,
                callbackQuery,
                GetMainMenuKeyboard(),
                cancellationToken))
            {
                return;
            }

            if (callbackQuery.Data != null && callbackQuery.Data.StartsWith("x3:"))
            {
                var callbackMainKeyboard = callbackIsSuperAdmin
                    ? GetMainMenuKeyboard()
                    : MainReplyMarkupKeyboardFa();
                if (await _xuiV3BotFlowService.TryHandleCallbackAsync(botClient, callbackQuery, callbackCredUser, callbackUserState, callbackMainKeyboard, cancellationToken))
                    return;
            }

            // Latest-client-software downloads are a global feature shared with tenant storefronts. The callback is
            // routed before the legacy payment/admin dispatcher so the owned flow never mistakes it for a payment action.
            if (ClientDownloadCallbacks.TryParse(callbackQuery.Data, out var downloadPlatform))
            {
                await HandleClientDownloadPlatformCallbackAsync(botClient, callbackQuery, downloadPlatform, cancellationToken);
                return;
            }

            await ProccessCallbacks(callbackQuery, cancellationToken);
            return;
        }
        //if (true) return;
        // Only process Message updates: https://core.telegram.org/bots/api#message

        if (update.Message is not { } message)
            return;
        if (message.From == null)
            return;

        List<long> allowedValues = _appConfig.AdminsUserIds;
        var isSuperAdmin = message.From != null && allowedValues != null && allowedValues.Contains(message.From.Id);
        var messageCredUser = message.From == null
            ? null
            : await _credentialsDbContext.GetUserStatus(GetCreduserFromMessage(message));

        await _userActivityLog.LogMessageAsync(message, messageCredUser, isSuperAdmin, cancellationToken);

        var currentBotType = CurrentBot?.Type ?? BotContextAccessor.CurrentBotType;
        var isTenantBot = string.Equals(currentBotType, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase);
        var isOwnedBot = string.Equals(currentBotType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase) ||
                         string.IsNullOrWhiteSpace(currentBotType);
        var currentBotUsername = CurrentBot?.Username ?? BotContextAccessor.CurrentBotUsername;
        var hasNavigationCommand = TelegramNavigationCommandParser.TryParse(
            message.Text,
            currentBotUsername,
            allowRefresh: isOwnedBot,
            out var navigationCommand);
        var isOwnedPaymentReturn = isOwnedBot && TryParseNowPaymentsReturnCommand(
            message.Text,
            currentBotUsername,
            out _);

        if (hasNavigationCommand || isOwnedPaymentReturn)
        {
            // Both stores derive their key from the active BotContext, so this cannot clear the same Telegram user's
            // independent flow in another owned brand or tenant storefront.
            await ResetCurrentBotConversationAsync(message.From.Id, cancellationToken);
        }

        if (!isSuperAdmin && messageCredUser?.IsBlocked == true)
        {
            await SendBlockedUserMessageAsync(botClient, message.Chat.Id, cancellationToken);
            return;
        }

        // "🗽 Admin" is privileged high-priority navigation for configured super-admins in owned bots only. It must
        // preempt every stale XUI/customer/renewal/colleague sub-flow BEFORE any stateful handler or service-plan/
        // panel dependency is evaluated, and it never runs inside tenant or assistant bots.
        if (isOwnedBot && await TryHandleSuperAdminPanelEntryAsync(botClient, message, cancellationToken))
            return;
        // The same precedence applies to "📑 Menu": while the super-admin panel is open it must abandon any stale
        // admin sub-flow and return to the owned-bot main menu without touching super-admin authorization.
        if (isOwnedBot && await TryHandleSuperAdminMenuExitAsync(botClient, message, cancellationToken))
            return;

        // Tenant bots answer as storefronts only; they do not expose the main brand menus.
        if (isTenantBot)
        {
            var tenantUserState = await _state.GetUserStatus(message.From.Id);
            await _tenantBotService.TryHandleTenantUpdateAsync(botClient, update, messageCredUser, tenantUserState, cancellationToken);
            return;
        }

        if (await TryHandleNowPaymentsReturnStartAsync(
            botClient,
            message,
            messageCredUser,
            isSuperAdmin ? GetMainMenuKeyboard() : MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }

        if (isSuperAdmin && hasNavigationCommand)
        {
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Main Menu",
                replyMarkup: GetMainMenuKeyboard());
            return;
        }

        if (isSuperAdmin && await TryHandleUsageStatisticsCommandAsync(botClient, message, cancellationToken))
            return;

        if (isSuperAdmin && await TryHandleUserActivityLogCommandAsync(botClient, message, messageCredUser, cancellationToken))
            return;

        // Super-admin messages bypass the regular customer handler. Route the owned-bot referral menu explicitly
        // before the legacy admin command chain so an administrator can use the same customer-facing dashboard.
        if (isSuperAdmin && IsReferralMenuCommand(message.Text))
        {
            await TryHandleReferralMenuCommandAsync(
                botClient,
                message,
                user: null,
                cancellationToken);
            return;
        }

        if (!isSuperAdmin)
        {


            await HandleUpdateRegularUsers(botClient, update, cancellationToken);
            return;
        }
        // Only process text messages
        if (message.Text is not { } messageText)
            return;

        var chatId = message.Chat.Id;

        Console.WriteLine($"Received a '{messageText}' message in chat {chatId}.");

        //_userDbContext.Database.Migrate();
        //6257546736 amir
        //85758085 hamed
        // 888197418 admin hamed

        //        List<long> allowedValues = _configuration.GetSection("adminsUserIds").Get<List<long>>();
        var currentUser = await _state.GetUserStatus(message.From.Id);
        //_userDbContext.Users.Attach(currentUser);

        if (message.Text == "🤖 وضعیت ربات‌ها")
        {
            await SendRuntimeBotStatusAsync(botClient, message.Chat.Id, cancellationToken);
            return;
        }

        if (message.Text == AdminPaymentGatewayAction)
        {
            await SendPaymentGatewayPanelAsync(botClient, message.Chat.Id, cancellationToken);
            return;
        }

        if (message.Text == AdminClientDownloadAction)
        {
            await SendClientDownloadPanelAsync(botClient, message.Chat.Id, cancellationToken);
            return;
        }

        if (await _xuiV3AdminFlowService.TryHandleMessageAsync(
            botClient,
            message,
            currentUser,
            GetMainMenuKeyboard(),
            cancellationToken))
        {
            return;
        }

        if (await TryHandleManualPhoneVerificationAsync(
            botClient,
            message,
            currentUser,
            cancellationToken))
        {
            return;
        }

        if (message.Text == "➕ Create New Account")
        {
            var createAccountKeyboard = GetLocationKeyboard();

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Select your country:",
                replyMarkup: createAccountKeyboard);

            // Save the user's context (selected country)
            await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "Create New Account", Flow = "create" });

        }

        else if (GetLocations().Contains(message.Text))
        {
            // Update the user's context with the selected country
            await _state.SaveUserStatus(new User { Id = message.From.Id, SelectedCountry = message.Text });


            var periodKeyboard = new ReplyKeyboardMarkup(new[]
            {
                new []
                {
                    new KeyboardButton("1 Month"),
                },
                new []
                {
                    new KeyboardButton("2 Months"),
                },
                new []
                {
                    new KeyboardButton("3 Months"),
                },
                new []
                {
                    new KeyboardButton("6 Months"),
                },
            });

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Select the account period:",
                replyMarkup: periodKeyboard);
        }

        else if (message.Text == "0 Month" || message.Text == "1 Month" || message.Text == "2 Months" || message.Text == "3 Months" || message.Text == "6 Months")
        {
            // Handle the selected period
            await _state.SaveUserStatus(new User { Id = message.From.Id, SelectedPeriod = message.Text });

            // user does not go throw the actual flow
            var user = currentUser;
            if (string.IsNullOrEmpty(user.SelectedCountry) && (user.Flow == "create"))
            {
                await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Main Menu:",
                replyMarkup: GetMainMenuKeyboard());
                return;
            }


            // Create a keyboard based on the selected period
            var keyboard = GetAccountTypeKeyboard();

            // get trafic for renew
            if (currentUser.Flow == "update")
            {
                await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "get_traffic" });
                await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "Type Traffic in GB and send! \n" + "For example if you send 20, the account will have 20GB traffic",
                        replyMarkup: new ReplyKeyboardRemove());
            }


            // Send the keyboard to the user for creation
            if (currentUser.Flow == "create")
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "Select the account type:",
                    replyMarkup: keyboard
                );


        }

        else if (message.Text == "Reality Ipv6")
        {
            await _state.SaveUserStatus(new User { Id = message.From.Id, Type = "realityv6", TotoalGB = "500" });

            var user = currentUser;
            if (string.IsNullOrEmpty(user.SelectedCountry) || string.IsNullOrEmpty(user.SelectedPeriod))
            {
                await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Main Menu:",
                replyMarkup: GetMainMenuKeyboard());
                return;
            }




            var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
            {
            new []
            {
                new KeyboardButton("Yes Create!"),
            },
            new []
            {
                new KeyboardButton("No Don't Create!"),
            },
        });

            user = currentUser;

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: $"You selected {user.SelectedCountry} for {user.SelectedPeriod} with account type {user.Type}. Confirm?",
                replyMarkup: confirmationKeyboard);

        }

        else if (message.Text == "All operators")
        {
            await _state.SaveUserStatus(new User { Id = message.From.Id, Type = "tunnel", LastStep = "get_traffic" });

            var user = currentUser;
            if (string.IsNullOrEmpty(user.SelectedCountry) || string.IsNullOrEmpty(user.SelectedPeriod))
            {
                await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Main Menu:",
                replyMarkup: GetMainMenuKeyboard());
                return;
            }


            await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "Type Traffic in GB and send! \n" + "For example if you send 20, the account will have 20GB traffic",
                        replyMarkup: new ReplyKeyboardRemove());
        }

        else if (message.Text == "Yes Create!")
        {
            await botClient.CustomSendTextMessageAsync(
                       chatId: message.Chat.Id,
                       text: "Please wait ...",
                        replyMarkup: new ReplyKeyboardRemove());


            var ready = await _state.IsUserReadyToCreate(message.From.Id);
            if (!ready) await botClient.CustomSendTextMessageAsync(
                       chatId: message.Chat.Id,
                       text: "Your information is not complete. please go throw steps correctly.",
                        replyMarkup: GetMainMenuKeyboard()); ;
            if (!ready) return;

            // Handle confirmation (create the account or perform other actions)
            var user = currentUser;

            // Access the server information from the servers.json file
            var serversJson = ReadJsonFile.ReadJsonAsString();
            var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

            if (servers.ContainsKey(user.SelectedCountry))
            {
                var serverInfo = servers[user.SelectedCountry];

                AccountDto accountDto = new AccountDto { TelegramUserId = message.From.Id, ServerInfo = serverInfo, SelectedCountry = user.SelectedCountry, SelectedPeriod = user.SelectedPeriod, AccType = user.Type, TotoalGB = user.TotoalGB };

                var result = await CreateAccount(accountDto);
                // Now you can use the selected country, period, and server information to perform actions
                // For example, create the account, send a request to the server, etc.
                if (result)
                {
                    user = await _state.GetUserStatus(currentUser.Id);

                    var msg = CaptionForAccountCreation(user, language: "en", showTraffic: false);

                    // Send the photo with caption


                    //await botClient.SendImagesWithCaptionAsync(message.Chat.Id, InputFile.FromStream(new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(user.ConfigLink, 200))), caption: msg)
                    await botClient.SendPhoto(message.Chat.Id, InputFile.FromStream(new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(user.ConfigLink, 200))), caption: msg, parseMode: ParseMode.Markdown);
                    // .GetAwaiter()
                    // .GetResult();


                    await botClient.CustomSendTextMessageAsync(
                       chatId: message.Chat.Id,
                       text: "Main menu",
                        replyMarkup: GetMainMenuKeyboard());

                    await _state.ClearUserStatus(new User { Id = user.Id });

                }
            }
            else
            {
                // Handle the case where the selected country is not found in the servers.json file
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"Server information not found for {user.SelectedCountry}.",
                    replyMarkup: GetMainMenuKeyboard());
            }
        }

        else if (message.Text == "No Don't Create!")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            // Handle rejection or provide other options
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Account creation canceled.",
                replyMarkup: GetMainMenuKeyboard());
        }

        else if (message.Text == "ℹ️ Get Account Info")
        {
            await _state.SaveUserStatus(new User { Id = Convert.ToInt64(message.From.Id), LastStep = "Get Account Info", Flow = "read" });

            // Handle "Get Account Info" button click
            // You can implement the logic for this button here
            // For example, retrieve and display account information
            await botClient.CustomSendTextMessageAsync(
                               chatId: message.Chat.Id,
                               text: "Send your Vmess or Vless link:",
                                replyMarkup: new ReplyKeyboardRemove());

        }

        else if (currentUser.Flow == "read" && StartsWithVMessOrVLess(message.Text))
        {

            ClientExtend client = await TryGetClient(message.Text);
            await _state.ClearUserStatus(new User { Id = message.From.Id });

            // Handle "Get Account Info" button click
            // You can implement the logic for this button here
            // For example, retrieve and display account information
            if (client == null)
            {
                await botClient.CustomSendTextMessageAsync(
                              chatId: message.Chat.Id,
                              text: "There is a Error with decoding Your config link!",
                               replyMarkup: GetMainMenuKeyboard());
                return;
            }

            var credUser = await _credentialsDbContext.GetUserStatus(GetCreduserFromMessage(message));
            string msg = string.Empty;

            // msg = $"✅ مشخصات اکانت شما:  \n";
            // msg += $"👤نام: `{client.Email}` \n";
            // //// msg += $"⌛️دوره : {ApiService.ConvertPeriodToDays(user.SelectedPeriod)} روزه \n";
            // //// msg += $"Location: {user.SelectedCountry} \n";
            // if (credUser.IsColleague) msg += $"🧮 حجم ترافیک: {client.TotalUsedTrafficInGB} گیگابایت\n";

            // string hijriShamsiDate = client.ExpiryTime.AddMinutes(210).ConvertToHijriShamsi();
            // msg += $"📅تاریخ انقضاء:  {hijriShamsiDate}\n";
            // msg += "\u200F" + "🔄 تمدید ⬅️  " + $"/renew_{client.Email} \n";


            msg = $"✅ Account details: \n";
            msg += $"Active: {client.Enable}";
            msg += $"\n Account Name: \n `{client.Email}` \n";

            msg += client.TotalUsedTrafficInGB;
            string hijriShamsiDate = client.ExpiryTime.AddMinutes(210).ConvertToHijriShamsi();
            msg += $"\nExpiration Date: {hijriShamsiDate}\n";


            await botClient.CustomSendTextMessageAsync(
               chatId: message.Chat.Id, parseMode: ParseMode.Markdown,
               text: msg,
                replyMarkup: GetMainMenuKeyboard());


        }

        else if (currentUser.Flow == "update" && StartsWithVMessOrVLess(message.Text))
        {
            var user = currentUser;
            user.ConfigLink = message.Text;
            await _state.SaveUserStatus(user);


            var periodKeyboard = new ReplyKeyboardMarkup(new[]
            {
                new []
                {
                    new KeyboardButton("0 Month"),
                },new []
                {
                    new KeyboardButton("1 Month"),
                },
                new []
                {
                    new KeyboardButton("2 Months"),
                },
                new []
                {
                    new KeyboardButton("3 Months"),
                },
                new []
                {
                    new KeyboardButton("6 Months"),
                },
            });

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Select the account period:",
                replyMarkup: periodKeyboard);

        }

        else if (message.Text == "🔄 Renew Existing Account")
        {
            await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "Renew Existing Account", Flow = "update" });
            await botClient.CustomSendTextMessageAsync(
                               chatId: message.Chat.Id,
                               text: "Send your Vmess or Vless link:",
                                replyMarkup: new ReplyKeyboardRemove());
        }

        else if (message.Text == "📑 Menu")
        {
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Main Menu:",
                replyMarkup: GetMainMenuKeyboard());
            await _state.ClearUserStatus(new User { Id = message.From.Id });

            // Handle "Menu" button click
            // You can implement the logic for this button here
            // For example, show a different menu or perform another action
        }

        else if (message.Text == "Yes Renew!")
        {

            await botClient.CustomSendTextMessageAsync(
                       chatId: message.Chat.Id,
                       text: "Please wait ...",
                        replyMarkup: new ReplyKeyboardRemove());


            var ready = await _state.IsUserReadyToUpdate(message.From.Id);
            if (!ready) await botClient.CustomSendTextMessageAsync(
                       chatId: message.Chat.Id,
                       text: "Your information is not complete. please go throw steps correctly.",
                        replyMarkup: GetMainMenuKeyboard()); ;
            if (!ready) return;


            var user = currentUser;
            ClientExtend client = await TryGetClient(user.ConfigLink);
            if (client == null)
            {
                await _state.ClearUserStatus(new User { Id = message.From.Id });

                await botClient.CustomSendTextMessageAsync(
                              chatId: message.Chat.Id,
                              text: "There is a Error with decoding Your config link!",
                               replyMarkup: new ReplyKeyboardRemove());
                return;
            }

            if (client != null)
            {
                ServerInfo findedServer = null;
                string findedcountry = null;
                AccountDtoUpdate accountDto = null;
                var serversJson = ReadJsonFile.ReadJsonAsString();
                var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);
                //trafic va modat faghat darim
                if (user.ConfigLink.StartsWith("vless://", StringComparison.OrdinalIgnoreCase))
                {
                    // location nadarim Get location
                    var vless = Vless.DecodeVlessLink(user.ConfigLink);

                    // Iterate over the dictionary
                    foreach (var kvp in servers)
                    {
                        var country = kvp.Key;
                        ServerInfo serverInfo = RuntimeSnapshot.Copy(kvp.Value);
                        if (serverInfo.Vless.Domain == vless.Domain)
                        {
                            findedServer = serverInfo;
                            findedcountry = country;
                        }
                    }
                    accountDto = new AccountDtoUpdate { TelegramUserId = message.From.Id, Client = client, ServerInfo = findedServer, SelectedCountry = findedcountry, SelectedPeriod = user.SelectedPeriod, AccType = "realityv6", TotoalGB = "500", ConfigLink = user.ConfigLink };
                }

                if (user.ConfigLink.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase))
                {
                    var vmess = VMessConfiguration.DecodeVMessLink(user.ConfigLink);

                    // Iterate over the dictionary
                    foreach (var kvp in servers)
                    {
                        string country = kvp.Key;
                        ServerInfo serverInfo = RuntimeSnapshot.Copy(kvp.Value);
                        if (serverInfo.VmessTemplate.Add == vmess.Add)
                        {
                            serverInfo.Inbounds = new List<Inbound> { serverInfo.Inbounds.FirstOrDefault(i => i.Port.ToString() == vmess.Port) };
                            serverInfo.VmessTemplate.Port = vmess.Port;
                            findedServer = serverInfo;
                            findedcountry = country;
                        }
                    }

                    accountDto = new AccountDtoUpdate { TelegramUserId = message.From.Id, Client = client, ServerInfo = findedServer, SelectedCountry = findedcountry, SelectedPeriod = user.SelectedPeriod, AccType = "tunnel", TotoalGB = user.TotoalGB, ConfigLink = user.ConfigLink };
                }
                await _state.SaveUserStatus(new User { Id = currentUser.Id, SelectedCountry = findedcountry });
                var result = await UpdateAccount(accountDto);


                if (result)
                {
                    user = await _state.GetUserStatus(user.Id);

                    user.TotoalGB = (Convert.ToInt64(user.TotoalGB) + (client.TotalGB / 1073741824L)).ToString();
                    var msg = $"✅ Account details: \n";
                    msg += $"Account Name: `{user.Email}`";
                    msg += $"\nLocation: {user.SelectedCountry} \nAdded duration: {user.SelectedPeriod}";
                    if (Convert.ToInt32(user.TotoalGB) < 100) msg += $"\nTraffic: {user.TotoalGB}GB.\n";
                    string hijriShamsiDate = client.ExpiryTime.AddDays(ApiService.ConvertPeriodToDays(user.SelectedPeriod)).AddMinutes(210).ConvertToHijriShamsi();

                    msg += $"\nExpiration Date: {hijriShamsiDate}\n";
                    msg += $"Your Sublink is: \n";
                    msg += $"`{user.SubLink}` \n";
                    msg += $"Your Connection link is: \n";
                    msg += "============= Tap to Copy =============\n";
                    msg += $"`{user.ConfigLink}`" + "\n ";

                    // Send the photo with caption

                    await botClient.SendPhoto(message.Chat.Id, InputFile.FromStream(new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(user.ConfigLink, 200))), caption: msg, parseMode: ParseMode.Markdown);
                    // .GetAwaiter()
                    // .GetResult();
                    await _state.ClearUserStatus(new User { Id = user.Id });
                }

                await botClient.CustomSendTextMessageAsync(
           chatId: message.Chat.Id, parseMode: ParseMode.Markdown,
           text: "Main menu",
            replyMarkup: GetMainMenuKeyboard());


            }
        }

        else if (currentUser.LastStep == "get_traffic")
        {
            var isSuccessful = int.TryParse(message.Text, out int res);
            if (!isSuccessful)
            {
                await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "Error! \n Type Traffic in GB and send! \n" + "For example if you send 20, the account will have 20GB traffic.\n Tap /start to cancell the proccess.",
                        replyMarkup: new ReplyKeyboardRemove());
                return;
            }

            if (currentUser.Flow == "update")
            {
                await _state.SaveUserStatus(new User { Id = message.From.Id, TotoalGB = res.ToString() });

                // The user entered a valid number
                var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                           {
            new []
            {
                new KeyboardButton("Yes Renew!"),
            },
            new []
            {
                new KeyboardButton("No Don't Create!"),
            },
        });

                var user = currentUser;
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"You selected {user.SelectedPeriod}(s) with account type and Traffic {res}GB. Confirm?",
                    replyMarkup: confirmationKeyboard);
                return;
            }
            if (currentUser.Flow == "create")
            {
                if (int.TryParse(message.Text, out int userTraffic))
                {
                    await _state.SaveUserStatus(new User { Id = message.From.Id, TotoalGB = userTraffic.ToString() });

                    // The user entered a valid number
                    var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                               {
            new []
            {
                new KeyboardButton("Yes Create!"),
            },
            new []
            {
                new KeyboardButton("No Don't Create!"),
            },
        });

                    var user = currentUser;

                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: $"You selected {user.SelectedCountry} for {user.SelectedPeriod}(s) with account type {user.Type} and Traffic {userTraffic}GB. Confirm?",
                        replyMarkup: confirmationKeyboard);


                    return;
                }
                // You can now use the 'userTraffic' value in your logic
                // For example, store it in a database, perform further actions, etc.
            }
            else
            {
                // The user did not enter a valid number
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "Please enter a valid number."
                );
            }
        }


        // The single authoritative Admin entry is TryHandleSuperAdminPanelEntryAsync, evaluated at the top of the
        // message router before any stateful handler. This legacy branch was removed so no second competing route
        // can let stale XUI/customer state consume the privileged navigation action.

        //get public message:
        else if (currentUser.Flow == "admin" && currentUser.LastStep == "Get-public-message")
        {

            currentUser.ConfigLink = message.Text;
            currentUser.LastStep = "confirm-public-message";
            await _state.SaveUserStatus(currentUser);

            var audienceLabel = GetBroadcastAudienceLabel(currentUser.SubLink);
            await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: $"این پیام برای «{audienceLabel}» آماده شده است. آیا ارسال شود؟",
                            replyMarkup: GetMessageSendConfirmationKeyboard());

            var forwardMessage = GetChannelAndPost(message.Text);
            if (forwardMessage != null)
            {
                await ActiveBotClient.CustomForwardMessage(
                    chatId: message.Chat.Id,
                    fromChatId: forwardMessage.ChannelName,
                    messageId: forwardMessage.PostNumber
                );
            }
            else
            {
                await botClient.CustomSendTextMessageAsync(
            chatId: message.Chat.Id,
            text: currentUser.ConfigLink,
            replyMarkup: GetMessageSendConfirmationKeyboard());
            }


            return;
        }


        else if (currentUser.Flow == "admin" && currentUser.LastStep == "Get-trackid")
        {

            currentUser.ConfigLink = message.Text;
            currentUser.LastStep = "confirm-zibal-trackid";
            await _state.SaveUserStatus(currentUser);


            var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                                          {
                        new []
                        {
                            new KeyboardButton("Yes Confirm!"),
                        },
                        new []
                        {
                            new KeyboardButton("No Don't Confirm!"),
                        },});

            await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: $"This is Your trackid:{message.Text} Are  you Sure to confirm it?",
                            replyMarkup: confirmationKeyboard);

            return;
        }

        else if (currentUser.Flow == "admin" && currentUser.LastStep.Contains("get-money-amount"))
        {
            currentUser.LastStep = currentUser.LastStep.Replace("get-money-amount", "confirm-admin-action");
            currentUser.LastStep = currentUser.LastStep + "|" + (message.Text ?? "0");
            await _state.SaveUserStatus(currentUser);

            var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                               {
                        new []
                        {
                            new KeyboardButton("Yes Confirm!"),
                        },
                        new []
                        {
                            new KeyboardButton("No Don't Confirm!"),
                        },});

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "You have entered:\n" + message.Text + $"\n for action {currentUser.LastStep.Split('|')[1]}" + " Are you sure?",
                replyMarkup: confirmationKeyboard);

        }

        //get user id for admin operations:
        else if (currentUser.Flow == "admin" && currentUser.LastStep.Contains("get-tel-user-id"))
        {
            // var action = "🚀 Promote as admin";
            var action = currentUser.LastStep.Split('|')[1];
            if (action == "ℹ️ See User Account")
            {
                try
                {
                    // var userid = Convert.ToInt64(message.Text.Split('|').ElementAt(2));
                    var userid = Convert.ToInt64(message.Text);
                    if (userid == 0) throw new Exception("user id is null");
                    var findedClient = await _credentialsDbContext.GetUserStatusWithId(userid) != null;
                    // if (!findedClient) await _credentialsDbContext.AddEmptyUser(userid);
                    // else { }
                    if (findedClient)
                    {
                        CredUser existedUser = await _credentialsDbContext.GetUserStatusWithId(userid);
                        var text = await GetUserProfileMessage(existedUser);
                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: text,
                            replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                    }
                    else
                    {
                        await botClient.CustomSendTextMessageAsync(
                                                    chatId: message.Chat.Id,
                                                    text: "User doesn't run the bot yet!. Ask him to first run the bot.",
                                                    replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);


                    }
                    await _state.ClearUserStatus(currentUser);

                }

                catch (System.Exception ex)
                {
                    string errorMessage;
                    switch (ex)
                    {
                        case ArgumentOutOfRangeException argumentOutOfRangeException:
                            errorMessage = "There is no userid in Database";
                            break;
                        case FormatException formatException:
                            errorMessage = "There is no userid in Database";
                            break;
                        case OverflowException overflowException:
                            errorMessage = "There is no userid in Database";
                            break;
                        default:
                            errorMessage = ex.Message;
                            break;
                    }
                    await botClient.CustomSendTextMessageAsync(
                                       chatId: message.Chat.Id,
                                       text: errorMessage,
                                       replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                    await _state.ClearUserStatus(currentUser);

                }
            }
            else if (action == "ℹ️ See All account of user")
            {
                try
                {
                    // var userid = Convert.ToInt64(message.Text.Split('|').ElementAt(2));
                    var userid = Convert.ToInt64(message.Text);
                    if (userid == 0) throw new Exception("user id is null");
                    var findedClient = await _credentialsDbContext.GetUserStatusWithId(userid) != null;
                    // if (!findedClient) await _credentialsDbContext.AddEmptyUser(userid);
                    // else { }
                    if (findedClient)
                    {
                        CredUser existedUser = await _credentialsDbContext.GetUserStatusWithId(userid);
                        // var text = await GetUserProfileMessage(existedUser);

                        await botClient.CustomSendTextMessageAsync(
                      chatId: message.Chat.Id,
                      text: "Please wait for tens seconds ...",
                      replyMarkup: new ReplyKeyboardRemove());

                        var accounts = await TryGetَAllClient(existedUser.TelegramUserId);
                        if (accounts.Count < 1)
                        {

                            await botClient.CustomSendTextMessageAsync(
                           chatId: message.Chat.Id,
                           text: "There is no account for specified user!",
                           replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                            return;
                        }

                        await SendMessageWithClientInfo(message.Chat.Id, true, accounts);


                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "Main Menu",
                            replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                        await _state.ClearUserStatus(new User { Id = message.From.Id });
                        return;

                    }
                    else
                    {
                        await botClient.CustomSendTextMessageAsync(
                                                    chatId: message.Chat.Id,
                                                    text: "User doesn't run the bot yet!. Ask him to first run the bot.",
                                                    replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                    }
                    await _state.ClearUserStatus(currentUser);

                }

                catch (System.Exception ex)
                {
                    string errorMessage;
                    switch (ex)
                    {
                        case ArgumentOutOfRangeException argumentOutOfRangeException:
                            errorMessage = "There is no userid in Database";
                            break;
                        case FormatException formatException:
                            errorMessage = "There is no userid in Database";
                            break;
                        case OverflowException overflowException:
                            errorMessage = "There is no userid in Database";
                            break;
                        default:
                            errorMessage = ex.Message;
                            break;
                    }
                    await botClient.CustomSendTextMessageAsync(
                                       chatId: message.Chat.Id,
                                       text: errorMessage,
                                       replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                    await _state.ClearUserStatus(currentUser);

                }
            }
            //promote demote
            else if (action == PromoteColleagueAction || action == DemoteColleagueAction)
            {
                // get confirmation
                currentUser.LastStep = currentUser.LastStep.Replace("get-tel-user-id", "confirm-admin-action");
                currentUser.LastStep = currentUser.LastStep + "|" + (message.Text ?? "0");
                await _state.SaveUserStatus(currentUser);


                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "You have entered:\n" + message.Text + $"\n for action {currentUser.LastStep.Split('|')[1]}" + " Are you sure?",
                    replyMarkup: GetAdminConfirmationKeyboard());
            }

            else if (action == "➕ Add credit" || action == "➖ Reduce credit")
            {
                // get confirmation
                currentUser.LastStep = currentUser.LastStep.Replace("get-tel-user-id", "get-money-amount");
                currentUser.LastStep = currentUser.LastStep + "|" + (message.Text ?? "0");
                await _state.SaveUserStatus(currentUser);

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "Enter Credit and send it:",
                    replyMarkup: new ReplyKeyboardRemove());
            }

        }

        // confirm ZIBAL
        else if ((message.Text == "Yes Confirm!" || message.Text == "No Don't Confirm!") && currentUser.Flow == "admin" && currentUser.LastStep == "confirm-zibal-trackid")
        {

            if (message.Text == "No Don't Confirm!")
            {
                await _state.ClearUserStatus(currentUser);
                if (message.Text == "No Don't Confirm!")
                    await botClient.CustomSendTextMessageAsync(
                         chatId: message.Chat.Id,
                         text: "Cancelled",
                         replyMarkup: GetMainMenuKeyboard());
            }

            long trackId = 0;
            var isTrackidValid = long.TryParse(currentUser.ConfigLink, out trackId);
            if (!isTrackidValid)
            {
                await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: "There is a error with interpreting the user inputs",
                                    replyMarkup: GetMainMenuKeyboard());
                return;
            }


            var credUser = await _credentialsDbContext.GetUserStatus(GetCreduserFromMessage(message));
            try
            {
                var zpi = await _workflow.ReadAsync(db => Task.FromResult(db.ZibalPaymentInfos.SingleOrDefault(x => x.TrackId == trackId)));
                var inq_respnse = await ZibalAPI.Inquiry(zpi.TrackId, _appConfig.ZibalMerchantCode);
                var msg = await ZibalAPI.VerifyAndGetMessage(trackId, _appConfig.ZibalMerchantCode);
                if (msg == "your payment was successfully confirmed!")
                {
                    zpi = ZibalAPI.MarkAsPaid(zpi, inq_respnse);


                    await ZibalAddtoBalance(zpi, _appConfig, credUser, chatId, true);
                    zpi.IsAddedToBallance = true;
                    await _workflow.SaveAsync();

                }

                await botClient.CustomSendTextMessageAsync(
                                   chatId: message.Chat.Id,
                                   text: msg,
                                   replyMarkup: GetMainMenuKeyboard());

                return;

            }
            catch
            {
                await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: "There is a error with confirmation proccess!",
                                    replyMarkup: GetMainMenuKeyboard());
                return;
            }


        }
        //get confirmation and do admin action:
        else if ((message.Text == "Yes Confirm!" || message.Text == "No Don't Confirm!") && currentUser.Flow == "admin" && currentUser.LastStep.Contains("confirm-admin-action"))
        {
            string status = "", action = "", userid = "";
            bool canContinue = false;
            try
            {
                status = currentUser.LastStep.Split('|')[0];
                action = currentUser.LastStep.Split('|')[1];
                userid = currentUser.LastStep.Split('|')[2];
                canContinue = true;
                if (string.IsNullOrEmpty(status) || string.IsNullOrEmpty(action) || string.IsNullOrEmpty(userid))
                    canContinue = false;

            }
            catch (System.Exception)
            {
                canContinue = false;
            }
            if (!canContinue)
            {
                await botClient.CustomSendTextMessageAsync(
                                     chatId: message.Chat.Id,
                                     text: "There is a error with interpreting the user inputs",
                                     replyMarkup: GetMainMenuKeyboard());
                return;
            }

            // "admin-confirmed" "get-money-amount"
            long cUserId;
            bool isuseridValid = long.TryParse(userid, out cUserId);
            long amount = 0;
            bool isCreditAmountValid = false;
            if (action == "➕ Add credit" || action == "➖ Reduce credit")
            {
                if (currentUser.LastStep.Split('|').Length >= 4)
                    isCreditAmountValid = long.TryParse(currentUser.LastStep.Split('|')[3], out amount);
            }
            // currentUser.LastStep.Replace("get-tel-user-id", "get-money-amount");

            if (message.Text == "No Don't Confirm!" || !isuseridValid)
            {
                await _state.ClearUserStatus(currentUser);
                if (message.Text == "No Don't Confirm!")
                    await botClient.CustomSendTextMessageAsync(
                         chatId: message.Chat.Id,
                         text: "Cancelled",
                         replyMarkup: GetMainMenuKeyboard());
                else
                {
                    await botClient.CustomSendTextMessageAsync(
                         chatId: message.Chat.Id,
                         text: "User Input is not correct",
                         replyMarkup: GetMainMenuKeyboard());
                }
            }
            else
            {
                var findedUser = await _credentialsDbContext.GetUserStatusWithId(cUserId);
                if (findedUser == null)
                {
                    await botClient.CustomSendTextMessageAsync(
                                                    chatId: message.Chat.Id,
                                                    text: "User with specified id doesn't existed!",
                                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                    return;
                }

                if (action == "➕ Add credit")
                {

                    if (isCreditAmountValid)
                    {
                        var receipt = await _credentialsDbContext.MutateWalletAsync(findedUser.TelegramUserId, amount,
                            $"admin:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:credit");
                        var beforeBalance = receipt.BeforeBalance;
                        var afterBalance = receipt.AfterBalance;
                        findedUser.AccountBalance = afterBalance;
                        await _walletLedgerService.RecordAsync(
                            findedUser.TelegramUserId,
                            WalletLedgerDirections.Credit,
                            amount,
                            beforeBalance,
                            afterBalance,
                            WalletLedgerReasons.AdminAdjustment,
                            provider: "admin",
                            referenceType: "admin-adjustment",
                            referenceId: message.From.Id.ToString(CultureInfo.InvariantCulture),
                            description: "Admin wallet credit",
                            idempotencyKey: receipt.OperationKey,
                            cancellationToken: cancellationToken);

                        LogAdminWalletAdjustment(
                            message.From,
                            findedUser,
                            isCredit: true,
                            amount,
                            beforeBalance,
                            afterBalance);


                        await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);


                        await botClient.CustomSendTextMessageAsync(
                                                    chatId: (findedUser).ChatID,
                                                    text: $"حساب شما به میزان {amount} تومان از طرف مدیریت شارژ شد.",
                                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                        await _ownedBotNotificationService.NotifyUserAcrossOwnedBotsAsync(
                            findedUser.TelegramUserId,
                            $"✅ حساب شما به میزان {amount.FormatCurrency()} از طرف مدیریت شارژ شد.\nموجودی جدید: {afterBalance.FormatCurrency()}",
                            cancellationToken: cancellationToken);

                        await botClient.CustomSendTextMessageAsync(
                        chatId: findedUser.ChatID,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                    }

                    else
                    {
                        await _state.ClearUserStatus(currentUser);
                        await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "The credit amount you have just entered is not correct! go through steps again! ",
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                    }
                    await _state.ClearUserStatus(currentUser);
                }
                else if (action == "➖ Reduce credit")
                {
                    if (isCreditAmountValid)
                    {
                        var receipt = await _credentialsDbContext.MutateWalletAsync(findedUser.TelegramUserId, -amount,
                            $"admin:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:debit");
                        var beforeBalance = receipt.BeforeBalance;
                        var afterBalance = receipt.AfterBalance;
                        findedUser.AccountBalance = afterBalance;
                        await _walletLedgerService.RecordAsync(
                            findedUser.TelegramUserId,
                            WalletLedgerDirections.Debit,
                            amount,
                            beforeBalance,
                            afterBalance,
                            WalletLedgerReasons.AdminAdjustment,
                            provider: "admin",
                            referenceType: "admin-adjustment",
                            referenceId: message.From.Id.ToString(CultureInfo.InvariantCulture),
                            description: "Admin wallet debit",
                            idempotencyKey: receipt.OperationKey,
                            cancellationToken: cancellationToken);

                        LogAdminWalletAdjustment(
                            message.From,
                            findedUser,
                            isCredit: false,
                            amount,
                            beforeBalance,
                            afterBalance);

                        await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                        await botClient.CustomSendTextMessageAsync(
                                                    chatId: findedUser.ChatID,
                                                    text: $"از حساب شما به میزان {amount} تومان از طرف مدیریت کسر شد.",
                                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                        await _ownedBotNotificationService.NotifyUserAcrossOwnedBotsAsync(
                            findedUser.TelegramUserId,
                            $"➖ از حساب شما به میزان {amount.FormatCurrency()} از طرف مدیریت کسر شد.\nموجودی جدید: {afterBalance.FormatCurrency()}",
                            cancellationToken: cancellationToken);

                        await botClient.CustomSendTextMessageAsync(
                        chatId: findedUser.ChatID,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                    }


                    else
                    {
                        await _state.ClearUserStatus(currentUser);
                        await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "The credit amount you have just entered is not correct! go through steps again! ",
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                    }

                    await _state.ClearUserStatus(currentUser);

                }
                else if (action == PromoteColleagueAction)
                {
                    var wasColleague = findedUser.IsColleague;
                    findedUser.IsColleague = true;
                    await ApplyColleagueRoleChangeAsync(findedUser, makeColleague: true, message.From, wasColleague);


                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                    await botClient.CustomSendTextMessageAsync(
                        chatId: findedUser.ChatID,
                        text: "تبریک! \n شما اکنون همکار مجموعه ما هستید. \n" + await GetUserProfileMessage(findedUser),
                        replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                    await _state.ClearUserStatus(currentUser);

                }
                else if (action == DemoteColleagueAction)
                {
                    // The action below only toggles CredUser.IsColleague; configured AdminsUserIds stay unchanged.
                    var wasColleague = findedUser.IsColleague;
                    findedUser.IsColleague = false;
                    await ApplyColleagueRoleChangeAsync(findedUser, makeColleague: false, message.From, wasColleague);

                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: await GetUserProfileMessage(findedUser),
                        replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                    await botClient.CustomSendTextMessageAsync(
                   chatId: findedUser.ChatID,
                   text: "شما اکنون کاربر عادی مجموعه ما هستید.\n" + await GetUserProfileMessage(findedUser),
                   replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                    await _state.ClearUserStatus(currentUser);

                }

                else
                {
                    await _state.ClearUserStatus(currentUser);
                    await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "Something went wrong! Go through the steps correctly",
                    replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);


                }


                // switch (action)
                // {
                //     case "➕ Add credit":

                //         if (isCreditAmountValid)
                //         {
                //             await _credentialsDbContext.AddFund(findedUser, amount);
                //             findedUser.AccountBalance += amount;

                //             await botClient.CustomSendTextMessageAsync(
                //             chatId: message.Chat.Id,
                //             text: await GetUserProfileMessage(findedUser),
                //             replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);


                //             await botClient.CustomSendTextMessageAsync(
                //                                         chatId: findedUser.ChatID,
                //                                         text: $"حساب شما به میزان {amount} تومان از طرف مدیریت شارژ شد.",
                //                                         replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                //             await botClient.CustomSendTextMessageAsync(
                //             chatId: findedUser.ChatID,
                //             text: await GetUserProfileMessage(findedUser),
                //             replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                //         }

                //         else
                //         {
                //             await _state.ClearUserStatus(currentUser);
                //             await botClient.CustomSendTextMessageAsync(
                //             chatId: message.Chat.Id,
                //             text: "The credit amount you have just entered is not correct! go through steps again! ",
                //             replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                //         }
                //         await _state.ClearUserStatus(currentUser);
                //         break;
                //     case "➖ Reduce credit":

                //         break;
                //     case "🚀 Promote as admin":

                //         findedUser.IsColleague = true;
                //         await _credentialsDbContext.SaveUserStatus(findedUser);

                //         await botClient.CustomSendTextMessageAsync(
                //             chatId: message.Chat.Id,
                //             text: await GetUserProfileMessage(findedUser),
                //             replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                //         await botClient.CustomSendTextMessageAsync(
                //             chatId: findedUser.ChatID,
                //             text: "تبریک! \n شما اکنون همکار مجموعه ما هستید. \n" + await GetUserProfileMessage(findedUser),
                //             replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                //         await _state.ClearUserStatus(currentUser);

                //         break;
                //     case "❌ Demote as admin":
                //         // Demote as admin logic here
                //         findedUser.IsColleague = false;
                //         await _credentialsDbContext.SaveUserStatus(findedUser);

                //         await botClient.CustomSendTextMessageAsync(
                //             chatId: message.Chat.Id,
                //             text: await GetUserProfileMessage(findedUser),
                //             replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);

                //         await botClient.CustomSendTextMessageAsync(
                //        chatId: findedUser.ChatID,
                //        text: "شما اکنون کاربر عادی مجموعه ما هستید.\n" + await GetUserProfileMessage(findedUser),
                //        replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

                //         await _state.ClearUserStatus(currentUser);

                //         break;
                //     case "ℹ️ See User Account":
                //         // See user account logic here
                //         // it has been implemented before!
                //         break;

                //     default:
                //         await _state.ClearUserStatus(currentUser);
                //         await botClient.CustomSendTextMessageAsync(
                //         chatId: message.Chat.Id,
                //         text: "Something went wrong! Go through the steps correctly",
                //         replyMarkup: GetMainMenuKeyboard(), parseMode: ParseMode.Markdown);
                //         break;
                // }
                // // await botClient.CustomSendTextMessageAsync(
                // chatId: message.Chat.Id,
                // text: "You have entered:\n" + message.Text + "\n Are you sure?",
                // replyMarkup: GetMainMenuKeyboard());

            }

        }

        //send public message:
        else if (currentUser.Flow == "admin" && currentUser.LastStep == "confirm-public-message")
        {
            var channelPost = GetChannelAndPost(currentUser.ConfigLink);
            if (message.Text == "Yes Send!")
            {
                var audience = NormalizeBroadcastAudience(currentUser.SubLink);
                var audienceLabel = GetBroadcastAudienceLabel(audience);
                // Broadcast recipients must be scoped to the owned bot that opened this admin flow.
                // credentials.db contains shared users for every brand, so it is only used after
                // BotUserStates has narrowed the audience to the current BotId.
                var allUsers = await GetBroadcastRecipientsAsync(audience, cancellationToken);

                if (allUsers.Count == 0)
                {
                    await botClient.SendMessage(
                        message.Chat.Id,
                        $"هیچ گیرنده‌ای برای ارسال پیام عمومی به «{audienceLabel}» پیدا نشد.",
                        replyMarkup: GetMainMenuKeyboard());
                    await _state.ClearUserStatus(new User { Id = message.From.Id });
                    return;
                }

                if (channelPost != null)
                {
                    var template = new BroadcastManager.BroadcastItem
                    {
                        FromChatId = BuildForwardSourceChatId(channelPost.ChannelName),
                        MessageId = channelPost.PostNumber,
                        IsForward = true
                    };

                    await StartBroadcastJobAsync(botClient, message, allUsers, template, cancellationToken);
                }
                else
                {
                    var template = new BroadcastManager.BroadcastItem
                    {
                        Text = currentUser.ConfigLink,
                        IsForward = false
                    };

                    await StartBroadcastJobAsync(botClient, message, allUsers, template, cancellationToken);
                }

                await _state.ClearUserStatus(new User { Id = message.From.Id });





                //     //forward
                //     if (channelPost != null)
                //     {
                //         foreach (var item in _credentialsDbContext.Users)
                //         {
                //             await ActiveBotClient.CustomForwardMessage(
                //                 chatId: item.ChatID,
                //                 fromChatId: channelPost.ChannelName,
                //                 messageId: channelPost.PostNumber
                //             );
                //             // Console.WriteLine("Message forwarded successfully.");
                //         }
                //     }

                //     // normal message
                //     else
                //     {
                //         foreach (var item in _credentialsDbContext.Users)
                //         {
                //             // Console.WriteLine($"{item.ChatID}")
                //             await botClient.CustomSendTextMessageAsync(
                //                                         chatId: item.ChatID,
                //                                         text: currentUser.ConfigLink,
                //                                         parseMode: ParseMode.Markdown,
                //                                         replyMarkup: inlineKeyboard
                //                                         );
                //         }

                //     }
                //     await _state.ClearUserStatus(new User { Id = message.From.Id });
                //     await botClient.CustomSendTextMessageAsync(

            }
            else if (message.Text == "Preview message")
            {
                if (channelPost != null)
                {
                    await ActiveBotClient.CustomForwardMessage(
                        chatId: message.Chat.Id,
                        fromChatId: channelPost.ChannelName,
                        messageId: channelPost.PostNumber);
                }
                else
                {
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.From.Id,
                        text: currentUser.ConfigLink,
                        parseMode: ParseMode.Markdown,
                        replyMarkup: GetMessageSendConfirmationKeyboard());
                }
            }
            else if (message.Text == "No Don't Send!")
            {
                await _state.ClearUserStatus(new User { Id = message.From.Id });
                await botClient.CustomSendTextMessageAsync(
                                           chatId: message.Chat.Id,
                                           text: "The Operation(send message) has been cancelled.",
                                            replyMarkup: GetMainMenuKeyboard());

            }
            else
            {
                await _state.ClearUserStatus(new User { Id = message.From.Id });
                await botClient.CustomSendTextMessageAsync(
                                           chatId: message.Chat.Id,
                                           text: "Oops! Start Again",
                                            replyMarkup: GetMainMenuKeyboard());
            }
        }

        else if (GetAdminActions().Contains(message.Text))
        {
            currentUser.Flow = "admin";
            currentUser.LastStep += "|" + message.Text;
            await _state.SaveUserStatus(currentUser);

            if (message.Text == "📑 Menu")
            {
                await _state.ClearUserStatus(currentUser);
                return;
            }
            else if (message.Text == "📨 Send message to all")
            {
                currentUser.Flow = "admin";
                currentUser.LastStep = "select-public-message-audience";
                currentUser.SubLink = string.Empty;
                await _state.SaveUserStatus(currentUser);

                await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: "مخاطب پیام عمومی را انتخاب کنید:",
                                replyMarkup: BuildBroadcastAudienceKeyboard());
                return;
            }


            else if (message.Text == "✔️ Verify payment")
            {
                currentUser.Flow = "admin";
                currentUser.LastStep = "Get-trackid";
                await _state.SaveUserStatus(currentUser);

                await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: "Type your Trackid(Zibal) and Send it:",
                                replyMarkup: new ReplyKeyboardRemove());
                return;
            }
            else
            {
                currentUser.Flow = "admin";
                currentUser.LastStep = "get-tel-user-id" + "|" + message.Text;
                await _state.SaveUserStatus(currentUser);

                // baraye ersal payam ya ertegha be admin
                await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "Send User (user must get it from @userinfobot or our bot)",
                replyMarkup: new ReplyKeyboardRemove());

                return;
            }
        }

        else
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await botClient.CustomSendTextMessageAsync(
                                       chatId: message.Chat.Id,
                                       text: "Oops! Start Again",
                                        replyMarkup: GetMainMenuKeyboard());

        }

    }

    /// <summary>
    /// Opens the owned-wallet charge flow from an insufficient-balance inline button.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned bot that received the callback.</param>
    /// <param name="callbackQuery">
    /// Callback whose sender is the wallet owner. The sender id, never callback payload data, selects the bot-scoped state.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for callback acknowledgement, state reset, and Telegram delivery.</param>
    /// <returns>A task that completes after the old message is updated and the charge-amount menu is sent.</returns>
    /// <remarks>
    /// Tenant storefronts are rejected before this handler because their customers pay orders directly. Clearing both
    /// persisted state and the in-memory XUI selection prevents an old purchase confirmation from resuming after top-up.
    /// Replaying an old callback has no financial side effect; it only reopens a fresh charge flow for its sender.
    /// </remarks>
    /// <example>
    /// <code>
    /// await ProcessWalletChargeShortcutAsync(botClient, callbackQuery, cancellationToken);
    /// </code>
    /// </example>
    private async Task ProcessWalletChargeShortcutAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        if (!string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
        {
            await SafeAnswerCallbackQueryAsync(botClient,
                callbackQuery.Id,
                "شارژ کیف پول در این فروشگاه در دسترس نیست.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        await AnswerCallbackSafely(callbackQuery, cancellationToken);
        await ShowWalletChargeMenuAsync(
            botClient,
            callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
            callbackQuery.From.Id,
            callbackQuery.Message?.MessageId,
            cancellationToken);
    }

    /// <summary>
    /// Resets an owned customer's previous flow and displays the canonical wallet charge-amount menu.
    /// </summary>
    /// <param name="botClient">Telegram client for the active owned bot.</param>
    /// <param name="chatId">Telegram chat id that receives the charge menu.</param>
    /// <param name="telegramUserId">Telegram user id whose bot-scoped state and XUI selection are replaced.</param>
    /// <param name="sourceMessageId">
    /// Optional insufficient-balance message id to replace with the successful-routing acknowledgement; null for entry
    /// through the main reply-keyboard button.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <returns>A task that completes after state persistence and charge-menu delivery.</returns>
    /// <remarks>
    /// Suggested amounts are derived from configured owned prices exactly as in the original charge menu. Gateway text
    /// is built from the live global gateway snapshot, so a provider disabled immediately before the click is omitted.
    /// This method creates no invoice and performs no wallet mutation.
    /// </remarks>
    /// <example>
    /// <code>
    /// await ShowWalletChargeMenuAsync(botClient, message.Chat.Id, message.From.Id, null, cancellationToken);
    /// </code>
    /// </example>
    private async Task ShowWalletChargeMenuAsync(
        ITelegramBotClient botClient,
        long chatId,
        long telegramUserId,
        int? sourceMessageId,
        CancellationToken cancellationToken)
    {
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        _xuiV3PurchaseSessionStore.Clear(telegramUserId);
        await _state.SaveUserStatus(new User
        {
            Id = telegramUserId,
            LastStep = "enter charge amount",
            Flow = "charge"
        });

        if (sourceMessageId.HasValue)
        {
            try
            {
                await botClient.EditMessageText(
                    chatId,
                    sourceMessageId.Value,
                    "✅ به منوی شارژ کیف پول هدایت شدید.",
                    cancellationToken: cancellationToken);
            }
            catch (ApiRequestException ex)
            {
                // A deleted or already-edited source message must not prevent the safe, non-financial charge menu entry.
                _logger.LogDebug(
                    ex,
                    "Wallet charge shortcut source message could not be edited. botId={BotId}, userId={UserId}, chatId={ChatId}, messageId={MessageId}",
                    BotContextAccessor.CurrentBotId,
                    telegramUserId,
                    chatId,
                    sourceMessageId.Value);
            }
        }

        var keyboardButtons = new List<List<KeyboardButton>>();
        var allPrices = _appConfig.Price
            .Concat(_appConfig.PriceCommon)
            .Concat(_appConfig.PriceColleagues)
            .Select(priceConfig => Convert.ToInt64(priceConfig.Price))
            .Where(price => price > 0)
            .Distinct()
            .OrderBy(price => price)
            .ToList();

        for (var index = 0; index < allPrices.Count; index += 4)
        {
            keyboardButtons.Add(allPrices
                .Skip(index)
                .Take(4)
                .Select(price => new KeyboardButton(price.FormatCurrency()))
                .ToList());
        }

        keyboardButtons.Add(new List<KeyboardButton> { new("بازگشت") });
        var keyboard = new ReplyKeyboardMarkup(keyboardButtons)
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
        var text = "💰 <b>شارژ کیف پول</b>\n\n" +
                   "🔘 یکی از مبلغ‌های پیشنهادی پایین را انتخاب کنید.\n" +
                   "✍️ یا مبلغ دلخواه خود را <b>به تومان و فقط به‌صورت عدد</b> ارسال کنید.\n" +
                   "مثال: <code>250000</code>\n\n" +
                   "⚡ درگاه‌های فعال پس از پرداخت موفق، نتیجه را به‌صورت خودکار و فوری بررسی می‌کنند.\n" +
                   BuildActiveChargeGatewaySummary();

        await botClient.CustomSendTextMessageAsync(
            chatId,
            text,
            replyMarkup: keyboard,
            parseMode: ParseMode.Html,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Routes legacy payment and administrative callbacks that were not handled by higher-level owned-bot dispatchers.
    /// </summary>
    /// <param name="callbackQuery">Telegram callback to classify by its stable prefix.</param>
    /// <param name="cancellationToken">Cancellation token for provider, database, logging, and Telegram operations.</param>
    /// <returns>A task that completes after a matching callback is processed or the unknown callback is ignored.</returns>
    private async Task ProccessCallbacks(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        //Process call back query
        if (callbackQuery == null || string.IsNullOrWhiteSpace(callbackQuery.Data))
            return;

        if (callbackQuery.Data.StartsWith("gw:", StringComparison.Ordinal))
        {
            await ProcessPaymentGatewayCallbackSafelyAsync(callbackQuery, cancellationToken);
            return;
        }

        if (callbackQuery.Data.StartsWith(ClientDownloadAdminCallbackPrefix, StringComparison.Ordinal))
        {
            await ProcessClientDownloadCallbackSafelyAsync(callbackQuery, cancellationToken);
            return;
        }

        try
        {
            if (callbackQuery.Data.Contains("Paid!"))
                return;

            if (callbackQuery.Data.StartsWith("broadcast_status_", StringComparison.Ordinal))
            {
                await ProcessBroadcastStatusCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("broadcast_scope_", StringComparison.Ordinal))
            {
                await ProcessBroadcastAudienceCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("ledger:", StringComparison.Ordinal))
            {
                await ProcessWalletLedgerCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("check_crypto_payment_"))
            {
                await ProcessCryptoPaymentCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("check_hooshpay_payment_") ||
                callbackQuery.Data.StartsWith("hpchk_"))
            {
                await ProcessHooshPayPaymentCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("tmchk_", StringComparison.Ordinal))
            {
                await ProcessTetraminatorPaymentCallbackAsync(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("upchk_", StringComparison.Ordinal))
            {
                await ProcessUniquePayPaymentCallbackAsync(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("apchk_", StringComparison.Ordinal))
            {
                await ProcessAtlasPayPaymentCallbackAsync(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.StartsWith("settle_crypto_partial_"))
            {
                await ProcessCryptoPartialSettlementCallback(callbackQuery, cancellationToken);
                return;
            }

            if (callbackQuery.Data.Contains("check_payment_"))
            {
                await ProcessZibalPaymentCallback(callbackQuery, cancellationToken);
                return;
            }
        }
        catch (Exception ex)
        {
            var credUser = await _credentialsDbContext.GetUserStatus(
                GetCreduserFromTelegramUser(callbackQuery.From, callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id));

            await _userActivityLog.LogErrorAsync(
                "payment_callback_failed",
                ex,
                credUser,
                IsSuperAdminUser(callbackQuery.From.Id),
                new Dictionary<string, object>
                {
                    ["callbackData"] = callbackQuery.Data ?? string.Empty
                },
                cancellationToken);

            Console.WriteLine($"[PaymentCallback] exception data={callbackQuery.Data}: {ex}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                text: "بررسی پرداخت با خطا روبه‌رو شد. جزئیات خطا در لاگ ثبت شد؛ لطفاً کمی بعد دوباره تلاش کنید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            await AnswerCallbackSafely(callbackQuery, cancellationToken);
        }
    }

    /// <summary>Validates an administrator audience choice and persists the next bot-scoped broadcast step.</summary>
    /// <param name="callbackQuery">Incoming Telegram callback; authorization uses its sender rather than the source message author.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>A task completing after the documented state transition and any required Telegram or panel work.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task ProcessBroadcastAudienceCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        if (!IsSuperAdminUser(callbackQuery.From.Id))
        {
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                text: "این بخش فقط برای سوپرادمین‌هاست.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var messageId = callbackQuery.Message?.MessageId;
        var selected = callbackQuery.Data.Replace("broadcast_scope_", "", StringComparison.Ordinal);

        if (string.Equals(selected, "back", StringComparison.OrdinalIgnoreCase))
        {
            await _state.ClearUserStatus(new User { Id = callbackQuery.From.Id });

            if (messageId.HasValue)
            {
                await ActiveBotClient.EditMessageText(
                    chatId: chatId,
                    messageId: messageId.Value,
                    text: "ارسال پیام عمومی لغو شد.",
                    cancellationToken: cancellationToken);
            }

            await ActiveBotClient.SendMessage(
                chatId: chatId,
                text: "Admin:",
                replyMarkup: GetAdminKeyboard(),
                cancellationToken: cancellationToken);

            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, cancellationToken: cancellationToken);
            return;
        }

        var audience = NormalizeBroadcastAudience(selected);
        var currentUser = await _state.GetUserStatus(callbackQuery.From.Id);
        currentUser.Flow = "admin";
        currentUser.LastStep = "Get-public-message";
        currentUser.SubLink = audience;
        await _state.SaveUserStatus(currentUser);

        var audienceLabel = GetBroadcastAudienceLabel(audience);
        if (messageId.HasValue)
        {
            await ActiveBotClient.EditMessageText(
                chatId: chatId,
                messageId: messageId.Value,
                text: $"مخاطب انتخاب شد: <b>{Html(audienceLabel)}</b>\n\nحالا متن پیام یا لینک پست کانال را ارسال کنید.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
        }

        await ActiveBotClient.SendMessage(
            chatId: chatId,
            text: "Type your message and Send it:",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        await SafeAnswerCallbackQueryAsync(
            callbackQuery.Id,
            text: "مخاطب پیام عمومی ثبت شد.",
            cancellationToken: cancellationToken);
    }

    private async Task SendWalletLedgerAsync(ITelegramBotClient botClient, ChatId chatId, long telegramUserId, int page, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _walletLedgerService.GetPageAsync(telegramUserId, page, 8, cancellationToken);
        await botClient.SendMessage(
            chatId,
            BuildWalletLedgerListText(items, totalCount, page),
            parseMode: ParseMode.Html,
            replyMarkup: BuildWalletLedgerKeyboard(items, totalCount, page),
            cancellationToken: cancellationToken);
    }

    private async Task ProcessWalletLedgerCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var data = callbackQuery.Data ?? string.Empty;
        var parts = data.Split(':');
        var botClient = ActiveBotClient;
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;

        if (parts.Length >= 3 && parts[1] == "page" && int.TryParse(parts[2], out var page))
        {
            var (items, totalCount) = await _walletLedgerService.GetPageAsync(callbackQuery.From.Id, page, 8, cancellationToken);
            await botClient.EditMessageText(
                chatId,
                callbackQuery.Message.MessageId,
                BuildWalletLedgerListText(items, totalCount, page),
                parseMode: ParseMode.Html,
                replyMarkup: BuildWalletLedgerKeyboard(items, totalCount, page),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
            return;
        }

        if (parts.Length >= 3 && parts[1] == "detail" && int.TryParse(parts[2], out var entryId))
        {
            var entry = await _walletLedgerService.GetByIdAsync(callbackQuery.From.Id, entryId, cancellationToken);
            if (entry == null)
            {
                await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "تراکنش پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
                return;
            }

            await botClient.EditMessageText(
                chatId,
                callbackQuery.Message.MessageId,
                BuildWalletLedgerDetailText(entry),
                parseMode: ParseMode.Html,
                replyMarkup: new InlineKeyboardMarkup(new[]
                {
                    new[] { InlineKeyboardButton.WithCallbackData("↩️ بازگشت به لیست", "ledger:page:0") },
                    new[] { InlineKeyboardButton.WithCallbackData("🏠 منوی اصلی", "ledger:home") }
                }),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
            return;
        }

        if (parts.Length >= 2 && parts[1] == "home")
        {
            await botClient.SendMessage(
                chatId,
                "منوی اصلی",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
        }
    }

    private static string BuildWalletLedgerListText(IReadOnlyCollection<WalletLedgerEntry> items, int totalCount, int page)
    {
        var totalPages = Math.Max(1, (int)Math.Ceiling(totalCount / 8d));
        var builder = new StringBuilder();
        builder.AppendLine("📒 <b>تراکنش‌های من</b>");
        builder.AppendLine($"صفحه <code>{page + 1}</code> از <code>{totalPages}</code>");
        builder.AppendLine();
        builder.AppendLine(items.Count == 0
            ? "هنوز تراکنشی ثبت نشده است."
            : "برای مشاهده جزئیات، روی دکمه هر تراکنش بزنید.");
        return builder.ToString();
    }

    private static InlineKeyboardMarkup BuildWalletLedgerKeyboard(IReadOnlyCollection<WalletLedgerEntry> items, int totalCount, int page)
    {
        var rows = new List<InlineKeyboardButton[]>();
        foreach (var item in items)
        {
            var isCredit = string.Equals(item.Direction, WalletLedgerDirections.Credit, StringComparison.OrdinalIgnoreCase);
            var icon = isCredit ? "➕🟢" : "➖🔴";
            var text = $"{icon} {item.AmountToman.FormatCurrency()} 🔚 {item.BalanceAfter.FormatCurrency()}";
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData(text, $"ledger:detail:{item.Id}") });
        }

        var totalPages = Math.Max(1, (int)Math.Ceiling(totalCount / 8d));
        var nav = new List<InlineKeyboardButton>();
        if (page > 0)
            nav.Add(InlineKeyboardButton.WithCallbackData("⬅️ قبلی", $"ledger:page:{page - 1}"));
        if (page + 1 < totalPages)
            nav.Add(InlineKeyboardButton.WithCallbackData("بعدی ➡️", $"ledger:page:{page + 1}"));
        if (nav.Count > 0)
            rows.Add(nav.ToArray());

        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("🏠 منوی اصلی", "ledger:home") });
        return new InlineKeyboardMarkup(rows);
    }

    private static string BuildWalletLedgerDetailText(WalletLedgerEntry entry)
    {
        var isCredit = string.Equals(entry.Direction, WalletLedgerDirections.Credit, StringComparison.OrdinalIgnoreCase);
        return $"{(isCredit ? "➕🟢" : "➖🔴")} <b>جزئیات تراکنش</b>\n\n" +
               $"مبلغ: <code>{Html(entry.AmountToman.FormatCurrency())}</code>\n" +
               $"بابت: <code>{Html(entry.Reason)}</code>\n" +
               $"منبع/درگاه: <code>{Html(entry.Provider)}</code>\n" +
               $"شماره سفارش: <code>{Html(entry.OrderId)}</code>\n" +
               $"موجودی قبل: <code>{Html(entry.BalanceBefore.FormatCurrency())}</code>\n" +
               $"موجودی بعد: <code>{Html(entry.BalanceAfter.FormatCurrency())}</code>\n" +
               $"ربات: <code>{Html(entry.BotUsername)}</code>\n" +
               $"توضیح: <code>{Html(entry.Description)}</code>\n" +
               $"زمان: <code>{Html(entry.CreatedAtUtc.AddMinutes(210).ConvertToHijriShamsi())}</code>";
    }

    private async Task ProcessBroadcastStatusCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var jobId = callbackQuery.Data.Replace("broadcast_status_", "");
        var job = _broadcastManager.GetJob(jobId);
        if (job == null)
        {
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                text: "وضعیت این ارسال پیدا نشد.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        if (job.RequestedByTelegramUserId != callbackQuery.From.Id && !IsSuperAdminUser(callbackQuery.From.Id))
        {
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                text: "فقط ادمین شروع‌کننده ارسال می‌تواند این وضعیت را بروزرسانی کند.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        await _broadcastManager.RefreshStatusMessageAsync(jobId, cancellationToken);
        await SafeAnswerCallbackQueryAsync(
            callbackQuery.Id,
            text: "وضعیت بروزرسانی شد.",
            cancellationToken: cancellationToken);
    }

    private async Task StartBroadcastJobAsync(
        ITelegramBotClient botClient,
        Message message,
        IReadOnlyCollection<long> allUsers,
        BroadcastManager.BroadcastItem template,
        CancellationToken cancellationToken)
    {
        Message statusMessage = null;
        try
        {
            statusMessage = await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"در حال آماده‌سازی ارسال عمومی برای <code>{allUsers.Count}</code> کاربر...",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);

            var job = await _broadcastManager.EnqueueAsync(
                allUsers,
                template,
                message.Chat.Id,
                statusMessage.MessageId,
                message.From.Id,
                CancellationToken.None);

            await _broadcastManager.RefreshStatusMessageAsync(job.Id, cancellationToken);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "ارسال عمومی شروع شد. وضعیت را از پیام بالا پیگیری کنید.",
                replyMarkup: GetMainMenuKeyboard(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Broadcast start failed. admin={message.From?.Id}, error={ex}");
            var errorText = $"شروع ارسال عمومی با خطا روبه‌رو شد:\n<code>{Html(ex.Message)}</code>";
            if (statusMessage != null)
            {
                await botClient.EditMessageText(
                    chatId: message.Chat.Id,
                    messageId: statusMessage.MessageId,
                    text: errorText,
                    parseMode: ParseMode.Html,
                    cancellationToken: cancellationToken);
            }
            else
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: errorText,
                    parseMode: ParseMode.Html,
                    replyMarkup: GetMainMenuKeyboard(),
                    cancellationToken: cancellationToken);
            }
        }
    }

    private async Task ProcessZibalPaymentCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;

        if (!int.TryParse(callbackQuery.Data.Replace("check_payment_", ""), out var zpiId))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "شناسه پرداخت زیبال معتبر نیست.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var zpi = await _workflow.ReadAsync(async db => await db.ZibalPaymentInfos.FindAsync(new object[] { zpiId }, cancellationToken));
        if (zpi == null)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "پرداخت زیبال مورد نظر در دیتابیس پیدا نشد.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (zpi.IsAddedToBallance)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "اعتبار مربوط به این پرداخت قبلاً به حساب کاربری شما افزوده شده است.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            await EditMessageWithCallback(ActiveBotClient, zpi.ChatId, Convert.ToInt32(zpi.TelMsgId));
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var inquiry = await ZibalAPI.Inquiry(zpi.TrackId, _appConfig.ZibalMerchantCode);
        if (inquiry == null)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "پاسخ معتبری از زیبال دریافت نشد. لطفاً کمی بعد دوباره بررسی کنید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        zpi.Result = BuildZibalStatusText(inquiry);
        await _workflow.SaveAsync(cancellationToken);

        Console.WriteLine(
            $"[Zibal] inquiry paymentId={zpi.Id}, trackId={zpi.TrackId}, user={zpi.TelegramUserId}, status={inquiry.Status}, result={inquiry.Result}, message={inquiry.Message}");

        if (inquiry.Status == 2)
        {
            var verify = await ZibalAPI.Verify(zpi.TrackId, _appConfig.ZibalMerchantCode);
            zpi.Result = BuildZibalStatusText(inquiry, verify);
            await _workflow.SaveAsync(cancellationToken);

            Console.WriteLine(
                $"[Zibal] verify paymentId={zpi.Id}, trackId={zpi.TrackId}, result={verify?.Result}, status={verify?.Status}, message={verify?.Message}");

            if (verify != null && (verify.Result == 100 || verify.Result == 201))
            {
                var credUser = await _credentialsDbContext.GetUserStatus(new CredUser { TelegramUserId = zpi.TelegramUserId });
                zpi = ZibalAPI.MarkAsPaid(zpi, inquiry);
                await ZibalAddtoBalance(zpi, _appConfig, credUser, chatId, false);
                await AnswerCallbackSafely(callbackQuery, cancellationToken);
                return;
            }

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: BuildZibalUserMessage(zpi.TrackId, inquiry, verify),
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (inquiry.Status == 1)
        {
            var credUser = await _credentialsDbContext.GetUserStatus(new CredUser { TelegramUserId = zpi.TelegramUserId });
            zpi = ZibalAPI.MarkAsPaid(zpi, inquiry);
            await ZibalAddtoBalance(zpi, _appConfig, credUser, chatId, false);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (inquiry.Status == -1)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"نشست شماره `{zpi.TrackId}` هنوز در انتظار پرداخت است.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        zpi.IsExpired = IsFinalUnsuccessfulZibalStatus(inquiry.Status);
        await _workflow.SaveAsync(cancellationToken);

        await _userActivityLog.LogWarningAsync(
            "zibal_payment_not_successful",
            await _credentialsDbContext.GetUserStatus(new CredUser { TelegramUserId = zpi.TelegramUserId }),
            false,
            new Dictionary<string, object>
            {
                ["paymentId"] = zpi.Id,
                ["trackId"] = zpi.TrackId,
                ["status"] = inquiry.Status,
                ["result"] = inquiry.Result,
                ["message"] = inquiry.Message ?? string.Empty
            },
            cancellationToken);

        await ActiveBotClient.CustomSendTextMessageAsync(
            chatId: chatId,
            text: BuildZibalUserMessage(zpi.TrackId, inquiry, null),
            replyMarkup: MainReplyMarkupKeyboardFa(),
            cancellationToken: cancellationToken);

        await AnswerCallbackSafely(callbackQuery, cancellationToken);
    }

    private async Task ProcessCryptoPaymentCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var messageId = callbackQuery.Message?.MessageId ?? 0;
        var orderId = callbackQuery.Data.Replace("check_crypto_payment_", "");
        Console.WriteLine($"[NOWPayments ManualCheck] start user={callbackQuery.From.Id}, chat={chatId}, orderId={orderId}");

        var payment = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.FirstOrDefaultAsync(
            p => p.OrderId == orderId,
            cancellationToken));
        if (payment == null)
        {
            Console.WriteLine($"[NOWPayments ManualCheck] payment not found. orderId={orderId}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "پرداخت مورد نظر پیدا نشد.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (payment.IsAddedToBallance)
        {
            Console.WriteLine($"[NOWPayments ManualCheck] already added. orderId={payment.OrderId}, paymentId={payment.PaymentId}, user={payment.TelegramUserId}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است و دوباره شارژ نمی‌شود.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);

            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var data = payment.GetNowPaymentsData();
        NowPaymentsPaymentStatusResult status;
        try
        {
            var paymentId = payment.PaymentId ?? data.PaymentId;
            if (!string.IsNullOrWhiteSpace(paymentId))
            {
                status = await _nowPayments.GetPaymentStatusAsync(paymentId, cancellationToken);
                Console.WriteLine(
                    $"[NOWPayments ManualCheck] remote status received by payment_id. orderId={payment.OrderId}, paymentId={paymentId}, status={status?.payment_status}, actuallyPaid={status?.actually_paid}, payAmount={status?.pay_amount}, payCurrency={status?.pay_currency}");
            }
            else
            {
                var invoiceId = payment.InvoiceId ?? data.InvoiceId;
                Console.WriteLine(
                    $"[NOWPayments ManualCheck] payment_id missing; searching NOWPayments by invoice/order. orderId={payment.OrderId}, invoiceId={invoiceId}, invoiceUrl={payment.InvoiceUrl ?? data.InvoiceUrl}");

                status = await _nowPayments.FindPaymentStatusByInvoiceOrOrderAsync(
                    invoiceId,
                    payment.OrderId ?? data.OrderId,
                    cancellationToken);

                if (status == null)
                {
                    Console.WriteLine($"[NOWPayments ManualCheck] no remote payment found for invoice/order. orderId={payment.OrderId}, invoiceId={invoiceId}");
                    await ActiveBotClient.CustomSendTextMessageAsync(
                        chatId: chatId,
                        text: "هنوز پرداختی برای این فاکتور در لیست پرداخت‌های NOWPayments پیدا نشد.\n" +
                              "اگر پرداخت را تازه انجام داده‌اید چند دقیقه بعد دوباره بررسی کنید.\n\n" +
                              $"<a href=\"{System.Net.WebUtility.HtmlEncode(payment.InvoiceUrl ?? data.InvoiceUrl ?? "")}\">باز کردن فاکتور</a>",
                        parseMode: ParseMode.Html,
                        cancellationToken: cancellationToken);
                    await AnswerCallbackSafely(callbackQuery, cancellationToken);
                    return;
                }

                Console.WriteLine(
                    $"[NOWPayments ManualCheck] remote status received by invoice/order. orderId={payment.OrderId}, paymentId={status.payment_id}, invoiceId={status.invoice_id}, status={status.payment_status}, actuallyPaid={status.actually_paid}, payAmount={status.pay_amount}, payCurrency={status.pay_currency}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[NOWPayments ManualCheck] remote status failed. orderId={payment.OrderId}, paymentId={payment.PaymentId ?? data.PaymentId}, invoiceId={payment.InvoiceId ?? data.InvoiceId}, error={ex.Message}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"خطا در بررسی وضعیت پرداخت: <code>{System.Net.WebUtility.HtmlEncode(ex.Message)}</code>",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        data.Apply(status);
        payment.SetNowPaymentsData(data);
        payment.OutcomeAmount = data.PayAmount == 0 ? payment.OutcomeAmount : data.PayAmount;
        payment.BaseAmount = data.PriceAmount == 0 ? payment.BaseAmount : data.PriceAmount;
        await _workflow.SaveAsync(cancellationToken);
        Console.WriteLine($"[NOWPayments ManualCheck] local payment updated. orderId={payment.OrderId}, paymentId={payment.PaymentId}, status={payment.PaymentStatus}, added={payment.IsAddedToBalance}");

        if (NowPaymentsStatuses.IsPaid(data.PaymentStatus))
        {
            var settlement = await _nowPaymentsSettlementService.ApplyFinishedPaymentAsync(
                payment,
                "manual-check",
                chatId,
                cancellationToken);
            Console.WriteLine($"[NOWPayments ManualCheck] settlement result. orderId={payment.OrderId}, paymentId={payment.PaymentId}, settlement={settlement.Status}, before={settlement.BeforeBalance}, after={settlement.AfterBalance}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: BuildCryptoManualCheckSettlementText(payment, data, settlement),
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);
        }
        else if (NowPaymentsStatuses.IsPartiallyPaid(data.PaymentStatus))
        {
            var partialAmountToman = CalculatePartialCryptoChargeToman(payment, data);
            var text = BuildPartialCryptoPaymentText(payment, data, partialAmountToman);
            var replyMarkup = BuildPartialCryptoPaymentKeyboard(payment);
            Console.WriteLine($"[NOWPayments ManualCheck] partial payment. orderId={payment.OrderId}, paymentId={payment.PaymentId}, partialAmountToman={partialAmountToman}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: replyMarkup,
                cancellationToken: cancellationToken);
        }
        else
        {
            var text = $"وضعیت فعلی پرداخت: <code>{System.Net.WebUtility.HtmlEncode(data.PaymentStatus ?? "unknown")}</code>\n" +
                       "بعد از تایید شبکه، موجودی شما به صورت خودکار شارژ می‌شود.";

            if (NowPaymentsStatuses.IsFinalFailure(data.PaymentStatus))
                text = $"این پرداخت با وضعیت <code>{System.Net.WebUtility.HtmlEncode(data.PaymentStatus)}</code> بسته شده و قابل شارژ نیست.";

            Console.WriteLine($"[NOWPayments ManualCheck] not settled. orderId={payment.OrderId}, paymentId={payment.PaymentId}, status={data.PaymentStatus}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
        }

        await AnswerCallbackSafely(callbackQuery, cancellationToken);
    }

    private async Task ProcessHooshPayPaymentCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var messageId = callbackQuery.Message?.MessageId ?? 0;
        var lookupValue = callbackQuery.Data.StartsWith("hpchk_", StringComparison.Ordinal)
            ? callbackQuery.Data.Replace("hpchk_", "")
            : callbackQuery.Data.Replace("check_hooshpay_payment_", "");
        Console.WriteLine($"[HooshPay ManualCheck] start user={callbackQuery.From.Id}, chat={chatId}, lookup={lookupValue}");

        HooshPayPaymentInfo payment = null;
        if (int.TryParse(lookupValue, out var paymentId))
        {
            payment = await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.FindAsync(new object[] { paymentId }, cancellationToken));
        }

        payment ??= await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.FirstOrDefaultAsync(
            p => p.OrderId == lookupValue,
            cancellationToken));
        if (payment == null)
        {
            Console.WriteLine($"[HooshPay ManualCheck] payment not found. lookup={lookupValue}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "پرداخت مورد نظر پیدا نشد.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var needsProvisionalProviderReconciliation = payment.IsProvisionallyApproved &&
                                                   !payment.ProviderConfirmedAfterProvisionalAtUtc.HasValue;
        if (payment.IsAddedToBalance && !needsProvisionalProviderReconciliation)
        {
            Console.WriteLine($"[HooshPay ManualCheck] already added. orderId={payment.OrderId}, invoiceUid={payment.InvoiceUid}, user={payment.TelegramUserId}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است و دوباره شارژ نمی‌شود.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);

            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (string.IsNullOrWhiteSpace(payment.InvoiceUid))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "شناسه فاکتور HooshPay برای این پرداخت ثبت نشده است.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        HooshPayVerifyResponse verify;
        try
        {
            var invoice = await _hooshPay.GetInvoiceAsync(payment.InvoiceUid, cancellationToken);
            payment.Apply(invoice?.data);
            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);

            verify = await _hooshPay.VerifyInvoiceAsync(payment.InvoiceUid, cancellationToken);
            payment.Apply(verify?.data);
            if (!string.IsNullOrWhiteSpace(verify?.status))
                payment.PaymentStatus = verify.status;
            payment.RawResponseJson = JsonConvert.SerializeObject(new
            {
                invoice,
                verify
            });

            await _workflow.SaveAsync(cancellationToken);
            Console.WriteLine($"[HooshPay ManualCheck] remote status received. orderId={payment.OrderId}, invoiceUid={payment.InvoiceUid}, status={payment.PaymentStatus}, paid={verify?.paid}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[HooshPay ManualCheck] remote status failed. orderId={payment.OrderId}, invoiceUid={payment.InvoiceUid}, error={ex.Message}");
            payment.ErrorMessage = ex.Message;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"خطا در بررسی وضعیت پرداخت: <code>{Html(ex.Message)}</code>",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (verify?.paid == true || HooshPayStatuses.IsPaid(payment.PaymentStatus))
        {
            payment.PaymentStatus = HooshPayStatuses.Paid;
            var isTenantOrder = string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.TenantOrder, StringComparison.OrdinalIgnoreCase);
            if (!isTenantOrder)
                await _hooshPaySettlementService.RecordProviderConfirmationAfterProvisionalAsync(
                    payment,
                    "manual-check",
                    cancellationToken);

            var settlement = isTenantOrder
                ? await _tenantBotService.ApplyPaidTenantOrderAsync(
                    payment,
                    "manual-check",
                    cancellationToken)
                : await _hooshPaySettlementService.ApplyFinishedPaymentAsync(
                    payment,
                    "manual-check",
                    chatId,
                    cancellationToken);

            Console.WriteLine($"[HooshPay ManualCheck] settlement result. orderId={payment.OrderId}, invoiceUid={payment.InvoiceUid}, settlement={settlement.Status}, before={settlement.BeforeBalance}, after={settlement.AfterBalance}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: BuildHooshPayManualCheckSettlementText(payment, settlement),
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);
        }
        else
        {
            var text = needsProvisionalProviderReconciliation
                ? $"اعتبار این پرداخت قبلاً به صورت موقت شارژ شده است. وضعیت فعلی HooshPay: <code>{Html(payment.PaymentStatus ?? "unknown")}</code>\n" +
                  "پس از تایید رسمی درگاه، فقط ثبت reconciliation و لاگ انجام می‌شود."
                : $"وضعیت فعلی پرداخت: <code>{Html(payment.PaymentStatus ?? "unknown")}</code>\n" +
                  "بعد از تایید پرداخت، موجودی شما از طریق IPN یا بررسی دستی شارژ می‌شود.";

            if (HooshPayStatuses.IsFinalFailure(payment.PaymentStatus))
                text = $"این پرداخت با وضعیت <code>{Html(payment.PaymentStatus)}</code> بسته شده و قابل شارژ نیست.";

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
        }

        await AnswerCallbackSafely(callbackQuery, cancellationToken);
    }

    private static string BuildHooshPayManualCheckSettlementText(
        HooshPayPaymentInfo payment,
        NowPaymentsSettlementResult settlement)
    {
        var status = Html(payment?.PaymentStatus ?? "unknown");
        var orderId = Html(payment?.OrderId ?? "");
        var invoiceUid = Html(payment?.InvoiceUid ?? "");
        var amount = Html((payment?.AmountToman ?? 0).FormatCurrency());
        var payableAmount = Html((payment?.PayableAmountToman ?? 0).FormatCurrency());

        if (settlement?.Status == NowPaymentsSettlementStatus.Applied)
        {
            return "✅ پرداخت شما با موفقیت تایید شد و کیف پول شارژ شد.\n\n" +
                   $"📌 وضعیت: <code>{status}</code>\n" +
                   $"🧾 Order ID: <code>{orderId}</code>\n" +
                   $"🧾 Invoice UID: <code>{invoiceUid}</code>\n" +
                   $"💰 مبلغ شارژ: <code>{amount}</code>\n" +
                   $"💳 مبلغ پرداختی: <code>{payableAmount}</code>\n" +
                   $"💳 موجودی قبل: <code>{Html(settlement.BeforeBalance.FormatCurrency())}</code>\n" +
                   $"💳 موجودی بعد: <code>{Html(settlement.AfterBalance.FormatCurrency())}</code>";
        }

        if (settlement?.Status == NowPaymentsSettlementStatus.AlreadyAdded)
        {
            return "ℹ️ اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است.\n\n" +
                   $"📌 وضعیت: <code>{status}</code>\n" +
                   $"🧾 Order ID: <code>{orderId}</code>\n" +
                   $"🧾 Invoice UID: <code>{invoiceUid}</code>\n" +
                   $"💳 موجودی فعلی: <code>{Html(settlement.AfterBalance.FormatCurrency())}</code>";
        }

        if (settlement?.Status == NowPaymentsSettlementStatus.UserNotFound)
            return "پرداخت در سمت HooshPay تایید شده، اما کاربر مربوط به این پرداخت در دیتابیس پیدا نشد.";

        return $"پرداخت تایید شد، اما شارژ کیف پول انجام نشد. وضعیت تسویه: <code>{Html(settlement?.Status.ToString() ?? "unknown")}</code>";
    }

    private static string BuildCryptoManualCheckSettlementText(
        SwapinoPaymentInfo payment,
        NowPaymentsPaymentRecordData data,
        NowPaymentsSettlementResult settlement)
    {
        var status = Html(data?.PaymentStatus ?? payment?.PaymentStatus ?? "unknown");
        var orderId = Html(payment?.OrderId ?? "");
        var paymentId = Html(payment?.PaymentId ?? data?.PaymentId ?? "");
        var amount = Html((payment?.AmountToman ?? 0).FormatCurrency());

        if (settlement?.Status == NowPaymentsSettlementStatus.Applied)
        {
            return "✅ پرداخت شما با موفقیت تایید شد و کیف پول شارژ شد.\n\n" +
                   $"📌 وضعیت: <code>{status}</code>\n" +
                   $"🧾 Order ID: <code>{orderId}</code>\n" +
                   $"🧾 Payment ID: <code>{paymentId}</code>\n" +
                   $"💰 مبلغ شارژ: <code>{amount}</code>\n" +
                   $"💳 موجودی قبل: <code>{Html(settlement.BeforeBalance.FormatCurrency())}</code>\n" +
                   $"💳 موجودی بعد: <code>{Html(settlement.AfterBalance.FormatCurrency())}</code>";
        }

        if (settlement?.Status == NowPaymentsSettlementStatus.AlreadyAdded)
        {
            return "ℹ️ اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است.\n\n" +
                   $"📌 وضعیت: <code>{status}</code>\n" +
                   $"🧾 Order ID: <code>{orderId}</code>\n" +
                   $"🧾 Payment ID: <code>{paymentId}</code>\n" +
                   $"💳 موجودی فعلی: <code>{Html(settlement.AfterBalance.FormatCurrency())}</code>";
        }

        if (settlement?.Status == NowPaymentsSettlementStatus.UserNotFound)
        {
            return "پرداخت در سمت NOWPayments تایید شده، اما کاربر مربوط به این پرداخت در دیتابیس پیدا نشد.\n" +
                   $"🧾 Order ID: <code>{orderId}</code>";
        }

        return "پرداخت در سمت NOWPayments تایید شده، اما شارژ کیف پول کامل نشد.\n\n" +
               $"📌 وضعیت پرداخت: <code>{status}</code>\n" +
               $"📌 نتیجه شارژ: <code>{Html(settlement?.Status.ToString() ?? "unknown")}</code>\n" +
               $"🧾 Order ID: <code>{orderId}</code>";
    }

    /// <summary>
    /// Handles an owned-wallet NOWPayments success or cancellation return without allowing a start payload to fall
    /// into an unrelated customer or super-admin state machine.
    /// </summary>
    /// <param name="botClient">Owned bot client that received the return message and sends progress/result text.</param>
    /// <param name="message">
    /// Incoming Telegram message containing a validated payment return command or legacy bare return token. Its sender
    /// id identifies the owned-wallet customer and its chat id receives the result.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials profile loaded for the sender. It is used only as a Telegram user-id fallback and may be
    /// <c>null</c>; the authoritative wallet payment remains the bot-scoped users.db row.
    /// </param>
    /// <param name="mainReplyMarkup">Owned customer or super-admin home keyboard shown after a terminal response.</param>
    /// <param name="cancellationToken">Token for users.db, provider inquiry, settlement, and Telegram operations.</param>
    /// <returns>
    /// <c>true</c> when the message is a NOWPayments return and was consumed, including when no pending row exists;
    /// otherwise <c>false</c> so normal owned routing can continue.
    /// </returns>
    /// <remarks>
    /// <see cref="HandleUpdateCoreAsync"/> clears transient bot-scoped conversation state before calling this method.
    /// A success return is only a lookup trigger: wallet credit still requires the existing authoritative provider
    /// verification and idempotent settlement path. A cancellation return updates only the matching pending payment
    /// record; it does not debit or credit a wallet. Payment rows are filtered by Telegram user and active bot id so a
    /// return link cannot settle another owned brand's invoice.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (await TryHandleNowPaymentsReturnStartAsync(
    ///         botClient,
    ///         message,
    ///         credUser,
    ///         mainReplyMarkup,
    ///         cancellationToken))
    /// {
    ///     return;
    /// }
    /// </code>
    /// </example>
    private async Task<bool> TryHandleNowPaymentsReturnStartAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (message?.Text == null)
            return false;

        if (!TryParseNowPaymentsReturnCommand(
                message.Text,
                CurrentBot?.Username ?? BotContextAccessor.CurrentBotUsername,
                out var isSuccess))
        {
            return false;
        }

        var isCancel = !isSuccess;

        var telegramUserId = message.From?.Id ?? credUser?.TelegramUserId ?? 0;
        Console.WriteLine($"[NOWPayments ReturnUrl] received start. user={telegramUserId}, chat={message.Chat.Id}, text={message.Text}, success={isSuccess}, cancel={isCancel}");

        var payment = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos
            .Where(p => p.TelegramUserId == telegramUserId &&
                        !p.IsAddedToBalance &&
                        (p.BotId == BotContextAccessor.CurrentBotId || string.IsNullOrWhiteSpace(p.BotId)))
            .OrderByDescending(p => p.Id)
            .FirstOrDefaultAsync(cancellationToken));

        if (payment == null)
        {
            Console.WriteLine($"[NOWPayments ReturnUrl] no pending crypto payment found. user={telegramUserId}");
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: isCancel
                    ? "پرداخت در حال انتظاری برای بستن پیدا نشد. اگر قبلاً کنسل شده باشد، نیازی به اقدام دوباره نیست."
                    : "پرداخت در حال انتظاری برای حساب شما پیدا نشد. اگر کیف پول قبلاً شارژ شده، نیازی به اقدام دوباره نیست.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (isCancel)
        {
            payment.PaymentStatus = "cancelled_by_user";
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "پرداخت توسط کاربر کنسل شد و فاکتور مربوطه در درگاه پرداخت به صورت بسته شده درآمد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "پرداخت از سمت درگاه پرداخت تایید شد.\nدر حال بررسی وضعیت پرداخت از NOWPayments هستم...",
            cancellationToken: cancellationToken);

        await CheckAndSettleCryptoPaymentCoreAsync(
            payment,
            message.Chat.Id,
            0,
            telegramUserId,
            "success-url",
            mainReplyMarkup,
            cancellationToken);

        return true;
    }

    /// <summary>
    /// Recognizes the bot-addressed NOWPayments return payloads and their retained legacy bare aliases.
    /// </summary>
    /// <param name="text">
    /// Raw Telegram message text. Supported values are a start command carrying <c>payment_success</c> or
    /// <c>payment_cancel</c>, or the legacy bare token with the same name.
    /// </param>
    /// <param name="currentBotUsername">
    /// Username of the owned bot handling the message. A command with an <c>@username</c> mention must match this value.
    /// </param>
    /// <param name="isSuccess">
    /// <c>true</c> for the success payload and <c>false</c> for the cancellation payload when parsing succeeds. Callers
    /// must ignore this value when the method returns <c>false</c>.
    /// </param>
    /// <returns><c>true</c> for a complete supported return token; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// This method is side-effect free. It deliberately requires a token boundary so attacker-controlled values such
    /// as <c>payment_success_fake</c> cannot trigger a provider lookup. Financial verification remains the
    /// responsibility of <see cref="TryHandleNowPaymentsReturnStartAsync"/>.
    /// </remarks>
    /// <example>
    /// <code>
    /// TryParseNowPaymentsReturnCommand("/start@ShopBot payment_success", "ShopBot", out var isSuccess);
    /// </code>
    /// </example>
    private static bool TryParseNowPaymentsReturnCommand(
        string text,
        string currentBotUsername,
        out bool isSuccess)
    {
        isSuccess = false;
        var normalized = text?.Trim();
        if (string.Equals(normalized, "payment_success", StringComparison.OrdinalIgnoreCase))
        {
            isSuccess = true;
            return true;
        }

        if (string.Equals(normalized, "payment_cancel", StringComparison.OrdinalIgnoreCase))
            return true;

        if (!TelegramNavigationCommandParser.TryParse(
                text,
                currentBotUsername,
                allowRefresh: false,
                out var command) ||
            command.Kind != TelegramNavigationCommandKind.Start)
        {
            return false;
        }

        if (command.HasPayloadToken("payment_success"))
        {
            isSuccess = true;
            return true;
        }

        return command.HasPayloadToken("payment_cancel");
    }

    private async Task CheckAndSettleCryptoPaymentCoreAsync(
        SwapinoPaymentInfo payment,
        long chatId,
        int messageId,
        long actorUserId,
        string source,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (payment.IsAddedToBalance)
        {
            Console.WriteLine($"[NOWPayments ManualCheck] already added. source={source}, actor={actorUserId}, orderId={payment.OrderId}, paymentId={payment.PaymentId}, user={payment.TelegramUserId}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است و دوباره شارژ نمی‌شود.",
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);

            return;
        }

        var data = payment.GetNowPaymentsData();
        NowPaymentsPaymentStatusResult status;
        try
        {
            var paymentId = payment.PaymentId ?? data.PaymentId;
            if (!string.IsNullOrWhiteSpace(paymentId))
            {
                status = await _nowPayments.GetPaymentStatusAsync(paymentId, cancellationToken);
                Console.WriteLine(
                    $"[NOWPayments ManualCheck] remote status received by payment_id. source={source}, orderId={payment.OrderId}, paymentId={paymentId}, status={status?.payment_status}, actuallyPaid={status?.actually_paid}, payAmount={status?.pay_amount}, payCurrency={status?.pay_currency}");
            }
            else
            {
                var invoiceId = payment.InvoiceId ?? data.InvoiceId;
                Console.WriteLine(
                    $"[NOWPayments ManualCheck] payment_id missing; searching NOWPayments by invoice/order. source={source}, orderId={payment.OrderId}, invoiceId={invoiceId}, invoiceUrl={payment.InvoiceUrl ?? data.InvoiceUrl}");

                status = await _nowPayments.FindPaymentStatusByInvoiceOrOrderAsync(
                    invoiceId,
                    payment.OrderId ?? data.OrderId,
                    cancellationToken);

                if (status == null)
                {
                    Console.WriteLine($"[NOWPayments ManualCheck] no remote payment found for invoice/order. source={source}, orderId={payment.OrderId}, invoiceId={invoiceId}");
                    await ActiveBotClient.CustomSendTextMessageAsync(
                        chatId: chatId,
                        text: "هنوز پرداختی برای این فاکتور در لیست پرداخت‌های NOWPayments پیدا نشد.\n" +
                              "اگر پرداخت را تازه انجام داده‌اید چند دقیقه بعد دوباره بررسی کنید.\n\n" +
                              $"<a href=\"{System.Net.WebUtility.HtmlEncode(payment.InvoiceUrl ?? data.InvoiceUrl ?? "")}\">باز کردن فاکتور</a>",
                        parseMode: ParseMode.Html,
                        replyMarkup: mainReplyMarkup,
                        cancellationToken: cancellationToken);
                    return;
                }

                Console.WriteLine(
                    $"[NOWPayments ManualCheck] remote status received by invoice/order. source={source}, orderId={payment.OrderId}, paymentId={status.payment_id}, invoiceId={status.invoice_id}, status={status.payment_status}, actuallyPaid={status.actually_paid}, payAmount={status.pay_amount}, payCurrency={status.pay_currency}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[NOWPayments ManualCheck] remote status failed. source={source}, orderId={payment.OrderId}, paymentId={payment.PaymentId ?? data.PaymentId}, invoiceId={payment.InvoiceId ?? data.InvoiceId}, error={ex.Message}");
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"خطا در بررسی وضعیت پرداخت: <code>{System.Net.WebUtility.HtmlEncode(ex.Message)}</code>",
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        data.Apply(status);
        payment.SetNowPaymentsData(data);
        payment.OutcomeAmount = data.PayAmount == 0 ? payment.OutcomeAmount : data.PayAmount;
        payment.BaseAmount = data.PriceAmount == 0 ? payment.BaseAmount : data.PriceAmount;
        await _workflow.SaveAsync(cancellationToken);
        Console.WriteLine($"[NOWPayments ManualCheck] local payment updated. source={source}, orderId={payment.OrderId}, paymentId={payment.PaymentId}, status={payment.PaymentStatus}, added={payment.IsAddedToBalance}");

        if (NowPaymentsStatuses.IsPaid(data.PaymentStatus))
        {
            var settlement = await _nowPaymentsSettlementService.ApplyFinishedPaymentAsync(
                payment,
                source,
                chatId,
                cancellationToken);
            Console.WriteLine($"[NOWPayments ManualCheck] settlement result. source={source}, orderId={payment.OrderId}, paymentId={payment.PaymentId}, settlement={settlement.Status}, before={settlement.BeforeBalance}, after={settlement.AfterBalance}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: BuildCryptoManualCheckSettlementText(payment, data, settlement),
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);
        }
        else if (NowPaymentsStatuses.IsPartiallyPaid(data.PaymentStatus))
        {
            var partialAmountToman = CalculatePartialCryptoChargeToman(payment, data);
            var text = BuildPartialCryptoPaymentText(payment, data, partialAmountToman);
            var replyMarkup = BuildPartialCryptoPaymentKeyboard(payment);
            Console.WriteLine($"[NOWPayments ManualCheck] partial payment. source={source}, orderId={payment.OrderId}, paymentId={payment.PaymentId}, partialAmountToman={partialAmountToman}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: replyMarkup,
                cancellationToken: cancellationToken);
        }
        else
        {
            var text = $"وضعیت فعلی پرداخت: <code>{System.Net.WebUtility.HtmlEncode(data.PaymentStatus ?? "unknown")}</code>\n" +
                       "بعد از تایید شبکه، موجودی شما به صورت خودکار شارژ می‌شود.";

            if (NowPaymentsStatuses.IsFinalFailure(data.PaymentStatus))
                text = $"این پرداخت با وضعیت <code>{System.Net.WebUtility.HtmlEncode(data.PaymentStatus)}</code> بسته شده و قابل شارژ نیست.";

            Console.WriteLine($"[NOWPayments ManualCheck] not settled. source={source}, orderId={payment.OrderId}, paymentId={payment.PaymentId}, status={data.PaymentStatus}");

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
        }
    }

    private async Task ProcessCryptoPartialSettlementCallback(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var messageId = callbackQuery.Message?.MessageId ?? 0;
        var idText = callbackQuery.Data.Replace("settle_crypto_partial_", "");

        if (!int.TryParse(idText, out var paymentDbId))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "شناسه پرداخت ناقص معتبر نیست.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var payment = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.FirstOrDefaultAsync(
            p => p.Id == paymentDbId,
            cancellationToken));

        if (payment == null)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "پرداخت مورد نظر پیدا نشد.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (payment.IsAddedToBalance)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "اعتبار این پرداخت قبلاً به کیف پول شما اضافه شده است.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);

            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var data = payment.GetNowPaymentsData();
        if (string.IsNullOrWhiteSpace(payment.PaymentId ?? data.PaymentId))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "شناسه پرداخت NOWPayments هنوز ثبت نشده است. کمی بعد دوباره بررسی کنید.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        try
        {
            var status = await _nowPayments.GetPaymentStatusAsync(payment.PaymentId ?? data.PaymentId, cancellationToken);
            data.Apply(status);
            payment.SetNowPaymentsData(data);
            payment.OutcomeAmount = data.PayAmount == 0 ? payment.OutcomeAmount : data.PayAmount;
            payment.BaseAmount = data.PriceAmount == 0 ? payment.BaseAmount : data.PriceAmount;
            await _workflow.SaveAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"خطا در بررسی مجدد پرداخت: <code>{System.Net.WebUtility.HtmlEncode(ex.Message)}</code>",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (NowPaymentsStatuses.IsPaid(data.PaymentStatus))
        {
            await _nowPaymentsSettlementService.ApplyFinishedPaymentAsync(
                payment,
                "manual-check-after-partial",
                chatId,
                cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);

            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        if (!NowPaymentsStatuses.IsPartiallyPaid(data.PaymentStatus))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"این پرداخت در وضعیت <code>{System.Net.WebUtility.HtmlEncode(data.PaymentStatus ?? "unknown")}</code> است و فعلاً قابل شارژ نسبی نیست.",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var partialAmountToman = CalculatePartialCryptoChargeToman(payment, data);
        if (partialAmountToman <= 0)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: "مقدار پرداخت‌شده برای شارژ نسبی قابل محاسبه نیست. لطفاً ادامه مبلغ را پرداخت کنید یا با پشتیبانی تماس بگیرید.",
                parseMode: ParseMode.Html,
                replyMarkup: BuildPartialCryptoPaymentKeyboard(payment),
                cancellationToken: cancellationToken);
            await AnswerCallbackSafely(callbackQuery, cancellationToken);
            return;
        }

        var settlement = await _nowPaymentsSettlementService.ApplyPartialPaymentAsync(
            payment,
            partialAmountToman,
            "manual-partial-check",
            chatId,
            cancellationToken);

        if (settlement.Status == NowPaymentsSettlementStatus.Applied)
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"پرداخت ناقص به اندازه <code>{partialAmountToman.FormatCurrency()}</code> به کیف پول شما اضافه شد.",
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            if (messageId != 0)
                await EditMessageWithCallback(ActiveBotClient, chatId, messageId);
        }
        else
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: chatId,
                text: $"شارژ نسبی انجام نشد. وضعیت: <code>{settlement.Status}</code>",
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
        }

        await AnswerCallbackSafely(callbackQuery, cancellationToken);
    }

    private static string BuildPartialCryptoPaymentText(
        SwapinoPaymentInfo payment,
        NowPaymentsPaymentRecordData data,
        long partialAmountToman)
    {
        var expectedPayAmount = GetExpectedCryptoPayAmount(payment, data);
        var actuallyPaid = GetActuallyPaidCryptoAmount(payment, data);
        var remaining = expectedPayAmount > actuallyPaid
            ? expectedPayAmount - actuallyPaid
            : 0;
        var payCurrency = payment.PayCurrency ?? data.PayCurrency ?? "crypto";
        var baseCurrency = payment.BaseCurrency ?? data.PriceCurrency ?? "usdtbsc";
        var baseAmount = payment.BaseAmount == 0 ? data.PriceAmount : payment.BaseAmount;

        var builder = new StringBuilder();
        builder.AppendLine("⚠️ <b>پرداخت شما ناقص ثبت شده است.</b>");
        builder.AppendLine();
        builder.AppendLine($"🧾 سفارش: <code>{Html(payment.OrderId)}</code>");
        builder.AppendLine($"📌 وضعیت: <code>{Html(data.PaymentStatus ?? payment.PaymentStatus ?? "partially_paid")}</code>");
        builder.AppendLine($"💵 مبلغ سفارش: <code>{Html(FormatCryptoDecimal(baseAmount))} {Html(baseCurrency)}</code>");
        builder.AppendLine($"🪙 مبلغ مورد انتظار: <code>{Html(FormatCryptoDecimal(expectedPayAmount))} {Html(payCurrency)}</code>");
        builder.AppendLine($"✅ پرداخت‌شده: <code>{Html(FormatCryptoDecimal(actuallyPaid))} {Html(payCurrency)}</code>");

        if (remaining > 0)
            builder.AppendLine($"⏳ باقی‌مانده: <code>{Html(FormatCryptoDecimal(remaining))} {Html(payCurrency)}</code>");

        builder.AppendLine();
        if (partialAmountToman > 0)
        {
            builder.AppendLine($"💰 معادل قابل شارژ فعلی: <code>{Html(partialAmountToman.FormatCurrency())}</code>");
            builder.AppendLine();
            builder.AppendLine("می‌توانید باقی مبلغ را از همان فاکتور پرداخت کنید، یا فقط همین مقدار پرداخت‌شده را به کیف پول خود اضافه کنید.");
        }
        else
        {
            builder.AppendLine("مقدار پرداخت‌شده هنوز برای شارژ نسبی قابل محاسبه نیست. لطفاً کمی بعد دوباره بررسی کنید یا ادامه مبلغ را پرداخت کنید.");
        }

        return builder.ToString();
    }

    private static InlineKeyboardMarkup BuildPartialCryptoPaymentKeyboard(SwapinoPaymentInfo payment)
    {
        var rows = new List<InlineKeyboardButton[]>();
        var invoiceUrl = payment.InvoiceUrl ?? payment.GetNowPaymentsData().InvoiceUrl;
        if (!string.IsNullOrWhiteSpace(invoiceUrl))
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithUrl("پرداخت باقی‌مانده", invoiceUrl)
            });
        }

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("شارژ به اندازه پرداختی", $"settle_crypto_partial_{payment.Id}")
        });

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("بررسی مجدد", $"check_crypto_payment_{payment.OrderId}")
        });

        return new InlineKeyboardMarkup(rows);
    }

    private static long CalculatePartialCryptoChargeToman(SwapinoPaymentInfo payment, NowPaymentsPaymentRecordData data)
    {
        if (payment == null || payment.AmountToman <= 0 || data == null)
            return 0;

        var expectedPayAmount = GetExpectedCryptoPayAmount(payment, data);
        var actuallyPaid = GetActuallyPaidCryptoAmount(payment, data);

        if (expectedPayAmount <= 0 || actuallyPaid <= 0)
        {
            var baseAmount = payment.BaseAmount == 0 ? data.PriceAmount : payment.BaseAmount;
            var actuallyPaidAtFiat = payment.ActuallyPaidAtFiat == 0 ? data.ActuallyPaidAtFiat : payment.ActuallyPaidAtFiat;
            if (baseAmount <= 0 || actuallyPaidAtFiat <= 0)
                return 0;

            return ClampPartialTomanAmount(payment.AmountToman, actuallyPaidAtFiat / baseAmount);
        }

        return ClampPartialTomanAmount(payment.AmountToman, actuallyPaid / expectedPayAmount);
    }

    private static decimal GetExpectedCryptoPayAmount(SwapinoPaymentInfo payment, NowPaymentsPaymentRecordData data)
    {
        if (data?.PayAmount > 0)
            return data.PayAmount;

        if (payment?.OutcomeAmount > 0)
            return payment.OutcomeAmount;

        return 0;
    }

    private static decimal GetActuallyPaidCryptoAmount(SwapinoPaymentInfo payment, NowPaymentsPaymentRecordData data)
    {
        if (data?.ActuallyPaid > 0)
            return data.ActuallyPaid;

        if (data?.AmountReceived > 0)
            return data.AmountReceived;

        if (payment?.ActuallyPaid > 0)
            return payment.ActuallyPaid;

        return 0;
    }

    private static long ClampPartialTomanAmount(long originalAmountToman, decimal ratio)
    {
        if (ratio <= 0)
            return 0;

        if (ratio > 1)
            ratio = 1;

        return (long)Math.Floor(originalAmountToman * ratio);
    }

    private static string FormatCryptoDecimal(decimal value)
    {
        return value.ToString("0.########", CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Acknowledges one callback through the active bot client using the bounded best-effort policy.
    /// </summary>
    /// <param name="callbackQueryId">Opaque Telegram callback id valid only briefly.</param>
    /// <param name="text">Optional toast or alert text; must never contain secrets.</param>
    /// <param name="showAlert">When true Telegram shows <paramref name="text"/> as a modal alert.</param>
    /// <param name="url">Optional game-callback URL; normally null.</param>
    /// <param name="cacheTime">Optional Telegram callback cache lifetime in seconds; normally null.</param>
    /// <param name="cancellationToken">Update lane cancellation token.</param>
    /// <param name="telegramUserId">
    /// Optional sender id of the user who tapped the button, for UX latency telemetry only. When omitted the ambient
    /// <see cref="TelegramInteractionActor"/> value recorded at dispatch is used.
    /// </param>
    /// <returns>A task completing after the bounded acknowledgement attempt; the result is never used for business logic.</returns>
    private Task<bool> SafeAnswerCallbackQueryAsync(
        string callbackQueryId,
        string text = null,
        bool? showAlert = null,
        string url = null,
        int? cacheTime = null,
        CancellationToken cancellationToken = default,
        long? telegramUserId = null)
        => TelegramCallbackAnswerPolicy.TryAnswerAsync(
            ActiveBotClient, callbackQueryId, text, showAlert, url, cacheTime, cancellationToken,
            _logger, BotContextAccessor.CurrentBotId, telegramUserId ?? TelegramInteractionActor.Current,
            _interactionTimeouts.CallbackAnswer);

    /// <summary>
    /// Acknowledges one callback through an explicitly supplied bot client using the bounded best-effort policy.
    /// </summary>
    /// <param name="botClient">Client of the bot that received the callback; never another bot of the same owner.</param>
    /// <param name="callbackQueryId">Opaque Telegram callback id valid only briefly.</param>
    /// <param name="text">Optional toast or alert text; must never contain secrets.</param>
    /// <param name="showAlert">When true Telegram shows <paramref name="text"/> as a modal alert.</param>
    /// <param name="url">Optional game-callback URL; normally null.</param>
    /// <param name="cacheTime">Optional Telegram callback cache lifetime in seconds; normally null.</param>
    /// <param name="cancellationToken">Update lane cancellation token.</param>
    /// <param name="telegramUserId">Optional sender id of the user who tapped the button, for telemetry only.</param>
    /// <returns>A task completing after the bounded acknowledgement attempt.</returns>
    private Task<bool> SafeAnswerCallbackQueryAsync(
        ITelegramBotClient botClient,
        string callbackQueryId,
        string text = null,
        bool? showAlert = null,
        string url = null,
        int? cacheTime = null,
        CancellationToken cancellationToken = default,
        long? telegramUserId = null)
        => TelegramCallbackAnswerPolicy.TryAnswerAsync(
            botClient, callbackQueryId, text, showAlert, url, cacheTime, cancellationToken,
            _logger, BotContextAccessor.CurrentBotId, telegramUserId ?? TelegramInteractionActor.Current,
            _interactionTimeouts.CallbackAnswer);

    /// <summary>
    /// Acknowledges one callback whose sender identity is known from the query itself.
    /// </summary>
    /// <param name="callbackQuery">Callback being answered; its sender id is forwarded for latency telemetry.</param>
    /// <param name="cancellationToken">Update lane cancellation token.</param>
    /// <returns>A task completing after the bounded acknowledgement attempt.</returns>
    /// <remarks>
    /// The sender is passed explicitly here because the query is in hand. Other call sites hold only the opaque callback
    /// id and rely on the ambient <see cref="TelegramInteractionActor"/> recorded for the update execution, so latency
    /// telemetry names the waiting user instead of <c>(null)</c>.
    /// </remarks>
    private async Task AnswerCallbackSafely(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        await SafeAnswerCallbackQueryAsync(
            callbackQuery.Id, cancellationToken: cancellationToken, telegramUserId: callbackQuery?.From?.Id);
    }

    private static string BuildZibalStatusText(InquiryResponse inquiry, PaymentVerificationResponse verify = null)
    {
        var builder = new StringBuilder();
        builder.Append($"inquiry_status={inquiry?.Status}");
        builder.Append($", inquiry_result={inquiry?.Result}");
        builder.Append($", inquiry_message={inquiry?.Message ?? string.Empty}");

        if (verify != null)
        {
            builder.Append($", verify_status={verify.Status}");
            builder.Append($", verify_result={verify.Result}");
            builder.Append($", verify_message={verify.Message ?? string.Empty}");
            builder.Append($", ref_number={verify.RefNumber ?? string.Empty}");
        }

        return builder.ToString();
    }

    private static string BuildZibalUserMessage(long trackId, InquiryResponse inquiry, PaymentVerificationResponse verify)
    {
        if (inquiry == null)
            return "امکان بررسی وضعیت پرداخت وجود ندارد. لطفاً کمی بعد دوباره تلاش کنید.";

        if (inquiry.Status == -1)
            return $"نشست شماره `{trackId}` هنوز در انتظار پرداخت است.";

        if (inquiry.Status == 2 && verify != null)
        {
            if (verify.Result == 100 || verify.Result == 201)
                return "پرداخت با موفقیت تایید شد و اعتبار به حساب شما اضافه شد.";

            return $"پرداخت انجام شده، اما تایید نهایی زیبال موفق نبود.\nکد پیگیری: `{trackId}`\nکد پاسخ: `{verify.Result}`\nلطفاً چند دقیقه بعد دوباره بررسی کنید یا با پشتیبانی تماس بگیرید.";
        }

        var statusText = inquiry.Status switch
        {
            3 => "پرداخت لغو شده است.",
            4 => "پرداخت ناموفق بوده است.",
            5 => "نشست پرداخت منقضی شده است.",
            _ => "پرداخت در وضعیت موفق قرار ندارد."
        };

        return $"{statusText}\nکد پیگیری: `{trackId}`\nکد وضعیت زیبال: `{inquiry.Status}`";
    }

    private static bool IsFinalUnsuccessfulZibalStatus(int status)
    {
        return status == 3 || status == 4 || status == 5;
    }

    /// <summary>
    /// Applies one provider-verified Zibal wallet charge using its persisted payment guard, records its ledger, and processes owned referral rewards.
    /// </summary>
    /// <param name="zpi">Local Zibal row containing final provider status, track id, wallet amount in rial, and originating bot.</param>
    /// <param name="appConfig">Application configuration retained for legacy call-site compatibility.</param>
    /// <param name="credUser">Legacy caller profile; the authoritative target user is reloaded by <paramref name="zpi"/> Telegram id.</param>
    /// <param name="chatid">Telegram chat id that receives the final wallet-credit confirmation.</param>
    /// <param name="isAdmin">Whether provider verification was initiated from an admin flow; this does not bypass final provider status.</param>
    /// <returns>A task that completes after wallet, ledger, referral, notification, and payment-message updates.</returns>
    /// <remarks>
    /// The amount is converted from rial to Iranian toman by dividing by ten. Only rows with <c>IsPaid=true</c>
    /// reach referral settlement. Repeated calls repair missing audit/referral work but never credit the wallet twice.
    /// </remarks>
    public async Task ZibalAddtoBalance(ZibalPaymentInfo zpi, AppConfig appConfig, CredUser credUser, long chatid, bool isAdmin)
    {
        if (zpi == null)
            return;
        zpi = await _workflow.ReadAsync(async db => await db.ZibalPaymentInfos.SingleAsync(x => x.Id == zpi.Id));
        await _workflow.ReloadAsync(zpi);
        if (!zpi.IsPaid)
            return;

        var findedUser = await _credentialsDbContext.GetUserStatusWithId(zpi.TelegramUserId);
        if (findedUser == null)
            return;

        var zibalProviderPaymentId = zpi.TrackId > 0
            ? zpi.TrackId.ToString(CultureInfo.InvariantCulture)
            : zpi.Id.ToString(CultureInfo.InvariantCulture);
        var zibalMutationKey = $"wallet-credit:zibal:{TenantBotPaymentPurposes.WalletCharge}:{zibalProviderPaymentId}";
        if (zpi.IsAddedToBallance)
        {
            await _walletLedgerService.RecordAsync(
                zpi.TelegramUserId,
                WalletLedgerDirections.Credit,
                zpi.Amount / 10,
                findedUser.AccountBalance - (zpi.Amount / 10),
                findedUser.AccountBalance,
                WalletLedgerReasons.WalletCharge,
                provider: "zibal",
                referenceType: nameof(ZibalPaymentInfo),
                referenceId: zpi.Id.ToString(CultureInfo.InvariantCulture),
                orderId: zibalProviderPaymentId,
                description: "Zibal wallet charge",
                botId: zpi.BotId,
                botUsername: zpi.BotUsername,
                botType: BotInstanceTypes.Owned,
                idempotencyKey: $"payment:zibal:{zpi.Id}:credit",
                cancellationToken: CancellationToken.None);
            if (zpi.IsPaid)
            {
                await _referralService.ProcessFinalOwnedWalletPaymentAsync(
                    new ReferralPaymentSource(
                        "zibal",
                        TenantBotPaymentPurposes.WalletCharge,
                        zibalProviderPaymentId,
                        zpi.BotId,
                        BotInstanceTypes.Owned,
                        zpi.TelegramUserId,
                        zpi.Amount / 10,
                        zpi.PaidAt == default ? zpi.CreatedAt : zpi.PaidAt,
                        true,
                        true,
                        false),
                    CancellationToken.None);
            }
            return;
        }

        var beforeBalance = findedUser.AccountBalance;
        var credited = await _credentialsDbContext.AddFund(
            zpi.TelegramUserId,
            zpi.Amount / 10, $"payment:zibal:{zpi.Id}:credit", botId: zpi.BotId);
        if (!credited)
            return;
        var walletReceipt = await _credentialsDbContext.GetWalletOperationAsync($"payment:zibal:{zpi.Id}:credit");
        beforeBalance = walletReceipt.BeforeBalance;
        var afterBalance = walletReceipt.AfterBalance;

        zpi.IsAddedToBallance = true;

        await _workflow.SaveAsync();
        await _walletLedgerService.RecordAsync(
            zpi.TelegramUserId,
            WalletLedgerDirections.Credit,
            zpi.Amount / 10,
            beforeBalance,
            afterBalance,
            WalletLedgerReasons.WalletCharge,
            provider: "zibal",
            referenceType: nameof(ZibalPaymentInfo),
            referenceId: zpi.Id.ToString(CultureInfo.InvariantCulture),
            orderId: zpi.TrackId.ToString(CultureInfo.InvariantCulture),
            description: isAdmin ? "Admin-confirmed Zibal wallet charge" : "Zibal wallet charge",
            botId: zpi.BotId,
            botUsername: zpi.BotUsername,
            botType: BotInstanceTypes.Owned,
            idempotencyKey: $"payment:zibal:{zpi.Id}:credit",
            cancellationToken: CancellationToken.None);

        if (zpi.IsPaid)
        {
            await _referralService.ProcessFinalOwnedWalletPaymentAsync(
                new ReferralPaymentSource(
                    "zibal",
                    TenantBotPaymentPurposes.WalletCharge,
                    zibalProviderPaymentId,
                    zpi.BotId,
                    BotInstanceTypes.Owned,
                    zpi.TelegramUserId,
                    zpi.Amount / 10,
                    zpi.PaidAt == default ? DateTime.UtcNow : zpi.PaidAt,
                    true,
                    true,
                    false),
                CancellationToken.None);
        }

        if (isAdmin)
        {
            // Provider verification can be initiated by an admin, but the user receives the same final-credit notice.
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: findedUser.ChatID,
                text: $"اعتبار کیف پول شما به میزان {(zpi.Amount / 10).FormatCurrency()} افزایش یافت. با اسفتاده از این اعتبار میتوانید اکانت مورد نیاز خودرا تهیه بفرمایید.",
                replyMarkup: MainReplyMarkupKeyboardFa());
        }

        //notify user ( admin)
        await ActiveBotClient.CustomSendTextMessageAsync(
            chatId: chatid,
            text: $"اعتبار کیف پول شما به میزان {(zpi.Amount / 10).FormatCurrency()} افزایش یافت. با اسفتاده از این اعتبار میتوانید اکانت مورد نیاز خودرا تهیه بفرمایید.",
            replyMarkup: MainReplyMarkupKeyboardFa());

        var msg = await GetZipalPaymentMessage(credUser, true, zpi, $"https://gateway.zibal.ir/start/{zpi.TrackId}");

        var start = "درگاه پرداخت زیبال \n";
        var logMesseage = $"{start}یوزر <code>{zpi.TelegramUserId}</code> \n {credUser} \n به مبلغ {(zpi.Amount / 10).FormatCurrency()}" + " حساب کاربری خود را شارژ کرد." + $"\n موجودی قبل از شارژ {beforeBalance.FormatCurrency()}" + $"\n موجودی پس از شارژ {afterBalance.FormatCurrency()} \n" + msg;

        if (isAdmin)
        {
            msg = await GetZipalPaymentMessage(findedUser, true, zpi, $"https://gateway.zibal.ir/start/{zpi.TrackId}");
            logMesseage = $"{start}یوزر <code>{zpi.TelegramUserId}</code> \n {findedUser} \n به مبلغ {(zpi.Amount / 10).FormatCurrency()}" + " حساب کاربری خود را شارژ کرد." + $"\n موجودی قبل از شارژ {beforeBalance.FormatCurrency()}" + $"\n موجودی پس از شارژ {afterBalance.FormatCurrency()} \n" + msg;
        }
        // _logger.LogInformation(logMesseage.EscapeMarkdown());
        _logger.LogPayment(logMesseage);


        //change buttons!
        await EditMessageWithCallback(ActiveBotClient, zpi.ChatId, Convert.ToInt32(zpi.TelMsgId));

        return;
    }

    private ReplyKeyboardMarkup GetAdminConfirmationKeyboard()
    {

        var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                               {
            new []
            {
                new KeyboardButton("Yes Confirm!"),
            },
            new []
            {
                new KeyboardButton("No Don't Confirm!"),
            },

        });
        return confirmationKeyboard;
    }
    private CredUser GetCreduserFromMessage(Message message)
    {
        return GetCreduserFromTelegramUser(message.From, message.Chat.Id);
    }

    private CredUser GetCreduserFromTelegramUser(Telegram.Bot.Types.User telegramUser, long chatId)
    {
        return new CredUser
        {
            TelegramUserId = telegramUser.Id,
            ChatID = chatId,
            IsColleague = false,
            FirstName = telegramUser.FirstName ?? string.Empty,
            LastName = telegramUser.LastName ?? string.Empty,
            Username = telegramUser.Username ?? string.Empty,
            LanguageCode = telegramUser.LanguageCode ?? string.Empty
        };
    }

    private CredUser GetCreduserFromUpdate(Update update)
    {
        if (update?.Message?.From != null)
            return GetCreduserFromTelegramUser(update.Message.From, update.Message.Chat.Id);

        if (update?.CallbackQuery?.From != null)
            return GetCreduserFromTelegramUser(
                update.CallbackQuery.From,
                update.CallbackQuery.Message?.Chat.Id ?? update.CallbackQuery.From.Id);

        return null;
    }

    private bool IsSuperAdminUser(long telegramUserId)
    {
        return telegramUserId != 0 && _appConfig.AdminsUserIds?.Contains(telegramUserId) == true;
    }

    private async Task<bool> TryHandleUserActivityLogCommandAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        CancellationToken cancellationToken)
    {
        if (message?.Text == null)
            return false;

        var text = message.Text.Trim();
        if (!text.StartsWith("/userlog", StringComparison.OrdinalIgnoreCase))
            return false;

        if (text.Equals("/userlog_on", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("/userlog on", StringComparison.OrdinalIgnoreCase))
        {
            _userActivityLog.SetEnabled(true);
            await _userActivityLog.LogBotActionAsync(
                "user_activity_log_settings_changed",
                credUser,
                true,
                new Dictionary<string, object>
                {
                    ["enabled"] = true,
                    ["level"] = _userActivityLog.CurrentLevel,
                    ["changedByCommand"] = text
                },
                cancellationToken);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"لاگ رفتار کاربران روشن شد.\nسطح فعلی: {_userActivityLog.CurrentLevel}\nفایل: {_userActivityLog.CurrentFilePath}",
                cancellationToken: cancellationToken);
            return true;
        }

        if (text.Equals("/userlog_off", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("/userlog off", StringComparison.OrdinalIgnoreCase))
        {
            await _userActivityLog.LogBotActionAsync(
                "user_activity_log_settings_changed",
                credUser,
                true,
                new Dictionary<string, object>
                {
                    ["enabled"] = false,
                    ["level"] = _userActivityLog.CurrentLevel,
                    ["changedByCommand"] = text
                },
                cancellationToken);

            _userActivityLog.SetEnabled(false);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "لاگ رفتار کاربران خاموش شد. برای روشن کردن دوباره از /userlog_on استفاده کنید.",
                cancellationToken: cancellationToken);
            return true;
        }

        if (text.Equals("/userlog_status", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("/userlog status", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("/userlog", StringComparison.OrdinalIgnoreCase))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"وضعیت لاگ رفتار کاربران:\nفعال: {_userActivityLog.IsEnabled}\nسطح: {_userActivityLog.CurrentLevel}\nفایل: {_userActivityLog.CurrentFilePath}\n\nفرمان‌ها:\n/userlog_on\n/userlog_off\n/userlog_level_error\n/userlog_level_warning\n/userlog_level_info\n/userlog_level_debug",
                cancellationToken: cancellationToken);
            return true;
        }

        var level = text.StartsWith("/userlog_level_", StringComparison.OrdinalIgnoreCase)
            ? text.Substring("/userlog_level_".Length)
            : text.StartsWith("/userlog level ", StringComparison.OrdinalIgnoreCase)
                ? text.Substring("/userlog level ".Length)
                : null;

        if (!string.IsNullOrWhiteSpace(level))
        {
            if (!_userActivityLog.TrySetLevel(level, out var normalizedLevel))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "سطح لاگ معتبر نیست. یکی از این مقدارها را بفرستید: error, warning, info, debug",
                    cancellationToken: cancellationToken);
                return true;
            }

            await _userActivityLog.LogBotActionAsync(
                "user_activity_log_settings_changed",
                credUser,
                true,
                new Dictionary<string, object>
                {
                    ["enabled"] = _userActivityLog.IsEnabled,
                    ["level"] = normalizedLevel,
                    ["changedByCommand"] = text
                },
                cancellationToken);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"سطح لاگ روی {normalizedLevel} تنظیم شد.",
                cancellationToken: cancellationToken);
            return true;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "فرمان لاگ نامعتبر است. برای دیدن راهنما /userlog_status را بفرستید.",
            cancellationToken: cancellationToken);
        return true;
    }
    private ReplyKeyboardMarkup GetMessageSendConfirmationKeyboard()
    {

        var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                       {
            new []
            {
                new KeyboardButton("Yes Send!"),
            },
            new []
            {
                new KeyboardButton("Preview message"),
            },
            new []
            {
                new KeyboardButton("No Don't Send!"),
            },

        });
        return confirmationKeyboard;
    }

    private static InlineKeyboardMarkup BuildBroadcastAudienceKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("کاربران عادی", "broadcast_scope_customers"),
                InlineKeyboardButton.WithCallbackData("همکاران", "broadcast_scope_colleagues")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("کل کاربران", "broadcast_scope_all")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("برگشت به منوی قبل", "broadcast_scope_back")
            }
        });
    }

    private static string NormalizeBroadcastAudience(string audience)
    {
        return (audience ?? string.Empty).Trim().ToLowerInvariant() switch
        {
            BroadcastAudienceCustomers => BroadcastAudienceCustomers,
            BroadcastAudienceColleagues => BroadcastAudienceColleagues,
            BroadcastAudienceAll => BroadcastAudienceAll,
            _ => BroadcastAudienceAll
        };
    }

    private static string GetBroadcastAudienceLabel(string audience)
    {
        return NormalizeBroadcastAudience(audience) switch
        {
            BroadcastAudienceCustomers => "کاربران عادی",
            BroadcastAudienceColleagues => "همکاران",
            _ => "کل کاربران"
        };
    }

    /// <summary>
    /// Builds the recipient list for an owned-bot public broadcast using the current bot scope.
    /// </summary>
    /// <param name="audience">
    /// Requested audience segment from the super-admin confirmation flow. Accepted values are
    /// <c>all</c>, <c>customers</c>, and <c>colleagues</c>; any other value is normalized to <c>all</c>.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the two database reads when the Telegram update is stopped or times out.
    /// </param>
    /// <returns>
    /// Distinct Telegram chat ids that belong to users who have interacted with the current owned bot.
    /// The collection can be empty. Values are safe to pass directly to Telegram send/forward methods.
    /// </returns>
    /// <remarks>
    /// Broadcast isolation is based on <see cref="BotUserState.BotId"/> and
    /// <see cref="BotContextAccessor.CurrentBotId"/>. The shared <c>credentials.db</c> user table is
    /// intentionally not the audience source because it contains users from every owned brand and tenant.
    ///
    /// Role filtering still uses <c>credentials.db</c> because colleague/customer status is shared profile
    /// data. Users without a credentials row are treated as regular customers for the customer/all scopes
    /// and are excluded from the colleague-only scope.
    /// </remarks>
    /// <example>
    /// <code>
    /// var recipients = await GetBroadcastRecipientsAsync("colleagues", cancellationToken);
    /// await StartBroadcastJobAsync(botClient, message, recipients, template, cancellationToken);
    /// </code>
    /// </example>
    private async Task<List<long>> GetBroadcastRecipientsAsync(string audience, CancellationToken cancellationToken)
    {
        // Recipient enumeration is the only part of a broadcast that runs inside the owner's update lane, and it is a
        // pure database read: two bounded audience reads and no per-user Telegram or network call. Measuring it as
        // database_wait makes a very large or slow audience visible in stage telemetry instead of hiding inside the
        // owner callback's total duration. Actual delivery belongs to BroadcastManager's background worker.
        using var stageMeasurement = TelegramUpdateLatencyScope.Current?.Measure(TelegramUpdateStage.DatabaseWait) ?? default;
        var normalizedAudience = NormalizeBroadcastAudience(audience);
        var botId = BotContextAccessor.CurrentBotId;
        var scopedTelegramUserIds = await _workflow.ReadAsync(async db => await db.BotUserStates
            .AsNoTracking()
            .Where(x => x.BotId == botId && x.TelegramUserId > 0)
            .Select(x => x.TelegramUserId)
            .Distinct()
            .ToListAsync(cancellationToken));

        if (scopedTelegramUserIds.Count == 0)
            return new List<long>();

        var credentialRows = await _credentialsDbContext.ReadAudienceAsync(cancellationToken);

        var credentialsByKnownId = new Dictionary<long, (long TelegramUserId, long ChatId, bool IsColleague)>();
        foreach (var credential in credentialRows)
        {
            var value = (credential.TelegramUserId, credential.ChatID, credential.IsColleague);
            if (credential.TelegramUserId > 0 && !credentialsByKnownId.ContainsKey(credential.TelegramUserId))
                credentialsByKnownId.Add(credential.TelegramUserId, value);

            if (credential.ChatID > 0 && !credentialsByKnownId.ContainsKey(credential.ChatID))
                credentialsByKnownId.Add(credential.ChatID, value);
        }

        var recipients = new List<long>();
        foreach (var scopedTelegramUserId in scopedTelegramUserIds)
        {
            credentialsByKnownId.TryGetValue(scopedTelegramUserId, out var credential);
            var hasCredential = credential.TelegramUserId > 0 || credential.ChatId > 0;
            var isColleague = hasCredential && credential.IsColleague;

            if (normalizedAudience == BroadcastAudienceCustomers && isColleague)
                continue;

            if (normalizedAudience == BroadcastAudienceColleagues && !isColleague)
                continue;

            var chatId = hasCredential && credential.ChatId > 0
                ? credential.ChatId
                : hasCredential && credential.TelegramUserId > 0
                    ? credential.TelegramUserId
                    : scopedTelegramUserId;

            if (chatId > 0)
                recipients.Add(chatId);
        }

        return recipients
            .Distinct()
            .ToList();
    }

    private List<string> GetLocations()
    {

        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);
        return servers.Keys.ToList();


    }
    /// <summary>
    /// Sends the current runtime status of every configured, assistant, and tenant bot to a super-admin chat.
    /// </summary>
    /// <param name="botClient">Telegram client that received the super-admin command.</param>
    /// <param name="chatId">Telegram chat id where the status report should be sent.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram send operations.</param>
    /// <returns>A task that completes after one or more status message chunks are sent.</returns>
    /// <remarks>
    /// The report is generated from in-memory receiver status plus <see cref="BotRegistry" /> configuration. It does
    /// not call Telegram or expose bot tokens, so it is safe to run while Telegram is unstable or while some bots are
    /// offline.
    /// </remarks>
    private async Task SendRuntimeBotStatusAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CancellationToken cancellationToken)
    {
        var snapshots = _botRuntimeStatusStore.GetSnapshots(_botRegistry.Bots);
        var report = BuildRuntimeBotStatusText(snapshots);

        foreach (var chunk in SplitTelegramPlainText(report, 3800))
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: chunk,
                replyMarkup: GetMainMenuKeyboard(),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Sends the live four-gateway status panel to an authenticated super-admin.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned bot.</param>
    /// <param name="chatId">Super-admin Telegram chat id.</param>
    /// <param name="cancellationToken">Cancellation token for the Telegram send operation.</param>
    /// <returns>A task that completes after the panel message is sent.</returns>
    /// <remarks>
    /// The panel exposes only enabled state, exact configuration key names, and credential readiness. Secret values
    /// and partial masks are deliberately absent. Each callback carries a revision and expires after ten minutes.
    /// </remarks>
    private async Task SendPaymentGatewayPanelAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CancellationToken cancellationToken)
    {
        await botClient.SendMessage(
            chatId,
            BuildPaymentGatewayPanelText(),
            parseMode: ParseMode.Html,
            replyMarkup: BuildPaymentGatewayPanelMarkup(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Builds the safe HTML status text for the global payment-gateway panel.
    /// </summary>
    /// <returns>Text containing four live states, configuration key names, and readiness labels without secrets.</returns>
    private string BuildPaymentGatewayPanelText()
    {
        var snapshot = _gatewayAvailability.Snapshot;
        var builder = new StringBuilder("⚙️ <b>مدیریت زنده درگاه‌ها</b>\n\n");
        AppendGatewayPanelLine(builder, PaymentGateway.HooshPay, "هوش‌پی", "hooshPayEnabled", snapshot);
        AppendGatewayPanelLine(builder, PaymentGateway.Tetraminator, "تترامیناتور", "tetraminatorEnabled", snapshot);
        AppendGatewayPanelLine(builder, PaymentGateway.UniquePay, "یونیک‌پی", "uniquePayEnabled", snapshot);
        AppendGatewayPanelLine(builder, PaymentGateway.AtlasPay, "اطلس‌پی", "atlasPayEnabled", snapshot);
        AppendGatewayPanelLine(builder, PaymentGateway.NowPayments, "NOWPayments", "nowPaymentsEnabled", snapshot);
        builder.AppendLine();
        builder.Append("تغییر فقط روی ساخت پرداخت‌های جدید اثر دارد؛ بررسی و تسویه پرداخت‌های قبلی ادامه خواهد داشت.");
        return builder.ToString();
    }

    /// <summary>
    /// Appends one gateway's safe state and readiness line to the panel text.
    /// </summary>
    /// <param name="builder">Panel text builder.</param>
    /// <param name="gateway">Gateway represented by the line.</param>
    /// <param name="displayName">Persian or stable provider name shown to administrators.</param>
    /// <param name="configurationKey">Exact root JSON enabled property name.</param>
    /// <param name="snapshot">Live switch snapshot used for a consistent panel render.</param>
    private void AppendGatewayPanelLine(
        StringBuilder builder,
        PaymentGateway gateway,
        string displayName,
        string configurationKey,
        PaymentGatewayAvailabilitySnapshot snapshot)
    {
        var state = snapshot.IsEnabled(gateway) ? "روشن" : "خاموش";
        var readiness = _gatewayAvailability.IsConfigured(gateway) ? "کلید ثبت شده" : "کانفیگ ناقص";
        builder.AppendLine(
            $"{(snapshot.IsEnabled(gateway) ? "✅" : "⛔️")} <b>{Html(displayName)}</b> — {Html(state)}\n" +
            $"<code>{Html(configurationKey)}</code> — {Html(readiness)}");
    }

    /// <summary>
    /// Builds target-state, revisioned callback buttons for the four global gateway switches.
    /// </summary>
    /// <returns>Inline keyboard with one toggle button per gateway and a refresh button.</returns>
    private InlineKeyboardMarkup BuildPaymentGatewayPanelMarkup()
    {
        var snapshot = _gatewayAvailability.Snapshot;
        var issuedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var rows = new List<InlineKeyboardButton[]>();
        foreach (var gateway in Enum.GetValues<PaymentGateway>())
        {
            var key = GetGatewayCallbackKey(gateway);
            var desired = !snapshot.IsEnabled(gateway);
            var label = $"{(desired ? "✅ روشن‌کردن" : "⛔️ خاموش‌کردن")} {GetGatewayDisplayName(gateway)}";
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    label,
                    $"gw:{snapshot.Revision}:{issuedAt}:{key}:{(desired ? 1 : 0)}")
            });
        }

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("🔄 تازه‌سازی", $"gw:{snapshot.Revision}:{issuedAt}:refresh:0")
        });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Processes one super-admin gateway panel callback after expiry and revision checks.
    /// </summary>
    /// <param name="callbackQuery">Callback carrying revision, timestamp, provider key, and target state.</param>
    /// <param name="cancellationToken">Cancellation token for persistence and Telegram edits.</param>
    /// <returns>A task that completes after the panel is refreshed or the callback is rejected.</returns>
    /// <remarks>
    /// Authorization is checked independently of the UI route. A stale callback cannot overwrite a newer state, and
    /// enabling a provider with missing credential/URL configuration is rejected by the central service.
    /// </remarks>
    private async Task ProcessPaymentGatewayCallbackSafelyAsync(
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        try
        {
            await ProcessPaymentGatewayCallbackAsync(callbackQuery, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            await LogPaymentGatewayAdminCallbackFailureSafelyAsync(callbackQuery, ex, cancellationToken);
            try
            {
                await SafeAnswerCallbackQueryAsync(
                    callbackQuery.Id,
                    "به‌روزرسانی پنل درگاه‌ها انجام نشد؛ لطفاً دوباره تلاش کنید.",
                    showAlert: true,
                    cancellationToken: cancellationToken);
            }
            catch (Exception answerEx)
            {
                _logger.LogWarning("Gateway admin callback failure response could not be delivered. botId={BotId}, errorType={ErrorType}", BotContextAccessor.CurrentBotId, answerEx.GetType().Name);
            }
        }
    }

    private async Task LogPaymentGatewayAdminCallbackFailureSafelyAsync(
        CallbackQuery callbackQuery, Exception exception, CancellationToken cancellationToken)
    {
        var parts = (callbackQuery.Data ?? string.Empty).Split(':');
        var action = parts.Length >= 4 ? parts[3] : "unknown";
        try
        {
            var credUser = await _credentialsDbContext.GetUserStatus(
                GetCreduserFromTelegramUser(callbackQuery.From, callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id));
            await _userActivityLog.LogErrorAsync(
                "payment_gateway_admin_callback_failed", exception, credUser, IsSuperAdminUser(callbackQuery.From.Id),
                new Dictionary<string, object>
                {
                    ["callbackFamily"] = "gw", ["gatewayAction"] = action,
                    ["exceptionType"] = exception.GetType().Name,
                    ["botId"] = BotContextAccessor.CurrentBotId ?? string.Empty
                }, cancellationToken);
        }
        catch (Exception logException)
        {
            _logger.LogWarning("Gateway admin callback audit logging failed. botId={BotId}, errorType={ErrorType}", BotContextAccessor.CurrentBotId, logException.GetType().Name);
        }
        _logger.LogWarning(exception, "Payment gateway admin callback failed. callbackFamily=gw, gatewayAction={GatewayAction}, botId={BotId}, superAdmin={SuperAdmin}", action, BotContextAccessor.CurrentBotId, IsSuperAdminUser(callbackQuery.From.Id));
    }

    private async Task ProcessPaymentGatewayCallbackAsync(
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        if (!IsSuperAdminUser(callbackQuery.From.Id))
        {
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                "این بخش فقط برای سوپرادمین‌هاست.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var parts = (callbackQuery.Data ?? string.Empty).Split(':');
        if (parts.Length != 5 ||
            !long.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out var revision) ||
            !long.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var issuedAt) ||
            !int.TryParse(parts[4], NumberStyles.Integer, CultureInfo.InvariantCulture, out var target))
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "دکمه نامعتبر است.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        if (Math.Abs(DateTimeOffset.UtcNow.ToUnixTimeSeconds() - issuedAt) > 600)
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "این دکمه منقضی شده است؛ پنل را تازه کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        if (string.Equals(parts[3], "refresh", StringComparison.Ordinal))
        {
            await RefreshPaymentGatewayPanelAsync(callbackQuery, cancellationToken);
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                "پنل به‌روزرسانی شد.",
                cancellationToken: cancellationToken);
            return;
        }

        if (!TryParseGatewayCallbackKey(parts[3], out var gateway) || target is < 0 or > 1)
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "درگاه نامعتبر است.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var result = await _gatewayAvailability.SetEnabledAsync(
            gateway,
            target == 1,
            revision,
            cancellationToken);
        await RefreshPaymentGatewayPanelAsync(callbackQuery, cancellationToken);
        await SafeAnswerCallbackQueryAsync(
            callbackQuery.Id,
            result.Message,
            showAlert: !result.Applied,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Re-renders the current gateway panel after a toggle or refresh request.
    /// </summary>
    /// <param name="callbackQuery">Callback whose message is being edited.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram edit.</param>
    /// <returns>A task that completes after the edit attempt.</returns>
    private async Task RefreshPaymentGatewayPanelAsync(
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        if (callbackQuery.Message == null)
            return;
        try
        {
            await ActiveBotClient.EditMessageText(
                callbackQuery.Message.Chat.Id,
                callbackQuery.Message.MessageId,
                BuildPaymentGatewayPanelText(),
                parseMode: ParseMode.Html,
                replyMarkup: BuildPaymentGatewayPanelMarkup(),
                cancellationToken: cancellationToken);
        }
        catch (ApiRequestException ex) when (TenantBotService.ISTELEGRAMMESSAGENOTMODIFIED(ex.ErrorCode, ex.Message))
        {
            // Telegram already displays the requested gateway panel; this is semantic success.
        }
    }

    /// <summary>Maps a gateway enum to a short callback-safe key.</summary>
    /// <param name="gateway">Gateway enum value.</param>
    /// <returns>Short ASCII key used in Telegram callback data.</returns>
    private static string GetGatewayCallbackKey(PaymentGateway gateway)
        => gateway switch
        {
            PaymentGateway.HooshPay => "hp",
            PaymentGateway.Tetraminator => "tm",
            PaymentGateway.UniquePay => "up",
            PaymentGateway.AtlasPay => "ap",
            PaymentGateway.NowPayments => "np",
            _ => "unknown"
        };

    /// <summary>Maps a callback-safe gateway key back to its enum.</summary>
    /// <param name="key">Short ASCII callback key.</param>
    /// <param name="gateway">Parsed gateway when the key is recognized.</param>
    /// <returns><c>true</c> for hp, tm, up, or np; otherwise <c>false</c>.</returns>
    private static bool TryParseGatewayCallbackKey(string key, out PaymentGateway gateway)
    {
        gateway = key switch
        {
            "hp" => PaymentGateway.HooshPay,
            "tm" => PaymentGateway.Tetraminator,
            "up" => PaymentGateway.UniquePay,
            "ap" => PaymentGateway.AtlasPay,
            "np" => PaymentGateway.NowPayments,
            _ => (PaymentGateway)(-1)
        };
        return Enum.IsDefined(gateway);
    }

    /// <summary>Gets a stable human-readable gateway name for the panel button.</summary>
    /// <param name="gateway">Gateway enum value.</param>
    /// <returns>Persian or provider name without secret data.</returns>
    private static string GetGatewayDisplayName(PaymentGateway gateway)
        => gateway switch
        {
            PaymentGateway.HooshPay => "هوش‌پی",
            PaymentGateway.Tetraminator => "تترامیناتور",
            PaymentGateway.UniquePay => "یونیک‌پی",
            PaymentGateway.AtlasPay => "اطلس‌پی",
            PaymentGateway.NowPayments => "NOWPayments",
            _ => gateway.ToString()
        };

    /// <summary>
    /// Builds a plain-text super-admin report from runtime bot status snapshots.
    /// </summary>
    /// <param name="snapshots">Status snapshots returned by <see cref="BotRuntimeStatusStore.GetSnapshots" />.</param>
    /// <returns>Plain Telegram-safe text that contains no Markdown or HTML entities.</returns>
    /// <remarks>
    /// The output intentionally avoids parse modes because bot ids and usernames often contain underscores. A parse
    /// error in this diagnostic command would make it useless exactly when the admin needs it most.
    /// </remarks>
    private static string BuildRuntimeBotStatusText(IReadOnlyList<BotRuntimeStatusSnapshot> snapshots)
    {
        var builder = new StringBuilder();
        var now = DateTime.UtcNow;
        var total = snapshots?.Count ?? 0;
        var running = snapshots?.Count(x => x.IsReceiverRunning) ?? 0;
        var enabled = snapshots?.Count(x => x.Enabled) ?? 0;

        builder.AppendLine("🤖 وضعیت ربات‌های در حال اجرای سرویس");
        builder.AppendLine($"زمان UTC: {now:yyyy-MM-dd HH:mm:ss}");
        builder.AppendLine($"خلاصه: {running}/{total} receiver running, enabled={enabled}");
        builder.AppendLine();

        foreach (var bot in snapshots ?? Array.Empty<BotRuntimeStatusSnapshot>())
        {
            var icon = GetRuntimeBotStatusIcon(bot);
            var username = string.IsNullOrWhiteSpace(bot.Username) ? "بدون username" : "@" + bot.Username.Trim().TrimStart('@');
            builder.AppendLine($"{icon} {bot.BotId} ({username})");
            builder.AppendLine($"   type={bot.BotType ?? "unknown"} | brand={bot.BrandName ?? "-"}");
            builder.AppendLine($"   enabled={bot.Enabled} | token={bot.HasToken} | receiver={bot.IsReceiverRunning}");
            builder.AppendLine($"   status={bot.Status ?? "-"} | updatedUtc={(bot.UpdatedAtUtc.HasValue ? bot.UpdatedAtUtc.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) : "-")}");
            if (bot.OwnerTelegramUserId.HasValue)
                builder.AppendLine($"   owner={bot.OwnerTelegramUserId.Value}");
            if (!string.IsNullOrWhiteSpace(bot.LastError))
                builder.AppendLine($"   lastError={TrimForStatus(bot.LastError, 180)}");
            builder.AppendLine();
        }

        return builder.ToString();
    }

    /// <summary>
    /// Selects a visual status marker for one runtime bot snapshot.
    /// </summary>
    /// <param name="snapshot">Bot status snapshot shown in the super-admin report.</param>
    /// <returns>
    /// Emoji marker that distinguishes disabled/missing/failed bots, fully listening receivers, and optimistic
    /// receivers whose Telegram initialization is still <c>initializing</c> or <c>degraded</c>.
    /// </returns>
    private static string GetRuntimeBotStatusIcon(BotRuntimeStatusSnapshot snapshot)
    {
        if (snapshot == null)
            return "⚪";
        if (!snapshot.Enabled)
            return "⚪";
        if (!snapshot.HasToken)
            return "🟡";
        if (snapshot.IsReceiverRunning &&
            (string.Equals(snapshot.Status, "initializing", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(snapshot.Status, "degraded", StringComparison.OrdinalIgnoreCase)))
        {
            return "⚠️";
        }
        if (snapshot.IsReceiverRunning)
            return "✅";
        if (string.Equals(snapshot.Status, "startup_failed", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(snapshot.Status, "invalid_token", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(snapshot.Status, "duplicate", StringComparison.OrdinalIgnoreCase))
        {
            return "❌";
        }

        return "⏸";
    }

    /// <summary>
    /// Splits a plain text report into Telegram-sized chunks while preserving line boundaries where possible.
    /// </summary>
    /// <param name="text">Plain text to split. The value must already be safe to send without parse mode.</param>
    /// <param name="maxLength">Maximum chunk length in UTF-16 characters. Use a value below Telegram's hard limit.</param>
    /// <returns>One or more chunks that can be sent as separate Telegram messages.</returns>
    private static IEnumerable<string> SplitTelegramPlainText(string text, int maxLength)
    {
        if (string.IsNullOrEmpty(text))
        {
            yield return string.Empty;
            yield break;
        }

        var builder = new StringBuilder();
        foreach (var line in text.Replace("\r\n", "\n").Split('\n'))
        {
            if (builder.Length + line.Length + 1 > maxLength && builder.Length > 0)
            {
                yield return builder.ToString();
                builder.Clear();
            }

            builder.AppendLine(line);
        }

        if (builder.Length > 0)
            yield return builder.ToString();
    }

    /// <summary>
    /// Trims long diagnostic text so one noisy error does not dominate the super-admin status screen.
    /// </summary>
    /// <param name="value">Raw non-secret error text.</param>
    /// <param name="maxLength">Maximum number of characters to keep.</param>
    /// <returns>The original value when short enough; otherwise a trimmed value with an ellipsis suffix.</returns>
    private static string TrimForStatus(string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value) || value.Length <= maxLength)
            return value;

        return value.Substring(0, Math.Max(0, maxLength - 1)) + "…";
    }

    /// <summary>
    /// Handles the super-admin flow that manually verifies any owned-bot user's phone number.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client of the currently active owned bot. The client is used only for the private admin conversation;
    /// the verified user is notified separately through every owned bot they have previously started.
    /// </param>
    /// <param name="message">
    /// Text message sent by a configured super-admin. The flow expects the action button, a numeric Telegram user id,
    /// a phone number, and finally one of the confirmation buttons.
    /// </param>
    /// <param name="currentUser">
    /// Bot-scoped conversation state for the super-admin. This state belongs to the active owned bot and cannot affect
    /// the same administrator's state in another owned or tenant bot.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for database operations and Telegram notifications.</param>
    /// <returns>
    /// <c>true</c> when the message belongs to the manual phone flow and has been fully handled; otherwise
    /// <c>false</c> so the normal super-admin router can process it.
    /// </returns>
    /// <remarks>
    /// Manual verification deliberately bypasses the normal Iranian-number and shared-contact ownership checks. This
    /// allows a super-admin to approve virtual numbers and numbers from any country. The target must already exist in
    /// <c>credentials.db</c>, and the flow requires a separate final confirmation before mutating the shared profile.
    /// </remarks>
    /// <example>
    /// <code>
    /// 📱 تایید دستی شماره تلفن
    /// 123456789
    /// +491701234567
    /// ✅ تایید شماره تلفن
    /// </code>
    /// </example>
    private async Task<bool> TryHandleManualPhoneVerificationAsync(
        ITelegramBotClient botClient,
        Message message,
        User currentUser,
        CancellationToken cancellationToken)
    {
        var text = message.Text?.Trim() ?? string.Empty;
        if (string.Equals(text, "/start", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(text, "📑 Menu", StringComparison.Ordinal))
        {
            return false;
        }

        if (string.Equals(text, AdminVerifyPhoneAction, StringComparison.Ordinal))
        {
            // Clear stale admin-flow data before starting this sensitive identity operation.
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            currentUser = new User
            {
                Id = message.From.Id,
                Flow = "admin",
                LastStep = AdminPhoneUserIdStep
            };
            await _state.SaveUserStatus(currentUser);

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "آیدی عددی تلگرام کاربر را وارد کنید.\n\nکاربر باید قبلاً حداقل یکی از ربات‌های مجموعه را اجرا کرده باشد.",
                replyMarkup: BuildAdminPhoneInputKeyboard());
            return true;
        }

        if (!string.Equals(currentUser.Flow, "admin", StringComparison.Ordinal))
            return false;

        if (string.Equals(currentUser.LastStep, AdminPhoneUserIdStep, StringComparison.Ordinal))
        {
            var normalizedUserId = text.PersianNumbersToEnglish();
            if (!long.TryParse(normalizedUserId, NumberStyles.None, CultureInfo.InvariantCulture, out var targetUserId) ||
                targetUserId <= 0)
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "آیدی عددی معتبر نیست. فقط آیدی عددی تلگرام کاربر را وارد کنید.",
                    replyMarkup: BuildAdminPhoneInputKeyboard());
                return true;
            }

            var target = await _credentialsDbContext.GetUserStatusWithId(targetUserId);
            if (target == null)
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "این کاربر در اطلاعات ربات پیدا نشد. از کاربر بخواهید ابتدا یکی از ربات‌های مجموعه را اجرا کند، سپس دوباره آیدی را بفرستید.",
                    replyMarkup: BuildAdminPhoneInputKeyboard());
                return true;
            }

            currentUser.LastStep = $"{AdminPhoneNumberStep}|{targetUserId.ToString(CultureInfo.InvariantCulture)}";
            await _state.SaveUserStatus(currentUser);

            var existingPhone = string.IsNullOrWhiteSpace(target.PhoneNumber)
                ? "ثبت نشده"
                : MaskPhoneNumber(target.PhoneNumber);

            // User-controlled names and usernames can contain Markdown control characters such as underscores.
            // Build this dynamic profile block as encoded HTML so Telegram cannot reject the next flow step.
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text:
                    "👤 <b>کاربر پیدا شد</b>\n" +
                    $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n" +
                    $"شماره فعلی: <code>{Html(existingPhone)}</code>\n\n" +
                    "شماره جدید را همراه کد کشور وارد کنید. شماره مجازی و شماره کشورهای غیرایرانی نیز قابل تأیید است.\n" +
                    "نمونه: +491701234567",
                parseMode: ParseMode.Html,
                replyMarkup: BuildAdminPhoneInputKeyboard());
            return true;
        }

        if (currentUser.LastStep?.StartsWith(AdminPhoneNumberStep + "|", StringComparison.Ordinal) == true)
        {
            if (!TryReadStateTargetUserId(currentUser.LastStep, AdminPhoneNumberStep, out var targetUserId))
            {
                await ResetBrokenAdminPhoneFlowAsync(botClient, message.Chat.Id, currentUser);
                return true;
            }

            if (!TryNormalizeAdminPhoneNumber(text, out var normalizedPhone))
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "ساختار شماره معتبر نیست. شماره را با ۷ تا ۱۸ رقم و در صورت نیاز با علامت + و کد کشور وارد کنید.",
                    replyMarkup: BuildAdminPhoneInputKeyboard());
                return true;
            }

            currentUser.ConfigLink = normalizedPhone;
            currentUser.LastStep = $"{AdminPhoneConfirmationStep}|{targetUserId.ToString(CultureInfo.InvariantCulture)}";
            await _state.SaveUserStatus(currentUser);

            var target = await _credentialsDbContext.GetUserStatusWithId(targetUserId);
            if (target == null)
            {
                await ResetBrokenAdminPhoneFlowAsync(botClient, message.Chat.Id, currentUser);
                return true;
            }

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text:
                    "📱 <b>تأیید نهایی شماره تلفن</b>\n\n" +
                    $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n" +
                    $"آیدی عددی: <code>{targetUserId}</code>\n" +
                    $"شماره: <code>{Html(normalizedPhone)}</code>\n\n" +
                    "پس از تأیید، محدودیت ثبت شماره برای این کاربر برداشته می‌شود.",
                parseMode: ParseMode.Html,
                replyMarkup: BuildAdminPhoneConfirmationKeyboard());
            return true;
        }

        if (currentUser.LastStep?.StartsWith(AdminPhoneConfirmationStep + "|", StringComparison.Ordinal) == true)
        {
            if (string.Equals(text, CancelAdminPhoneButton, StringComparison.Ordinal))
            {
                await _state.ClearUserStatus(currentUser);
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "عملیات تأیید شماره تلفن لغو شد.",
                    replyMarkup: GetAdminKeyboard());
                return true;
            }

            if (!string.Equals(text, ConfirmAdminPhoneButton, StringComparison.Ordinal))
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "برای ثبت شماره از دکمه تأیید استفاده کنید یا عملیات را لغو کنید.",
                    replyMarkup: BuildAdminPhoneConfirmationKeyboard());
                return true;
            }

            if (!TryReadStateTargetUserId(currentUser.LastStep, AdminPhoneConfirmationStep, out var targetUserId) ||
                !TryNormalizeAdminPhoneNumber(currentUser.ConfigLink, out var normalizedPhone))
            {
                await ResetBrokenAdminPhoneFlowAsync(botClient, message.Chat.Id, currentUser);
                return true;
            }

            var target = await _credentialsDbContext.GetUserStatusWithId(targetUserId);
            if (target == null)
            {
                await ResetBrokenAdminPhoneFlowAsync(botClient, message.Chat.Id, currentUser);
                return true;
            }

            var previousPhone = target.PhoneNumber;
            await _credentialsDbContext.SavePhoneNumber(targetUserId, normalizedPhone);
            target.PhoneNumber = normalizedPhone;
            await _state.ClearUserStatus(currentUser);

            LogAdminPhoneVerification(message.From, target, previousPhone, normalizedPhone);

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text:
                    "✅ <b>شماره تلفن کاربر با موفقیت تأیید شد.</b>\n\n" +
                    $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n" +
                    $"شماره ثبت‌شده: <code>{Html(normalizedPhone)}</code>\n" +
                    $"نوع حساب: <code>{Html(target.IsColleague ? "همکار" : "کاربر عادی")}</code>",
                parseMode: ParseMode.Html,
                replyMarkup: GetAdminKeyboard());

            try
            {
                await _ownedBotNotificationService.NotifyUserAcrossOwnedBotsAsync(
                    targetUserId,
                    "✅ شماره تلفن حساب شما توسط مدیریت تأیید شد و اکنون می‌توانید از امکانات ربات استفاده کنید.",
                    cancellationToken: cancellationToken);
            }
            catch (Exception ex)
            {
                // Verification is already persisted; a Telegram delivery failure must not roll it back.
                _logger.LogWarning(
                    ex,
                    "Manual phone verification notification failed after persistence. userId={TelegramUserId}",
                    targetUserId);
            }

            return true;
        }

        return false;
    }

    /// <summary>
    /// Parses the target Telegram user id stored in a manual-phone conversation-state key.
    /// </summary>
    /// <param name="lastStep">State value in the form <c>step-prefix|telegram-user-id</c>.</param>
    /// <param name="expectedPrefix">Exact state-step prefix expected by the current phase.</param>
    /// <param name="telegramUserId">Receives the positive numeric Telegram user id when parsing succeeds.</param>
    /// <returns><c>true</c> when the state contains the expected prefix and a positive user id; otherwise <c>false</c>.</returns>
    /// <remarks>This rejects malformed or stale state instead of applying a sensitive verification to the wrong user.</remarks>
    private static bool TryReadStateTargetUserId(string lastStep, string expectedPrefix, out long telegramUserId)
    {
        telegramUserId = 0;
        var parts = lastStep?.Split('|', StringSplitOptions.TrimEntries);
        return parts?.Length == 2 &&
               string.Equals(parts[0], expectedPrefix, StringComparison.Ordinal) &&
               long.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out telegramUserId) &&
               telegramUserId > 0;
    }

    /// <summary>
    /// Normalizes a super-admin supplied phone number without applying country, carrier, or virtual-number rules.
    /// </summary>
    /// <param name="input">
    /// Raw phone number from the private admin chat. Persian/Arabic digits and common visual separators are accepted;
    /// letters, extensions, and multiple plus signs are rejected.
    /// </param>
    /// <param name="normalizedPhone">
    /// Receives 7 to 18 ASCII digits, optionally prefixed with <c>+</c>. A leading <c>00</c> is converted to <c>+</c>.
    /// </param>
    /// <returns><c>true</c> when the input has a safe phone-number shape; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// This is an administrative override, not proof that Telegram owns the number. It intentionally accepts Iranian,
    /// non-Iranian, and virtual numbers while still rejecting arbitrary text from entering the credentials profile.
    /// </remarks>
    private static bool TryNormalizeAdminPhoneNumber(string input, out string normalizedPhone)
    {
        normalizedPhone = string.Empty;
        if (string.IsNullOrWhiteSpace(input))
            return false;

        var value = input.PersianNumbersToEnglish().Trim();
        var digits = new StringBuilder(value.Length);
        var hasLeadingPlus = false;

        for (var index = 0; index < value.Length; index++)
        {
            var character = value[index];
            if (character == '+' && index == 0)
            {
                hasLeadingPlus = true;
                continue;
            }

            if (char.IsDigit(character))
            {
                digits.Append(character);
                continue;
            }

            if (character is ' ' or '-' or '(' or ')')
                continue;

            return false;
        }

        if (digits.Length < 7 || digits.Length > 18)
            return false;

        var digitText = digits.ToString();
        if (!hasLeadingPlus && digitText.StartsWith("00", StringComparison.Ordinal) && digitText.Length > 2)
        {
            hasLeadingPlus = true;
            digitText = digitText.Substring(2);
        }

        if (digitText.All(character => character == '0'))
            return false;

        normalizedPhone = hasLeadingPlus ? "+" + digitText : digitText;
        return true;
    }

    /// <summary>
    /// Creates the compact input keyboard used while an admin enters a target id or phone number.
    /// </summary>
    /// <returns>A keyboard whose only action returns safely to the super-admin main menu.</returns>
    private static ReplyKeyboardMarkup BuildAdminPhoneInputKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("📑 Menu") }
        })
        {
            ResizeKeyboard = true
        };
    }

    /// <summary>
    /// Creates the final confirmation keyboard for a manual phone verification.
    /// </summary>
    /// <returns>A keyboard containing explicit confirm, cancel, and final-row main-menu actions.</returns>
    private static ReplyKeyboardMarkup BuildAdminPhoneConfirmationKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton(ConfirmAdminPhoneButton), new KeyboardButton(CancelAdminPhoneButton) },
            new[] { new KeyboardButton("📑 Menu") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    /// <summary>
    /// Clears a malformed manual-phone flow and returns the super-admin to a usable admin panel.
    /// </summary>
    /// <param name="botClient">Telegram client for the active owned bot.</param>
    /// <param name="chatId">Private super-admin Telegram chat id that should receive the recovery message.</param>
    /// <param name="currentUser">Bot-scoped admin state that could not be parsed safely.</param>
    /// <returns>A task that completes after state cleanup and Telegram notification.</returns>
    /// <remarks>No credentials profile is modified by this recovery path.</remarks>
    private async Task ResetBrokenAdminPhoneFlowAsync(
        ITelegramBotClient botClient,
        long chatId,
        User currentUser)
    {
        await _state.ClearUserStatus(currentUser);
        await botClient.CustomSendTextMessageAsync(
            chatId: chatId,
            text: "اطلاعات این مرحله ناقص یا منقضی شده بود. لطفاً تأیید شماره تلفن را از پنل ادمین دوباره شروع کنید.",
            replyMarkup: GetAdminKeyboard());
    }

    /// <summary>
    /// Masks a phone number for non-confirmation status and private audit messages.
    /// </summary>
    /// <param name="phoneNumber">Stored or normalized phone number. The value may include a leading plus sign.</param>
    /// <returns>A partially masked phone number that keeps only a short prefix and suffix visible.</returns>
    private static string MaskPhoneNumber(string phoneNumber)
    {
        if (string.IsNullOrWhiteSpace(phoneNumber))
            return "ثبت نشده";

        var value = phoneNumber.Trim();
        if (value.Length <= 6)
            return new string('*', value.Length);

        return value.Substring(0, 3) + new string('*', value.Length - 6) + value.Substring(value.Length - 3);
    }

    /// <summary>
    /// Writes a private-channel audit record after a super-admin manually verifies a user's phone number.
    /// </summary>
    /// <param name="actor">Telegram super-admin who confirmed the operation.</param>
    /// <param name="target">Shared credentials user whose phone verification was persisted.</param>
    /// <param name="previousPhone">Phone value before the operation; it may be empty when the user was unverified.</param>
    /// <param name="verifiedPhone">New normalized phone value persisted in <c>credentials.db</c>.</param>
    /// <remarks>
    /// Phone values are masked because the central logger channel is an operational audit surface. The target and actor
    /// remain clickable by numeric Telegram id, and no bot token or other credential is included.
    /// The audit is committed to the durable Telegram outbox as HTML (EventId 1001/TelegramHtml) and never requests
    /// a database backup, because no financial state changed.
    /// </remarks>
    private void LogAdminPhoneVerification(
        Telegram.Bot.Types.User actor,
        CredUser target,
        string previousPhone,
        string verifiedPhone)
    {
        var actorUser = BuildCredUserFromTelegramActor(actor);
        var message =
            "📱 <b>تأیید دستی شماره تلفن</b>\n\n" +
            "📌 انجام‌دهنده\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(actorUser)}\n\n" +
            "📌 کاربر هدف\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n\n" +
            $"وضعیت قبلی: <code>{Html(string.IsNullOrWhiteSpace(previousPhone) ? "تأیید نشده" : "تأیید شده")}</code>\n" +
            $"شماره قبلی: <code>{Html(MaskPhoneNumber(previousPhone))}</code>\n" +
            $"شماره جدید: <code>{Html(MaskPhoneNumber(verifiedPhone))}</code>\n" +
            $"نوع حساب: <code>{Html(target.IsColleague ? "همکار" : "کاربر عادی")}</code>";

        _logger.LogTelegramHtml(message);
    }

    /// <summary>
    /// Handles completed-day weekly and monthly usage commands and sends a high-resolution line-chart PNG.
    /// </summary>
    /// <param name="botClient">Owned-bot Telegram client that received the super-admin command.</param>
    /// <param name="message">
    /// Incoming super-admin text message. The sender id has already been checked against global
    /// <see cref="AppConfig.AdminsUserIds"/> by the common update router.
    /// </param>
    /// <param name="cancellationToken">Polling cancellation token used for state, file, database, and Telegram work.</param>
    /// <returns>
    /// <c>true</c> when the text is one of the usage commands, including when report generation fails after a safe
    /// user-facing error is sent; otherwise <c>false</c> so normal admin routing may continue.
    /// </returns>
    /// <remarks>
    /// The command clears only the sender's temporary bot-scoped conversation state. It reports either seven or thirty
    /// complete Tehran days ending yesterday, globally de-duplicates users per day across owned and tenant bots, counts
    /// incoming messages plus callbacks, excludes all configured super-admin ids, and sends the daily series as a
    /// readable Telegram photo instead of a text-only list.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (isSuperAdmin &amp;&amp; await TryHandleUsageStatisticsCommandAsync(client, message, cancellationToken))
    ///     return;
    /// </code>
    /// </example>
    private async Task<bool> TryHandleUsageStatisticsCommandAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        var text = message?.Text?.Trim();
        var dayCount = string.Equals(text, AdminWeeklyUsageAction, StringComparison.Ordinal)
            ? 7
            : string.Equals(text, AdminMonthlyUsageAction, StringComparison.Ordinal)
                ? 30
                : 0;
        if (dayCount == 0 || message?.From == null)
            return false;

        try
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            var yesterdayIran = _usageAnalyticsService.GetIranNow().Date.AddDays(-1);
            var startIran = yesterdayIran.AddDays(-(dayCount - 1));
            var report = await _usageAnalyticsService.GetReportAsync(
                startIran,
                dayCount,
                botIdFilter: null,
                includeSales: false,
                cancellationToken);
            var png = _usageReportChartRenderer.RenderCompletedPeriod(report, includeSales: false);
            await using var imageStream = new MemoryStream(png, writable: false);
            var sentMessage = await botClient.SendPhoto(
                chatId: message.Chat.Id,
                photo: InputFile.FromStream(
                    imageStream,
                    dayCount == 7 ? "weekly-usage.png" : "monthly-usage.png"),
                caption: BuildAdminUsageReportCaption(report, dayCount),
                parseMode: ParseMode.Html,
                replyMarkup: GetAdminKeyboard(),
                cancellationToken: cancellationToken);
            if (sentMessage == null || sentMessage.MessageId <= 0)
                throw new InvalidOperationException("Telegram returned no valid photo message for the super-admin usage report.");

            _logger.LogInformation(
                "Super-admin usage report photo sent. userId={UserId}, botId={BotId}, dayCount={DayCount}, messageId={MessageId}, imageBytes={ImageBytes}, missingDays={MissingDays}, malformedLines={MalformedLines}",
                message.From.Id,
                BotContextAccessor.CurrentBotId,
                dayCount,
                sentMessage.MessageId,
                png.Length,
                report.MissingActivityLogDays,
                report.MalformedLines);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Super-admin usage report failed. userId={UserId}, botId={BotId}, dayCount={DayCount}",
                message.From.Id,
                BotContextAccessor.CurrentBotId,
                dayCount);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "دریافت آمار در حال حاضر با خطا روبه‌رو شد. جزئیات برای بررسی ثبت شد؛ لطفاً کمی بعد دوباره تلاش کنید.",
                replyMarkup: GetAdminKeyboard(),
                cancellationToken: cancellationToken);
        }

        return true;
    }

    /// <summary>
    /// Builds the concise HTML caption attached to a super-admin weekly or monthly usage chart.
    /// </summary>
    /// <param name="report">
    /// Completed-day report shown by the image. Its daily buckets exclude the current incomplete Tehran day.
    /// </param>
    /// <param name="dayCount">Requested report length in completed days; currently either 7 or 30.</param>
    /// <returns>
    /// Telegram HTML caption containing the date range, aggregate users/interactions, and any data-quality warning.
    /// </returns>
    /// <remarks>
    /// Per-day values remain in the chart to avoid an oversized caption. Missing activity files and malformed JSONL
    /// lines remain visible so a visually empty day is not mistaken for confirmed zero usage.
    /// </remarks>
    private static string BuildAdminUsageReportCaption(UsageAnalyticsReport report, int dayCount)
    {
        var builder = new StringBuilder();
        builder.AppendLine(dayCount == 7
            ? "📊 <b>نمودار آمار هفتگی کل مجموعه</b>"
            : "📈 <b>نمودار آمار ۳۰ روزه کل مجموعه</b>");
        builder.AppendLine(
            $"بازه کامل: <code>{UsageAnalyticsService.FormatPersianDate(report.StartDateIran)}</code> تا " +
            $"<code>{UsageAnalyticsService.FormatPersianDate(report.EndDateIran.AddDays(-1))}</code>");
        builder.AppendLine("روز جاری در محاسبات وارد نشده است.");
        builder.AppendLine();
        builder.AppendLine($"👤 مجموع کاربران یکتای روزانه: <code>{report.TotalDailyUniqueUsers:N0}</code>");
        builder.AppendLine($"💬 مجموع تعامل‌ها: <code>{report.TotalInteractions:N0}</code>");
        if (report.MissingActivityLogDays > 0 || report.MalformedLines > 0)
        {
            builder.AppendLine();
            builder.AppendLine(
                $"⚠️ کیفیت داده: <code>{report.MissingActivityLogDays}</code> روز بدون فایل، " +
                $"<code>{report.MalformedLines}</code> خط خراب نادیده گرفته شد.");
        }

        return builder.ToString();
    }

    /// <summary>
    /// Gets the reply-keyboard actions available to super-admin users.
    /// </summary>
    /// <returns>Ordered action labels shown in the super-admin keyboard.</returns>
    private string[] GetAdminActions()
    {
        string[] actions = new string[]
        {
            "🚫 Ban user",
            "✅ Unban user",
            "➕ Add credit",
            "➖ Reduce credit",
            PromoteColleagueAction,
            DemoteColleagueAction,
            "ℹ️ See User Account",
            "📨 Send message to all",
            "✉️ Send message to user",
            "ℹ️ See All account of user",
            "🗑 Delete expired accounts",
            "Sync Gozargah Site",
            "✔️ Verify payment",
            AdminVerifyPhoneAction,
            AdminWeeklyUsageAction,
            AdminMonthlyUsageAction,
            AdminPaymentGatewayAction,
            AdminClientDownloadAction,
            "🤖 وضعیت ربات‌ها",
            "📑 Menu"
        };
        return actions;
    }

    /// <summary>
    /// Builds the super-admin reply keyboard while keeping the main-menu action on its own final row.
    /// </summary>
    /// <returns>
    /// A two-column reply keyboard for administrative actions, followed by a single full-width
    /// <c>📑 Menu</c> row.
    /// </returns>
    /// <remarks>
    /// The keyboard is used only in owned bots for users listed in <c>adminsUserIds</c>. Tenant owners receive their
    /// separate storefront panel and cannot reach these platform-wide actions.
    /// </remarks>
    private ReplyKeyboardMarkup GetAdminKeyboard()
    {
        var actions = GetAdminActions()
            .Where(action => !string.Equals(action, "📑 Menu", StringComparison.Ordinal))
            .ToArray();

        // Keep operational actions dense, but reserve the final full row for an unambiguous escape to the main menu.
        List<KeyboardButton[]> keyboardRows = new List<KeyboardButton[]>();
        for (int i = 0; i < actions.Length; i += 2)
        {
            KeyboardButton[] row;
            if (i + 1 < actions.Length)
            {
                // Pair two locations in one row
                row = new KeyboardButton[] { new KeyboardButton(actions[i]), new KeyboardButton(actions[i + 1]) };
            }
            else
            {
                // For odd number of locations, last row will have a single column
                row = new KeyboardButton[] { new KeyboardButton(actions[i]) };
            }
            keyboardRows.Add(row);
        }

        keyboardRows.Add(new[] { new KeyboardButton("📑 Menu") });

        var createAccountKeyboard = new ReplyKeyboardMarkup(keyboardRows.ToArray());
        return createAccountKeyboard;
    }




    private ReplyKeyboardMarkup GetLocationKeyboard()
    {
        // Example list of locations
        List<string> locations = GetLocations();

        // Creating keyboard buttons dynamically
        var keyboardButtons = locations.Select(location => new KeyboardButton[] { new KeyboardButton(location) }).ToArray();

        // Creating the keyboard markup
        var createAccountKeyboard = new ReplyKeyboardMarkup(keyboardButtons);
        return createAccountKeyboard;
    }

    private string CaptionForRenewAccount(User user, DateTime expirationDateUTC, bool showTraffic)
    {
        string msg = "";
        msg = $"✅ مشخصات اکانت شما:  \n";
        msg += $"👤نام: `{user.Email}` \n";
        msg += $"⌛️دوره : {ApiService.ConvertPeriodToDays(user.SelectedPeriod)} روزه \n";
        // msg += $"Location: {user.SelectedCountry} \n";
        if (showTraffic) msg += $"🧮 حجم ترافیک: {user.TotoalGB} گیگابایت\n";

        string hijriShamsiDate = DateTime.UtcNow.AddDays(ApiService.ConvertPeriodToDays(user.SelectedPeriod)).AddMinutes(210).ConvertToHijriShamsi();

        //expired
        if (expirationDateUTC <= DateTime.UtcNow)
            msg += $"📅تاریخ انقضاء:  {hijriShamsiDate}\n";
        else
        {
            hijriShamsiDate = expirationDateUTC.AddDays(ApiService.ConvertPeriodToDays(user.SelectedPeriod)).AddMinutes(210).ConvertToHijriShamsi();
            msg += $"📅تاریخ انقضاء:  {hijriShamsiDate}\n";
        }


        // msg += "✳️ آموزش کانفیگ لینک" + $"**آی‌اواس** [link text]({_appConfig.ConfiglinkTutorial[0]})" + " | " + $"**اندروید** [link text]({_appConfig.ConfiglinkTutorial[1]}) \n";
        // msg += "✴️ آموزش سابلینک (برای تعویض اتوماتیک و فیلترینگ شدید)" + $"**آی‌اواس** [link text]({_appConfig.SubLinkTotorial[0]})" + " | " + $"**اندروید** [link text]({_appConfig.SubLinkTotorial[1]}) \n";
        msg += $"🔗 ساب لینک: \n `{user.SubLink}`\n \n ";

        msg += $"🔗 لینک اتصال: \n";
        msg += "=== برای کپی شدن لمس کنید === \n";
        msg += $"`{user.ConfigLink}`" + "\n ";
        return msg;
    }

    private string CaptionForAccountCreation(User user, string language, bool showTraffic)
    {
        string msg;
        if (language == "en")
        {
            msg = $"✅ Account details: \n";
            msg += $"Account Name: `{user.Email}`\n";
            msg += $"Location: {user.SelectedCountry} \nDuration: {user.SelectedPeriod}";
            if (Convert.ToInt32(user.TotoalGB) < 100) msg += $"\nTraffic: {user.TotoalGB}GB.\n";
            string hijriShamsiDate = DateTime.UtcNow.AddDays(ApiService.ConvertPeriodToDays(user.SelectedPeriod)).AddMinutes(210).ConvertToHijriShamsi();
            msg += $"\nExpiration Date: {hijriShamsiDate}\n";
            msg += $"Your Sublink is: \n `{user.SubLink}` \n";
            msg += $"Your Connection link is: \n";
            msg += "============= Tap to Copy =============\n";
            msg += $"`{user.ConfigLink}`" + "\n ";
        }
        else
        {
            msg = $"✅ مشخصات اکانت شما:  \n";
            msg += $"👤نام: `{user.Email}` \n";
            msg += $"⌛️دوره : {ApiService.ConvertPeriodToDays(user.SelectedPeriod)} روزه \n";
            // msg += $"Location: {user.SelectedCountry} \n";
            if (showTraffic) msg += $"🧮 حجم ترافیک: {user.TotoalGB} گیگابایت\n";

            string hijriShamsiDate = DateTime.UtcNow.AddDays(ApiService.ConvertPeriodToDays(user.SelectedPeriod)).AddMinutes(210).ConvertToHijriShamsi();
            msg += $"📅تاریخ انقضاء:  {hijriShamsiDate}\n";

            // msg += "✳️ آموزش کانفیگ لینک" + $"**آی‌اواس** [link text]({_appConfig.ConfiglinkTutorial[0]})" + " | " + $"**اندروید** [link text]({_appConfig.ConfiglinkTutorial[1]}) \n";
            // msg += "✴️ آموزش سابلینک (برای تعویض اتوماتیک و فیلترینگ شدید)" + $"**آی‌اواس** [link text]({_appConfig.SubLinkTotorial[0]})" + " | " + $"**اندروید** [link text]({_appConfig.SubLinkTotorial[1]}) \n";
            msg += $"🔗 ساب لینک: \n `{user.SubLink}`\n \n ";

            msg += $"🔗 لینک اتصال: \n";
            msg += "=== برای کپی شدن لمس کنید === \n";
            msg += $"`{user.ConfigLink}`" + "\n ";

        }
        return msg;
    }

    /// <summary>
    /// Builds the owned-bot insufficient-wallet message used by legacy purchase and renewal flows.
    /// </summary>
    /// <param name="requiredAmountToman">Exact purchase or renewal price in Iranian toman; must be non-negative.</param>
    /// <param name="currentBalanceToman">Customer's current shared bot-wallet balance in Iranian toman.</param>
    /// <returns>A Persian customer message showing the current balance, required amount, and charge instruction.</returns>
    /// <example>
    /// <code>
    /// var text = BuildOwnedInsufficientBalanceText(250000, 100000);
    /// </code>
    /// </example>
    private static string BuildOwnedInsufficientBalanceText(long requiredAmountToman, long currentBalanceToman)
    {
        return "⛔️ موجودی کیف پول شما برای خرید یا تمدید مورد نظر کافی نیست.\n" +
               $"💳 موجودی فعلی: {currentBalanceToman.FormatCurrency()}\n" +
               $"💰 مبلغ مورد نیاز: {requiredAmountToman.FormatCurrency()}\n\n" +
               "برای ادامه، کیف پول خود را شارژ کنید.";
    }

    /// <summary>
    /// Builds the single inline action that routes an owned customer into wallet charging.
    /// </summary>
    /// <returns>An inline keyboard containing the bot-scoped wallet-charge callback.</returns>
    /// <remarks>
    /// The callback contains no Telegram user id or financial value. The handler derives ownership from the callback
    /// sender and creates no invoice until the customer later selects an amount and an enabled gateway.
    /// </remarks>
    private static InlineKeyboardMarkup BuildWalletChargeShortcutKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    WalletChargeShortcutLabel,
                    WalletChargeShortcutCallback)
            }
        });
    }

    /// <summary>
    /// Handles customer messages for owned bots, including legacy purchase, renewal, wallet-charge, and account menus.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned bot that received the message.</param>
    /// <param name="update">Telegram update containing the customer message and sender identity.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram, database, payment, and XUI operations.</param>
    /// <returns>A task that completes after the matching owned-customer state transition is handled.</returns>
    /// <remarks>
    /// Tenant storefront updates are removed by the outer dispatcher before this method runs. Valid <c>/start</c> and
    /// <c>/refresh</c> commands have already cleared the current bot/user persisted state and XUI purchase session, but
    /// this method still enforces mandatory-channel membership before displaying the owned main menu. Start referral
    /// payloads are registered after the reset and retain their existing immutable relationship rules. Legacy
    /// insufficient-wallet branches show an inline shortcut into the canonical main-keyboard charge flow.
    /// Trial entry displays «اکانت تست» while accepting the previous free-account button as an input alias.
    /// </remarks>
    /// <example>
    /// <code>
    /// await HandleUpdateRegularUsers(botClient, update, cancellationToken);
    /// </code>
    /// </example>
    private async Task HandleUpdateRegularUsers(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {


        if (update.Message is not { } message)
            return;
        var chatId = message.Chat.Id;


        if (message is not null && message.Type == MessageType.Contact && message.Contact != null)
        {
            await _credentialsDbContext.GetUserStatus(GetCreduserFromMessage(message));
            var normalizedPhoneNumber = await ValidateOwnedBotPhoneContactAsync(
                botClient,
                message,
                cancellationToken);
            if (!string.IsNullOrWhiteSpace(normalizedPhoneNumber))
            {
                await _credentialsDbContext.SavePhoneNumber(message.From.Id, normalizedPhoneNumber);
                await botClient.CustomSendTextMessageAsync(
                             chatId: message.Chat.Id,
                             text: "شماره شما با موفقیت تایید شد. حالا دوباره گزینه مورد نظرتان را انتخاب کنید.",
                             replyMarkup: MainReplyMarkupKeyboardFa());
                return;
            }
            else
            {

            }
        }
        // Only process text messages
        if (message.Text is not { } messageText)
            return;

        Console.WriteLine($"Received a '{message.Text}' message in chat {chatId}.");


        var credUser = await _credentialsDbContext.GetUserStatus(GetCreduserFromMessage(message));
        var user = await _state.GetUserStatus(message.From.Id);
        // The download menu is high-level navigation. It is answered before any conversation state can consume the label
        // as user data, and it re-checks the live global switch so a stale reply keyboard fails closed.
        if (await TryHandleClientDownloadMenuRequestAsync(botClient, message, user, cancellationToken))
            return;

        var hasNavigationCommand = TelegramNavigationCommandParser.TryParse(
            message.Text,
            CurrentBot?.Username ?? BotContextAccessor.CurrentBotUsername,
            allowRefresh: true,
            out var navigationCommand);
        ReferralRegistrationResult referralRegistration = null;
        var normalizedStartPayload = hasNavigationCommand &&
                                     navigationCommand.Kind == TelegramNavigationCommandKind.Start &&
                                     navigationCommand.Payload.Length > 0
            ? $"/start {navigationCommand.Payload}"
            : string.Empty;
        var isReferralStart = ReferralService.TryParseStartPayload(normalizedStartPayload, out var referralCode);
        if (isReferralStart)
        {
            referralRegistration = await _referralService.RegisterRelationshipAsync(
                message.From.Id,
                referralCode,
                CurrentBot?.Id ?? BotContextAccessor.DefaultBotId,
                CurrentBot?.Type ?? BotInstanceTypes.Owned,
                cancellationToken);
        }

        var mandatoryJoinChannels = BuildMandatoryJoinChannels(CurrentChannelIds);
        var isJoined = await isJoinedToChannel(mandatoryJoinChannels.Select(c => c.ChatId), message.From.Id, cancellationToken);
        // var isJoined = false;
        if (!isJoined)
        {
            ReplyKeyboardMarkup replyKeyboardMarkup = new(new[]
               {
                    new KeyboardButton[] { "عضو شدم!" }
                })
            {
                ResizeKeyboard = false
            };
            List<InlineKeyboardButton[]> rows = new List<InlineKeyboardButton[]>();
            foreach (var channel in mandatoryJoinChannels.Where(c => !string.IsNullOrWhiteSpace(c.Url)))
            {
                rows.Add(new[] { InlineKeyboardButton.WithUrl(channel.Label, channel.Url) });
            }

            await _state.ClearUserStatus(new User { Id = message.From.Id });
            if (rows.Count > 0)
            {
                InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup(rows.ToArray());
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "به کانال(های) زیر بپیوندید و روی استارت کلیک کنید. \n" + "/start",
                    replyMarkup: inlineKeyboard);
            }
            else
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "برای استفاده از ربات باید عضو کانال‌های معرفی‌شده شوید، اما لینک قابل نمایش برای کانال‌ها تنظیم نشده است. لطفاً به پشتیبانی پیام بدهید.");
            }

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "پس از عضویت روی دکمه زیر کلیک کنید.",
                replyMarkup: replyKeyboardMarkup);
            return;
        }

        if (hasNavigationCommand)
        {
            var registrationText = BuildReferralRegistrationMessage(referralRegistration);
            await botClient.CustomSendTextMessageAsync(
               chatId: message.Chat.Id,
               text: string.IsNullOrWhiteSpace(registrationText)
                   ? "به ربات خوش آمدید!"
                   : $"به ربات خوش آمدید!\n\n{registrationText}",
                replyMarkup: MainReplyMarkupKeyboardFa());
            return;
        }
        else if (await TryHandleReferralMenuCommandAsync(
                     botClient,
                     message,
                     user,
                     cancellationToken))
        {
            return;
        }
        else if (message.Text == "عضو شدم!")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "به ربات خوش آمدید!",
                replyMarkup: MainReplyMarkupKeyboardFa());

        }
        else if (message.Text == "💻 ارتباط با ادمین")
        {
            var support = BuildOwnedBotSupportContactHtml(CurrentSupportAccount);
            var text = string.IsNullOrWhiteSpace(support)
                ? "پشتیبانی این ربات هنوز تنظیم نشده است. لطفاً بعداً دوباره تلاش کنید."
                : "✅ برای ارتباط با پشتیبانی از لینک زیر اقدام کنید.\n🆔 " + support;

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: text, parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa());

            // Save the user's context
            await _state.ClearUserStatus(new User { Id = message.From.Id });

        }

        else if (message.Text == "🏠منو" || message.Text == "لغو" || message.Text == "منوی اصلی")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "منوی اصلی",
                replyMarkup: MainReplyMarkupKeyboardFa());
        }

        else if (message.Text == "📌 قابلیت‌های ربات" || message.Text == "قابلیت‌های ربات")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: BuildBotCapabilitiesMessage(credUser),
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa());
            return;
        }

        else if (message.Text == "📋 تعرفه‌ها" || message.Text == "تعرفه‌ها")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: _xuiV3PurchaseService.BuildTariffsText(credUser?.IsColleague == true),
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa());
            return;
        }

        else if (message.Text == "📒 تراکنش‌های من" || message.Text == "تراکنش‌های من")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await SendWalletLedgerAsync(botClient, message.Chat.Id, message.From.Id, 0, cancellationToken);
            return;
        }

        else if (await _tenantBotService.TryHandleOwnerMessageAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }

        else if (await _xuiV3BotFlowService.TryHandleAccountActionAsync(
            botClient,
            message,
            credUser,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            await _state.ClearUserStatus(user);
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleDeleteExpiredAccountsAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleAccountCommentTextAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleAccountSearchAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleColleagueRequestAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleFreeTrialAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }

        else if (await _xuiV3BotFlowService.TryHandlePurchaseTextAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleRenewAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }
        else if (await _xuiV3BotFlowService.TryHandleAccountCounterLookupAsync(
            botClient,
            message,
            credUser,
            user,
            MainReplyMarkupKeyboardFa(),
            cancellationToken))
        {
            return;
        }

        else if (StartsWithEnableOrDisable(message.Text))
        {
            bool enable;
            var input = message.Text;
            if (message.Text.Contains("/enable_"))
            {
                input = message.Text.Replace("/enable_", "");
                enable = true;
            }
            else
            {
                input = message.Text.Replace("/disable_", "");
                enable = false;
            }

            bool result = await ApiService.AccountActivating(input, credUser.TelegramUserId, enable);


            if (!result)
            {
                await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: "متاسفانه عملیات مورد نظر انجام نشد!",
                                replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
            }
            else
            {
                await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: "عملیات مورد نظر با موفقیت انجام شد!",
                                replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
            }

            await _state.ClearUserStatus(user);
            return;
        }

        else if (message.Text is "🌟اکانت تست" or "🌟اکانت رایگان")
        {
            var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                           {
            new []
            {
                new KeyboardButton("تایید نهایی"),
            },
            new []
            {
                new KeyboardButton("انصراف"),
            },
        });

            if (credUser.IsColleague)
            {
                if (credUser.AccountBalance <= 1000)
                {
                    await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"شما اعتبار لازم برای ساخت اکانت تست را ندارید. ابتدا حساب خود را شارژ بفرمایید.",
                    replyMarkup: MainReplyMarkupKeyboardFa());
                    return;
                }

                user.Flow = "create";
                user.LastStep = "ask_confirmation";
                user.SelectedCountry = "Test";
                user.TotoalGB = "1";
                user.Type = "tunnel";
                user.PaymentMethod = "credit";
                user.SelectedPeriod = "1 Day";
                user.ConfigPrice = 0;
                await _state.SaveUserStatus(user);

                await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: $"✅ شما اعتبار لازم برای ساخت اکانت مورد نظر را دارید. \n" + " ❕ برای دریافت اکانت، گزینه تایید نهایی را بزنید در غیر این صورت انصراف را انتخاب نمایید.\n",
                                    replyMarkup: confirmationKeyboard);
                return;

            }
            // Normal user
            else
            {
                if (string.IsNullOrEmpty(credUser.PhoneNumber))
                {
                    string text =
                        "برای تأیید خودکار، فقط شماره موبایل ایران پذیرفته می‌شود و شماره ارسالی باید متعلق به همین حساب تلگرام باشد.\n\n" +
                        "لطفاً شماره خود را با دکمه زیر ارسال کنید و سپس دوباره روی دریافت اکانت تست بزنید. " +
                        "برای انصراف می‌توانید /start را ارسال کنید.";
                    await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: text,
                                replyMarkup: GetPhoneNumber());
                    return;
                }
                else if ((DateTime.Now - user.LastFreeAcc).Days <= 30)
                {
                    var remainingDays = (TimeSpan.FromDays(31) - (DateTime.Now - user.LastFreeAcc)).Days.ToString();
                    string text = $"شما در یک ماه گذشته اکانت تست خود را دریافت کرده اید. لطفاً {remainingDays} روز دیگر تلاش کنید. ";
                    await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: text,
                                replyMarkup: MainReplyMarkupKeyboardFa());
                    return;
                }
                else
                {
                    user.Flow = "create";
                    user.LastStep = "ask_confirmation";
                    user.SelectedCountry = "Test";
                    user.TotoalGB = "1";
                    user.Type = "tunnel";
                    user.PaymentMethod = "credit";
                    user.SelectedPeriod = "1 Day";
                    user.ConfigPrice = 0;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: $"✅ شما امکان ساخت اکانت مورد نظر را دارید. \n" + " ❕ برای دریافت اکانت، گزینه تایید نهایی را بزنید در غیر این صورت انصراف را انتخاب نمایید.\n",
                                    replyMarkup: confirmationKeyboard);
                    return;
                }
            }


        }

        else if (message.Text == "شارژ حساب کاربری")
        {
            // await _state.ClearUserStatus(new User { Id = message.From.Id });

            // var text = "درحال حاضر شارژ حساب فقط از طریق ادمین امکان پذیر می‌باشد.برای شارژ حساب خود به ادمین پیام دهید و پیام زیر را برای ایشان فوروارد کنید: /n @vpsnetiran_vpn /n به زودی پرداخت ریالی و ترونی به ربات اضافه خواهد شد.";
            // await botClient.CustomSendTextMessageAsync(
            //                 chatId: message.Chat.Id,
            //                 text: text,
            //                 replyMarkup: new ReplyKeyboardRemove());

            // text = await GetUserProfileMessage(credUser);
            // await botClient.CustomSendTextMessageAsync(
            //     chatId: message.Chat.Id,
            //     text: text,
            //     replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

            await _state.ClearUserStatus(new User { Id = message.From.Id });



            user.PaymentMethod = "crypto";
            user.Flow = "charge";
            user.LastStep = "payment_method_selection";
            await _state.SaveUserStatus(user);



        }

        else if (message.Text == "💳خرید اکانت جدید")
        {
            if (string.Equals(_appConfig.XuiApiVersionMode, "v3", StringComparison.OrdinalIgnoreCase))
            {
                var xuiUser = await _state.GetUserStatus(message.From.Id);
                if (await _xuiV3BotFlowService.TryStartPurchaseAsync(botClient, message, credUser, xuiUser, cancellationToken))
                    return;
            }

            var replyKeboard = PriceReplyMarkupKeyboardFa(credUser.IsColleague, false);

            await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "Create New Account", Flow = "create" });

            await botClient.CustomSendTextMessageAsync(
               chatId: message.Chat.Id,
               text: "شرایط اکانت ها به شرح زیر میباشد:",
               replyMarkup: replyKeboard);

        }

        else if (message.Text.Contains("راهنما"))
        {

            await _state.ClearUserStatus(new User { Id = message.From.Id });
            var rkm = new ReplyKeyboardMarkup(new[]
                {
                    new KeyboardButton[] { "راهنمای اپل 📱" },
                    new KeyboardButton[] { "راهنمای اندروید 📱" },
                    new KeyboardButton[] { "راهنمای ویندوز 💻" }
                })
            {
                ResizeKeyboard = true, // Optional: to fit the keyboard to the button sizes
                OneTimeKeyboard = true // Optional: to hide the keyboard after a button is pressed
            };
            if (message.Text == "💡راهنما نصب")
            {

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "منوی راهنما",
                    replyMarkup: rkm);
                return;
            }
            else if (message.Text == "راهنمای اپل 📱")
            {
                List<InlineKeyboardButton[]> rows = (CurrentIosTutorial ?? Array.Empty<string>()).Select((url, index) => new InlineKeyboardButton[]
                    {
                        InlineKeyboardButton.WithUrl(GetTutorialButtonText(index), url)
                    }).ToList();

                // Create the InlineKeyboardMarkup
                InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup(rows);

                await ActiveBotClient.CustomSendTextMessageAsync(chatId: message.Chat.Id,
                     text: "برای دریافت آموزش روی دکمه زیر کلیک کنید.",
                     replyMarkup: inlineKeyboard);


                // foreach (var item in _appConfig.IosTutorial)
                // {
                // var forwardMessage = GetChannelAndPost(item);
                // await ActiveBotClient.CustomForwardMessage(chatId: message.Chat.Id,
                // fromChatId: forwardMessage.ChannelName,
                // messageId: forwardMessage.PostNumber);


                // }
            }
            else if (message.Text == "راهنمای اندروید 📱")
            {
                List<InlineKeyboardButton[]> rows = (CurrentAndroidTutorial ?? Array.Empty<string>()).Select((url, index) => new InlineKeyboardButton[]
                    {
                        InlineKeyboardButton.WithUrl(GetTutorialButtonText(index), url)
                    }).ToList();

                // Create the InlineKeyboardMarkup
                InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup(rows);

                await ActiveBotClient.CustomSendTextMessageAsync(chatId: message.Chat.Id,
                     text: "برای دریافت آموزش روی دکمه زیر کلیک کنید.",
                     replyMarkup: inlineKeyboard);

                // foreach (var item in _appConfig.AndroidTutorial)
                // {
                //     var forwardMessage = GetChannelAndPost(item);
                //     await ActiveBotClient.CustomForwardMessage(chatId: message.Chat.Id,
                //     fromChatId: forwardMessage.ChannelName,
                //     messageId: forwardMessage.PostNumber);
                // }
            }
            else if (message.Text == "راهنمای ویندوز 💻")
            {

                List<InlineKeyboardButton[]> rows = (CurrentWindowsTutorial ?? Array.Empty<string>()).Select((url, index) => new InlineKeyboardButton[]
                    {
                        InlineKeyboardButton.WithUrl(GetTutorialButtonText(index), url)
                    }).ToList();

                // Create the InlineKeyboardMarkup
                InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup(rows);

                await ActiveBotClient.CustomSendTextMessageAsync(chatId: message.Chat.Id,
                     text: "برای دریافت آموزش روی دکمه زیر کلیک کنید.",
                     replyMarkup: inlineKeyboard);

                // foreach (var item in _appConfig.WindowsTutorial)
                // {
                //     var forwardMessage = GetChannelAndPost(item);
                //     await ActiveBotClient.CustomForwardMessage(chatId: message.Chat.Id,
                //     fromChatId: forwardMessage.ChannelName,
                //     messageId: forwardMessage.PostNumber);
                // }
            }
            else
            {
                await botClient.CustomSendTextMessageAsync(
                              chatId: message.Chat.Id,
                              text: "آموزش مورد نظر وجود ندارد",
                              replyMarkup: MainReplyMarkupKeyboardFa());
            }
            await botClient.CustomSendTextMessageAsync(
                              chatId: message.Chat.Id,
                              text: "منوی اصلی",
                              replyMarkup: MainReplyMarkupKeyboardFa());
        }

        else if (message.Text == "⚙️ مدیریت اکانت")
        {
            var accountManagementRows = new List<KeyboardButton[]>
            {
                new KeyboardButton[] { "مشاهده وضعیت حساب","تمدید اکانت"},
                new KeyboardButton[] { "وضعیت اکانت های من","🔎 جستجوی اکانت" },
            };

            if (credUser?.IsColleague != true)
                accountManagementRows.Add(new KeyboardButton[] { "حذف اکانت های منقضی", "🤝 درخواست همکاری" });
            else
                accountManagementRows.Add(new KeyboardButton[] { "حذف اکانت های منقضی", "📌 قابلیت‌های ربات" });

            if (credUser?.IsColleague != true)
                accountManagementRows.Add(new KeyboardButton[] { "📌 قابلیت‌های ربات", "💳خرید اکانت جدید" });
            else
            {
                accountManagementRows.Add(new KeyboardButton[] { "💳خرید اکانت جدید", "💰شارژ حساب کاربری" });
                accountManagementRows.Add(new KeyboardButton[] { TenantBotService.OwnerMenuButton });
            }

            accountManagementRows.Add(new KeyboardButton[] { "منوی اصلی" });

            ReplyKeyboardMarkup replyKeyboardMarkup = new(accountManagementRows)
            {
                ResizeKeyboard = true, // This will make the keyboard buttons resize to fit their container
                OneTimeKeyboard = true // This will hide the keyboard after a button is pressed (optional)
            };


            // var text = await GetUserProfileMessage(credUser);
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "یک گزینه را انتخاب نمائید.",
                replyMarkup: replyKeyboardMarkup, parseMode: ParseMode.Markdown);

        }
        else if (user.LastStep == "confirmation" && user.Flow == "charge")
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            if (message.Text == "انصراف")
            {
                await botClient.CustomSendTextMessageAsync(
                                        chatId: message.Chat.Id,
                                        text: "فرایند شارژ حساب شما کنسل شد.",
                                        replyMarkup: MainReplyMarkupKeyboardFa());
                return;

            }
            else if (message.Text == "تایید نهایی")
            {
                var confirmedAmount = long.TryParse(
                    user.ConfigLink,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out var parsedConfirmedAmount)
                    ? parsedConfirmedAmount
                    : 0;

                if (user.PaymentMethod == "zibal")
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);

                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "درگاه پرداخت ریالی فعلاً غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                if (user.PaymentMethod == "hooshpay" &&
                    (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) ||
                     !HooshPayAmountPolicy.IsValid(confirmedAmount)))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);

                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay)
                            ? "درگاه هوش‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید."
                            : HooshPayAmountPolicy.BuildUserMessage(),
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                if (user.PaymentMethod == "tetraminator" &&
                    !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "درگاه تترامیناتور در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                if (user.PaymentMethod == "uniquepay" &&
                    (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) ||
                     !UniquePayAmountPolicy.IsValid(confirmedAmount)))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay)
                            ? "درگاه یونیک‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید."
                            : UniquePayAmountPolicy.BuildUserMessage(),
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                if (user.PaymentMethod == "atlaspay" &&
                    !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay))
                {
                    user.LastStep = "payment_method_selection"; user.Flow = "charge"; user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(message.Chat.Id,
                        "درگاه اطلس‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                        replyMarkup: BuildChargePaymentMethodKeyboard(), cancellationToken: cancellationToken);
                    return;
                }

                if (user.PaymentMethod == "crypto" &&
                    !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "درگاه ارز دیجیتال در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                await botClient.CustomSendTextMessageAsync(
                                                                            chatId: message.Chat.Id,
                                                                            text: "لطفاً چند ثانیه صبر کنید.",
                                                                            replyMarkup: new ReplyKeyboardRemove());

                if (user.PaymentMethod == "zibal")
                {
                    long amount = Convert.ToInt64(user.ConfigLink) * 10;
                    var zpi = new ZibalPaymentInfo(user.Id);
                    zpi.ChatId = message.Chat.Id;


                    //search for descripttion
                    // Assuming Price and PriceColleagues are IEnumerable<T>
                    var combinedList = _appConfig.Price.Concat(_appConfig.PriceCommon).Concat(_appConfig.PriceColleagues).ToList();
                    var temp = Math.Abs(combinedList[0].Price - amount);
                    string description = combinedList[0].FakeDescription;
                    foreach (var item in combinedList)
                    {
                        if (Math.Abs(item.Price - amount) < temp)
                        {
                            temp = Math.Abs(item.Price - amount);
                            description = item.FakeDescription;
                        }
                    }




                    long dollarPrice = await new DollarPriceHelper().NobitexUSDTIRTPrice();
                    if (dollarPrice == 0) dollarPrice = 780000;
                    description = $"گیفت کارت {Math.Ceiling((double)(amount / dollarPrice))} دلاری استیم";
                    PaymentRequestResponse x = await ZibalAPI.SendPaymentRequest(amount, zpi.CallbackUrl, _appConfig.ZibalMerchantCode, description);
                    x.PayLink = ZibalAPI.GetPaymentLink(x);
                    zpi.TrackId = x.TrackId;
                    zpi.Amount = amount;
                    zpi.Result = x.Result;
                    zpi.CreatedAt = DateTime.UtcNow;

                    _workflow.Add(zpi);
                    await _workflow.SaveAsync();

                    var msg = await GetZipalPaymentMessage(credUser, false, zpi, x.PayLink);

                    var inlineKeyboardMarkup = new InlineKeyboardMarkup(new[]
                         {
                                new[]
                                {
                                    InlineKeyboardButton.WithUrl(text: "پرداخت آنلاین  🏧", url: x.PayLink),
                                    InlineKeyboardButton.WithCallbackData(text: "پرداخت کردم", callbackData: $"check_payment_{zpi.Id}"),

                                }
                            });
                    // var msg = x.Message + "\n" + x.PayLink + "\n" + x.Result + "\n" + x.TrackId;
                    var latestMsg = await botClient.CustomSendTextMessageAsync(
                                                chatId: message.Chat.Id,
                                                text: msg,
                                                replyMarkup: inlineKeyboardMarkup,
                                                parseMode: ParseMode.Html);
                    await botClient.CustomSendTextMessageAsync(
                                                chatId: message.Chat.Id,
                                                text: "منوی اصلی",
                                                replyMarkup: MainReplyMarkupKeyboardFa());



                    zpi.TelMsgId = latestMsg.MessageId;

                    await _workflow.SaveAsync();

                }

                else if (user.PaymentMethod == "hooshpay")
                {
                    await CreateHooshPayWalletChargeAsync(message, credUser, user, cancellationToken);
                }

                else if (user.PaymentMethod == "tetraminator")
                {
                    await CreateTetraminatorWalletChargeAsync(message, credUser, user, cancellationToken);
                }

                else if (user.PaymentMethod == "uniquepay")
                {
                    await CreateUniquePayWalletChargeAsync(message, credUser, user, cancellationToken);
                }
                else if (user.PaymentMethod == "atlaspay")
                {
                    await CreateAtlasPayWalletChargeAsync(message, credUser, user, cancellationToken);
                }

                else if (user.PaymentMethod == "swapino")
                {

                    //                     NowPayments nowPayments = new NowPayments(_configuration);
                    //                     long amount = Convert.ToInt64(user.ConfigLink);
                    //                     var now_response = await nowPayments.Createpayment(amount);
                    //                     var trx = (decimal)amount / (await nowPayments.GetTronRate());
                    //                     var theter = (decimal)amount / (await nowPayments.GetUsThetherRate());


                    //                     var text = "✅ لینک خرید از درگاه سواپینو  \n";
                    //                     text += $"\u200F📝 شماره سند:  `{now_response.payment_id}` \n";

                    //                     text += $"\u200F🆔 آیدی عددی کاربر: `{credUser.TelegramUserId}` \n";
                    //                     string hijriShamsiDate = now_response.created_at.ConvertToHijriShamsi();

                    //                     text += $"‌\u200F📅 تاریخ صدور صورتحساب: {hijriShamsiDate}\n";
                    //                     text += $"‌\u200F🧰 آدرس ولت ترونی : `{now_response.pay_address}`\n";

                    //                     text += $"‌\u200F💰(تومان): {Convert.ToInt64(user.ConfigLink).FormatCurrency()}\n";
                    //                     text += $"‌\u200F💲 ترون: {trx.ToString("F4")}\n";
                    //                     text += $"‌\u200F💵 تتر: {theter.ToString("F4")}\n";

                    //                     text += $"‌\u200F🔗  لینک پرداخت: {now_response.weswap_paymentlink}\n";


                    //                     InlineKeyboardMarkup inlineKeyboard = new(new[]
                    //                   {
                    //                  // first row
                    //             new []
                    //     {
                    //                 InlineKeyboardButton.WithCallbackData(text:"وضعیت در انتظار پرداخت 🔄",callbackData:$"PaymentID{now_response.payment_id}"),

                    //     },
                    //     // second row
                    //     new []
                    //     {
                    //         InlineKeyboardButton.WithCallbackData(text:"❓بررسی پرداخت",callbackData:$"PaymentID{now_response.payment_id}"),
                    //         //InlineKeyboardButton.WithCallbackData(text: "2.2", callbackData: "22"),
                    //     },
                    // });

                    //                     var x = new SwapinoPaymentInfo() { Payment_Id = now_response.payment_id, RialAmount = Convert.ToInt64(user.ConfigLink), TelegramUserId = credUser.TelegramUserId, TronAmount = now_response.pay_amount, UsdtAmount = now_response.price_amount };
                    //                     _userDbContext.SwapinoPaymentInfos.Add(x);
                    //                     _userDbContext.SaveChanges();

                    //                     await botClient.CustomSendTextMessageAsync(
                    //                                         chatId: message.Chat.Id,
                    //                                         text: text.EscapeMarkdown(),
                    //                                         replyMarkup: inlineKeyboard);

                    //                     await botClient.CustomSendTextMessageAsync(
                    //                                         chatId: message.Chat.Id,
                    //                                         text: "پس از پرداخت فاکتور 5 دقیقه صبر کنید و روی گزینه بررسی وضعیت پرداخت بزنید تا حساب شما شارژ شود.",
                    //                                         replyMarkup: MainReplyMarkupKeyboardFa());
                    return;

                }

                else if (user.PaymentMethod == "crypto")
                {
                    if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments))
                    {
                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "درگاه ارز دیجیتال در حال حاضر غیرفعال است.",
                            replyMarkup: BuildChargePaymentMethodKeyboard(),
                            cancellationToken: cancellationToken);
                        return;
                    }

                    long amount = Convert.ToInt64(user.ConfigLink);
                    var payment = SwapinoPaymentInfo.CreateCryptoCharge(
                        credUser.TelegramUserId,
                        amount,
                        _appConfig.NowpaymentIpnUrl,
                        chatId: message.Chat.Id,
                        baseCurrency: _appConfig.NowpaymentPriceCurrency);

                    _workflow.Add(payment);
                    await _workflow.SaveAsync();

                    try
                    {
                        var priceCurrency = string.IsNullOrWhiteSpace(_appConfig.NowpaymentPriceCurrency)
                            ? "usdtbsc"
                            : _appConfig.NowpaymentPriceCurrency;

                        Console.WriteLine($"[NOWPayments] Creating invoice for user={credUser.TelegramUserId}, amount={amount}, orderId={payment.OrderId}, priceCurrency={priceCurrency}, payCurrency=all");

                        var nowPayment = await _nowPayments.CreateInvoiceAsync(
                            amount,
                            payment.OrderId,
                            $"Wallet charge {payment.OrderId}",
                            null,
                            priceCurrency,
                            CurrentNowPaymentsSuccessUrl,
                            CurrentNowPaymentsCancelUrl,
                            cancellationToken);

                        payment.RawRequestJson = JsonConvert.SerializeObject(new
                        {
                            orderId = payment.OrderId,
                            invoiceId = nowPayment.id,
                            invoiceUrl = nowPayment.invoice_url,
                            paymentId = (string)null,
                            amountToman = amount,
                            priceCurrency,
                            payCurrency = (string)null,
                            usdtIrtPrice = nowPayment.LocalUsdtIrtPrice,
                            priceSource = nowPayment.LocalPriceSource,
                            usedFallbackPrice = nowPayment.LocalUsedFallbackPrice,
                            priceIsRial = nowPayment.LocalPriceIsRial,
                            calculatedPriceAmount = nowPayment.price_amount,
                            callbackUrl = _appConfig.NowpaymentIpnUrl
                        });
                        payment.RawResponseJson = JsonConvert.SerializeObject(nowPayment);
                        Console.WriteLine(
                            $"[NOWPayments] Invoice created. orderId={payment.OrderId}, invoiceId={nowPayment.id}, invoiceUrl={nowPayment.invoice_url}, ipnCallbackUrl={_appConfig.NowpaymentIpnUrl}, priceCurrency={nowPayment.price_currency}, priceAmount={nowPayment.price_amount}, paymentId=");
                        var data = NowPaymentsPaymentRecordData.FromInvoiceResponse(nowPayment);
                        data.OrderId = payment.OrderId;
                        payment.SetNowPaymentsData(data);
                        payment.BaseAmount = nowPayment.price_amount;
                        payment.BaseCurrency = nowPayment.price_currency;
                        await _workflow.SaveAsync();

                        var msg = await GetNowPaymentsPaymentMessage(credUser, payment);
                        var inlineKeyboardMarkup = new InlineKeyboardMarkup(new[]
                        {
                            new[]
                            {
                                InlineKeyboardButton.WithUrl(text: "باز کردن فاکتور", url: nowPayment.invoice_url)
                            },
                            new[]
                            {
                                InlineKeyboardButton.WithCallbackData(text: "بررسی وضعیت", callbackData: $"check_crypto_payment_{payment.OrderId}")
                            }
                        });

                        Message latestMsg;
                        if (!string.IsNullOrWhiteSpace(nowPayment.invoice_url))
                        {
                            using var qrStream = new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(nowPayment.invoice_url, 200));
                            latestMsg = await botClient.SendPhoto(
                                message.Chat.Id,
                                InputFile.FromStream(qrStream),
                                caption: msg,
                                parseMode: ParseMode.Html,
                                replyMarkup: inlineKeyboardMarkup,
                                cancellationToken: cancellationToken);
                        }
                        else
                        {
                            latestMsg = await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: msg,
                                replyMarkup: inlineKeyboardMarkup,
                                parseMode: ParseMode.Html,
                                cancellationToken: cancellationToken);
                        }

                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "منوی اصلی",
                            replyMarkup: MainReplyMarkupKeyboardFa(),
                            cancellationToken: cancellationToken);

                        if (latestMsg != null)
                            payment.TelMsgId = latestMsg.MessageId;

                        await _workflow.SaveAsync();
                    }
                    catch (NowPaymentsRateUnavailableException ex)
                    {
                        Console.WriteLine("[NOWPayments] Canonical exchange rate unavailable; create request was not sent.");
                        payment.Result = JsonConvert.SerializeObject(new
                        {
                            error = "rate_unavailable",
                            message = ex.Message,
                            orderId = payment.OrderId,
                            createdAt = DateTime.UtcNow
                        });
                        await _workflow.SaveAsync();

                        // Restored literal: the original Persian sentence was committed as literal '?' characters by a
                        // later edit, so the terminal-shaped message was unreadable. The intended wording was recovered
                        // verbatim from the revision that introduced this NOWPayments failure branch (the commit that
                        // added the gateway), which is the same catch block at the same call site. It is deliberately
                        // identical to the sibling NOWPayments messages on this branch: the customer learns the payment
                        // attempt failed and that diagnostics were logged, without being told to retry a payment that
                        // may already have been created.
                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "ایجاد پرداخت ارز دیجیتال ناموفق بود. جزئیات خطا در ترمینال ثبت شد.",
                            replyMarkup: MainReplyMarkupKeyboardFa(),
                            cancellationToken: cancellationToken);
                    }
                    catch (NowPaymentsApiException ex)
                    {
                        Console.WriteLine("[NOWPayments] API exception while creating payment:");
                        Console.WriteLine(ex.ToString());

                        payment.Result = JsonConvert.SerializeObject(new
                        {
                            error = ex.Message,
                            statusCode = ex.StatusCode,
                            requestMethod = ex.RequestMethod,
                            requestUri = ex.RequestUri,
                            requestBody = ex.RequestBody,
                            responseBody = ex.ResponseBody,
                            orderId = payment.OrderId,
                            createdAt = DateTime.UtcNow
                        });
                        await _workflow.SaveAsync();

                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "NOWPayments درخواست را رد کرده است. جزئیات خطا در ترمینال ثبت شد.",
                            replyMarkup: MainReplyMarkupKeyboardFa(),
                            cancellationToken: cancellationToken);
                    }
                    catch (InvalidOperationException ex) when (ex.Message.Contains("minimum for usd->"))
                    {
                        Console.WriteLine("[NOWPayments] Minimum amount validation failed:");
                        Console.WriteLine(ex.ToString());

                        payment.Result = JsonConvert.SerializeObject(new
                        {
                            error = ex.Message,
                            orderId = payment.OrderId,
                            createdAt = DateTime.UtcNow
                        });
                        await _workflow.SaveAsync();

                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "مبلغ وارد شده از حداقل مجاز NOWPayments کمتر است. جزئیات دقیق در ترمینال ثبت شد.",
                            replyMarkup: MainReplyMarkupKeyboardFa(),
                            cancellationToken: cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("[NOWPayments] Unexpected exception while creating payment:");
                        Console.WriteLine(ex.ToString());

                        payment.Result = JsonConvert.SerializeObject(new
                        {
                            error = ex.Message,
                            orderId = payment.OrderId,
                            createdAt = DateTime.UtcNow
                        });
                        await _workflow.SaveAsync();

                        await botClient.CustomSendTextMessageAsync(
                            chatId: message.Chat.Id,
                            text: "ایجاد پرداخت ارز دیجیتال ناموفق بود. جزئیات خطا در ترمینال ثبت شد.",
                            replyMarkup: MainReplyMarkupKeyboardFa(),
                            cancellationToken: cancellationToken);
                    }

                }

                else
                {
                }
            }
        }
        else if (user.LastStep == "payment_method_selection" && user.Flow == "charge")
        {

            // The user entered a valid number
            var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                       {
            new []
            {
                new KeyboardButton("تایید نهایی"),
            },
            new []
            {
                new KeyboardButton("انصراف"),
            },
        });

            if (message.Text == "درگاه سواپینو(غیرفعال)")
            {
                user.LastStep = "payment_method_selection";
                user.Flow = "charge";
                user.PaymentMethod = string.Empty;
                await _state.SaveUserStatus(user);

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "این درگاه فعلاً غیرفعال است. لطفاً یکی از درگاه‌های فعال را انتخاب کنید.",
                    replyMarkup: BuildChargePaymentMethodKeyboard(),
                    cancellationToken: cancellationToken);
                return;
            }
            else if (IsGatewayAction(message.Text, HooshPayGatewayAction, "⚡ هوش‌پی آنی | کارمزد ۱۵٪", "درگاه ریالی هوش‌پی"))
            {
                var amount = long.TryParse(user.ConfigLink, NumberStyles.Integer, CultureInfo.InvariantCulture, out var selectedAmount)
                    ? selectedAmount
                    : 0;
                if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) ||
                    !HooshPayAmountPolicy.IsValid(amount))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay)
                            ? "درگاه هوش‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید."
                            : HooshPayAmountPolicy.BuildUserMessage(),
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                user.PaymentMethod = "hooshpay";
            }
            else if (IsGatewayAction(message.Text, TetraminatorGatewayAction, "⚡ تترامیناتور آنی | کارمزد ۱۲٪", "درگاه ریالی تترامیناتور"))
            {
                var amount = long.TryParse(user.ConfigLink, out var selectedAmount) ? selectedAmount : 0;
                if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator) ||
                    amount < _appConfig.TetraminatorMinimumAmountToman)
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        message.Chat.Id,
                        amount < _appConfig.TetraminatorMinimumAmountToman
                            ? $"حداقل مبلغ پرداخت با تترامیناتور {_appConfig.TetraminatorMinimumAmountToman.FormatCurrency()} است."
                            : "درگاه تترامیناتور در حال حاضر غیرفعال است.",
                    replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }
                user.PaymentMethod = "tetraminator";
            }
            else if (IsGatewayAction(message.Text, UniquePayGatewayAction, "⚡ یونیک‌پی آنی | کارمزد ۱۲٪", "درگاه ریالی یونیک‌پی"))
            {
                var amount = long.TryParse(user.ConfigLink, NumberStyles.Integer, CultureInfo.InvariantCulture, out var selectedAmount)
                    ? selectedAmount
                    : 0;
                if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) ||
                    !UniquePayAmountPolicy.IsValid(amount))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay)
                            ? "درگاه یونیک‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید."
                            : UniquePayAmountPolicy.BuildUserMessage(),
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }

                user.PaymentMethod = "uniquepay";
            }
            else if (IsGatewayAction(message.Text, AtlasPayGatewayAction, "💳 اطلس‌پی | کارت‌به‌کارت آنی", "درگاه ریالی اطلس‌پی"))
            {
                if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay))
                {
                    user.LastStep = "payment_method_selection"; user.Flow = "charge"; user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(message.Chat.Id,
                        "درگاه اطلس‌پی در حال حاضر غیرفعال است.", replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }
                user.PaymentMethod = "atlaspay";
            }
            else if (message.Text == "درگاه ریالی" || message.Text == "درگاه ریالی (غیرفعال)")
            {
                user.LastStep = "payment_method_selection";
                user.Flow = "charge";
                user.PaymentMethod = string.Empty;
                await _state.SaveUserStatus(user);

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "درگاه پرداخت ریالی فعلاً غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                    replyMarkup: BuildChargePaymentMethodKeyboard(),
                    cancellationToken: cancellationToken);
                return;
            }
            else if (IsGatewayAction(message.Text, CryptoGatewayAction, "درگاه ارز دیجیتال"))
            {
                if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments))
                {
                    user.LastStep = "payment_method_selection";
                    user.Flow = "charge";
                    user.PaymentMethod = string.Empty;
                    await _state.SaveUserStatus(user);
                    await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "درگاه ارز دیجیتال در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                        replyMarkup: BuildChargePaymentMethodKeyboard(),
                        cancellationToken: cancellationToken);
                    return;
                }
                user.PaymentMethod = "crypto";
            }

            user.LastStep = "confirmation";
            user.Flow = "charge";
            await _state.SaveUserStatus(user);


            var gatewayName = user.PaymentMethod == "crypto"
                ? "درگاه ارز دیجیتال آنی با کارمزد ۰٪"
                : user.PaymentMethod == "hooshpay"
                    ? "درگاه ریالی هوش‌پی آنی با کارمزد ۱۵٪"
                : user.PaymentMethod == "tetraminator"
                    ? "درگاه ریالی تترامیناتور آنی با کارمزد ۱۲٪"
                : user.PaymentMethod == "uniquepay"
                    ? "درگاه ریالی یونیک‌پی آنی با کارمزد ۱۲٪"
                : user.PaymentMethod == "atlaspay"
                    ? "اطلس‌پی | کارت‌به‌کارت آنی"
                : user.PaymentMethod == "zibal"
                    ? "درگاه ریالی"
                    : "درگاه پرداخت";

            var text = $"✅ شما مقدار {Convert.ToInt64(user.ConfigLink).FormatCurrency()} را برای شارژ حساب خود وارد کرده‌اید.\n" +
                       $"درگاه انتخابی: {gatewayName}\n" +
                       "برای ادامه، گزینه تایید نهایی را بزنید. در غیر این صورت انصراف را انتخاب کنید.";
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: confirmationKeyboard);
            return;


        }

        else if (message.Text == "💰شارژ حساب کاربری")
        {
            await ShowWalletChargeMenuAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                sourceMessageId: null,
                cancellationToken);
        }

        else if (user.LastStep == "enter charge amount" && user.Flow == "charge")
        {
            // Usage
            bool canConvert = message.Text.PersianNumbersToEnglish().ToValidNumber().TryConvertToLong(out long longValue);
            if (canConvert)
            {
                // use longValue
                user.ConfigLink = longValue.ToString();
                user.LastStep = "payment_method_selection";
                user.Flow = "charge";
                await _state.SaveUserStatus(user);


                // The user entered a valid number
                var paymentmethod = BuildChargePaymentMethodKeyboard();


                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"✅ مبلغ <b>{longValue.FormatCurrency()}</b> برای شارژ کیف پول ثبت شد.\n\n" +
                          "⚡ درگاه‌های فعال پرداخت موفق را به‌صورت خودکار و فوری تایید می‌کنند.\n" +
                          BuildActiveChargeGatewaySummary() + "\n\n" +
                          "👇 درگاه موردنظر را انتخاب کنید.",
                    parseMode: ParseMode.Html,
                    replyMarkup: paymentmethod);
                return;

            }
            else
            {
                // handle the case where it's not a valid long
                await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "enter charge amount", Flow = "charge" });
                var msg = "عدد وارد شده صحیح نمیباشد. لطفاً مبلغ را به تومان و به عدد وارد کنید و گزینه ارسال را بزنید.";
                msg += "\n  در صورتی که میخواهید به منوی اصلی  برگردید روی استارت کلیک کنید /start";
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: msg,
                    replyMarkup: new ReplyKeyboardRemove(), parseMode: ParseMode.Markdown);

            }
            return;

        }

        else if (message.Text == "مشاهده وضعیت حساب")
        {
            var text = await GetUserProfileMessage(credUser);
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: text,
                replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
        }
        else if (message.Text == "وضعیت اکانت های من")
        {
            if (await _xuiV3BotFlowService.TryHandleMyAccountsAsync(
                botClient,
                message,
                credUser,
                MainReplyMarkupKeyboardFa(),
                cancellationToken))
            {
                await _state.ClearUserStatus(new User { Id = message.From.Id });
                return;
            }

            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "لطفاً چند ثانیه صبر کنید. دریافت اطلاعات از سرورها ممکن است لحظاتی طول بکشد ...",
                replyMarkup: new ReplyKeyboardRemove());

            var accounts = await TryGetَAllClient(credUser.TelegramUserId);
            if (accounts.Count < 1)
            {

                await botClient.CustomSendTextMessageAsync(
               chatId: message.Chat.Id,
               text: "شما هنوز هیچ اکانتی از مجموعه ما ندارید.",
               replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                return;
            }
            await SendMessageWithClientInfo(credUser.ChatID, credUser.IsColleague, accounts);


            await botClient.CustomSendTextMessageAsync(
               chatId: message.Chat.Id,
               text: "منوی اصلی",
               replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);

            await _state.ClearUserStatus(new User { Id = message.From.Id });
            return;
        }
        else if (message.Text == "تمدید اکانت")
        {
            await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "Renew Existing Account", Flow = "update" });
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "لطفاً لینک Vmess یا نام اکانت خود را برای ربات ارسال کنید:",
                replyMarkup: new ReplyKeyboardRemove(), parseMode: ParseMode.Markdown);

        }
        else if (user.Flow == "update" && user.LastStep == "get-traffic")
        {
            var isSuccessful = int.TryParse(message.Text, out int res);
            if (!isSuccessful)
            {
                await botClient.CustomSendTextMessageAsync(
                        chatId: message.Chat.Id,
                        text: "خطا! \n ترافیک را به گیگابایت و با اعداد انگلیسی تایپ کنید \n" + "به عنوان مثال 20 معادل بیست گیگابایت خواهد بود \n روی /start برای شروع مجدد کلیک کنید.",
                        replyMarkup: new ReplyKeyboardRemove());
                await _state.ClearUserStatus(new User { Id = message.From.Id });
                return;
            }

            long price = res * 1000;
            if (credUser.AccountBalance >= price)
            {

                user.Flow = "update";
                user.LastStep = "ask_confirmation";
                user._ConfigPrice = price.ToString();
                user.Type = "tunnel";
                user.TotoalGB = res.ToString();
                user.SelectedPeriod = "0 Month";


                await _state.SaveUserStatus(user);


                // The user entered a valid number
                var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                           {
            new []
            {
                new KeyboardButton("تایید نهایی"),
            },
            new []
            {
                new KeyboardButton("انصراف"),
            },
        });

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"✅ شما اعتبار لازم برای تمدید اکانت مورد نظر را دارید. \n" + " ❕ برای دریافت اکانت، گزینه تایید نهایی را بزنید در غیر این صورت انصراف را انتخاب نمایید.\n",
                    replyMarkup: confirmationKeyboard);
                return;

            }

            else
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: BuildOwnedInsufficientBalanceText(price, credUser.AccountBalance),
                    replyMarkup: BuildWalletChargeShortcutKeyboard());
                await _state.ClearUserStatus(new User { Id = message.From.Id });

                return;
            }

        }

        else if (message.Text == "تمدید حجمی" && user.Flow == "update")
        {
            user.LastStep = "get-traffic";
            await _state.SaveUserStatus(user);

            await botClient.CustomSendTextMessageAsync(
                                chatId: message.Chat.Id,
                                text: "ترافیک مورد نظر را به عدد ارسال کنید. هر گیگابایت معادل 1000 تومان از حساب شما کسر خواهد شد.",
                                replyMarkup: new ReplyKeyboardRemove(), parseMode: ParseMode.Markdown);

        }
        else if (user.Flow == "update" && user.LastStep == "ask_confirmation" && (message.Text == "تایید نهایی" || message.Text == "انصراف"))
        {
            await FinalizeRenewCustomerAccount(ActiveBotClient, user, credUser, message);

        }
        else if (user.Flow == "update" && user.LastStep == "set-renew-type" && message.Text.Contains("تمدید"))
        {
            long price = TryParsPrice(message.Text);
            if (price == 0)
            {
                await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: "خطا",
                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                await _state.ClearUserStatus(user);
                return;
            }

            if (CheckButtonCorrectness(credUser.IsColleague, message.Text, true) == false)
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "خطا",
                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                await _state.ClearUserStatus(user);
                return;
            }

            if (credUser.AccountBalance >= price)
            {

                await PrepareAccount(message.Text, credUser, user, true);
                user.Flow = "update";
                user.LastStep = "ask_confirmation";
                user._ConfigPrice = price.ToString();
                await _state.SaveUserStatus(user);


                // The user entered a valid number
                var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                           {
            new []
            {
                new KeyboardButton("تایید نهایی"),
            },
            new []
            {
                new KeyboardButton("انصراف"),
            },
        });

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"✅ شما اعتبار لازم برای تمدید اکانت مورد نظر را دارید. \n" + " ❕ برای دریافت اکانت، گزینه تایید نهایی را بزنید در غیر این صورت انصراف را انتخاب نمایید.\n",
                    replyMarkup: confirmationKeyboard);
                return;

            }

            else
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: BuildOwnedInsufficientBalanceText(price, credUser.AccountBalance),
                    replyMarkup: BuildWalletChargeShortcutKeyboard());
                await _state.ClearUserStatus(new User { Id = message.From.Id });

                return;
            }
        }

        else if ((user.Flow == "update" && user.LastStep == "Renew Existing Account") || message.Text.Contains("/renew_"))
        {

            var replyKeboard = PriceReplyMarkupKeyboardFa(credUser.IsColleague, true);

            var input = message.Text;

            if (message.Text.Contains("/renew_"))
                input = message.Text.Replace("/renew_", "");

            if (StartsWithVMessOrVLess(message.Text))
            {
                user.ConfigLink = message.Text;
                await _state.SaveUserStatus(user);
            }
            else // if (message.Text.StartsWith("/renew_", StringComparison.OrdinalIgnoreCase))
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "لطفاً چند لحظه صبر کنید تا اکانت شما را پیدا کنیم. این عملیات ممکن است چند ثانیه طول بکشد...",
                    replyMarkup: new ReplyKeyboardRemove(), parseMode: ParseMode.Markdown);
                // ممکن است که مشکلی در رابطه با ذخیره وی مس  در  دیتا بیس وجود داشته باشد.
                var client = await ApiService.FetchClientByEmail(input, credUser.TelegramUserId);
                if (client.ClientExtend == null)
                {
                    await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: "اکانت مورد نظر پیدا نشد.",
                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                    await _state.ClearUserStatus(user);
                    return;

                }
            }

            await _state.SaveUserStatus(new User { Id = message.From.Id, LastStep = "set-renew-type", Flow = "update" });

            await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "یک گزینه را انتخاب نمائید:",
                    replyMarkup: replyKeboard, parseMode: ParseMode.Markdown);

        }

        else if (user.Flow == "create" && user.LastStep == "Create New Account" && message.Text.Contains("خرید"))
        {
            long price = TryParsPrice(message.Text);
            if (price == 0)
            {
                await botClient.CustomSendTextMessageAsync(
                                    chatId: message.Chat.Id,
                                    text: "خطا",
                                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                await _state.ClearUserStatus(user);
                return;
            }

            if (CheckButtonCorrectness(credUser.IsColleague, message.Text, false) == false)
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "خطا",
                    replyMarkup: MainReplyMarkupKeyboardFa(), parseMode: ParseMode.Markdown);
                await _state.ClearUserStatus(user);
                return;
            }

            if (credUser.AccountBalance >= price)
            {
                await PrepareAccount(message.Text, credUser, user, false);
                user.Flow = "create";
                user.LastStep = "ask_confirmation";
                user._ConfigPrice = price.ToString();
                await _state.SaveUserStatus(user);


                // The user entered a valid number
                var confirmationKeyboard = new ReplyKeyboardMarkup(new[]
                           {
            new []
            {
                new KeyboardButton("تایید نهایی"),
            },
            new []
            {
                new KeyboardButton("انصراف"),
            },
        });

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: $"✅ شما اعتبار لازم برای ساخت اکانت مورد نظر را دارید. \n" + " ❕ برای دریافت اکانت، گزینه تایید نهایی را بزنید در غیر این صورت انصراف را انتخاب نمایید.\n",
                    replyMarkup: confirmationKeyboard);
                return;

            }
            else
            {
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: BuildOwnedInsufficientBalanceText(price, credUser.AccountBalance),
                    replyMarkup: BuildWalletChargeShortcutKeyboard());
                return;
            }

        }
        else if (user.Flow == "create" && user.LastStep == "ask_confirmation" && (message.Text == "تایید نهایی" || message.Text == "انصراف"))
        {
            await FinalizeCustomerAccount(ActiveBotClient, user, credUser, message);
        }

        else
        {
            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await botClient.CustomSendTextMessageAsync(
                                       chatId: message.Chat.Id,
                                       text: "مشکلی به وجود امد. لطفاً از اول تلاش کنید.",
                                        replyMarkup: MainReplyMarkupKeyboardFa());

        }

        return;

    }

    private async Task EditMessageWithCallback(ITelegramBotClient botClient, long chatid, int messageId)
    {
        //string payment_status = (await new NowPayments().GetPaymentStatus(paymentID)).payment_status;

        DateTime d = DateTime.Now;
        PersianCalendar pc = new PersianCalendar();
        string persianDateTime = string.Format("{0}/{1}/{2} {3}:{4}:{5}:{6} ", pc.GetYear(d), pc.GetMonth(d), pc.GetDayOfMonth(d), pc.GetHour(d), pc.GetMinute(d), pc.GetSecond(d), pc.GetMilliseconds(d));


        InlineKeyboardMarkup paid = new(new[]
                       {
                 // first row
            new []
    {
                InlineKeyboardButton.WithUrl(text:"پرداخت شده ✅",url:"google.com"),

    },
    // second row
    // new []
    // {
    //     InlineKeyboardButton.WithCallbackData(text:"❓بررسی پرداخت"+"\n" +persianDateTime,callbackData:$"PaymentID{paymentID}"),
    //     //InlineKeyboardButton.WithCallbackData(text: "2.2", callbackData: "22"),
    // },
});


        //         InlineKeyboardMarkup notpaid = new(new[]
        //                            {
        //                  // first row
        //                   new []
        //     {
        //                 // InlineKeyboardButton.WithCallbackData(text:payment_status + new Random().Next().ToString(),callbackData:$"PaymentID{paymentID}"),
        //                 InlineKeyboardButton.WithCallbackData(text:payment_status ,callbackData:$"PaymentID{paymentID}"),

        //     },

        //     // second row
        //     new []
        //     {
        //         InlineKeyboardButton.WithCallbackData(text:"❓بررسی پرداخت"+"\n"+persianDateTime,callbackData:$"PaymentID{paymentID}"),
        //         //InlineKeyboardButton.WithCallbackData(text: "2.2", callbackData: "22"),
        //     },
        // });


        // if (payment_status == "finished")
        await botClient.EditMessageReplyMarkup(
                  chatId: chatid,
                  messageId: messageId,
                  replyMarkup: paid);
        // else await botClient.EditMessageReplyMarkup(
        // chatId: chatid,
        // messageId: messageId,
        // replyMarkup: notpaid,
        // cancellationToken: cancellationToken);



    }

    /// <summary>
    /// Finalizes a successful legacy owned-bot account renewal and records its wallet and sales audit entries.
    /// </summary>
    /// <param name="botClient">Current owned-bot Telegram client used for progress and account delivery.</param>
    /// <param name="user">Bot-scoped legacy renewal state containing the selected account, period, traffic, and price.</param>
    /// <param name="credUser">Shared credentials profile whose bot wallet is debited in Iranian toman.</param>
    /// <param name="message">Customer confirmation message that supplies the Telegram user and chat ids.</param>
    /// <returns>A task that completes after renewal, wallet debit, ledger write, sales event, and notification.</returns>
    /// <remarks>
    /// The structured <c>legacy_account_renewed</c> activity event is emitted only after the panel renewal succeeds and
    /// both wallet debit and ledger entry are persisted. This keeps weekly gross sales free from pending or failed work.
    /// Legacy panel calls are measured explicitly because this v2 route does not use the shared v3 HTTP transport. The
    /// central logger records both logical panel-call time and total renewal/settlement/delivery time.
    /// </remarks>
    private async Task FinalizeRenewCustomerAccount(ITelegramBotClient botClient, User user, CredUser credUser, Message message)
    {
        if (message.Text == "انصراف")
        {
            await _state.ClearUserStatus(user);
            return;
        }
        await botClient.CustomSendTextMessageAsync(
                           chatId: message.Chat.Id,
                           text: "لطفاً تا تمدید شدن اکانت چند لحظه صبر کنید ...",
                            replyMarkup: new ReplyKeyboardRemove());


        var ready = await _state.IsUserReadyToCreate(message.From.Id);

        if (!ready)
        {
            await botClient.CustomSendTextMessageAsync(
                   chatId: message.Chat.Id,
                   text: "مشخصات اکانت کامل نیست. لطفاً مراحل دریافت اکانت را به طور کامل طی کنید..",
                    replyMarkup: MainReplyMarkupKeyboardFa());
            await _state.ClearUserStatus(user);
            return;
        }

        using var operationTiming = XuiOperationTiming.Start();
        ClientExtend client = await operationTiming.MeasureLegacyPanelCallAsync(() => TryGetClient(user.ConfigLink));
        if (client == null)
        {
            _logger.LogInformation(
                "Legacy account renewal failed before update. userId={UserId}, panelApiElapsed={PanelApiElapsed}, totalElapsed={TotalElapsed}",
                credUser.TelegramUserId,
                XuiOperationTiming.Format(operationTiming.PanelApiElapsed),
                XuiOperationTiming.Format(operationTiming.TotalElapsed));
            await _state.ClearUserStatus(new User { Id = message.From.Id });

            await botClient.CustomSendTextMessageAsync(
                          chatId: message.Chat.Id,
                          text: "مشکلی با لینک vmess ارسالی شما وجود دارد. سعی کنید ابتدا لینک سالم را برای ربات بفرستید و درصورت عدم رفع مشکل به پشتیبانی پیام دهید.",
                           replyMarkup: new ReplyKeyboardRemove());
            return;
        }

        if (client != null)
        {
            ServerInfo findedServer = null;
            string findedcountry = null;
            AccountDtoUpdate accountDto = null;
            var serversJson = ReadJsonFile.ReadJsonAsString();
            var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

            if (user.ConfigLink.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase))
            {
                var vmess = VMessConfiguration.DecodeVMessLink(user.ConfigLink);

                // Iterate over the dictionary
                foreach (var kvp in servers)
                {
                    string country = kvp.Key;
                    ServerInfo serverInfo = RuntimeSnapshot.Copy(kvp.Value);
                    if (serverInfo.VmessTemplate.Add == vmess.Add)
                    {
                        serverInfo.Inbounds = new List<Inbound> { serverInfo.Inbounds.FirstOrDefault(i => i.Port.ToString() == vmess.Port) };
                        serverInfo.VmessTemplate.Port = vmess.Port;
                        findedServer = serverInfo;
                        findedcountry = country;
                    }
                }

                accountDto = new AccountDtoUpdate { TelegramUserId = message.From.Id, Client = client, ServerInfo = findedServer, SelectedCountry = findedcountry, SelectedPeriod = user.SelectedPeriod, AccType = "tunnel", TotoalGB = user.TotoalGB, ConfigLink = user.ConfigLink };
            }
            await _state.SaveUserStatus(new User { Id = user.Id, SelectedCountry = findedcountry });
            var result = await operationTiming.MeasureLegacyPanelCallAsync(() => UpdateAccount(accountDto));

            if (result)
            {
                user = await _state.GetUserStatus(user.Id);

                if (client == null)
                {
                    await botClient.CustomSendTextMessageAsync(
                                  chatId: message.Chat.Id,
                                  text: "متاسفانه مشکلی در ساخت اکانت شما به وجود آمد. مجدداً دقایقی دیگر تلاش کنید",
                                   replyMarkup: MainReplyMarkupKeyboardFa());
                    await _state.ClearUserStatus(user);
                    return;
                }

                var msg = CaptionForRenewAccount(user, expirationDateUTC: client.ExpiryTime, showTraffic: false);

                await botClient.SendPhoto(message.Chat.Id, InputFile.FromStream(new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(user.ConfigLink, 200))), caption: msg, parseMode: ParseMode.Markdown);
                // .GetAwaiter()
                // .GetResult();

                await botClient.CustomSendTextMessageAsync(
                   chatId: message.Chat.Id,
                   text: "بازگشت به منوی اصلی",
                    replyMarkup: MainReplyMarkupKeyboardFa());

                long beforeBalance = credUser.AccountBalance;
                await _credentialsDbContext.Pay(credUser, Convert.ToInt64(user._ConfigPrice),
                    $"legacy-renew:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:debit");
                long afterBalance = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
                await _walletLedgerService.RecordAsync(
                    credUser.TelegramUserId,
                    WalletLedgerDirections.Debit,
                    Convert.ToInt64(user._ConfigPrice),
                    beforeBalance,
                    afterBalance,
                    WalletLedgerReasons.AccountRenew,
                    provider: "wallet",
                    referenceType: "legacy-renew",
                    referenceId: user.ConfigLink,
                    description: "Legacy account renewal",
                    idempotencyKey: $"legacy-renew:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:debit",
                    cancellationToken: CancellationToken.None);
                await _userActivityLog.LogBotActionAsync(
                    "legacy_account_renewed",
                    credUser,
                    isSuperAdmin: false,
                    new Dictionary<string, object>
                    {
                        ["accountEmail"] = client.Email ?? user.Email ?? string.Empty,
                        ["priceToman"] = Convert.ToInt64(user._ConfigPrice)
                    },
                    CancellationToken.None);

                var logMesseage = "تمدید \n" + $"یوزر `{credUser.TelegramUserId}` \n {credUser} \n با مبلغ {user._ConfigPrice}" + " اکانت زیر را خریداری کرد" + $"\n موجودی قبل از خرید {beforeBalance.FormatCurrency()}" + $"\n موجودی پس از خرید {afterBalance.FormatCurrency()}" + " \n \n" + msg +
                                 $"\nزمان API پنل: {XuiOperationTiming.Format(operationTiming.PanelApiElapsed)}" +
                                 $"\nزمان کل عملیات: {XuiOperationTiming.Format(operationTiming.TotalElapsed)}";

                if (user.ConfigPrice > 1000) _logger.LogInformation(logMesseage.EscapeMarkdown());

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "✅ تمدید با موفقیت انجام شد.\n\n" +
                          BuildPlainBalanceDeductionText(beforeBalance, Convert.ToInt64(user._ConfigPrice), afterBalance),
                    replyMarkup: MainReplyMarkupKeyboardFa());

                if (user.SelectedPeriod == "1 Day")
                {
                    user.LastFreeAcc = DateTime.Now;
                    await _state.SaveUserStatus(user);
                }

            }
            else
            {
                _logger.LogInformation(
                    "Legacy account renewal was rejected. userId={UserId}, panelApiElapsed={PanelApiElapsed}, totalElapsed={TotalElapsed}",
                    credUser.TelegramUserId,
                    XuiOperationTiming.Format(operationTiming.PanelApiElapsed),
                    XuiOperationTiming.Format(operationTiming.TotalElapsed));
            }
        }
        else
        {
            // Handle the case where the selected country is not found in the servers.json file
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "مشکلی در بازیابی اطاعات اکانت ارسالی شما برای عملیات تمدید وجود دارد.",
                replyMarkup: MainReplyMarkupKeyboardFa());
            await _state.ClearUserStatus(user);

        }

        await _state.ClearUserStatus(user);

    }
    /// <summary>
    /// Finalizes a successful legacy owned-bot account purchase and records its wallet and sales audit entries.
    /// </summary>
    /// <param name="botClient">Current owned-bot Telegram client used for progress and account delivery.</param>
    /// <param name="user">Bot-scoped legacy purchase state containing the selected service and final price.</param>
    /// <param name="credUser">Shared credentials profile whose bot wallet is debited in Iranian toman.</param>
    /// <param name="message">Customer confirmation message that supplies the Telegram user and chat ids.</param>
    /// <returns>A task that completes after creation, wallet debit, ledger write, sales event, and notification.</returns>
    /// <remarks>
    /// The structured <c>legacy_account_purchased</c> event is written only after the created account is read back as
    /// enabled and the matching debit ledger entry exists. Wallet top-ups and failed creations are never sales events.
    /// Legacy create and read-back calls are measured explicitly; their sum is reported as panel API time while total
    /// time also includes wallet, persistence, activity logging, and customer delivery performed before the audit.
    /// </remarks>
    private async Task FinalizeCustomerAccount(ITelegramBotClient botClient, User user, CredUser credUser, Message message)
    {
        if (message.Text == "انصراف")
        {
            await _state.ClearUserStatus(user);
            return;
        }

        await botClient.CustomSendTextMessageAsync(
                           chatId: message.Chat.Id,
                           text: "لطفاً تا ساخته شدن اکانت چند لحظه صبر کنید ...",
                            replyMarkup: new ReplyKeyboardRemove());


        var ready = await _state.IsUserReadyToCreate(message.From.Id);
        if (!ready) await botClient.CustomSendTextMessageAsync(
                   chatId: message.Chat.Id,
                   text: "مشخصات اکانت کامل نیست. لطفاً مراحل دریافت اکانت را به طور کامل طی کنید..",
                    replyMarkup: MainReplyMarkupKeyboardFa()); ;

        if (!ready)
        {
            await _state.ClearUserStatus(user);
            return;
        }

        // Access the server information from the servers.json file
        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

        if (servers.ContainsKey(user.SelectedCountry))
        {
            using var operationTiming = XuiOperationTiming.Start();
            var serverInfo = servers[user.SelectedCountry];

            AccountDto accountDto = new AccountDto { TelegramUserId = message.From.Id, IsColleague = credUser.IsColleague, AccountCounter = user.AccountCounter + 1, ServerInfo = serverInfo, SelectedCountry = user.SelectedCountry, SelectedPeriod = user.SelectedPeriod, AccType = user.Type, TotoalGB = user.TotoalGB };

            var result = await operationTiming.MeasureLegacyPanelCallAsync(() => CreateAccount(accountDto));

            if (result)
            {
                user = await _state.GetUserStatus(user.Id);

                ClientExtend client = await operationTiming.MeasureLegacyPanelCallAsync(() => TryGetClient(user.ConfigLink));

                if (client == null || client?.Enable == false)
                {
                    _logger.LogInformation(
                        "Legacy account creation read-back failed. userId={UserId}, panelApiElapsed={PanelApiElapsed}, totalElapsed={TotalElapsed}",
                        credUser.TelegramUserId,
                        XuiOperationTiming.Format(operationTiming.PanelApiElapsed),
                        XuiOperationTiming.Format(operationTiming.TotalElapsed));
                    await botClient.CustomSendTextMessageAsync(
                                  chatId: message.Chat.Id,
                                  text: "متاسفانه مشکلی در ساخت اکانت شما به وجود آمد. مجدداً دقایقی دیگر تلاش کنید",
                                   replyMarkup: MainReplyMarkupKeyboardFa());
                    await _state.ClearUserStatus(user);
                    return;
                }


                var msg = CaptionForAccountCreation(user, language: "fa", showTraffic: false);

                await botClient.SendPhoto(message.Chat.Id, InputFile.FromStream(new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(user.ConfigLink, 200))), caption: msg, parseMode: ParseMode.Markdown);
                // .GetAwaiter()
                // .GetResult();

                await botClient.CustomSendTextMessageAsync(
                   chatId: message.Chat.Id,
                   text: "بازگشت به منوی اصلی",
                    replyMarkup: MainReplyMarkupKeyboardFa());

                long beforeBalance = credUser.AccountBalance;
                await _credentialsDbContext.Pay(credUser, Convert.ToInt64(user._ConfigPrice),
                    $"legacy-purchase:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:debit");
                long afterBalance = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
                await _walletLedgerService.RecordAsync(
                    credUser.TelegramUserId,
                    WalletLedgerDirections.Debit,
                    Convert.ToInt64(user._ConfigPrice),
                    beforeBalance,
                    afterBalance,
                    WalletLedgerReasons.AccountPurchase,
                    provider: "wallet",
                    referenceType: "legacy-purchase",
                    referenceId: user.Email,
                    description: "Legacy account purchase",
                    idempotencyKey: $"legacy-purchase:{BotContextAccessor.CurrentBotId}:{message.Chat.Id}:{message.MessageId}:debit",
                    cancellationToken: CancellationToken.None);
                await _userActivityLog.LogBotActionAsync(
                    "legacy_account_purchased",
                    credUser,
                    isSuperAdmin: false,
                    new Dictionary<string, object>
                    {
                        ["accountEmail"] = user.Email ?? string.Empty,
                        ["priceToman"] = Convert.ToInt64(user._ConfigPrice)
                    },
                    CancellationToken.None);

                var logMesseage = $"یوزر `{credUser.TelegramUserId}` \n {credUser} \n با مبلغ {user._ConfigPrice}" + " اکانت زیر را خریداری کرد" + $"\n موجودی قبل از خرید {beforeBalance.FormatCurrency()}" + $"\n موجودی پس از خرید {afterBalance.FormatCurrency()}" + " \n \n" + msg +
                                 $"\nزمان API پنل: {XuiOperationTiming.Format(operationTiming.PanelApiElapsed)}" +
                                 $"\nزمان کل عملیات: {XuiOperationTiming.Format(operationTiming.TotalElapsed)}";

                if (user.ConfigPrice > 1000) _logger.LogInformation(logMesseage.EscapeMarkdown());

                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "✅ خرید با موفقیت انجام شد.\n\n" +
                          BuildPlainBalanceDeductionText(beforeBalance, Convert.ToInt64(user._ConfigPrice), afterBalance),
                    replyMarkup: MainReplyMarkupKeyboardFa());

                if (user.SelectedPeriod == "1 Day")
                {
                    user.LastFreeAcc = DateTime.Now;

                    await _workflow.SaveAsync();
                }
                else
                {
                    user.AccountCounter = user.AccountCounter + 1;
                    await _state.SaveUserStatus(user);
                    await _state.ClearUserStatus(new User { Id = user.Id });
                }

            }
            else
            {
                _logger.LogInformation(
                    "Legacy account creation was rejected. userId={UserId}, panelApiElapsed={PanelApiElapsed}, totalElapsed={TotalElapsed}",
                    credUser.TelegramUserId,
                    XuiOperationTiming.Format(operationTiming.PanelApiElapsed),
                    XuiOperationTiming.Format(operationTiming.TotalElapsed));
                await botClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "متاسفانه مشکلی در ساخت اکانت شما به وجود آمد. مجدداً دقایقی دیگر تلاش کنید",
                    replyMarkup: MainReplyMarkupKeyboardFa());
            }
        }
        else
        {
            // Handle the case where the selected country is not found in the servers.json file
            await botClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: $"اطلاعات سرور مورد نظر پیدا نشد.",
                replyMarkup: MainReplyMarkupKeyboardFa());
            await _state.ClearUserStatus(user);

        }
        await _state.ClearUserStatus(user);

    }
    /// <summary>
    /// Normalizes configured mandatory-join channel values for Telegram membership checks and join buttons.
    /// </summary>
    /// <param name="channelIds">
    /// Channel identifiers from the current bot configuration. Each item may be a bare username, an <c>@username</c>,
    /// a <c>https://t.me/...</c> link, or a numeric Telegram channel id.
    /// </param>
    /// <returns>
    /// A list of normalized channel descriptors. <c>ChatId</c> is safe to pass to <c>GetChatMember</c>; <c>Url</c>
    /// is safe to use in an inline URL button when the source value can be represented as a public Telegram link.
    /// </returns>
    /// <remarks>
    /// The old mandatory-join path prepended <c>@</c> after a simple URL replacement, which could produce invalid
    /// values such as <c>@@channel</c>. This helper keeps membership checks and button URLs consistent for every
    /// owned bot, including bot-specific channel settings restored from the database.
    /// </remarks>
    private static IReadOnlyList<(string ChatId, string Url, string Label)> BuildMandatoryJoinChannels(IEnumerable<string> channelIds)
    {
        return (channelIds ?? Enumerable.Empty<string>())
            .Select(NormalizeMandatoryJoinChannel)
            .Where(channel => !string.IsNullOrWhiteSpace(channel.ChatId))
            .ToList();
    }

    /// <summary>
    /// Converts one mandatory-join channel setting into Telegram API and button-safe values.
    /// </summary>
    /// <param name="channelId">
    /// Raw channel value from configuration or the current bot database record. The value is optional; blank values
    /// return an empty descriptor and are ignored by the caller.
    /// </param>
    /// <returns>
    /// A normalized tuple containing the Telegram chat id for membership checks, a public URL when one can be built,
    /// and a readable label for the inline join button.
    /// </returns>
    /// <remarks>
    /// Public channel usernames are represented as <c>@username</c> for the Bot API and <c>https://t.me/username</c>
    /// for user-facing buttons. Numeric private channel ids can be checked by Telegram but cannot automatically be
    /// converted into a public join link.
    /// </remarks>
    private static (string ChatId, string Url, string Label) NormalizeMandatoryJoinChannel(string channelId)
    {
        var value = (channelId ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(value))
            return (string.Empty, string.Empty, string.Empty);

        if (Uri.TryCreate(value, UriKind.Absolute, out var uri) &&
            (string.Equals(uri.Host, "t.me", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(uri.Host, "telegram.me", StringComparison.OrdinalIgnoreCase)))
        {
            value = uri.AbsolutePath.Trim('/');
        }

        value = value.Trim().TrimStart('/');
        if (value.Contains('?'))
            value = value[..value.IndexOf('?')];

        value = value.TrimStart('@');
        if (string.IsNullOrWhiteSpace(value))
            return (string.Empty, string.Empty, string.Empty);

        if (long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
            return (value, string.Empty, value);

        var chatId = "@" + value;
        return (chatId, $"https://t.me/{value}", chatId);
    }

    /// <summary>
    /// Checks whether a Telegram user is a member of all mandatory channels for the active bot.
    /// </summary>
    /// <param name="channelIDs">
    /// Normalized Telegram chat identifiers for mandatory channels. Values should come from
    /// <see cref="BuildMandatoryJoinChannels(IEnumerable&lt;string&gt;)"/> so usernames are not double-prefixed with <c>@</c>.
    /// </param>
    /// <param name="userId">
    /// Numeric Telegram user id from the incoming update sender. This is the account whose channel membership is checked.
    /// </param>
    /// <returns>
    /// <c>true</c> only when the user is visible as a non-left, non-kicked member of every configured mandatory channel;
    /// <c>false</c> when the user is missing from at least one channel or when the active bot cannot verify membership.
    /// </returns>
    /// <remarks>
    /// Telegram may return <c>chat not found</c> or <c>member list is inaccessible</c> when the bot is not added to the
    /// channel or lacks the required channel access. The method fails closed in that case so users cannot bypass the
    /// mandatory-join gate because of a bad channel setting.
    ///
    /// Budget shape:
    /// The timeout is one overall budget for the entire channel loop, taken from
    /// <see cref="TelegramInteractionTimeouts.MandatoryJoin"/> (five seconds in production). It is deliberately
    /// not one budget per channel: with N channels the whole evaluation must still finish inside a single
    /// five-second window, otherwise a slow Telegram API would stretch a three-channel check into fifteen
    /// seconds of lane stall. Tests inject a millisecond budget so this behaviour is proven without waiting.
    ///
    /// Failure mode:
    /// On local timeout, transport failure, or channel-access error the method returns <c>false</c> so membership
    /// is treated as unverified and the gate stays closed. Cancellation from <paramref name="cancellationToken"/>
    /// is rethrown, because that means the lane itself is stopping.
    ///
    /// Side effects:
    /// Emits one slow-operation diagnostic for the <c>telegram_mandatory_join</c> operation when the evaluation is
    /// slow or fails. The diagnostic carries only bot id, Telegram user id, elapsed milliseconds, outcome, and
    /// exception type; it never logs channel payloads or bot tokens.
    /// </remarks>
    /// <param name="cancellationToken">
    /// Outer lane cancellation token. When cancelled the resulting <see cref="OperationCanceledException"/> is
    /// propagated instead of being converted into a local timeout.
    /// </param>
    private async Task<bool> isJoinedToChannel(
        IEnumerable<string> channelIDs,
        long userId,
        CancellationToken cancellationToken)
    {
        var started = Stopwatch.GetTimestamp();
        var outcome = "completed";
        string errorType = null;
        // One linked source bounds the whole channel loop, so the total wait never exceeds a single budget
        // while outer lane cancellation still propagates immediately.
        using var bounded = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        bounded.CancelAfter(_interactionTimeouts.MandatoryJoin);

        try
        {
            foreach (var channelId in channelIDs)
            {
                if (string.IsNullOrWhiteSpace(channelId)) return false;
                try
                {
                    var member = await ActiveBotClient.GetChatMember(
                        channelId, userId, cancellationToken: bounded.Token);
                    if (member == null || member.Status is ChatMemberStatus.Left or ChatMemberStatus.Kicked)
                        return false;
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (OperationCanceledException ex)
                {
                    outcome = "local_timeout"; errorType = ex.GetType().Name; return false;
                }
                catch (ApiRequestException ex)
                {
                    outcome = IsMandatoryJoinChannelAccessError(ex) ? "channel_access_error" : "telegram_api_error";
                    errorType = ex.GetType().Name; return false;
                }
                catch (RequestException ex)
                {
                    outcome = "transport_error"; errorType = ex.GetType().Name; return false;
                }
            }
            return true;
        }
        finally
        {
            var elapsed = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
            if (elapsed >= 2000 || outcome != "completed")
                _logger.LogInformation(
                    "Slow Telegram operation. BotId={BotId} TelegramUserId={TelegramUserId} Operation={Operation} ElapsedMs={ElapsedMs:0} Outcome={Outcome} ErrorType={ErrorType}",
                    BotContextAccessor.CurrentBotId, userId, "telegram_mandatory_join", elapsed, outcome, errorType ?? string.Empty);
        }
    }

    /// <summary>
    /// Detects Telegram Bot API errors that mean the bot could not verify mandatory channel membership.
    /// </summary>
    /// <param name="ex">Telegram API exception thrown by <c>GetChatMember</c>; may be <c>null</c>.</param>
    /// <returns>
    /// <c>true</c> when the error is one of Telegram's known inaccessible-channel responses; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Callers use this only to choose the safe failure path for mandatory join. The error is still logged by the
    /// membership checker because it usually means the bot must be added to the channel or promoted.
    /// </remarks>
    private static bool IsMandatoryJoinChannelAccessError(ApiRequestException ex)
    {
        var message = ex?.Message ?? string.Empty;
        return ex?.ErrorCode == 400 &&
               (message.Contains("member list is inaccessible", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("chat not found", StringComparison.OrdinalIgnoreCase));
    }
    /// <summary>Resolves legacy pricing and panel selection and saves the pending purchase or renewal values for this bot/user.</summary>
    /// <param name="messageText">Required incoming plan label used to resolve the configured legacy price and account limits.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="user">Detached current bot/user state; explicit store writes reload their targets and never attach this snapshot.</param>
    /// <param name="isForRenew">True selects renewal pricing; false selects creation pricing. This method does not debit the wallet.</param>
    /// <returns>A task completing after the documented state transition and any required Telegram or panel work.</returns>
    /// <remarks>Reads configured legacy plans and saves only conversation selection. It does not provision an account or mutate a wallet.</remarks>
    private async Task PrepareAccount(string messageText, CredUser credUser, User user, bool isForRenew)
    {

        var priceConfig = GetPriceConfig(messageText, credUser, isForRenew);
        ServerInfo randomServerInfo = GetRandomServer();
        var serverInfo = randomServerInfo;

        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

        var pair = servers.FirstOrDefault(kv => kv.Value != null &&
                                                   typeof(ServerInfo).GetProperty("Url")?.GetValue(kv.Value)?.ToString() == serverInfo.Url);


        user.Type = "tunnel";
        user.TotoalGB = priceConfig.Traffic.ToString();
        user.SelectedPeriod = priceConfig.Duration;
        user.SelectedCountry = pair.Key;
        await _state.SaveUserStatus(user);

        // AccountDto accountDto = new AccountDto { TelegramUserId = user.Id, ServerInfo = serverInfo, SelectedCountry = pair.Key, SelectedPeriod = priceConfig.Duration, AccType = user.Type, TotoalGB = priceConfig.Traffic.ToString() };

        return;
    }

    private ServerInfo GetRandomServer()
    {
        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);


        List<ServerInfo> serverInfos = servers.Values.ToList();
        // List<ServerInfo> serverInfos = new List<ServerInfo>();
        var weightedItems = serverInfos.Select(i => new WeightedItem<ServerInfo>(i, i.Chance));



        ServerInfo selected = RouletteWheel.Spin(weightedItems.ToList<WeightedItem<ServerInfo>>());
        return selected;
        // Console.WriteLine($"Selected item: {selected}");
    }
    public void TestGetRandomServerHits()
    {
        var hitDictionary = new Dictionary<string, int>();
        int numberOfTests = 100;

        for (int i = 0; i < numberOfTests; i++)
        {
            ServerInfo server = GetRandomServer();

            if (hitDictionary.ContainsKey(server.Name))
            {
                hitDictionary[server.Name]++;
            }
            else
            {
                hitDictionary.Add(server.Name, 1);
            }
        }

        // Calculate and print the percentage of hits for each server
        foreach (var entry in hitDictionary)
        {
            double percentage = (double)entry.Value / numberOfTests * 100;
            Console.WriteLine($"Server: {entry.Key}, Hits: {entry.Value}, Percentage: {percentage}%");
        }
    }
    private bool CheckButtonCorrectness(bool isColleague, string text, bool isForRenew)
    {
        return GetPrices(isColleague, isForRenew).Contains(text);
    }

    /// <summary>
    /// Sends one or more Telegram messages containing the legacy account-status representation of XUI clients.
    /// </summary>
    /// <param name="chatId">
    /// The destination Telegram chat id from the active owned bot conversation.
    /// </param>
    /// <param name="isColleague">
    /// Whether the recipient has colleague privileges and may see usage and enable/disable actions.
    /// </param>
    /// <param name="clients">
    /// The XUI client records to display. The collection must be non-null and may be empty.
    /// </param>
    /// <returns>A task that completes after every non-empty message chunk has been delivered.</returns>
    /// <remarks>
    /// Messages are split below Telegram's 4096-character limit. This legacy formatter does not mutate clients,
    /// account ownership, wallet balances, or conversation state.
    /// </remarks>
    public async Task SendMessageWithClientInfo(ChatId chatId, bool isColleague, List<ClientExtend> clients)
    {
        const int MaxMessageLength = 4096; // Telegram max message length
        StringBuilder messageBuilder = new StringBuilder();
        string clientInfo = "وضعیت اکانت های شما به شرح زیر است: \n";
        foreach (var client in clients)
        {
            clientInfo = $"👤 نام: `{client.Email}`\n";
            // $"- Name: {client.Name}\n" +
            // $"- Subscription: {client.}\n" +


            if (client.ExpiryTimeRaw > 0)
            {
                clientInfo += $"📅 انقضاء: {client.ExpiryTime.AddMinutes(210).ConvertToHijriShamsi()}\n";
                if (client.ExpiryTime < DateTime.UtcNow)
                    clientInfo += $"\u200F🚫 منقضی شده است. \n";
                else if ((client.ExpiryTime - DateTime.UtcNow) <= TimeSpan.FromDays(5))
                    clientInfo += $"\u200F❕⌛️ روزهای باقی‌مانده: " + (client.ExpiryTime - DateTime.UtcNow).Days + " روز \n";

                else
                    clientInfo += $"\u200F⏳ روزهای باقی‌مانده: " + (client.ExpiryTime - DateTime.UtcNow).Days + " روز \n";
            }
            else
                clientInfo += $"\u200F⌛️ روزهای باقی‌مانده: " + (client.ExpiryTime - DateTime.UtcNow).Days + " روز پس از برقراری اولین اتصال \n";



            if (isColleague)
            {

                double totalUsed = (client.Up + client.Down).ConvertBytesToGB();
                if (((client.Up + client.Down) / client.TotalGB) < 0.9)
                    clientInfo += "\u200F" + "🔋 میزان مصرف : " + $"{totalUsed:F2}" + $" از {client.TotalGB.ConvertBytesToGB()} گیگابایت" + "\n";
                else
                    clientInfo += "\u200F" + "🪫 میزان مصرف: " + $"{totalUsed:F2}" + $" از {client.TotalGB.ConvertBytesToGB()} گیگابایت" + "\n";

                if (client.Enable)
                    clientInfo += $"\u200F✔️ فعال  \n" + "\u200F غیر فعال سازی ⬅️" + $"/disable_{client.Email} \n";

                else
                    clientInfo += $"\u200F🚫 غیرفعال  \n" + "\u200F فعالسازی ⬅️" + $"/enable_{client.Email} \n";

            }
            else
            {
                if ((client.Up + client.Down) >= client.TotalGB && (client.ExpiryTime > DateTime.UtcNow))
                    clientInfo += "\u200F" + $"❗️مولتی آیپی \n";
            }


            // tamdid
            clientInfo += "\u200F" + "🔄 تمدید ⬅️  " + $"/renew_{client.Email} \n";
            // /renew_{client.Email}
            clientInfo += "\u200F" + "🔗 ساب لینک: \n" + $"`{client.SubId}` \n";
            //clientInfo += ":میزان مصرف" + client.TotalUsedTrafficInGB + "\n";

            clientInfo += "___________________________\n";

            // Check if adding this client's info will exceed the Telegram message length limit
            if (messageBuilder.Length + clientInfo.Length > MaxMessageLength)
            {
                // Send the current message
                await ActiveBotClient.CustomSendTextMessageAsync(chatId, messageBuilder.ToString().EscapeMarkdown(), parseMode: ParseMode.Markdown);
                messageBuilder.Clear(); // Clear the builder for the next message
            }

            // Add the current client's info to the message builder
            messageBuilder.Append(clientInfo);
        }

        // Send any remaining info
        if (messageBuilder.Length > 0)
        {
            await ActiveBotClient.SendMessage(chatId, messageBuilder.ToString().EscapeMarkdown(), parseMode: ParseMode.Markdown);
        }
    }

    /// <summary>
    /// Handles Telegram polling errors without allowing logging failures to stop bot receivers.
    /// </summary>
    /// <param name="botClient">Telegram client whose polling loop reported the error.</param>
    /// <param name="exception">Exception raised by Telegram polling or by an update handler.</param>
    /// <param name="cancellationToken">Polling cancellation token supplied by Telegram.Bot.</param>
    /// <returns>A task that completes after best-effort logging.</returns>
    /// <remarks>
    /// The Telegram polling library routes unhandled update-handler exceptions here. Per-user delivery errors,
    /// such as a customer blocking an owned or tenant bot, are non-actionable delivery noise and must not crash the
    /// process or spam the private Telegram logger channel. The method catches its own logging failures so the
    /// error callback remains non-throwing.
    /// Telegram 5xx polling bursts are treated as transient provider noise: they are written only as local warning
    /// activity entries and are not sent to the operational Telegram logger channel.
    /// </remarks>
    public async Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        var ErrorMessage = exception switch
        {
            ApiRequestException apiRequestException
                => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
            _ => exception.ToString()
        };

        try
        {
            if (IsUserDeliveryPollingError(exception))
            {
                await _userActivityLog.LogWarningAsync(
                    "telegram_polling_delivery_skipped",
                    null,
                    false,
                    new Dictionary<string, object>
                    {
                        ["source"] = "Telegram polling",
                        ["telegramError"] = exception.Message ?? string.Empty
                    },
                    cancellationToken);
            }
            else if (IsTransientTelegramPollingError(exception))
            {
                await _userActivityLog.LogWarningAsync(
                    "telegram_polling_transient_skipped",
                    null,
                    false,
                    new Dictionary<string, object>
                    {
                        ["source"] = "Telegram polling",
                        ["telegramError"] = exception.Message ?? string.Empty
                    },
                    cancellationToken);
            }
            else
            {
                await _userActivityLog.LogErrorAsync(
                    "telegram_polling_error",
                    exception,
                    null,
                    false,
                    new Dictionary<string, object>
                    {
                        ["source"] = "Telegram polling"
                    },
                    cancellationToken);
            }
        }
        catch (Exception logException)
        {
            _logger.LogError(
                logException,
                "Failed to write Telegram polling error activity log. originalError={OriginalError}",
                exception.Message);
        }

        var isDeliveryError = IsUserDeliveryPollingError(exception);
        var isTransientTelegramError = IsTransientTelegramPollingError(exception);
        if (isDeliveryError)
        {
            _logger.LogDebug("Telegram polling delivery error ignored. {ErrorMessage}", ErrorMessage);
        }
        else if (isTransientTelegramError)
        {
            _logger.LogDebug("Transient Telegram polling error ignored. {ErrorMessage}", ErrorMessage);
        }
        else
        {
            _logger.LogError(exception, "Telegram polling error. {ErrorMessage}", ErrorMessage);

            // Only genuine, non-transient polling failures reach the process console. Per-user delivery noise and
            // transient 5xx/429/timeout bursts are already captured in the local activity log, and writing one console
            // line per failed getUpdates across every bot receiver is what previously flooded the journal.
            Console.WriteLine(ErrorMessage);
        }
    }

    /// <summary>
    /// Detects Telegram delivery failures that definitively identify an unreachable user chat.
    /// </summary>
    /// <param name="exception">Exception raised by Telegram polling or update handling.</param>
    /// <returns>
    /// <c>true</c> when the error is a blocked-user, deactivated-user, forbidden, or chat-not-found response;
    /// otherwise <c>false</c>. Transport timeouts are intentionally excluded.
    /// </returns>
    /// <remarks>
    /// These responses prove that Telegram cannot deliver to that chat. A request timeout proves only a temporary
    /// transport failure and is instead handled by <see cref="IsExternalOperationTimeout" />, without changing or
    /// mislabeling user reachability.
    /// </remarks>
    private static bool IsUserDeliveryPollingError(Exception exception)
    {
        if (exception is not ApiRequestException apiException)
            return false;

        var message = apiException.Message ?? string.Empty;
        return apiException.ErrorCode == 403 ||
               message.Contains("bot was blocked", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("user is deactivated", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("chat not found", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("forbidden", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Detects temporary Telegram 5xx polling responses that should not be forwarded to the operational log channel.
    /// </summary>
    /// <param name="exception">Exception raised by Telegram polling or update handling.</param>
    /// <returns>
    /// <c>true</c> when Telegram returned a transient response such as a 429 rate limit, a 5xx gateway/server status,
    /// or a network transport failure that the polling loop will retry; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// These errors happen before a user update is available and are retried by the polling loop. They are written
    /// to the local activity file as warnings but logged only at debug level through <see cref="ILogger"/> so the
    /// private Telegram logger channel does not receive repeated non-actionable rate-limit or 502 messages.
    /// Classification is delegated to <see cref="TelegramPollingBackoffPolicy.IsTransientGatewayFailure"/> so the shared
    /// dispatcher and the multi-bot receiver lifecycle cannot disagree about what is transient.
    /// </remarks>
    private static bool IsTransientTelegramPollingError(Exception exception)
    {
        // Shares one classifier with the multi-bot polling error handler so the dispatcher cannot disagree with the
        // receiver about whether a 502/503/504, an HTTP timeout, or a network transport failure is transient.
        return TelegramPollingBackoffPolicy.IsTransientGatewayFailure(exception);
    }

    /// <summary>
    /// Detects non-shutdown transient failures from external systems used while handling a Telegram update.
    /// </summary>
    /// <param name="exception">
    /// Exception caught by the update wrapper. This is commonly a <see cref="TaskCanceledException"/> from
    /// <see cref="HttpClient"/> when the XUI panel times out, or an <see cref="HttpRequestException"/> when the panel
    /// or Telegram connection fails with a transient TLS/socket problem.
    /// </param>
    /// <param name="cancellationToken">
    /// Polling cancellation token from Telegram.Bot. When this token is cancelled, the timeout belongs to shutdown
    /// and must not be swallowed as a recoverable business failure.
    /// </param>
    /// <returns>
    /// <c>true</c> when the exception represents a transient external failure that should be logged and handled
    /// without stopping the receiver; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Gozargah and other owned bots can hit slow 3x-ui panels. Timeouts, TLS bad-record errors, and temporary
    /// gateway failures should produce a user-facing retry message, not a polling failure that stops the active bot.
    /// </remarks>
    private static bool IsExternalOperationTimeout(Exception exception, CancellationToken cancellationToken)
    {
        if (cancellationToken.IsCancellationRequested)
            return false;

        if (exception is TimeoutException)
            return true;

        if (exception is TaskCanceledException)
            return true;

        if (ApiServicev3.IsTransientXuiTransportException(exception, cancellationToken))
            return true;

        var message = exception?.Message ?? string.Empty;
        return message.Contains("HttpClient.Timeout", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("request timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("decryption failed", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("bad record mac", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("SSL_ERROR_SSL", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("Bad Gateway", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("gateway timeout", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("service unavailable", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Sends a short best-effort timeout notice and normal customer menu to the Telegram chat that triggered the update.
    /// </summary>
    /// <param name="botClient">Telegram client for the active owned or tenant bot.</param>
    /// <param name="update">Update whose message or callback chat should receive the notice.</param>
    /// <param name="cancellationToken">Polling cancellation token for the Telegram send attempt.</param>
    /// <returns>A task that completes after the notification is sent or skipped.</returns>
    /// <remarks>
    /// This method intentionally swallows Telegram delivery failures. It is already running inside an exception
    /// handler, so a blocked user or another send timeout must not create a second polling error.
    /// </remarks>
    private async Task SendBestEffortTimeoutMessageAsync(
        ITelegramBotClient botClient,
        Update update,
        CancellationToken cancellationToken)
    {
        var chatId = update?.Message?.Chat.Id ?? update?.CallbackQuery?.Message?.Chat.Id;
        if (!chatId.HasValue)
            return;

        try
        {
            await botClient.SendMessage(
                chatId: chatId.Value,
                text: "ارتباط با پنل یا تلگرام بیش از حد طول کشید. لطفاً چند دقیقه دیگر دوباره تلاش کنید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex) when (IsUserDeliveryPollingError(ex) || IsExternalOperationTimeout(ex, cancellationToken))
        {
            _logger.LogWarning(
                "Skipped timeout notification because Telegram could not deliver it. botId={BotId}, chatId={ChatId}, telegramError={TelegramError}",
                BotContextAccessor.CurrentBotId,
                chatId.Value,
                ex.Message);
        }
    }

    /// <summary>
    /// Sends a concise best-effort failure notice with the normal menu after an unhandled update error.
    /// </summary>
    /// <param name="botClient">Telegram client for the active owned or tenant runtime.</param>
    /// <param name="update">Failed update whose message or callback chat identifies the customer destination.</param>
    /// <param name="cancellationToken">Handler token used only to bound the Telegram send attempt.</param>
    /// <returns>A task completing after the safe notice is delivered or a secondary delivery failure is suppressed.</returns>
    /// <remarks>
    /// This method performs no database, wallet, gateway, or XUI work. The original exception is rethrown after this
    /// call so the durable scheduler records a terminal error receipt, while the menu lets the customer continue.
    /// </remarks>
    /// <example><code>await SendBestEffortFailureMessageAsync(botClient, update, cancellationToken);</code></example>
    private async Task SendBestEffortFailureMessageAsync(
        ITelegramBotClient botClient,
        Update update,
        CancellationToken cancellationToken)
    {
        var chatId = update?.Message?.Chat.Id ?? update?.CallbackQuery?.Message?.Chat.Id;
        if (!chatId.HasValue)
            return;

        try
        {
            await botClient.SendMessage(
                chatId: chatId.Value,
                text: "انجام درخواست با خطا روبه‌رو شد. لطفاً دوباره تلاش کنید یا از منوی اصلی ادامه دهید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception deliveryFailure)
        {
            _logger.LogWarning(
                "Skipped failure notification because Telegram could not deliver it. botId={BotId}, chatId={ChatId}, errorType={ErrorType}",
                BotContextAccessor.CurrentBotId,
                chatId.Value,
                deliveryFailure.GetType().Name);
        }
    }

    /// <summary>
    /// Builds the owned-bot account-status message for one profile.
    /// </summary>
    /// <param name="credUser">Detached credentials profile whose status is being displayed.</param>
    /// <param name="cancellationToken">
    /// Lane cancellation token forwarded to the optional Gozargah website wallet lookup. A cancelled lane abandons that
    /// display-only lookup instead of holding the update.
    /// </param>
    /// <returns>Markdown-escaped profile text, optionally including the website wallet line for colleagues.</returns>
    /// <remarks>
    /// The website wallet line is display-only enrichment. It is bounded by
    /// <see cref="GozargahSiteApiClient.OptionalLookupTimeout" /> and never blocks the profile response beyond that
    /// budget, and it never debits either wallet.
    /// </remarks>
    async Task<string> GetUserProfileMessage(CredUser credUser, CancellationToken cancellationToken = default)
    {
        var _credUser = await _credentialsDbContext.GetUserStatus(credUser);

        var text = "✅ مشخصات اکانت شما به شرح زیر میباشد:  \n";
        text += $"👤نام حساب: {_credUser.FirstName} {_credUser.LastName} \n";
        if (!string.IsNullOrEmpty(_credUser.Username))
            text += $"\u200F🆔 آیدی: @{_credUser.Username} \n";
        text += $"\u200Fℹ️ آیدی عددی: `{_credUser.TelegramUserId}` \n";
        text += $"‌💰اعتبار حساب: {_credUser.AccountBalance.FormatCurrency()}\n";
        if (_credUser.IsColleague)
        {
            text += await BuildGozargahSiteWalletStatusLineAsync(_credUser.TelegramUserId, cancellationToken);
            text += $"‌🧰 نوع: اکانت شما از نوع همکار 💎می‌باشد. \n";
        }
        else
        {
            text += "‌🧰 نوع: اکانت شما از نوع کاربر عادی می‌باشد. \n";
        }
        return text.EscapeMarkdown();
    }

    /// <summary>
    /// Builds the optional Gozargah website wallet line shown in colleague account status messages.
    /// </summary>
    /// <param name="telegramUserId">
    /// Numeric Telegram user id of the colleague. The Gozargah website API uses the same id to find the linked website user.
    /// </param>
    /// <param name="cancellationToken">
    /// Lane cancellation token linked with the foreground website-lookup budget so a slow website releases the update
    /// instead of holding it for the transport ceiling.
    /// </param>
    /// <returns>
    /// A human-readable status line containing the website wallet balance, ban status, or a short unavailable message.
    /// The returned text is not escaped; <see cref="GetUserProfileMessage(CredUser, CancellationToken)"/> escapes the full
    /// profile message.
    /// </returns>
    /// <remarks>
    /// This method is display-only and is one of the foreground Gozargah lookups: the colleague is waiting for the
    /// response. The lookup is therefore bounded by <see cref="GozargahSiteApiClient.CreateOptionalLookupCancellation" />
    /// (four seconds overall, hard maximum five) rather than by the provider-oriented transport timeout. It never debits
    /// either wallet, never mutates financial state, and never blocks the owned-bot status flow: on timeout the line simply
    /// reports that the website is unavailable.
    /// </remarks>
    private async Task<string> BuildGozargahSiteWalletStatusLineAsync(long telegramUserId, CancellationToken cancellationToken = default)
    {
        if (_gozargahSiteApiClient == null || !_gozargahSiteApiClient.IsConfigured())
            return string.Empty;

        try
        {
            using var lookupTimeout = GozargahSiteApiClient.CreateOptionalLookupCancellation(cancellationToken);
            var siteUser = await _gozargahSiteApiClient.GetUserAsync(telegramUserId, lookupTimeout.Token);
            if (!siteUser.Success || siteUser.Data == null)
            {
                var statusText = IsGozargahSiteUserNotConnectedMessage(siteUser.Message)
                    ? "متصل نشده"
                    : $"در دسترس نیست ({siteUser.Message ?? "کاربر پیدا نشد"})";
                return $"🌐 موجودی سایت گذرگاه: {statusText}\n";
            }

            var banText = siteUser.Data.IsBanned ? " - مسدود در سایت" : string.Empty;
            return $"🌐 موجودی سایت گذرگاه: {siteUser.Data.Wallet.FormatCurrency()}{banText}\n";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to load Gozargah site wallet for colleague profile. userId={TelegramUserId}", telegramUserId);
            return "🌐 موجودی سایت گذرگاه: خطا در دریافت اطلاعات سایت\n";
        }
    }

    /// <summary>
    /// Detects the normal Gozargah website response for a Telegram user that has not connected a site account.
    /// </summary>
    /// <param name="message">
    /// Message returned by the Gozargah website <c>get_user</c> response wrapper. It may be a plain API message or
    /// the local HTTP wrapper text, for example <c>HTTP 404: {"success":false,"message":"not found"}</c>.
    /// </param>
    /// <returns>
    /// <c>true</c> when the message represents the expected "not connected/not found" state; otherwise <c>false</c>
    /// so real API failures can still be shown as unavailable.
    /// </returns>
    /// <remarks>
    /// The profile page is customer-facing. A website 404 is not an operational error here; it only means the
    /// Telegram user has not linked or registered a Gozargah website wallet, so the bot should show "متصل نشده".
    /// </remarks>
    private static bool IsGozargahSiteUserNotConnectedMessage(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("HTTP 404", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("not found", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("پیدا نشد", StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildPlainBalanceDeductionText(long beforeBalance, long deductedAmount, long afterBalance)
    {
        return $"💳 موجودی قبل: {beforeBalance.FormatCurrency()}\n" +
               $"💸 مبلغ کسر شده: {deductedAmount.FormatCurrency()}\n" +
               $"💰 موجودی باقی‌مانده: {afterBalance.FormatCurrency()}";
    }

    /// <summary>
    /// Writes the private-channel audit log for a manual admin wallet adjustment.
    /// </summary>
    /// <param name="actor">
    /// Telegram sender who confirmed the admin operation. The value comes from the update sender and is converted
    /// to a clickable audit identity without storing or exposing any bot token.
    /// </param>
    /// <param name="target">
    /// Credentials user whose shared bot-wallet balance was changed by the admin operation.
    /// </param>
    /// <param name="isCredit">
    /// <c>true</c> when the admin added balance; <c>false</c> when the admin deducted balance.
    /// </param>
    /// <param name="amountToman">Adjustment amount in Iranian toman.</param>
    /// <param name="beforeBalance">Target bot-wallet balance in toman before the adjustment.</param>
    /// <param name="afterBalance">Target bot-wallet balance in toman after the adjustment.</param>
    /// <remarks>
    /// The wallet mutation and ledger write happen before this method is called. This method only mirrors the
    /// completed financial action to the central private logger channel so admins can audit manual changes later.
    /// </remarks>
    private void LogAdminWalletAdjustment(
        Telegram.Bot.Types.User actor,
        CredUser target,
        bool isCredit,
        long amountToman,
        long beforeBalance,
        long afterBalance)
    {
        var actorUser = BuildCredUserFromTelegramActor(actor);
        var actionText = isCredit ? "افزایش موجودی دستی" : "کسر موجودی دستی";
        var directionIcon = isCredit ? "➕🟢" : "➖🔴";

        var message =
            $"{directionIcon} <b>{Html(actionText)}</b>\n\n" +
            "📌 انجام‌دهنده\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(actorUser)}\n\n" +
            "📌 کاربر هدف\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n\n" +
            $"مبلغ: <code>{Html(amountToman.FormatCurrency())}</code>\n" +
            $"موجودی قبل: <code>{Html(beforeBalance.FormatCurrency())}</code>\n" +
            $"موجودی بعد: <code>{Html(afterBalance.FormatCurrency())}</code>";

        _logger.LogPayment(message);
    }

    /// <summary>
    /// Writes the private-channel audit log for a super-admin colleague role change.
    /// </summary>
    /// <param name="actor">
    /// Telegram sender who confirmed the role change. The value is used only to build a clickable admin identity
    /// for the private audit log.
    /// </param>
    /// <param name="target">Credentials user whose colleague pricing flag was changed.</param>
    /// <param name="wasColleague">Role flag before the admin operation was applied.</param>
    /// <param name="isColleagueAfter">Role flag after the admin operation was persisted.</param>
    /// <remarks>
    /// Role changes affect pricing and tenant-bot access, so both promotion and demotion are logged. The caller
    /// performs the database update first; this method has no side effects except the private audit log, which is
    /// committed to the durable Telegram outbox as HTML (EventId 1001/TelegramHtml) without any database backup
    /// intent because the role change itself does not mutate wallet or payment state.
    /// </remarks>
    private void LogAdminRoleChange(
        Telegram.Bot.Types.User actor,
        CredUser target,
        bool wasColleague,
        bool isColleagueAfter)
    {
        var actorUser = BuildCredUserFromTelegramActor(actor);
        var actionText = isColleagueAfter ? "ارتقای کاربر به همکار" : "تنزل کاربر به عادی";

        var message =
            $"👥 <b>{Html(actionText)}</b>\n\n" +
            "📌 انجام‌دهنده\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(actorUser)}\n\n" +
            "📌 کاربر هدف\n" +
            $"{TelegramUserLinkFormatter.HtmlSummary(target)}\n\n" +
            $"نقش قبل: <code>{Html(wasColleague ? "همکار" : "کاربر عادی")}</code>\n" +
            $"نقش بعد: <code>{Html(isColleagueAfter ? "همکار" : "کاربر عادی")}</code>";

        _logger.LogTelegramHtml(message);
    }

    /// <summary>
    /// Converts a Telegram update sender into the shared credentials shape used by audit link formatters.
    /// </summary>
    /// <param name="actor">
    /// Telegram sender from the incoming update. A null value is converted to a zero-id placeholder to keep audit
    /// logging best-effort and non-throwing.
    /// </param>
    /// <returns>
    /// A lightweight credentials user object suitable for HTML audit summaries. The returned object is not tracked
    /// by EF Core and must not be saved.
    /// </returns>
    private static CredUser BuildCredUserFromTelegramActor(Telegram.Bot.Types.User actor)
    {
        return new CredUser
        {
            TelegramUserId = actor?.Id ?? 0,
            ChatID = actor?.Id ?? 0,
            Username = actor?.Username ?? string.Empty,
            FirstName = actor?.FirstName ?? string.Empty,
            LastName = actor?.LastName ?? string.Empty,
            LanguageCode = actor?.LanguageCode ?? string.Empty
        };
    }

    /// <summary>
    /// Builds the owned-bot HTML help text describing available features, the account-test title and public Telegram commands.
    /// </summary>
    /// <param name="credUser">
    /// Shared credentials profile of the owned-bot user requesting help. A null or non-colleague profile receives the
    /// regular-user capability text; active colleagues receive the additional colleague section.
    /// </param>
    /// <returns>
    /// Telegram-safe static HTML containing the role label, feature descriptions, command syntax, and examples. The
    /// caller may send it to owned-bot users with <see cref="ParseMode.Html"/>; no secret or wallet value is included.
    /// </returns>
    /// <remarks>
    /// The command section mirrors the owned command menu configured at runtime. Tenant storefronts use their own help
    /// and must not expose the owned-only <c>/refresh</c> alias or colleague account commands.
    /// </remarks>
    /// <example><code>var helpText = BuildBotCapabilitiesMessage(credUser);</code></example>
    private static string BuildBotCapabilitiesMessage(CredUser credUser)
    {
        var roleText = credUser?.IsColleague == true ? "همکار" : "کاربر عادی";
        var builder = new StringBuilder();

        builder.AppendLine("📌 <b>قابلیت‌های مهم ربات</b>");
        builder.AppendLine();
        builder.AppendLine($"نوع حساب شما: <code>{Html(roleText)}</code>");
        builder.AppendLine();
        builder.AppendLine("با این ربات می‌توانید:");
        builder.AppendLine();
        builder.AppendLine("🛒 <b>خرید اکانت</b>");
        builder.AppendLine("انتخاب سرویس نت عادی، نت ملی یا نامحدود با مصرف منصفانه، تعداد اکانت و ثبت کامنت اختصاصی.");
        builder.AppendLine();
        builder.AppendLine("📋 <b>تعرفه‌های داینامیک</b>");
        builder.AppendLine("تعرفه‌ها همیشه بر اساس نوع حساب شما، یعنی کاربر عادی یا همکار، نمایش داده می‌شود.");
        builder.AppendLine();
        builder.AppendLine("👤 <b>مدیریت اکانت‌ها</b>");
        builder.AppendLine("مشاهده همه اکانت‌ها، صفحه‌بندی، جستجو، دیدن جزئیات، تمدید، حذف تکی و تغییر لینک.");
        builder.AppendLine();
        builder.AppendLine("🔎 <b>جستجوی سریع</b>");
        builder.AppendLine("جستجو با نام اکانت، بخشی از کامنت یا UUID کامل کانفیگ.");
        builder.AppendLine();
        builder.AppendLine("🔁 <b>تمدید و تغییر لینک</b>");
        builder.AppendLine("تمدید با پلن‌های فعال ربات، تمدید مستقیم از پیام هشدار انقضا و ساخت لینک جدید در صورت لو رفتن اطلاعات اکانت.");
        builder.AppendLine();
        builder.AppendLine("⏰ <b>هشدار انقضا</b>");
        builder.AppendLine("برای اکانت‌های قابل تمدید، ۷ روز، ۳ روز و ۱ روز قبل از انقضا پیام یادآوری همراه با دکمه تمدید ارسال می‌شود.");
        builder.AppendLine();
        builder.AppendLine("🧹 <b>حذف اکانت‌های منقضی</b>");
        builder.AppendLine("نمایش و حذف یکجای اکانت‌هایی که حجم یا زمان آن‌ها تمام شده است.");
        builder.AppendLine();
        builder.AppendLine("💰 <b>شارژ حساب</b>");
        builder.AppendLine("شارژ کیف پول از درگاه ریالی HooshPay یا پرداخت ارز دیجیتال، با ثبت و بررسی وضعیت پرداخت.");
        builder.AppendLine();
        builder.AppendLine("🌟 <b>اکانت تست</b>");
        builder.AppendLine("دریافت تست دوره‌ای برای بررسی کیفیت سرویس‌ها، در صورت داشتن شرایط.");

        if (credUser?.IsColleague == true)
        {
            builder.AppendLine();
            builder.AppendLine("💎 <b>امکانات همکاران</b>");
            builder.AppendLine("قیمت همکار، ساخت چند اکانت در یک سفارش و دسترسی سریع به اکانت‌ها با شماره اکانت.");
            builder.AppendLine("فعالسازی ربات فروشگاهی اختصاصی، خرید و تمدید مستقیم با HooshPay، ارز دیجیتال یا کارت‌به‌کارت همکار.");
            builder.AppendLine("مدیریت آموزش‌های فروشگاه، پیام عمومی فقط به مشتریان همان tenant، گزارش سفارش‌ها، آمار روزانه و ثبت سود یا کسر هزینه در ledger.");
        }
        else
        {
            builder.AppendLine();
            builder.AppendLine("🤝 <b>درخواست همکاری</b>");
            builder.AppendLine("اگر فروش هفتگی شما به حد نصاب برسد، می‌توانید از بخش مدیریت اکانت درخواست همکاری ثبت کنید.");
        }

        builder.AppendLine();
        builder.AppendLine("📋 <b>دستورهای عمومی و اکانت</b>");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/start</code>");
        builder.AppendLine("شروع مجدد ربات، پاک کردن وضعیت موقت کاربر و برگشت به منوی اصلی.");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/refresh</code>");
        builder.AppendLine("تازه‌سازی ربات، پاک کردن وضعیت موقت و برگشت به منوی اصلی؛ با همان رفتار دستور /start.");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/renew_EMAIL</code>");
        builder.AppendLine("شروع تمدید اکانت با نام اکانت یا همان ایمیل.");
        builder.AppendLine("مثال:");
        builder.AppendLine("<code>/renew_vniaccXXXXX</code>");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/enable_EMAIL</code>");
        builder.AppendLine("فعال کردن اکانت با نام اکانت یا ایمیل.");
        builder.AppendLine("ابتدا از پنل نسخه ۳ انجام می‌شود و در صورت نیاز مسیر قدیمی نسخه ۲ بررسی می‌شود.");
        builder.AppendLine("مثال:");
        builder.AppendLine("<code>/enable_vniaccXXXXX</code>");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/disable_EMAIL</code>");
        builder.AppendLine("غیرفعال کردن اکانت با نام اکانت یا ایمیل.");
        builder.AppendLine("ابتدا از پنل نسخه ۳ انجام می‌شود و در صورت نیاز مسیر قدیمی نسخه ۲ بررسی می‌شود.");
        builder.AppendLine("مثال:");
        builder.AppendLine("<code>/disable_vniaccXXXXX</code>");
        builder.AppendLine();
        builder.AppendLine("🔹 <code>/account_NUMBER</code>");
        builder.AppendLine("جستجوی اکانت همکار بر اساس شماره اکانت.");
        builder.AppendLine("این دستور فقط برای همکاران فعال است.");
        builder.AppendLine("مثال:");
        builder.AppendLine("<code>/account_34</code>");
        builder.AppendLine();
        builder.AppendLine("همچنین می‌توانید فقط عدد اکانت را بدون پیشوند ارسال کنید:");
        builder.AppendLine("<code>34</code>");
        builder.AppendLine();
        builder.AppendLine("برای شروع، از دکمه‌های پایین صفحه استفاده کنید.");
        return builder.ToString();
    }

    private static string Html(string value)
    {
        return System.Net.WebUtility.HtmlEncode(value ?? string.Empty);
    }

    /// <summary>
    /// Builds enabled owned-wallet payment methods for an owned-bot wallet charge.
    /// </summary>
    /// <returns>
    /// A one-time reply keyboard containing one readable row per enabled instant gateway, including its fee percentage.
    /// </returns>
    /// <remarks>
    /// Every provider is read from the live global snapshot. Tetraminator remains visible for manually entered amounts
    /// below its provider minimum whenever enabled; the selection handler explains the minimum without calling its API.
    /// </remarks>
    private ReplyKeyboardMarkup BuildChargePaymentMethodKeyboard()
    {
        var rows = new List<KeyboardButton[]>();
        var snapshot = _gatewayAvailability.Snapshot;
        if (snapshot.IsEnabled(PaymentGateway.HooshPay))
            rows.Add(new[] { new KeyboardButton(HooshPayGatewayAction) });
        if (snapshot.IsEnabled(PaymentGateway.Tetraminator))
            rows.Add(new[] { new KeyboardButton(TetraminatorGatewayAction) });
        if (snapshot.IsEnabled(PaymentGateway.UniquePay))
            rows.Add(new[] { new KeyboardButton(UniquePayGatewayAction) });
        if (snapshot.IsEnabled(PaymentGateway.AtlasPay))
            rows.Add(new[] { new KeyboardButton(AtlasPayGatewayAction) });
        if (snapshot.IsEnabled(PaymentGateway.NowPayments))
            rows.Add(new[] { new KeyboardButton(CryptoGatewayAction) });

        return new ReplyKeyboardMarkup(rows)
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    /// <summary>
    /// Builds the customer-facing list of currently enabled owned-wallet gateways and their fee policies.
    /// </summary>
    /// <returns>
    /// HTML-formatted lines for every gateway enabled in the live global snapshot. The list may be empty when an
    /// operator disables all platform gateways.
    /// </returns>
    /// <remarks>
    /// This text is informational only. Invoice creation methods independently recheck their gateway switches so
    /// stale Telegram keyboards or persisted conversation state cannot bypass an operator disablement.
    /// </remarks>
    private string BuildActiveChargeGatewaySummary()
    {
        var lines = new List<string>();
        var snapshot = _gatewayAvailability.Snapshot;
        if (snapshot.IsEnabled(PaymentGateway.HooshPay))
            lines.Add("💳 هوش‌پی: <b>کارمزد ۱۵٪</b>");
        if (snapshot.IsEnabled(PaymentGateway.Tetraminator))
            lines.Add("💳 تترامیناتور: <b>کارمزد ۱۲٪</b>");
        if (snapshot.IsEnabled(PaymentGateway.UniquePay))
            lines.Add("💳 یونیک‌پی: <b>کارمزد ۱۲٪</b>");
        if (snapshot.IsEnabled(PaymentGateway.AtlasPay))
            lines.Add("💳 اطلس‌پی: <b>مبلغ نهایی در فاکتور نمایش داده می‌شود</b>");
        if (snapshot.IsEnabled(PaymentGateway.NowPayments))
            lines.Add("🪙 ارز دیجیتال: <b>کارمزد ۰٪</b>");
        if (lines.Count == 0)
            lines.Add("⛔️ در حال حاضر هیچ درگاه آنلاینی فعال نیست.");
        return string.Join("\n", lines);
    }

    /// <summary>
    /// Matches a current fee-bearing gateway button while preserving compatibility with already-issued legacy keyboards.
    /// </summary>
    /// <param name="input">Incoming owned-bot reply-keyboard text; it may be empty for non-text updates.</param>
    /// <param name="currentLabel">Current instant-gateway label, including its displayed fee percentage and rial marker.</param>
    /// <param name="acceptedLegacyLabels">
    /// Zero or more previously shipped button labels accepted only so keyboards already delivered to customers keep
    /// routing correctly after a label change. Ordering is irrelevant and duplicate values are harmless.
    /// </param>
    /// <returns><c>true</c> when the trimmed input equals the current label or any accepted legacy label; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// The selected label controls routing only. Actual payment amount and provider settlement continue to come from
    /// the persisted wallet-charge state and provider response, never from Telegram button text.
    ///
    /// Telegram reply keyboards are one-time and already issued to customers, so every label that gained the
    /// <c>ریالی</c> marker also passes its pre-marker wording here. Without that alias a customer who received the
    /// payment-method keyboard before a label change could press the older button and be routed to "unknown" text.
    /// </remarks>
    /// <example>
    /// <code>
    /// // A keyboard issued after the rial marker was added, plus the caption issued before it.
    /// if (IsGatewayAction(message.Text, HooshPayGatewayAction, "⚡ هوش‌پی آنی | کارمزد ۱۵٪", "درگاه ریالی هوش‌پی"))
    /// {
    ///     user.PaymentMethod = "hooshpay";
    /// }
    /// </code>
    /// </example>
    private static bool IsGatewayAction(string input, string currentLabel, params string[] acceptedLegacyLabels)
    {
        var normalized = input?.Trim();
        if (string.Equals(normalized, currentLabel, StringComparison.Ordinal))
            return true;

        // Alias comparison stays case-sensitive and ordinal because these are Persian display labels, not identifiers.
        foreach (var legacyLabel in acceptedLegacyLabels)
        {
            if (string.Equals(normalized, legacyLabel, StringComparison.Ordinal))
                return true;
        }

        return false;
    }

    /// <summary>
    /// Creates and persists a HooshPay invoice for an owned-bot wallet charge when the gateway is globally enabled.
    /// </summary>
    /// <param name="message">
    /// Owned-bot customer message whose Telegram chat receives the invoice or the unavailable-gateway notice.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials-database wallet owner identified by the Telegram user id on the incoming update.
    /// </param>
    /// <param name="user">
    /// Persisted owned-bot charge state containing the customer-entered amount in Iranian toman.
    /// </param>
    /// <param name="cancellationToken">
    /// Cancellation token propagated to users.db, HooshPay HTTP, and Telegram operations.
    /// </param>
    /// <remarks>
    /// The global switch and HooshPay's inclusive 50,000 through 1,000,000 toman range are checked before creating a
    /// local payment row or calling the provider. Invalid persisted or crafted state returns to payment-method
    /// selection without provider contact. Disabling new invoices does not affect existing inquiry or settlement.
    /// </remarks>
    /// <returns>A task completing after invoice creation and its payment link, or a validation/provider failure reply.</returns>
    private async Task CreateHooshPayWalletChargeAsync(
        Message message,
        CredUser credUser,
        User user,
        CancellationToken cancellationToken)
    {
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay))
        {
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "درگاه هوش‌پی در حال حاضر غیرفعال است. لطفاً از درگاه‌های فعال استفاده کنید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            return;
        }

        var amount = long.TryParse(user.ConfigLink, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsedAmount)
            ? parsedAmount
            : 0;
        if (!HooshPayAmountPolicy.IsValid(amount))
        {
            user.LastStep = "payment_method_selection";
            user.Flow = "charge";
            user.PaymentMethod = string.Empty;
            await _state.SaveUserStatus(user);
            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: HooshPayAmountPolicy.BuildUserMessage(),
                replyMarkup: BuildChargePaymentMethodKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        var payment = HooshPayPaymentInfo.CreateWalletCharge(
            credUser.TelegramUserId,
            amount,
            _appConfig.HooshPayIpnUrl,
            CurrentHooshPayReturnUrl,
            message.Chat.Id);

        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);

        try
        {
            payment.RawRequestJson = JsonConvert.SerializeObject(new
            {
                amount,
                fee_mode = HooshPayFeeModes.Buyer,
                order_id = payment.OrderId,
                callback_url = _appConfig.HooshPayIpnUrl,
                return_url = CurrentHooshPayReturnUrl
            });

            Console.WriteLine($"[HooshPay] Creating invoice for user={credUser.TelegramUserId}, amount={amount}, orderId={payment.OrderId}, feeMode={HooshPayFeeModes.Buyer}");

            var invoice = await _hooshPay.CreateInvoiceAsync(
                amount,
                payment.OrderId,
                $"Wallet charge {payment.OrderId}",
                _appConfig.HooshPayIpnUrl,
                CurrentHooshPayReturnUrl,
                cancellationToken);

            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            if (invoice?.data == null)
                throw new InvalidOperationException("HooshPay invoice response did not contain data.");

            payment.Apply(invoice.data);
            await _workflow.SaveAsync(cancellationToken);

            var msg = await GetHooshPayPaymentMessage(credUser, payment);
            var inlineKeyboardMarkup = new InlineKeyboardMarkup(new[]
            {
                new[]
                {
                    InlineKeyboardButton.WithUrl(text: "پرداخت آنلاین", url: payment.PaymentUrl)
                },
                new[]
                {
                    InlineKeyboardButton.WithCallbackData(text: "بررسی وضعیت", callbackData: $"hpchk_{payment.Id}")
                }
            });

            Message latestMsg;
            if (!string.IsNullOrWhiteSpace(payment.PaymentUrl))
            {
                using var qrStream = new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(payment.PaymentUrl, 200));
                latestMsg = await ActiveBotClient.SendPhoto(
                    message.Chat.Id,
                    InputFile.FromStream(qrStream),
                    caption: msg,
                    parseMode: ParseMode.Html,
                    replyMarkup: inlineKeyboardMarkup,
                    cancellationToken: cancellationToken);
            }
            else
            {
                latestMsg = await ActiveBotClient.CustomSendTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: msg,
                    replyMarkup: inlineKeyboardMarkup,
                    parseMode: ParseMode.Html,
                    cancellationToken: cancellationToken);
            }

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "منوی اصلی",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);

            if (latestMsg != null)
                payment.TelMsgId = latestMsg.MessageId;

            await _workflow.SaveAsync(cancellationToken);
        }
        catch (HooshPayApiException ex)
        {
            Console.WriteLine("[HooshPay] API exception while creating invoice:");
            Console.WriteLine(ex.ToString());

            _logger.LogWarning(
                ex,
                "HooshPay invoice creation was rejected. botId={BotId}, userId={UserId}, chatId={ChatId}, orderId={OrderId}, amountToman={AmountToman}, statusCode={StatusCode}",
                BotContextAccessor.CurrentBotId,
                credUser.TelegramUserId,
                message.Chat.Id,
                payment.OrderId,
                amount,
                ex.StatusCode);

            payment.ErrorCode = ex.StatusCode.ToString(CultureInfo.InvariantCulture);
            payment.ErrorMessage = ex.Message;
            payment.RawResponseJson = ex.ResponseBody;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: BuildHooshPayInvoiceCreationFailureText(ex),
                parseMode: ParseMode.Html,
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            Console.WriteLine("[HooshPay] Unexpected exception while creating invoice:");
            Console.WriteLine(ex.ToString());

            _logger.LogError(
                ex,
                "HooshPay invoice creation failed unexpectedly. botId={BotId}, userId={UserId}, chatId={ChatId}, orderId={OrderId}, amountToman={AmountToman}",
                BotContextAccessor.CurrentBotId,
                credUser.TelegramUserId,
                message.Chat.Id,
                payment.OrderId,
                amount);

            payment.ErrorMessage = ex.Message;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await ActiveBotClient.CustomSendTextMessageAsync(
                chatId: message.Chat.Id,
                text: "ایجاد پرداخت ریالی HooshPay ناموفق بود. جزئیات خطا در ترمینال ثبت شد.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
    }

    private async Task CreateAtlasPayWalletChargeAsync(Message message, CredUser credUser, User user, CancellationToken cancellationToken)
    {
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay))
        {
            await ActiveBotClient.SendMessage(message.Chat.Id, "درگاه اطلس‌پی در حال حاضر غیرفعال است.",
                replyMarkup: BuildChargePaymentMethodKeyboard(), cancellationToken: cancellationToken);
            return;
        }
        var amount = long.TryParse(user.ConfigLink, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed) ? parsed : 0;
        if (amount <= 0)
        {
            await ActiveBotClient.SendMessage(message.Chat.Id, "مبلغ پرداخت معتبر نیست.",
                replyMarkup: BuildChargePaymentMethodKeyboard(), cancellationToken: cancellationToken);
            return;
        }
        await _state.ClearUserStatus(user);
        var payment = AtlasPayPaymentInfo.CreateWalletCharge(credUser.TelegramUserId, message.Chat.Id, amount);
        payment.BotId = BotContextAccessor.CurrentBotId;
        payment.BotUsername = CurrentBot?.Username;
        payment.BeginCreationAttempt(DateTime.UtcNow);
        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);
        try
        {
            var created = await _atlasPay.CreateOrderAsync(payment.MerchantOrderRef, payment.BaseAmountToman,
                payment.TelegramUserId, cancellationToken);
            payment.ApplyCreate(created, DateTime.UtcNow,
                DateTime.UtcNow.AddSeconds(Math.Clamp(_appConfig.AtlasPayReconciliationIntervalSeconds, 10, 3600)));
            await _workflow.SaveAsync(cancellationToken);
            var deadline = payment.PaymentDeadlineAtUtc?.ToString("yyyy-MM-dd HH:mm 'UTC'", CultureInfo.InvariantCulture) ?? "نامشخص";
            var text = "⚠️ <b>پیش از پرداخت لطفاً موارد زیر را بررسی کنید:</b>\n\n" +
                       $"💰 مبلغ دقیق قابل پرداخت: <code>{Html(payment.TotalAmountToman!.Value.FormatCurrency())}</code>\n" +
                       $"⏱ مهلت پرداخت: <code>{Html(deadline)}</code>\n" +
                       $"🔖 شماره پیگیری: <code>{Html(payment.TrackingCode)}</code>\n\n" +
                       "مبلغ را دقیقاً مطابق عدد بالا پرداخت کنید. شارژ کیف پول فقط پس از استعلام رسمی اطلس‌پی انجام می‌شود.";
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithUrl("💳 پرداخت با اطلس‌پی | ریالی", payment.CustomerStartLink) },
                new[] { InlineKeyboardButton.WithCallbackData("🔄 بررسی وضعیت پرداخت", $"apchk_{payment.Id}") }
            });
            var sent = await ActiveBotClient.SendMessage(message.Chat.Id, text, parseMode: ParseMode.Html,
                replyMarkup: keyboard, cancellationToken: cancellationToken);
            payment.TelMsgId = sent.MessageId;
            await _workflow.SaveAsync(cancellationToken);
            await ActiveBotClient.SendMessage(message.Chat.Id, "منوی اصلی", replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            var definitive = AtlasPay.IsDefinitiveCreateFailure(ex);
            var code = ex is AtlasPayApiException api ? (api.StatusCode > 0 ? api.StatusCode.ToString(CultureInfo.InvariantCulture) : "ambiguous") : "ambiguous";
            payment.RecordCreationFailure(definitive, code, DateTime.UtcNow);
            payment.ErrorCode = code;
            payment.ErrorMessage = definitive ? "AtlasPay rejected order creation." : "AtlasPay create outcome is ambiguous; automatic retry is disabled.";
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogWarning("AtlasPay create attempt ended without a usable invoice. paymentId={PaymentId}, botId={BotId}, definitive={Definitive}, errorType={ErrorType}",
                payment.Id, payment.BotId, definitive, ex.GetType().Name);
            await ActiveBotClient.SendMessage(message.Chat.Id,
                definitive ? "ساخت فاکتور اطلس‌پی ناموفق بود. لطفاً از درگاه دیگری استفاده کنید."
                    : "نتیجه ساخت فاکتور اطلس‌پی نامشخص است. برای جلوگیری از صدور فاکتور تکراری، درخواست ساخت دوباره ارسال نخواهد شد و موضوع نیازمند بررسی است.",
                replyMarkup: MainReplyMarkupKeyboardFa(), cancellationToken: cancellationToken);
        }
    }

    private async Task ProcessAtlasPayPaymentCallbackAsync(CallbackQuery callbackQuery, CancellationToken cancellationToken)
    {
        var value = callbackQuery.Data?["apchk_".Length..];
        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var paymentId)) return;
        var payment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.AsNoTracking().FirstOrDefaultAsync(x =>
            x.Id == paymentId && x.TelegramUserId == callbackQuery.From.Id && x.BotId == BotContextAccessor.CurrentBotId, cancellationToken));
        if (payment == null)
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "فاکتور اطلس‌پی پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }
        var isTenant = string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.TenantOrder, StringComparison.OrdinalIgnoreCase);
        if (isTenant)
        {
            var linked = await _workflow.ReadAsync(async db => await db.TenantBotOrders.AsNoTracking().AnyAsync(x =>
                x.Id == payment.TenantBotOrderId && x.AtlasPayPaymentInfoId == payment.Id &&
                x.CustomerTelegramUserId == callbackQuery.From.Id && x.TenantBotId == BotContextAccessor.CurrentBotId, cancellationToken));
            if (!linked)
            {
                await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "فاکتور اطلس‌پی با این سفارش تطبیق ندارد.", showAlert: true, cancellationToken: cancellationToken);
                return;
            }
        }
        else if (!string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.WalletCharge, StringComparison.OrdinalIgnoreCase))
            return;

        // Provider-traffic guard: AtlasPay documents polling and provides no server callback, so every customer check is
        // a real provider request. The cooldown is measured from the last inquiry, which the background reconciliation
        // worker also writes, so pressing the button cannot bypass the provider rate limit. While it is active no
        // provider call is made and no financial state changes.
        if (AtlasPayManualCheckPolicy.IsWithinCooldown(payment, _appConfig.AtlasPayManualCheckMinIntervalSeconds,
                DateTime.UtcNow, out var waitSeconds))
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id,
                $"لطفاً {waitSeconds} ثانیه دیگر دوباره بررسی کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "در حال استعلام رسمی از اطلس‌پی...", cancellationToken: cancellationToken);
        var result = await _atlasPayReconciliation.ReconcilePaymentAsync(payment.Id, "customer-check", useVerify: true, cancellationToken);
        var latest = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.AsNoTracking().FirstAsync(x => x.Id == payment.Id, cancellationToken));
        string text;
        if (result.Status == NowPaymentsSettlementStatus.Applied) text = isTenant ? "✅ پرداخت اطلس‌پی تایید و سفارش شما پردازش شد." : "✅ پرداخت اطلس‌پی تایید و کیف پول شما شارژ شد.";
        else if (result.Status == NowPaymentsSettlementStatus.AlreadyAdded) text = "این پرداخت قبلاً تایید و به کیف پول شما اضافه شده است.";
        else if (latest.RequiresManualDelivery || latest.SettlementState == AtlasPaySettlementStates.ManualReview)
            text = "⚠️ پرداخت شما ثبت شده اما به دلیل مغایرت مبلغ نیاز به بررسی دستی دارد.";
        else if (AtlasPayStatuses.IsTerminal(latest.ProviderStatus))
            text = latest.ProviderStatus == "expired" ? "مهلت این پرداخت منقضی شده است." : latest.ProviderStatus == "cancelled" ? "این پرداخت لغو شده است." : "این پرداخت توسط اطلس‌پی رد شده است.";
        else text = "پرداخت هنوز تایید نشده است.";
        await ActiveBotClient.SendMessage(callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id, text,
            replyMarkup: !AtlasPayStatuses.IsTerminal(latest.ProviderStatus) && latest.SettlementState != AtlasPaySettlementStates.ManualReview && !latest.IsAddedToBalance
                ? new InlineKeyboardMarkup(new[] { new[] { InlineKeyboardButton.WithCallbackData("بررسی مجدد", $"apchk_{payment.Id}") } }) : MainReplyMarkupKeyboardFa(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Creates and persists one UniquePay invoice for an owned-bot wallet charge.
    /// </summary>
    /// <param name="message">Owned-bot customer message whose chat receives the hosted invoice and check button.</param>
    /// <param name="credUser">Shared credentials profile whose wallet will be credited after authoritative verification.</param>
    /// <param name="user">Persisted charge state containing the requested base amount in Iranian toman.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, the single create request, and Telegram delivery.</param>
    /// <remarks>
    /// The live global switch and UniquePay's exclusive minimum (greater than 50,000 toman) are rechecked before any
    /// row or provider request is created. Invalid state returns to payment-method selection without persistence or
    /// HTTP. For valid amounts the local merchant hash and one-attempt creation reservation are persisted first,
    /// creation is attempted once, and an ambiguous failure remains locked to read-only provider inquiry. The
    /// invoice-specific unsigned callback and browser return only
    /// trigger authoritative inquiry. The displayed 12% is the gateway fee; UniquePay decides whether the
    /// <c>user</c>/<c>buyer</c> or owner bears it, while only the immutable local base amount can be credited.
    /// </remarks>
    /// <returns>A task completing after durable invoice preparation and the non-retried provider request and customer response.</returns>
    private async Task CreateUniquePayWalletChargeAsync(
        Message message,
        CredUser credUser,
        User user,
        CancellationToken cancellationToken)
    {
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay))
        {
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                "درگاه یونیک‌پی در حال حاضر غیرفعال است.",
                replyMarkup: BuildChargePaymentMethodKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        var amount = long.TryParse(user.ConfigLink, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsedAmount)
            ? parsedAmount
            : 0;
        if (!UniquePayAmountPolicy.IsValid(amount))
        {
            user.LastStep = "payment_method_selection";
            user.Flow = "charge";
            user.PaymentMethod = string.Empty;
            await _state.SaveUserStatus(user);
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                UniquePayAmountPolicy.BuildUserMessage(),
                replyMarkup: BuildChargePaymentMethodKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        await _state.ClearUserStatus(user);
        var payment = UniquePayPaymentInfo.CreateWalletCharge(
            credUser.TelegramUserId,
            message.Chat.Id,
            amount,
            _appConfig.UniquePayFeePercent);
        var returnUrl = BuildUniquePayReturnUrl(payment.HashId);
        var callbackUrl = BuildUniquePayCallbackUrl(payment.HashId);
        payment.RawRequestJson = JsonConvert.SerializeObject(new
        {
            hashId = payment.HashId,
            orderId = payment.HashId,
            amount,
            redirectUrl = returnUrl,
            callbackUrl
        });
        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);

        try
        {
            var invoice = await _uniquePay.CreateInvoiceAsync(
                payment.HashId,
                payment.BaseAmountToman,
                returnUrl,
                callbackUrl,
                cancellationToken);
            payment.Apply(invoice);
            payment.NextInquiryAtUtc = DateTime.UtcNow.AddSeconds(Math.Clamp(
                _appConfig.UniquePayReconciliationIntervalSeconds,
                10,
                3600));
            await _workflow.SaveAsync(cancellationToken);

            var text = "✅ <b>فاکتور یونیک‌پی ساخته شد</b>\n\n" +
                       $"💰 مبلغ شارژ کیف پول: <code>{Html(payment.BaseAmountToman.FormatCurrency())}</code>\n" +
                       "💸 کارمزد درگاه: <code>۱۲٪</code>\n" +
                       "💳 مبلغ نهایی مطابق تنظیمات کارمزد، در صفحه رسمی یونیک‌پی نمایش داده می‌شود.\n" +
                       $"🧾 شناسه فاکتور: <code>{Html(payment.RefId)}</code>\n\n" +
                       "پس از پرداخت، دکمه بررسی وضعیت را بزنید. شارژ فقط بعد از استعلام رسمی یونیک‌پی انجام می‌شود.";
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithUrl("پرداخت با یونیک‌پی | ریالی", payment.PaymentLink) },
                new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت", $"upchk_{payment.Id}") }
            });
            var sent = await ActiveBotClient.SendMessage(
                message.Chat.Id,
                text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
            payment.TelMsgId = sent.MessageId;
            await _workflow.SaveAsync(cancellationToken);
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                "منوی اصلی",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            var definitiveFailure = UniquePay.IsDefinitiveCreateFailure(ex);
            var creationErrorCode = ex is UniquePayApiException apiException
                ? apiException.StatusCode.ToString(CultureInfo.InvariantCulture)
                : "create_failed";
            payment.RecordCreationFailure(
                definitiveFailure,
                creationErrorCode,
                DateTime.UtcNow);
            payment.ErrorCode = creationErrorCode;
            payment.ErrorMessage = ex.Message;
            payment.RawResponseJson = ex is UniquePayApiException providerError
                ? providerError.ResponseBody
                : payment.RawResponseJson;
            payment.PaymentStatus = definitiveFailure ? UniquePayStatuses.Failed : UniquePayStatuses.Pending;
            payment.NextInquiryAtUtc = definitiveFailure
                ? null
                : DateTime.UtcNow.AddSeconds(Math.Clamp(
                    _appConfig.UniquePayReconciliationIntervalSeconds,
                    10,
                    3600));
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            // Merchant hashes, response bodies, tokens, and request headers are excluded from this operational event.
            _logger.LogError(
                ex,
                "UniquePay invoice creation failed. botId={BotId}, userId={UserId}, paymentId={PaymentId}, amountToman={AmountToman}, providerCode={ProviderCode}",
                BotContextAccessor.CurrentBotId,
                credUser.TelegramUserId,
                payment.Id,
                amount,
                payment.ErrorCode);
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                definitiveFailure
                    ? "ساخت فاکتور یونیک‌پی ناموفق بود. مشکل برای مدیر سیستم ثبت شد؛ لطفاً از درگاه دیگری استفاده کنید."
                    : "نتیجه ساخت فاکتور یونیک‌پی نامشخص است. وضعیت آن به‌صورت خودکار و فقط با استعلام امن بررسی می‌شود و درخواست ساخت دوباره ارسال نخواهد شد.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Rechecks an owned UniquePay invoice selected by its customer and applies wallet settlement when verified.
    /// </summary>
    /// <param name="callbackQuery">Customer callback containing the internal users.db payment id.</param>
    /// <param name="cancellationToken">Cancellation token for inquiry, settlement, and Telegram replies.</param>
    /// <returns>A task that completes after the official inquiry result and safe retry controls are sent.</returns>
    /// <remarks>
    /// The callback payer must own the local row. The global creation switch is deliberately ignored so payments
    /// issued before an operator disablement remain settleable.
    /// </remarks>
    private async Task ProcessUniquePayPaymentCallbackAsync(
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        var value = callbackQuery.Data?["upchk_".Length..];
        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var paymentId))
            return;
        var payment = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.Id == paymentId &&
                     x.TelegramUserId == callbackQuery.From.Id &&
                     x.PaymentPurpose == TenantBotPaymentPurposes.WalletCharge,
                cancellationToken));
        if (payment == null)
        {
            await SafeAnswerCallbackQueryAsync(
                callbackQuery.Id,
                "فاکتور یونیک‌پی پیدا نشد.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        await SafeAnswerCallbackQueryAsync(
            callbackQuery.Id,
            "در حال استعلام رسمی از یونیک‌پی...",
            cancellationToken: cancellationToken);
        var settlement = await _uniquePayReconciliation.ReconcilePaymentAsync(
            payment.Id,
            "customer-check",
            cancellationToken);
        var latest = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == payment.Id, cancellationToken));
        var text = settlement.Status == NowPaymentsSettlementStatus.Applied
            ? "✅ پرداخت یونیک‌پی تایید و کیف پول شما شارژ شد."
            : settlement.Status == NowPaymentsSettlementStatus.AlreadyAdded
                ? "این پرداخت قبلاً تایید و به کیف پول شما اضافه شده است."
                : string.Equals(latest?.PaymentStatus, UniquePayStatuses.Expired, StringComparison.Ordinal)
                    ? "مهلت این فاکتور یونیک‌پی منقضی شده و هیچ مبلغی به کیف پول اضافه نشد."
                    : string.Equals(latest?.PaymentStatus, UniquePayStatuses.Cancelled, StringComparison.Ordinal)
                        ? "این فاکتور یونیک‌پی لغو شده و هیچ مبلغی به کیف پول اضافه نشد."
                        : string.Equals(latest?.PaymentStatus, UniquePayStatuses.Failed, StringComparison.Ordinal)
                            ? "اطلاعات این پرداخت با پاسخ معتبر یونیک‌پی منطبق نبود؛ برای امنیت، شارژ انجام نشد."
                            : string.Equals(latest?.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal)
                                ? "پرداخت تایید شده اما تسویه محلی برای بررسی امن مدیر متوقف شده است؛ شارژ تکراری انجام نمی‌شود."
                                : "پرداخت هنوز به‌صورت معتبر تایید نشده است. کمی بعد دوباره بررسی کنید.";
        var canRetry = settlement.Status == NowPaymentsSettlementStatus.ProviderNotPaid &&
                       !UniquePayStatuses.IsTerminal(latest?.PaymentStatus) &&
                       !string.Equals(latest?.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal);
        await ActiveBotClient.SendMessage(
            callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
            text,
            replyMarkup: canRetry
                ? new InlineKeyboardMarkup(new[]
                {
                    new[] { InlineKeyboardButton.WithCallbackData("بررسی مجدد", $"upchk_{payment.Id}") }
                })
                : MainReplyMarkupKeyboardFa(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Adds the saved UniquePay merchant hash to the configured platform return endpoint.
    /// </summary>
    /// <param name="hashId">Persisted merchant hash used only to locate the local row before provider inquiry.</param>
    /// <returns>An absolute return URL preserving existing query parameters.</returns>
    private string BuildUniquePayReturnUrl(string hashId)
    {
        var builder = new UriBuilder(_appConfig.UniquePayReturnUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query)
            ? string.Empty
            : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "hashId=" + Uri.EscapeDataString(hashId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Adds the saved UniquePay merchant hash to the configured provider-notification endpoint.
    /// </summary>
    /// <param name="hashId">
    /// Persisted merchant hash used only to locate the owned-wallet invoice before an authoritative provider inquiry.
    /// It is not accepted as payment proof.
    /// </param>
    /// <returns>An absolute callback URL preserving configured query parameters.</returns>
    /// <remarks>
    /// UniquePay's bot-compatible create route calls this unsigned URL. The receiving controller ignores callback
    /// status and amount fields and settles only after <c>/api/check-invoice</c> passes every financial invariant.
    /// </remarks>
    /// <example>
    /// A configured <c>https://merchant.example/uniquepay-callback</c> becomes
    /// <c>https://merchant.example/uniquepay-callback?hashId=merchant-hash</c>.
    /// </example>
    private string BuildUniquePayCallbackUrl(string hashId)
    {
        var builder = new UriBuilder(_appConfig.UniquePayCallbackUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query)
            ? string.Empty
            : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "hashId=" + Uri.EscapeDataString(hashId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Creates and persists a Tetraminator invoice for an owned-bot wallet charge.
    /// </summary>
    /// <param name="message">Owned-bot customer message whose chat receives the invoice controls.</param>
    /// <param name="credUser">Shared wallet owner identified by Telegram user id.</param>
    /// <param name="user">Temporary charge flow state containing the selected amount in toman.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, provider, and Telegram operations.</param>
    /// <remarks>
    /// The non-idempotent provider create call runs once. A timeout is stored as a failed/ambiguous local row and is
    /// not retried automatically because Tetraminator does not accept a merchant idempotency key. The completed
    /// confirmation state is cleared before the provider request so tapping the old reply-keyboard command again does
    /// not create another invoice from the same owned-bot charge flow.
    /// </remarks>
    /// <returns>A task completing after durable invoice preparation, provider creation, and the customer response.</returns>
    private async Task CreateTetraminatorWalletChargeAsync(
        Message message,
        CredUser credUser,
        User user,
        CancellationToken cancellationToken)
    {
        var amount = Convert.ToInt64(user.ConfigLink, CultureInfo.InvariantCulture);
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator) ||
            amount < _appConfig.TetraminatorMinimumAmountToman)
        {
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator)
                    ? "درگاه تترامیناتور در حال حاضر غیرفعال است."
                    : $"حداقل مبلغ پرداخت با تترامیناتور {_appConfig.TetraminatorMinimumAmountToman.FormatCurrency()} است.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
            return;
        }

        // Consume the confirmed charge flow before the non-idempotent provider mutation. A failed or ambiguous create
        // remains auditable by its local payment row and cannot be silently repeated through the stale keyboard.
        await _state.ClearUserStatus(user);

        var payment = TetraminatorPaymentInfo.CreateWalletCharge(
            credUser.TelegramUserId,
            amount,
            _appConfig.TetraminatorCallbackUrl,
            message.Chat.Id);
        payment.CallbackUrl = BuildTetraminatorCallbackUrl(payment.OrderId);
        payment.RawRequestJson = JsonConvert.SerializeObject(new
        {
            price = amount,
            callback_url = payment.CallbackUrl,
            order_id = payment.OrderId
        });
        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);

        try
        {
            var invoice = await _tetraminator.CreateInvoiceAsync(amount, payment.CallbackUrl, cancellationToken);
            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.Apply(invoice);
            await _workflow.SaveAsync(cancellationToken);

            var text = "✅ <b>فاکتور تترامیناتور ساخته شد</b>\n\n" +
                       $"💰 مبلغ: <code>{Html(amount.FormatCurrency())}</code>\n" +
                       $"🧾 شناسه پرداخت: <code>{Html(payment.PayId)}</code>\n\n" +
                       "پس از پرداخت، دکمه بررسی وضعیت را بزنید. شارژ فقط بعد از تایید رسمی درگاه انجام می‌شود.";
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithUrl("پرداخت با تترامیناتور | ریالی", payment.PaymentLink) },
                new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت", $"tmchk_{payment.Id}") }
            });
            var sent = await ActiveBotClient.SendMessage(
                message.Chat.Id,
                text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
            payment.TelMsgId = sent.MessageId;
            await _workflow.SaveAsync(cancellationToken);
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                "منوی اصلی",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            payment.ErrorCode = ex is TetraminatorApiException apiException
                ? apiException.StatusCode.ToString(CultureInfo.InvariantCulture)
                : "create_failed";
            payment.ErrorMessage = ex.Message;
            payment.RawResponseJson = ex is TetraminatorApiException providerError ? providerError.ResponseBody : null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogError(
                ex,
                "Tetraminator invoice creation failed. botId={BotId}, userId={UserId}, paymentId={PaymentId}, amountToman={AmountToman}",
                BotContextAccessor.CurrentBotId,
                credUser.TelegramUserId,
                payment.Id,
                amount);
            await ActiveBotClient.SendMessage(
                message.Chat.Id,
                "ساخت فاکتور تترامیناتور ناموفق بود. لطفاً کمی بعد دوباره تلاش کنید.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Rechecks a Tetraminator invoice selected by its owned-customer callback and applies settlement when verified.
    /// </summary>
    /// <param name="callbackQuery">Customer callback containing the internal users.db payment id.</param>
    /// <param name="cancellationToken">Cancellation token for provider inquiry, wallet settlement, and Telegram replies.</param>
    /// <remarks>
    /// The callback user must own the payment row. The global enable switch is intentionally ignored so invoices
    /// created before an operator disables the gateway can still be settled.
    /// </remarks>
    private async Task ProcessTetraminatorPaymentCallbackAsync(
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        var value = callbackQuery.Data?["tmchk_".Length..];
        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var paymentId))
            return;
        var payment = await _workflow.ReadAsync(async db => await db.TetraminatorPaymentInfos.FirstOrDefaultAsync(
            x => x.Id == paymentId && x.TelegramUserId == callbackQuery.From.Id,
            cancellationToken));
        if (payment == null)
        {
            await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "فاکتور پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        await SafeAnswerCallbackQueryAsync(callbackQuery.Id, "در حال استعلام از تترامیناتور...", cancellationToken: cancellationToken);
        try
        {
            var verified = await RefreshTetraminatorPaymentAsync(payment, cancellationToken);
            if (!verified)
            {
                await ActiveBotClient.SendMessage(
                    callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                    payment.ErrorCode == "provider_not_paid"
                        ? $"پرداخت هنوز تایید نشده است.\nوضعیت: <code>{Html(payment.PaymentStatus)}</code>"
                        : "اطلاعات پرداخت با فاکتور محلی تطبیق نداشت و هیچ مبلغی به کیف پول اضافه نشد.",
                    parseMode: ParseMode.Html,
                    replyMarkup: new InlineKeyboardMarkup(new[] { new[] { InlineKeyboardButton.WithCallbackData("بررسی مجدد", $"tmchk_{payment.Id}") } }),
                    cancellationToken: cancellationToken);
                return;
            }

            var settlement = await _tetraminatorSettlementService.ApplyOfficialPaymentAsync(
                payment,
                "customer-check",
                callbackQuery.Message?.Chat.Id,
                cancellationToken);
            var resultText = settlement.Status == NowPaymentsSettlementStatus.Applied
                ? "✅ پرداخت تایید و کیف پول شما شارژ شد."
                : settlement.Status == NowPaymentsSettlementStatus.AlreadyAdded
                    ? "این پرداخت قبلاً تایید و به کیف پول شما اضافه شده است."
                    : "پرداخت تایید شد، اما اعمال موجودی کامل نشد. موضوع برای بررسی ثبت شد.";
            await ActiveBotClient.SendMessage(
                callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                resultText,
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Tetraminator customer inquiry failed. paymentId={PaymentId}, userId={UserId}", payment.Id, callbackQuery.From.Id);
            await ActiveBotClient.SendMessage(
                callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                "فعلاً امکان استعلام تترامیناتور وجود ندارد. کمی بعد دوباره تلاش کنید.",
                replyMarkup: new InlineKeyboardMarkup(new[] { new[] { InlineKeyboardButton.WithCallbackData("بررسی مجدد", $"tmchk_{payment.Id}") } }),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Performs an authoritative inquiry and persists a safe paid or mismatch result on the local payment row.
    /// </summary>
    /// <param name="payment">Tracked users.db payment containing a non-empty provider pay id.</param>
    /// <param name="cancellationToken">Cancellation token for provider and database work.</param>
    /// <returns><c>true</c> only when provider status, pay id, and amount all match.</returns>
    private async Task<bool> RefreshTetraminatorPaymentAsync(
        TetraminatorPaymentInfo payment,
        CancellationToken cancellationToken)
    {
        var inquiry = await _tetraminator.InquiryAsync(payment.PayId, cancellationToken);
        payment.RawResponseJson = JsonConvert.SerializeObject(inquiry);
        payment.Apply(inquiry);
        var verified = TetraminatorPaymentVerifier.IsVerifiedPaid(payment, inquiry, out var errorCode);
        payment.ErrorCode = errorCode;
        payment.ErrorMessage = verified ? null : errorCode;
        if (verified)
        {
            payment.PaymentStatus = TetraminatorStatuses.Paid;
            payment.PaidAtUtc ??= DateTime.UtcNow;
        }
        await _workflow.SaveAsync(cancellationToken);
        return verified;
    }

    /// <summary>
    /// Appends the local order id to the configured unsigned Tetraminator callback endpoint.
    /// </summary>
    /// <param name="orderId">Unique local order id used only to find the saved payment before provider inquiry.</param>
    /// <returns>An absolute callback URL whose existing query parameters are preserved.</returns>
    private string BuildTetraminatorCallbackUrl(string orderId)
    {
        var builder = new UriBuilder(_appConfig.TetraminatorCallbackUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query) ? string.Empty : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "order_id=" + Uri.EscapeDataString(orderId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Builds the customer-safe error message for a rejected HooshPay invoice request.
    /// </summary>
    /// <param name="exception">
    /// HooshPay API exception containing the HTTP status and provider response body. The raw body is parsed only for
    /// a user-safe provider message and is never inserted into Telegram unescaped.
    /// </param>
    /// <returns>
    /// Persian HTML-safe plain-text message that explains the provider rejection. Amount-limit responses also tell the
    /// customer to split the charge into multiple payments or use the crypto gateway.
    /// </returns>
    /// <remarks>
    /// Provider response text can be malformed, HTML-like, or unexpectedly long. This method truncates and escapes
    /// it before Telegram delivery while the complete raw payload remains stored on the local payment row and daily
    /// diagnostic file for administrators.
    /// </remarks>
    private static string BuildHooshPayInvoiceCreationFailureText(HooshPayApiException exception)
    {
        var providerMessage = ExtractHooshPayProviderMessage(exception?.ResponseBody);
        var safeDetails = string.IsNullOrWhiteSpace(providerMessage)
            ? string.Empty
            : $"\nجزئیات درگاه: <code>{Html(providerMessage)}</code>";

        if (IsHooshPayAmountLimitFailure(exception, providerMessage))
        {
            return "درگاه ریالی HooshPay این مبلغ را برای یک تراکنش نپذیرفت." +
                   safeDetails +
                   "\n\nلطفاً مبلغ را در چند تراکنش کوچک‌تر پرداخت کنید یا از درگاه ارز دیجیتال استفاده کنید.";
        }

        return "HooshPay درخواست پرداخت را رد کرد." + safeDetails +
               "\nلطفاً مبلغ یا اطلاعات پرداخت را بررسی کنید؛ در صورت تکرار، از درگاه ارز دیجیتال استفاده کنید.";
    }

    /// <summary>
    /// Extracts a compact provider message from a HooshPay JSON or plain-text error response.
    /// </summary>
    /// <param name="responseBody">Raw error response body returned by HooshPay; it may be JSON, plain text, or empty.</param>
    /// <returns>At most 300 characters of provider detail suitable for escaped Telegram display, or an empty string.</returns>
    /// <remarks>
    /// The response body is intentionally not trusted as HTML and must be escaped by the caller before display.
    /// </remarks>
    private static string ExtractHooshPayProviderMessage(string responseBody)
    {
        if (string.IsNullOrWhiteSpace(responseBody))
            return string.Empty;

        try
        {
            var token = JToken.Parse(responseBody);
            var message = token["message"]?.ToString()
                          ?? token["error"]?.ToString()
                          ?? token["errors"]?.ToString(Formatting.None);
            if (!string.IsNullOrWhiteSpace(message))
                return message.Length <= 300 ? message : message[..300] + "...";
        }
        catch (JsonException)
        {
            // A non-JSON gateway response is still useful after a conservative length limit is applied below.
        }

        var compact = responseBody.Trim();
        return compact.Length <= 300 ? compact : compact[..300] + "...";
    }

    /// <summary>
    /// Detects whether a rejected HooshPay request is likely caused by the provider's per-transaction amount limit.
    /// </summary>
    /// <param name="exception">HTTP-level HooshPay exception, when available.</param>
    /// <param name="providerMessage">Compact provider message parsed from the response body.</param>
    /// <returns><c>true</c> when the rejection indicates an amount, maximum, limit, or ceiling constraint.</returns>
    /// <remarks>
    /// HooshPay has returned validation responses with different wording over time, so the check combines validation
    /// status codes with conservative Persian and English message markers rather than relying on one exact string.
    /// </remarks>
    private static bool IsHooshPayAmountLimitFailure(HooshPayApiException exception, string providerMessage)
    {
        var text = string.Join(" ", exception?.ResponseBody ?? string.Empty, providerMessage ?? string.Empty);
        return exception?.StatusCode is 400 or 409 or 422 &&
               (text.Contains("amount", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("maximum", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("max", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("limit", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("سقف", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("مبلغ", StringComparison.OrdinalIgnoreCase) ||
                text.Contains("حداکثر", StringComparison.OrdinalIgnoreCase));
    }


    async Task<string> GetZipalPaymentMessage(CredUser credUser, bool isSuperAdmin, ZibalPaymentInfo zpi, string paymentLink)
    {
        var _credUser = await _credentialsDbContext.GetUserStatus(credUser);

        string text = string.Empty;
        if (!isSuperAdmin) text = "✅ درگاه پرداخت برای شما با موفقیت ایجاد شد.  \n";
        text += $"💵 مبلغ: {(zpi.Amount / 10).FormatCurrency()} \n";
        text += $"\u200F📅 تاریخ: {DateTime.Now.ConvertToHijriShamsi()} \n";
        text += $"‌🧾شماره سند: <code>{zpi.TrackId}</code>    \n";
        if (isSuperAdmin == true) text += $"\u200F 🧾شماره سند: {zpi.Id} \n";
        text += $"\u200F ℹ️  آیدی عددی خریدار: <code>{credUser.TelegramUserId}</code> \n";

        text += $"\u200F لطفاً برای پرداخت از لینک زیر اقدام فرمایید. \n";
        text += $"\u200F <a href=\"{paymentLink}\">🏧   برای پرداخت کلیک کنید.</a> \n";
        if (!isSuperAdmin)
            text += "❗️نکات زیر را حتماً مد نظر قرار دهید:" + "\n" + "2. بعد از تکمیل پرداخت روی گزینه پرداخت کردم بزنید تا حساب شما شارژ شود." + "\n" + "3. ساعت 12 شب تا  بامداد1 سیکل تسویه بانک مرکزی است و در این مدت امکان پرداخت وجود ندارد." + "\n" + "4. نیم ساعت پس از ایجاد لینک پرداخت، نشست منقضی میشود و امکان پرداخت آن وجود ندارد. لذا سعی کنید بلافاصله بعد از ایجاد درگاه، آنرا پرداخت کنید." + "\n" + "5. هنگام پرداخت VPN خود را خاموش کنید." + "\n" + "6. در صورت بروز هرگونه مشکل با آیدی پشتیبانی(@vpnetiran_admin) در تماس باشید." + "\n";

        return text;
    }

    async Task<string> GetHooshPayPaymentMessage(CredUser credUser, HooshPayPaymentInfo payment)
    {
        await _credentialsDbContext.GetUserStatus(credUser);

        var paymentUrl = System.Net.WebUtility.HtmlEncode(payment.PaymentUrl ?? "");
        var orderId = System.Net.WebUtility.HtmlEncode(payment.OrderId ?? "");
        var invoiceUid = System.Net.WebUtility.HtmlEncode(payment.InvoiceUid ?? "");
        var trackingCode = System.Net.WebUtility.HtmlEncode(payment.TrackingCode ?? "");
        var payableAmount = payment.PayableAmountToman > 0
            ? payment.PayableAmountToman
            : payment.AmountToman + payment.FeeAmountToman;
        var payableAmountRial = payableAmount * 10;

        string text = "✅ درگاه پرداخت ریالی HooshPay برای شما ایجاد شد.\n";
        text += $"💰 مبلغ شارژ کیف پول: {payment.AmountToman.FormatCurrency()}\n";
        text += $"💳 مبلغ قابل پرداخت با کارمزد: {payableAmount.FormatCurrency()}\n";
        text += $"💳 مبلغ دقیق قابل پرداخت به ریال: <code>{payableAmountRial:0,0}</code>\n";
        if (payment.FeeAmountToman > 0)
            text += $"🧾 کارمزد درگاه: {payment.FeeAmountToman.FormatCurrency()}\n";
        text += "\n⚠️ کارمزد درگاه هوش‌پی ۱۵ درصد است و به مبلغ شما اضافه می‌شود. اگر نمی‌خواهید کارمزد پرداخت کنید، از درگاه ارز دیجیتال استفاده کنید.\n";
        text += "⚠️ مبلغ پرداخت را دقیقاً مطابق عدد نمایش داده‌شده در صفحه پرداخت و تا ریال آخر واریز کنید. در پرداخت کارت‌به‌کارت، هر اختلافی باعث گم شدن پرداخت و تایید نشدن آن می‌شود و مجموعه ما مسئولیتی در قبال مبلغ گم‌شده نمی‌پذیرد.\n";
        text += $"🧾 شماره سفارش: <code>{orderId}</code>\n";
        if (!string.IsNullOrWhiteSpace(invoiceUid))
            text += $"🧾 شناسه فاکتور: <code>{invoiceUid}</code>\n";
        if (!string.IsNullOrWhiteSpace(trackingCode))
            text += $"🔎 کد پیگیری: <code>{trackingCode}</code>\n";
        if (!string.IsNullOrWhiteSpace(paymentUrl))
            text += $"🔗 لینک پرداخت: <a href=\"{paymentUrl}\">باز کردن صفحه پرداخت</a>\n";
        text += "\nپس از تایید پرداخت، شارژ کیف پول شما از طریق IPN به صورت خودکار انجام می‌شود. اگر لازم بود می‌توانید از دکمه بررسی وضعیت استفاده کنید.";

        return text;
    }

    async Task<string> GetNowPaymentsPaymentMessage(CredUser credUser, SwapinoPaymentInfo payment)
    {
        await _credentialsDbContext.GetUserStatus(credUser);
        var data = payment.GetNowPaymentsData();
        var baseCurrency = System.Net.WebUtility.HtmlEncode((payment.BaseCurrency ?? data.PriceCurrency ?? "usdtbsc").ToUpperInvariant());
        var baseAmount = (payment.BaseAmount == 0 ? data.PriceAmount : payment.BaseAmount).ToString("0.########", CultureInfo.InvariantCulture);
        var invoiceUrl = System.Net.WebUtility.HtmlEncode(payment.InvoiceUrl ?? data.InvoiceUrl ?? "");
        var paymentId = System.Net.WebUtility.HtmlEncode(payment.PaymentId ?? data.PaymentId ?? "");
        var orderId = System.Net.WebUtility.HtmlEncode(payment.OrderId);

        string text = "✅ درگاه پرداخت ارز دیجیتال برای شما ایجاد شد.\n";
        text += $"💵 مبلغ شارژ کیف پول: {payment.AmountToman.FormatCurrency()}\n";
        text += $"💲 ارز مبنا: <code>{baseAmount} {baseCurrency}</code>\n";
        if (data.UsdtIrtPrice > 0)
        {
            var dollarPriceToman = data.PriceIsRial
                ? data.UsdtIrtPrice / 10m
                : data.UsdtIrtPrice;
            var priceNote = data.UsedFallbackPrice ? "قیمت پیش‌فرض" : "قیمت لحظه‌ای نوبیتکس";
            text += $"💱 نرخ تتر/دلار زمان ساخت فاکتور: <code>{dollarPriceToman:0,0} تومان</code> ({priceNote})\n";
        }
        text += $"🧾 شماره سفارش: <code>{orderId}</code>\n";
        if (!string.IsNullOrWhiteSpace(invoiceUrl))
            text += $"🔗 لینک فاکتور: <a href=\"{invoiceUrl}\">باز کردن صفحه پرداخت</a>\n";
        if (!string.IsNullOrWhiteSpace(paymentId))
            text += $"🧾 شناسه پرداخت: <code>{paymentId}</code>\n";
        text += "\nشما می‌توانید از هر ارز دیجیتالی که NOWPayments پشتیبانی می‌کند پرداخت را انجام دهید. پس از تایید شبکه، شارژ کیف پول شما از طریق IPN به صورت خودکار انجام می‌شود.";

        return text;
    }

    private static string GetTutorialButtonText(int index)
    {
        return index switch
        {
            0 => "آموزش نصب کانفیگ لینک",
            1 => "آموزش نصب سابلینک",
            _ => $"آموزش شماره {index + 1}"
        };
    }

    string[] GetPrices(bool isColleague, bool isForRenew)
    {

        List<string> buttonsName = new List<string>();
        if (isForRenew)
        {
            if (isColleague)
            {
                _appConfig.PriceColleagues.ForEach(i => buttonsName.Add($"تمدید اکانت {i.DurationName} قیمت {i.Price}"));
            }
            else
            {
                _appConfig.Price.ForEach(i => buttonsName.Add($"تمدید اکانت {i.DurationName} قیمت {i.Price}"));
            }
        }
        else
        {
            if (isColleague)
            {
                _appConfig.PriceColleagues.ForEach(i => buttonsName.Add($"خرید اکانت {i.DurationName} قیمت {i.Price}"));
            }
            else
            {
                _appConfig.Price.ForEach(i => buttonsName.Add($"خرید اکانت {i.DurationName} قیمت {i.Price}"));
            }
        }
        return buttonsName.ToArray();
    }

    PriceConfig GetPriceConfig(string messageText, CredUser credUser, bool isForRenew)
    {
        var appConfig = _configuration.Get<AppConfig>();

        PriceConfig priceConfig;
        var prices = GetPrices(credUser.IsColleague, isForRenew);
        int index = -1;
        try
        {
            index = Array.IndexOf(prices, messageText);
        }
        catch (System.Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        if (index == -1) return null;

        if (credUser.IsColleague)
        {
            priceConfig = appConfig.PriceColleagues.ToArray().ElementAtOrDefault(index) ?? null;
        }
        else
        {
            priceConfig = appConfig.Price.ToArray().ElementAtOrDefault(index) ?? null;
        }
        return priceConfig;

    }
    long TryParsPrice(string input)
    {

        //input = "خرید اکانت شش ماهه قیمت 360000";

        // Define a regular expression pattern to match a numeric value.
        //string pattern = @"([\d٠-٩]+)";
        string pattern = @"(\d+)";

        // Use Regex.Match to find the first match in the input string.
        Match match = Regex.Match(input, pattern);
        long value = 0;
        // Check if the match was successful.
        if (match.Success)
        {
            // Try to parse the matched value as a long.
            if (long.TryParse(match.Groups[1].Value, out long extractedValue))
            {
                value = extractedValue;
            }
            else
            {
                value = 0;
            }
        }
        else
        {
            value = 0;
        }
        return value;
    }
    /// <summary>
    /// Builds the Persian owned-bot main reply keyboard including global referral access and the account-test label.
    /// </summary>
    /// <returns>A resized reply keyboard whose final row is the single full-width main-menu button.</returns>
    /// <remarks>
    /// The referral button is available only in owned routing; tenant storefronts construct their own customer menu
    /// and do not use this keyboard for referral registration or reporting.
    /// </remarks>
    ReplyKeyboardMarkup MainReplyMarkupKeyboardFa()
    {
        // The latest-client-download row is global and re-read from the live switch on every render, so a super-admin
        // toggle shows up on the next keyboard the customer receives. Only the customer menu carries it; the super-admin
        // keyboard is built separately and is unaffected.
        var rows = new List<KeyboardButton[]>
        {
            new KeyboardButton[] { "💳خرید اکانت جدید", "💰شارژ حساب کاربری" },
            new KeyboardButton[] { "📋 تعرفه‌ها", "📒 تراکنش‌های من" },
            new KeyboardButton[] { "⚙️ مدیریت اکانت" },
            new KeyboardButton[] { "🌟اکانت تست", "💡راهنما نصب" },
            new KeyboardButton[] { "🎁 دعوت از دوستان", "💻 ارتباط با ادمین" }
        };

        if (_clientDownloadAvailability.Snapshot.Enabled)
            rows.Add(new KeyboardButton[] { ClientDownloadCallbacks.OpenCommand });

        rows.Add(new KeyboardButton[] { "🏠منو" });

        ReplyKeyboardMarkup replyKeyboardMarkup = new(rows)
        {
            ResizeKeyboard = true
        };
        return replyKeyboardMarkup;

        // var buttons = new[]
        // {
        // new[] { "💳خرید اکانت جدید", "🏠منو","💻 ارتباط با ادمین" },
        // new[] { "💡راهنما نصب", "🌟اکانت تست", "⚙️مدیریت اکانت ها" }
        // };

        // var keyboardButtons = buttons
        //     .Select(row => row.Select(buttonText => new KeyboardButton(buttonText)))
        //     .ToArray();
        // return new ReplyKeyboardMarkup(keyboardButtons, ResizeKeyboard = false);
    }


    ReplyKeyboardMarkup PriceReplyMarkupKeyboardFa(bool isColleague, bool isForRenew)
    {
        var prices = GetPrices(isColleague, isForRenew);
        if (isForRenew && isColleague)
        {
            ReplyKeyboardMarkup replyKeyboardMarkup = new(new[]
                          {
                    new KeyboardButton[] { prices[0], prices[1] },
                    new KeyboardButton[] { prices[2],prices[3] },
                    new KeyboardButton[] { "تمدید حجمی" },
                    new KeyboardButton[] { "🏠منو" }})
            {
                ResizeKeyboard = true,
                OneTimeKeyboard = true
            };

            return replyKeyboardMarkup;
        }
        else
        {
            ReplyKeyboardMarkup replyKeyboardMarkup = new(new[]
              {
                    new KeyboardButton[] { prices[0], prices[1] },
                    new KeyboardButton[] { prices[2],prices[3] },
                    new KeyboardButton[] { "🏠منو" }})
            {
                ResizeKeyboard = true,
                OneTimeKeyboard = true
            };

            return replyKeyboardMarkup;

        }

    }

    static ReplyKeyboardMarkup GetMainMenuKeyboard()
    {
        var keyboard = new ReplyKeyboardMarkup(new[]
        {
            new[]
            {
                new KeyboardButton("➕ Create New Account"),
            },
            new[]
            {
                new KeyboardButton("🔄 Renew Existing Account"),
            },
            new[]
            {
                new KeyboardButton("ℹ️ Get Account Info"),
            },
            new[]
            {
                new KeyboardButton("🗽 Admin"),
            },
            new[]
            {
                new KeyboardButton("📑 Menu"),
            }
        });

        return keyboard;
    }

    /// <summary>
    /// Builds the user-facing outcome shown after an owned-bot referral start payload is processed.
    /// </summary>
    /// <param name="result">Registration result returned by the global referral service, or <c>null</c> for ordinary start.</param>
    /// <returns>Readable Persian status text, or an empty string when no referral-specific message is needed.</returns>
    /// <remarks>
    /// The message deliberately does not reveal another referrer's Telegram id when the immutable relationship was
    /// already claimed through a different link.
    /// </remarks>
    private static string BuildReferralRegistrationMessage(ReferralRegistrationResult result)
    {
        if (result == null)
            return string.Empty;

        return result.Status switch
        {
            ReferralRegistrationStatus.Created =>
                "✅ دعوت شما با موفقیت ثبت شد. پاداش‌ها پس از اولین پرداخت واجدشرایط اعمال می‌شوند.",
            ReferralRegistrationStatus.AlreadyRegistered =>
                "ℹ️ این لینک دعوت قبلاً برای حساب شما ثبت شده است.",
            ReferralRegistrationStatus.DifferentReferrerAlreadyRegistered =>
                "ℹ️ حساب شما قبلاً با یک لینک دعوت دیگر ثبت شده و معرف اول قابل تغییر نیست.",
            ReferralRegistrationStatus.SelfReferralRejected =>
                "⛔️ امکان ثبت لینک دعوت خودتان وجود ندارد.",
            ReferralRegistrationStatus.InvalidCode =>
                "⚠️ لینک دعوت معتبر نیست یا صاحب آن هنوز در ربات ثبت نشده است.",
            _ => string.Empty
        };
    }

    /// <summary>
    /// Determines whether a Telegram text message requests the owned-bot referral dashboard.
    /// </summary>
    /// <param name="text">
    /// Raw message text received from Telegram. Null and whitespace are allowed; surrounding whitespace is ignored.
    /// </param>
    /// <returns>
    /// <c>true</c> for the referral reply-keyboard label with or without the gift emoji; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This method intentionally recognizes a main-menu command instead of a persisted customer-flow value. Callers
    /// must route a match before arbitrary-text purchase, search, comment, trial, colleague, or renewal handlers.
    /// </remarks>
    /// <example>
    /// <code>
    /// IsReferralMenuCommand("  🎁 دعوت از دوستان  "); // true
    /// IsReferralMenuCommand("دعوت از دوستان");       // true
    /// </code>
    /// </example>
    private static bool IsReferralMenuCommand(string text)
    {
        var normalized = text?.Trim();
        return string.Equals(normalized, "🎁 دعوت از دوستان", StringComparison.Ordinal) ||
               string.Equals(normalized, "دعوت از دوستان", StringComparison.Ordinal);
    }

    /// <summary>
    /// Cancels the current owned-bot customer conversation and displays the existing global referral dashboard.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned bot that received the main-menu command.</param>
    /// <param name="message">
    /// Incoming Telegram message. Its sender id selects bot-scoped conversation/session state and its chat id receives
    /// the dashboard or a safe failure message.
    /// </param>
    /// <param name="user">
    /// Current bot-scoped persisted customer state when the caller has already loaded it. Pass <c>null</c> from the
    /// super-admin route so this handler loads the state inside its protected/logged operation. Only transient
    /// conversation fields are cleared; credentials, wallet, referral relationships, rewards, and XUI accounts are
    /// untouched.
    /// </param>
    /// <param name="cancellationToken">Token that cancels users.db access and Telegram delivery.</param>
    /// <returns>
    /// <c>true</c> when the text is a referral menu command and the update was consumed, including safe error handling;
    /// <c>false</c> for unrelated text or a non-owned bot.
    /// </returns>
    /// <remarks>
    /// This handler is shared by regular and super-admin owned-bot routes. It clears both the persisted <see cref="User"/>
    /// flow and the current bot/user entry in <see cref="XuiV3PurchaseSessionStore"/> before calling
    /// <see cref="SendReferralDashboardAsync"/>. A routine successful dashboard delivery is logged only at debug level
    /// so it does not flood the private Telegram logger channel; failures remain error-level diagnostics. Telegram
    /// notification failures never mutate referral or financial data.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (await TryHandleReferralMenuCommandAsync(botClient, message, user, cancellationToken))
    ///     return;
    /// </code>
    /// </example>
    private async Task<bool> TryHandleReferralMenuCommandAsync(
        ITelegramBotClient botClient,
        Message message,
        User user,
        CancellationToken cancellationToken)
    {
        if (message?.From == null || !IsReferralMenuCommand(message.Text))
            return false;

        var botType = CurrentBot?.Type ?? BotContextAccessor.CurrentBotType;
        if (!string.Equals(botType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
            return false;

        var telegramUserId = message.From.Id;
        var botId = CurrentBot?.Id ?? BotContextAccessor.CurrentBotId;
        var botUsername = CurrentBot?.Username ?? BotContextAccessor.CurrentBotUsername;
        var isSuperAdmin = IsSuperAdminUser(telegramUserId);
        var previousFlow = user?.Flow ?? "(not-loaded)";
        var previousLastStep = user?.LastStep ?? "(not-loaded)";

        try
        {
            var currentState = user ?? await _state.GetUserStatus(telegramUserId);
            previousFlow = currentState?.Flow ?? string.Empty;
            previousLastStep = currentState?.LastStep ?? string.Empty;

            // Both stores are bot-scoped. Clearing them prevents a stale arbitrary-text handler or purchase selection
            // from resuming after the user deliberately returned to the referral main-menu screen.
            await _state.ClearUserStatus(currentState ?? new User { Id = telegramUserId });
            _xuiV3PurchaseSessionStore.Clear(telegramUserId);

            var dashboardMessage = await SendReferralDashboardAsync(botClient, message, cancellationToken);
            var dashboardSent = dashboardMessage != null;
            if (!dashboardSent)
                throw new InvalidOperationException("Telegram did not return a message for the referral dashboard.");

            _logger.LogDebug(
                "Owned-bot referral menu routed. telegramUserId={TelegramUserId}, botId={BotId}, botUsername={BotUsername}, isSuperAdmin={IsSuperAdmin}, previousFlow={PreviousFlow}, previousLastStep={PreviousLastStep}, dashboardSent={DashboardSent}",
                telegramUserId,
                botId,
                botUsername,
                isSuperAdmin,
                previousFlow,
                previousLastStep,
                dashboardSent);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            var telegramApiException = ex as ApiRequestException;
            _logger.LogError(
                ex,
                "Owned-bot referral menu failed. telegramUserId={TelegramUserId}, botId={BotId}, botUsername={BotUsername}, isSuperAdmin={IsSuperAdmin}, previousFlow={PreviousFlow}, previousLastStep={PreviousLastStep}, dashboardSent={DashboardSent}, exceptionType={ExceptionType}, telegramErrorCode={TelegramErrorCode}, errorMessage={ErrorMessage}",
                telegramUserId,
                botId,
                botUsername,
                isSuperAdmin,
                previousFlow,
                previousLastStep,
                false,
                ex.GetType().FullName,
                telegramApiException?.ErrorCode,
                ex.Message);

            try
            {
                await botClient.SendReferralTextMessageAsync(
                    chatId: message.Chat.Id,
                    text: "نمایش اطلاعات دعوت از دوستان با خطا روبه‌رو شد. لطفاً چند دقیقه دیگر دوباره تلاش کنید.",
                    replyMarkup: MainReplyMarkupKeyboardFa(),
                    cancellationToken: cancellationToken);
            }
            catch (Exception deliveryException)
            {
                _logger.LogError(
                    deliveryException,
                    "Referral dashboard failure notification could not be delivered. telegramUserId={TelegramUserId}, botId={BotId}, botUsername={BotUsername}",
                    telegramUserId,
                    botId,
                    botUsername);
            }
        }

        return true;
    }

    /// <summary>
    /// Shows the current user's global referral link and reward statistics in an owned bot.
    /// </summary>
    /// <param name="botClient">Telegram client for the currently handling owned bot.</param>
    /// <param name="message">Incoming message containing the numeric Telegram user and chat ids.</param>
    /// <param name="cancellationToken">Cancellation token for users.db statistics and Telegram delivery.</param>
    /// <returns>
    /// The non-null Telegram message accepted for delivery. The caller must use this result, rather than completion of
    /// the method alone, when recording <c>dashboardSent=true</c>.
    /// </returns>
    /// <remarks>
    /// The link uses the current owned bot username, but invited count and rewards are global across every owned bot.
    /// Tenant bots never call this method and cannot create referral links or relationships.
    /// </remarks>
    private async Task<Message> SendReferralDashboardAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        if (_appConfig.Referral?.Enabled != true)
        {
            return await botClient.SendReferralTextMessageAsync(
                chatId: message.Chat.Id,
                text: "قابلیت دعوت از دوستان در حال حاضر فعال نیست.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }

        var username = (CurrentBot?.Username ?? string.Empty).Trim().TrimStart('@');
        if (string.IsNullOrWhiteSpace(username))
        {
            return await botClient.SendReferralTextMessageAsync(
                chatId: message.Chat.Id,
                text: "نام کاربری این ربات برای ساخت لینک دعوت تنظیم نشده است.",
                replyMarkup: MainReplyMarkupKeyboardFa(),
                cancellationToken: cancellationToken);
        }

        var stats = await _referralService.GetUserStatsAsync(message.From.Id, cancellationToken);
        var code = ReferralCodeCodec.Encode(message.From.Id);
        var link = $"https://t.me/{username}?start=ref_{code}";
        var text =
            "🎁 دعوت از دوستان\n\n" +
            $"لینک اختصاصی شما:\n{link}\n\n" +
            $"👥 تعداد دعوت‌شده‌ها: {stats.InvitedCount:N0}\n" +
            $"✅ دعوت‌های واجدشرایط: {stats.EligibleReferralCount:N0}\n" +
            $"💰 مجموع پاداش‌ها: {stats.TotalAppliedRewardToman:N0} تومان\n" +
            $"⏳ پاداش‌های در انتظار: {stats.PendingRewardCount:N0}\n" +
            $"⚠️ پاداش‌های نیازمند بررسی مجدد: {stats.FailedRewardCount:N0}\n\n" +
            $"حداقل پرداخت واجدشرایط: {_appConfig.Referral.MinimumEligiblePaymentAmountToman:N0} تومان";

        return await botClient.SendReferralTextMessageAsync(
            chatId: message.Chat.Id,
            text: text,
            replyMarkup: MainReplyMarkupKeyboardFa(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Builds one clickable, HTML-safe support reference for an owned bot customer message.
    /// </summary>
    /// <param name="supportAccount">
    /// Support value from the current owned bot configuration. A public Telegram username may be supplied as
    /// <c>username</c>, <c>@username</c>, <c>t.me/username</c>, or <c>https://t.me/username</c>.
    /// </param>
    /// <returns>
    /// A clickable HTML anchor whose visible text is <c>@username</c>, or an empty string when no valid public
    /// Telegram support username has been configured for the active bot.
    /// </returns>
    /// <remarks>
    /// This helper is intentionally owned-bot scoped. Tenant storefront support formatting remains in
    /// <see cref="TenantBotService"/> because tenant owners manage a separate support setting.
    /// </remarks>
    private static string BuildOwnedBotSupportContactHtml(string supportAccount)
    {
        if (string.IsNullOrWhiteSpace(supportAccount))
            return string.Empty;

        var normalized = supportAccount.Trim();
        if (normalized.StartsWith("@http://", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@https://", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@t.me/", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@telegram.me/", StringComparison.OrdinalIgnoreCase))
        {
            normalized = normalized[1..];
        }

        if (normalized.StartsWith("t.me/", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("telegram.me/", StringComparison.OrdinalIgnoreCase))
        {
            normalized = "https://" + normalized;
        }

        if (Uri.TryCreate(normalized, UriKind.Absolute, out var uri) &&
            (string.Equals(uri.Host, "t.me", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(uri.Host, "telegram.me", StringComparison.OrdinalIgnoreCase)))
        {
            normalized = uri.AbsolutePath.Trim('/');
        }

        normalized = normalized.Trim().TrimStart('@');
        if (string.IsNullOrWhiteSpace(normalized) ||
            normalized.Any(character => !(char.IsLetterOrDigit(character) || character == '_')))
        {
            return string.Empty;
        }

        var safeUsername = Html(normalized);
        return $"<a href=\"https://t.me/{safeUsername}\">@{safeUsername}</a>";
    }

    /// <summary>
    /// Sends the current owned bot's blocked-user notice with its own configured support contact.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that blocked the user.</param>
    /// <param name="chatId">Telegram chat id that should receive the notice.</param>
    /// <param name="cancellationToken">Cancellation token for the Telegram send operation.</param>
    /// <returns>A task that completes after Telegram accepts the notice or throws a delivery exception.</returns>
    /// <remarks>
    /// Support identity must stay brand-scoped here as well; an empty support setting is reported instead of leaking
    /// the default bot's contact to users of another owned brand.
    /// </remarks>
    private async Task SendBlockedUserMessageAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CancellationToken cancellationToken)
    {
        var support = BuildOwnedBotSupportContactHtml(CurrentSupportAccount);
        var supportText = string.IsNullOrWhiteSpace(support)
            ? "پشتیبانی این ربات تنظیم نشده است."
            : support;

        await botClient.SendMessage(
            chatId: chatId,
            text: $"به علت تخلف مسدود شدید و امکان استفاده از ربات را ندارید.\nبرای پیگیری می‌توانید به پشتیبانی تلگرام پیام بدهید:\n{supportText}",
            parseMode: ParseMode.Html,
            cancellationToken: cancellationToken);
    }

    static ReplyKeyboardMarkup GetAccountTypeKeyboard()
    {
        // Create an inline keyboard with the available account types

        var keyboard = new ReplyKeyboardMarkup(new[]
        {
        new[]
        {
            new KeyboardButton("All operators"),
        },
        new[]
        {
            new KeyboardButton("Reality Ipv6"),
        }
        });

        return keyboard;
    }


    /// <summary>
    /// Creates one legacy x-ui account after obtaining a session cookie for the selected panel.
    /// </summary>
    /// <param name="accountDto">
    /// Account creation request assembled by the Telegram purchase flow. It must include a non-null
    /// <see cref="AccountDto.ServerInfo"/> with a valid panel URL and inbound configuration.
    /// </param>
    /// <returns>
    /// <c>true</c> when login succeeds and the x-ui add-client request reports success; otherwise <c>false</c>.
    /// Exceptions are caught and converted to <c>false</c> so Telegram update handling does not crash.
    /// </returns>
    /// <remarks>
    /// This is the legacy non-v3 account creation path used by <c>FinalizeCustomerAccount</c>. A null return from
    /// <see cref="ApiService.LoginAndGetSessionCookie"/> is treated as a recoverable login failure.
    /// </remarks>
    async Task<bool> CreateAccount(AccountDto accountDto)
    {
        try
        {
            if (accountDto?.ServerInfo == null)
            {
                Console.WriteLine("[CreateAccount] AccountDto or ServerInfo is null.");
                return false;
            }

            var sessionCookie = await ApiService.LoginAndGetSessionCookie(accountDto.ServerInfo);
            if (!string.IsNullOrWhiteSpace(sessionCookie))
            {
                accountDto.SessionCookie = sessionCookie;
                // var selectedCountry = "🇸🇪 Sweden";
                // var selectedPeriod = "2 Months";

                return await ApiService.CreateUserAccount(accountDto);
            }

            Console.WriteLine($"[CreateAccount] Could not obtain session cookie. user={accountDto.TelegramUserId}, panel={accountDto.ServerInfo.Url}");
            return false;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[CreateAccount] Failed. user={accountDto?.TelegramUserId}, error={ex}");
            return false;
        }
    }

    async Task<bool> UpdateAccount(AccountDtoUpdate accountDto)
    {
        bool result;
        var sessionCookie = await ApiService.LoginAndGetSessionCookie(accountDto.ServerInfo);
        if (sessionCookie != null)
        {
            accountDto.SessionCookie = sessionCookie;
            result = await ApiService.UpdateUserAccount(accountDto);
        }
        else
        {
            // Handle the case where login fails
            result = false;
        }
        return result;
    }

    static bool StartsWithVMessOrVLess(string value)
    {
        return value.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase)
            || value.StartsWith("vless://", StringComparison.OrdinalIgnoreCase);
    }
    static bool StartsWithEnableOrDisable(string value)
    {
        return value.StartsWith("/disable_", StringComparison.OrdinalIgnoreCase)
            || value.StartsWith("/enable_", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>Resolves a private panel copy for a parsed legacy VMess link.</summary>
    /// <param name="vmess">Required parsed customer link, including host and port; credentials must not be logged.</param>
    /// <returns>A detached panel descriptor narrowed to the matching inbound.</returns>
    /// <remarks>Mutating the returned template cannot affect concurrent customers or global configuration.</remarks>
    /// <exception cref="Exception">The link is incomplete or no configured panel owns its host.</exception>
    static ServerInfo GetConfigServer(VMessConfiguration vmess)
    {

        if (VMessConfiguration.ArePropertiesNotNullOrEmpty(vmess, null))
        {
            // Access the server information from the servers.json file
            var serversJson = ReadJsonFile.ReadJsonAsString();
            var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

            // Iterate over the dictionary
            foreach (var kvp in servers)
            {
                string country = kvp.Key;
                ServerInfo serverInfo = RuntimeSnapshot.Copy(kvp.Value);
                if (serverInfo.VmessTemplate.Add == vmess.Add)
                {
                    serverInfo.Inbounds = new List<Inbound> { serverInfo.Inbounds.FirstOrDefault(i => i.Port.ToString() == vmess.Port) };
                    serverInfo.VmessTemplate.Port = vmess.Port;
                    return serverInfo;
                }
            }

            throw new Exception("Your Vmess Link is not for us! Try again ...");

        }
        else
        {

            throw new Exception("Your Vmess Link is not completed!");
        }


    }

    /// <summary>Resolves a private panel copy for a parsed legacy VLESS link.</summary>
    /// <param name="vless">Required parsed customer link with a configured panel domain; never log its client credentials.</param>
    /// <returns>A detached panel descriptor matching the link's domain.</returns>
    /// <remarks>The returned descriptor belongs only to the caller's lookup operation.</remarks>
    /// <exception cref="Exception">The link has no domain or its domain is absent from configuration.</exception>
    static ServerInfo GetConfigServerFromVless(Vless vless)
    {

        if (vless.Domain != null)
        {
            // Access the server information from the servers.json file
            var serversJson = ReadJsonFile.ReadJsonAsString();
            var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

            // Iterate over the dictionary
            foreach (var kvp in servers)
            {
                string country = kvp.Key;
                ServerInfo serverInfo = RuntimeSnapshot.Copy(kvp.Value);
                if (serverInfo.Vless.Domain == vless.Domain)
                {
                    return serverInfo;
                }
            }

            throw new Exception("Your Vmess Link is not for us! Try again ...");

        }
        else
        {
            throw new Exception("Your Vmess Link is not completed!");
        }
    }

    async Task<ClientExtend> TryGetClient(string messageText)
    {
        ClientExtend client = null;

        // Handle "Get Account Info" button click
        // You can implement the logic for this button here
        // For example, retrieve and display account information

        //vmess
        if (messageText.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                var vmess = VMessConfiguration.DecodeVMessLink(messageText);
                ServerInfo serverInfo = GetConfigServer(vmess);
                var inbound = serverInfo.Inbounds.FirstOrDefault(i => i.Type == "tunnel");
                if (inbound == null) return null;
                client = await ApiService.FetchClientFromServer(vmess.Id, serverInfo, inbound.Id);

                //var inboundIds = new List<int>();
                //serverInfo.Inbounds.ForEach(i => inboundIds.Add(i.Id));
            }

            catch (System.Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        //vless
        else
        {
            try
            {
                var vless = Vless.DecodeVlessLink(messageText);
                var serverInfo = GetConfigServerFromVless(vless);
                var inbound = serverInfo.Inbounds.FirstOrDefault(i => i.Type == "realityv6");
                if (inbound == null) return null;
                client = await ApiService.FetchClientFromServer(vless.Id, serverInfo, inbound.Id);
            }
            catch (System.Exception ex)
            {

                Console.WriteLine(ex.Message);
            }


        }
        return client;

    }



    async Task<List<ClientExtend>> TryGetَAllClient(long telegramUserId)
    {
        List<ClientExtend> clients = new List<ClientExtend>();

        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

        foreach (var s in servers)
        {
            ServerInfo serverInfo = s.Value;
            foreach (var inbound in serverInfo.Inbounds)
            {
                if (s.Key == "Vpnnetiran")
                    Console.WriteLine("seen");
                if (inbound.Type == "tunnel")
                {
                    try
                    {
                        var temp = await ApiService.FetchAllClientFromServer(telegramUserId, serverInfo, inbound.Id);

                        if (temp.Count > 0)
                            clients.AddRange(temp);

                    }
                    catch (System.Exception ex)
                    {

                        Console.WriteLine(ex.Message);
                    }

                }
            }

        }
        return clients;

    }

    /// <summary>
    /// Validates an owned-bot Telegram contact for automatic Iranian phone verification.
    /// </summary>
    /// <param name="botClient">Owned-bot client that received the contact and must send validation feedback.</param>
    /// <param name="message">
    /// Incoming private Telegram message containing a contact. Its sender id and contact user id must match.
    /// </param>
    /// <param name="cancellationToken">Polling cancellation token used for Telegram feedback.</param>
    /// <returns>
    /// The canonical <c>+989xxxxxxxxx</c> phone number when the contact belongs to the sender and is Iranian;
    /// otherwise <c>null</c>. A rejection message is sent before returning <c>null</c>.
    /// </returns>
    /// <remarks>
    /// This owned-bot wrapper delegates to the verifier also used by tenant handlers with their own menus and support.
    /// Foreign or virtual numbers may still be approved through the separate super-admin manual flow. When an
    /// own foreign contact is rejected, support comes strictly from the current owned bot configuration.
    /// </remarks>
    /// <example>
    /// <code>
    /// var phone = await ValidateOwnedBotPhoneContactAsync(client, message, cancellationToken);
    /// if (phone != null)
    ///     await credentials.SavePhoneNumber(message.From.Id, phone);
    /// </code>
    /// </example>
    private async Task<string> ValidateOwnedBotPhoneContactAsync(
        ITelegramBotClient botClient,
        Message message,
        CancellationToken cancellationToken)
    {
        return await TelegramPhoneVerification.ValidateAsync(botClient, message,
            BuildOwnedBotSupportContactHtml(CurrentSupportAccount), MainReplyMarkupKeyboardFa(), cancellationToken);
    }


    private ReplyKeyboardMarkup GetPhoneNumber()
    {
        ReplyKeyboardMarkup replyKeyboardMarkup = new(new[]
            {
                // Row with the 'send contact' button
                new KeyboardButton[]
                {
                    KeyboardButton.WithRequestContact("ارسال شماره تلفن")
                },
                // Row with the 'cancel' button
                new KeyboardButton[]
                {
                    new KeyboardButton("لغو") // Replace "لغو" with the text you want for the cancellation button
                }
            })
        {
            ResizeKeyboard = true, // Set to true to fit the keyboard size to its buttons
            OneTimeKeyboard = true // Optional: set to true to hide the keyboard after a button is pressed
        };
        return replyKeyboardMarkup;
    }

    private ChannelInfo GetChannelAndPost(string link)
    {


        ChannelInfo channelInfo = null;
        var match = Regex.Match(link?.Trim() ?? string.Empty, @"^https?://t\.me/(?<channelname>@?[A-Za-z0-9_]+)/(?<postnumber>\d+)/?$", RegexOptions.IgnoreCase);
        // var match = Regex.Match(link, @"https://t.me/(?<channelname>[^/]+)/(?<postnumber>\d+)");
        if (match.Success)
        {
            string channelName = match.Groups["channelname"].Value;
            int postNumber = int.Parse(match.Groups["postnumber"].Value);

            channelInfo = new ChannelInfo { PostNumber = postNumber, ChannelName = channelName };

        }
        else
        {
            Console.WriteLine("Normal public message");
        }
        return channelInfo;

    }

    private static ChatId BuildForwardSourceChatId(string channelName)
    {
        var value = (channelName ?? string.Empty).Trim();
        if (long.TryParse(value, out var numericChatId))
            return new ChatId(numericChatId);

        if (!value.StartsWith("@", StringComparison.Ordinal))
            value = "@" + value;

        return new ChatId(value);
    }
}
