using Adminbot.Domain;
using Adminbot.Utils;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Globalization;
using Adminbot.Domain.Logging;

/// <summary>
/// Coordinates shared XUI v3 customer purchase, renewal, search, and owned-account management flows for Telegram bots.
/// </summary>
/// <remarks>
/// The service is reused by owned bots and tenant storefront bots under the active bot context. Account-management
/// callbacks are bot-routed but must still reload panel clients and enforce Telegram ownership. Read-only
/// configuration delivery keeps private SubId and proxy URLs out of callback data and operational logs.
/// </remarks>
public class XuiV3BotFlowService
{
    private const string RenewFlowName = "xui-v3-renew";
    private const string RenewStepAccount = "renew-account";
    private const string RenewStepExternalTargetConfirmation = "renew-confirm-external-target";
    private const string RenewStepTraffic = "renew-traffic";
    private const string RenewStepDuration = "renew-duration";
    private const string RenewStepUnlimitedPlan = "renew-unlimited-plan";
    private const string RenewStepConfirm = "renew-confirm";
    private const string DeleteExpiredFlowName = "xui-v3-delete-expired";
    private const string DeleteExpiredStepConfirm = "delete-expired-confirm";
    private const string AccountSearchFlowName = "xui-v3-account-search";
    private const string AccountSearchStepQuery = "account-search-query";
    private const string AccountSearchStepResults = "account-search-results";
    private const string AccountCommentFlowName = "xui-v3-account-comment";
    private const string AccountCommentStepText = "account-comment-text";
    private const string AccountCommentSourceList = "list";
    private const string AccountCommentSourceSearch = "search";
    private const string LegacyExternalUuidRenewPaymentMethod = "xui-v3-uuid-renew";
    private const string PurchaseFlowName = "xui-v3";
    private const string PurchaseStepSelectService = "select-service";
    private const string PurchaseStepSelectTraffic = "select-traffic";
    private const string PurchaseStepSelectDuration = "select-duration";
    private const string PurchaseStepSelectUnlimitedPlan = "select-unlimited-plan";
    private const string PurchaseStepAccountCount = "select-account-count";
    private const string PurchaseStepUserComment = "select-user-comment";
    private const string PurchaseStepConfirm = "confirm";
    private const string TrialFlowName = "xui-v3-trial";
    private const string TrialStepSelectService = "trial-select-service";
    private const string ColleagueRequestFlowName = "colleague-request";
    private const string ColleagueRequestStepConfirm = "colleague-request-confirm";
    private const string SkipCommentText = "ادامه بدون کامنت";
    private const int TrialDays = 3;
    private const long NationalTrialBytes = 100L * 1024L * 1024L;
    private const long NormalTrialBytes = 1L * 1024L * 1024L * 1024L;
    private const long MinimumWeeklyColleagueSalesToman = 5_000_000L;
    private const int AccountListPageSize = 20;
    /// <summary>Safe Telegram HTML limit that leaves room below the platform's 4096-character message ceiling.</summary>
    private const int MaxAccountConfigsHtmlLength = 3900;

    /// <summary>
    /// Identifies the earliest owned-purchase step that remains valid after the live plan catalog changes.
    /// </summary>
    private enum PurchaseRecoveryTarget
    {
        /// <summary>The restored selection is valid for the requested step and needs no recovery.</summary>
        None,

        /// <summary>The saved service no longer exists, is disabled, or cannot be trusted.</summary>
        Service,

        /// <summary>The metered service remains valid but its saved traffic is missing or below the current minimum.</summary>
        Traffic,

        /// <summary>The metered service and traffic remain valid but the preset or custom duration is no longer allowed.</summary>
        Duration,

        /// <summary>The unlimited service remains valid but its saved unlimited sub-plan is missing or disabled.</summary>
        UnlimitedPlan
    }

    private readonly XuiV3PurchaseService _purchaseService;
    private readonly XuiV3PurchaseSessionStore _sessionStore;
    private readonly UserStateStore _state;
    private readonly CredentialsStore _credentialsDbContext;
    private readonly IConfiguration _configuration;
    private readonly AppConfig _appConfig;
    private readonly ILogger<XuiV3BotFlowService> _logger;
    private readonly UserActivityLogService _activityLog;
    private readonly WalletLedgerService _walletLedgerService;
    private readonly GozargahSiteSyncService _gozargahSiteSyncService;
    private readonly BotContextAccessor _botContextAccessor;
    private readonly XuiV3LinkChangeOperationStore _linkChangeOperationStore;
    private readonly XuiV3VolumeReminderStateStore _volumeReminderStateStore;
    private readonly XuiV3RenewalOperationStore _renewalOperationStore;

    /// <summary>
    /// Immutable budget for UX-only callback acknowledgement inside this flow. Production uses the shared
    /// two-second default; tests inject a millisecond budget so bounded-acknowledgement behaviour is proven
    /// without waiting the real production timeout.
    /// </summary>
    private readonly TelegramInteractionTimeouts _interactionTimeouts;

    /// <summary>
    /// Creates the shared XUI v3 customer-flow service used by owned bots and tenant storefront bots.
    /// </summary>
    /// <param name="purchaseService">
    /// Resolves XUI v3 service plans, prices, and account-creation payloads from the configured plan file.
    /// </param>
    /// <param name="sessionStore">
    /// Stores temporary purchase selections keyed by bot id and Telegram user id while a customer moves through
    /// the multi-step purchase flow.
    /// </param>
    /// <param name="userDbContext">
    /// Factory-backed conversation store that reloads bot/user state for each explicit write.
    /// </param>
    /// <param name="credentialsDbContext">
    /// Factory-backed global profile and wallet receipt store. Financial mutations commit a unique business key with the balance.
    /// </param>
    /// <param name="configuration">Application configuration used for XUI panel and plan settings.</param>
    /// <param name="logger">Logger used for operational diagnostics that are not customer-facing.</param>
    /// <param name="activityLog">
    /// Structured activity logger used for audit entries related to XUI account operations.
    /// </param>
    /// <param name="walletLedgerService">
    /// Append-only wallet ledger writer. It records wallet debits for purchases and renewals in toman so
    /// customers and admins can audit balance changes later.
    /// </param>
    /// <param name="gozargahSiteSyncService">
    /// Gozargah website sync service used to publish successful XUI v3 account creates, renewals, deletes,
    /// and link changes without making the website database a blocking source of truth.
    /// </param>
    /// <param name="botContextAccessor">
    /// Async-local bot context accessor used to decide whether the active flow belongs to an owned bot or a tenant
    /// storefront and to add bot metadata to operational purchase logs.
    /// </param>
    /// <param name="linkChangeOperationStore">
    /// Durable users.db store that provides confirmation expiry, per-client uniqueness, leases, and recovery state for
    /// account link changes across every owned and tenant bot.
    /// </param>
    /// <param name="volumeReminderStateStore">
    /// Durable users.db volume-cycle store notified after a panel-confirmed renewal. Its best-effort write never changes
    /// the renewal price, wallet debit, account payload, or customer success outcome.
    /// </param>
    /// <param name="renewalOperationStore">
    /// Durable users.db store that makes each renewal operation exactly-once: unique-key creation, lease-bound
    /// processing claims, the atomic applied transition, the settlement guard, and read-only timeout recovery.
    /// </param>
    /// <param name="interactionTimeouts">
    /// Optional immutable budgets for UX-only Telegram interactions. When null the production budgets are used, so
    /// callback acknowledgement is bounded at two seconds. Tests pass millisecond values. This value is never read
    /// from configuration and never affects purchase, renewal, wallet, or settlement semantics.
    /// </param>
    /// <remarks>
    /// This service is intentionally shared between owned bots and tenant storefronts. Tenant callers must
    /// set the active bot context before invoking it so state reads and callback handling stay scoped to the
    /// bot that received the Telegram update.
    /// </remarks>
    public XuiV3BotFlowService(
        XuiV3PurchaseService purchaseService,
        XuiV3PurchaseSessionStore sessionStore,
        UserStateStore userDbContext,
        CredentialsStore credentialsDbContext,
        IConfiguration configuration,
        ILogger<XuiV3BotFlowService> logger,
        UserActivityLogService activityLog,
        WalletLedgerService walletLedgerService,
        GozargahSiteSyncService gozargahSiteSyncService,
        BotContextAccessor botContextAccessor,
        XuiV3LinkChangeOperationStore linkChangeOperationStore,
        XuiV3VolumeReminderStateStore volumeReminderStateStore,
        XuiV3RenewalOperationStore renewalOperationStore,
        TelegramInteractionTimeouts interactionTimeouts = null)
    {
        _purchaseService = purchaseService;
        _sessionStore = sessionStore;
        _state = userDbContext;
        _credentialsDbContext = credentialsDbContext;
        _configuration = configuration;
        _appConfig = configuration.Get<AppConfig>() ?? new AppConfig();
        _logger = logger;
        _activityLog = activityLog;
        _walletLedgerService = walletLedgerService;
        _gozargahSiteSyncService = gozargahSiteSyncService;
        _botContextAccessor = botContextAccessor;
        _linkChangeOperationStore = linkChangeOperationStore;
        _volumeReminderStateStore = volumeReminderStateStore;
        _renewalOperationStore = renewalOperationStore;
        _interactionTimeouts = interactionTimeouts ?? TelegramInteractionTimeouts.Production;
    }

    public bool IsEnabledForPurchaseFlow()
    {
        return string.Equals(_appConfig.XuiApiVersionMode, "v3", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Detects every reply-keyboard label that should open the shared XUI v3 "my accounts" flow.
    /// </summary>
    /// <param name="text">
    /// Telegram message text from an owned bot or tenant storefront. The value may be null or empty.
    /// </param>
    /// <returns>
    /// <c>true</c> when the text is one of the owned-bot or tenant-bot labels for listing the sender's accounts.
    /// </returns>
    /// <remarks>
    /// Tenant storefronts use the shorter "اکانت‌های من" label while the original owned bot uses
    /// "وضعیت اکانت های من". Keeping both labels here lets tenant bots reuse this flow instead of duplicating
    /// account-list code.
    /// </remarks>
    private static bool IsMyAccountsCommand(string text)
    {
        var normalized = text?.Trim();
        return string.Equals(normalized, "وضعیت اکانت های من", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(normalized, "اکانت‌های من", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(normalized, "اکانت های من", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Detects every reply-keyboard label that should start the shared account-search flow.
    /// </summary>
    /// <param name="text">
    /// Telegram message text from an owned bot or tenant storefront. The value may be null or empty.
    /// </param>
    /// <returns>
    /// <c>true</c> when the text asks the bot to collect a search query for an XUI v3 account.
    /// </returns>
    private static bool IsAccountSearchCommand(string text)
    {
        var normalized = text?.Trim();
        return string.Equals(normalized, "🔎 جستجوی اکانت", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(normalized, "جستجوی اکانت", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Detects every reply-keyboard label that should start the shared account-renewal flow.
    /// </summary>
    /// <param name="text">
    /// Telegram message text from an owned bot or tenant storefront. The value may be null or empty.
    /// </param>
    /// <returns>
    /// <c>true</c> when the text asks the bot to start renewal for an existing XUI v3 account.
    /// </returns>
    private static bool IsRenewCommand(string text)
    {
        return string.Equals(text?.Trim(), "تمدید اکانت", StringComparison.OrdinalIgnoreCase);
    }

    public async Task<bool> TryHandleMyAccountsAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || !IsMyAccountsCommand(message?.Text))
            return false;

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "لطفاً چند ثانیه صبر کنید. در حال دریافت اکانت‌های شما از پنل نسخه ۳ هستم...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            Console.WriteLine($"[XUIv3] my accounts start user={credUser.TelegramUserId} panel={serverInfo.Url}, rootPath={serverInfo.RootPath}");

            var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
            if (!response.Success)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: $"دریافت اکانت‌ها ناموفق بود.\n{response.Msg}",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            var accounts = response.Obj?
                .Where(client => ClientBelongsToUser(client, credUser.TelegramUserId))
                .OrderBy(client => client.Email)
                .ToList() ?? new List<XuiV3Client>();

            Console.WriteLine($"[XUIv3] my accounts found user={credUser.TelegramUserId} count={accounts.Count}");

            if (accounts.Count == 0)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "شما هنوز هیچ اکانتی از مجموعه ما ندارید.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            await SendV3AccountListPageAsync(botClient, message.Chat.Id, 0, credUser, cancellationToken);


            return true;
        }
        catch (XuiV3ForegroundReadTimeoutException)
        {
            // The whole foreground panel read exceeded its overall budget. The lane is released immediately with a
            // safe retry prompt; no panel URL, token, or exception detail is ever exposed to the user.
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "دریافت اطلاعات از سرور بیشتر از حد معمول طول کشید. لطفاً چند لحظه دیگر دوباره تلاش کنید.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] my accounts exception user={credUser.TelegramUserId}: {ex}");
            await _activityLog.LogErrorAsync(
                "xui_v3_my_accounts_failed",
                ex,
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["panelUrl"] = _appConfig.XuiV3ApiBaseUrl ?? string.Empty
                },
                cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "در دریافت وضعیت اکانت‌ها خطا رخ داد. جزئیات در ترمینال ثبت شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }
    }

    /// <summary>
    /// Handles a colleague's direct numeric account-counter lookup and displays the owned account's full action card.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned or tenant bot receiving the text message.</param>
    /// <param name="message">Incoming Telegram message whose text may contain an account counter.</param>
    /// <param name="credUser">Bot user profile; only colleague profiles may use this direct lookup route.</param>
    /// <param name="user">
    /// Bot-scoped conversation state. A lookup is accepted only when no other flow is active for this user and bot.
    /// </param>
    /// <param name="mainReplyMarkup">Main-menu keyboard used for not-found or panel-failure responses.</param>
    /// <param name="cancellationToken">Token that cancels panel and Telegram operations.</param>
    /// <returns>
    /// <c>true</c> when the message was recognized as an eligible account-counter lookup, including not-found results;
    /// otherwise <c>false</c> so later text handlers may process it.
    /// </returns>
    /// <remarks>
    /// The panel result is filtered by the sender's Telegram ownership metadata before the card is shown. A successful
    /// result uses the same complete menu as list and search cards, including read-only configuration retrieval.
    /// </remarks>
    /// <example>
    /// <code>
    /// var handled = await flow.TryHandleAccountCounterLookupAsync(
    ///     botClient, message, credUser, userState, mainMenu, cancellationToken);
    /// </code>
    /// </example>
    public async Task<bool> TryHandleAccountCounterLookupAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() ||
            message?.Text == null ||
            credUser?.IsColleague != true ||
            !string.IsNullOrWhiteSpace(user?.Flow) ||
            !TryParseAccountCounterLookup(message.Text, out var accountCounter))
        {
            return false;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "در حال جست‌وجوی اکانت نسخه ۳ با شماره اکانت...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        var serverInfo = BuildConfiguredPanelServerInfo();
        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"دریافت اکانت‌ها ناموفق بود.\n{response.Msg}",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        var client = response.Obj?
            .Where(item => ClientBelongsToUser(item, credUser.TelegramUserId))
            .FirstOrDefault(item => ClientHasAccountCounter(item, accountCounter));

        if (client == null)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"اکانتی با شماره <code>{accountCounter}</code> برای حساب شما پیدا نشد.",
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, IsClientRenewable(client)),
            parseMode: ParseMode.Html,
            replyMarkup: BuildAccountDetailsKeyboard(client, 0, IsClientRenewable(client)),
            cancellationToken: cancellationToken);

        return true;
    }

    /// <summary>Consumes account-search input only when the current bot/user is in the account-search flow.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="message">Incoming Telegram message from the current actor; required unless the route explicitly declines missing text.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="user">Detached current bot/user state; explicit store writes reload their targets and never attach this snapshot.</param>
    /// <param name="mainReplyMarkup">Reply markup selected for the current bot and user role, or null when no keyboard is required.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>True when this flow consumed the input, including handled validation or cancellation; false lets another route try it.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    public async Task<bool> TryHandleAccountSearchAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();
        var isStart = IsAccountSearchCommand(text);

        if (user?.Flow != AccountSearchFlowName && !isStart)
            return false;

        if (IsCancel(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "جستجوی اکانت لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (isStart || user?.LastStep == null)
        {
            await StartAccountSearchAsync(botClient, message.Chat.Id, message.From.Id, cancellationToken);
            return true;
        }

        if (user.LastStep != AccountSearchStepQuery && user.LastStep != AccountSearchStepResults)
            return false;

        var query = text.Trim();
        if (string.IsNullOrWhiteSpace(query))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "عبارت جستجو خالی است. نام اکانت، بخشی از کامنت، یا UUID کامل کانفیگ را بفرستید.",
                cancellationToken: cancellationToken);
            return true;
        }

        await _state.SaveUserStatus(new User
        {
            Id = message.From.Id,
            Flow = AccountSearchFlowName,
            LastStep = AccountSearchStepResults,
            ConfigLink = query
        });

        await SendAccountSearchResultsAsync(
            botClient,
            message.Chat.Id,
            credUser,
            query,
            0,
            cancellationToken);

        return true;
    }

    /// <summary>Validates a pending account comment and applies it through the owner-checked XUI flow.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="message">Incoming Telegram message from the current actor; required unless the route explicitly declines missing text.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="user">Detached current bot/user state; explicit store writes reload their targets and never attach this snapshot.</param>
    /// <param name="mainReplyMarkup">Reply markup selected for the current bot and user role, or null when no keyboard is required.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>True when this flow consumed the input, including handled validation or cancellation; false lets another route try it.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    public async Task<bool> TryHandleAccountCommentTextAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() ||
            string.IsNullOrWhiteSpace(message?.Text) ||
            user?.Flow != AccountCommentFlowName)
            return false;

        var text = message.Text.Trim();
        if (IsCancel(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "تغییر کامنت لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep != AccountCommentStepText)
            return false;

        if (IsBlankCommentInput(text))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "کامنت نمی‌تواند خالی یا «بدون کامنت» باشد. لطفاً متن کامنت جدید را ارسال کنید یا «انصراف» را بزنید.",
                cancellationToken: cancellationToken);
            return true;
        }

        if (!int.TryParse(user.ConfigLink, out var clientId) || clientId <= 0)
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "شناسه اکانت برای تغییر کامنت معتبر نیست. لطفاً دوباره از لیست اکانت‌ها اقدام کنید.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        var fromSearch = string.Equals(user.SelectedCountry, AccountCommentSourceSearch, StringComparison.OrdinalIgnoreCase);
        var page = int.TryParse(user.SubLink, out var parsedPage) ? parsedPage : 0;
        await ApplyAccountCommentAsync(
            botClient,
            message.Chat.Id,
            0,
            credUser,
            clientId,
            page,
            fromSearch,
            text,
            mainReplyMarkup,
            cancellationToken);

        await _state.ClearUserStatus(user);
        return true;
    }

    /// <summary>
    /// Handles slash-command activation and deactivation for one ownership-verified XUI v3 account.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned bot.</param>
    /// <param name="message">Incoming command containing an exact <c>/enable_</c> or <c>/disable_</c> target.</param>
    /// <param name="credUser">Bot user whose numeric Telegram id must own the selected panel account.</param>
    /// <param name="mainReplyMarkup">Main-menu keyboard restored after the operation or safe rejection.</param>
    /// <param name="cancellationToken">Token that cancels panel, audit, activity-log, and Telegram work.</param>
    /// <returns><c>true</c> when an account-state command was recognized; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// Authorization is revalidated before mutation. Every terminal panel outcome is written to the central logger
    /// with accumulated XUI API time and end-to-end operation time; wallet, order, and renewal state are unchanged.
    /// </remarks>
    public async Task<bool> TryHandleAccountActionAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();
        var enable = text.StartsWith("/enable_", StringComparison.OrdinalIgnoreCase);
        var disable = text.StartsWith("/disable_", StringComparison.OrdinalIgnoreCase);
        if (!enable && !disable)
            return false;

        var email = enable
            ? text.Substring("/enable_".Length)
            : text.Substring("/disable_".Length);

        if (string.IsNullOrWhiteSpace(email))
            return false;

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "لطفاً چند لحظه صبر کنید. در حال اعمال تغییر روی پنل نسخه ۳ هستم...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        using var operationTiming = XuiOperationTiming.Start();
        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            var client = await FindClientByEmailAsync(serverInfo, email, credUser.TelegramUserId, cancellationToken);
            if (client == null || !ClientBelongsToUser(client, credUser.TelegramUserId))
            {
                LogXuiOperationOutcome(
                    enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                    "اکانت پیدا نشد یا مجاز نبود",
                    credUser,
                    operationTiming,
                    accountEmail: email,
                    source: "command");
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            var updateResponse = await ApiServicev3.SetClientEnabledAsync(
                serverInfo,
                _configuration,
                client.Email ?? email,
                enable,
                credUser.TelegramUserId,
                cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: updateResponse.Success
                    ? "عملیات مورد نظر با موفقیت انجام شد."
                    : $"متاسفانه عملیات مورد نظر انجام نشد.\n{updateResponse.Msg}",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);

            if (updateResponse.Success)
            {
                await _activityLog.LogBotActionAsync(
                    enable ? "xui_v3_account_enabled" : "xui_v3_account_disabled",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["accountEmail"] = email,
                        ["panelUrl"] = serverInfo.Url,
                        ["rootPath"] = serverInfo.RootPath,
                        ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                        ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
                    },
                    cancellationToken);
            }

            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                updateResponse.Success ? "موفق" : "پنل تغییر را رد کرد",
                credUser,
                operationTiming,
                accountEmail: client.Email ?? email,
                source: "command");

            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] account action exception user={credUser.TelegramUserId}, email={email}: {ex}");
            await _activityLog.LogErrorAsync(
                "xui_v3_account_action_failed",
                ex,
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["accountEmail"] = email,
                    ["requestedAction"] = enable ? "enable" : "disable"
                },
                cancellationToken);
            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                $"خطا ({ex.GetType().Name})",
                credUser,
                operationTiming,
                accountEmail: email,
                source: "command");
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "در انجام عملیات خطا رخ داد. جزئیات در ترمینال ثبت شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }
    }

    /// <summary>
    /// Routes owned-bot renewal commands and text replies through the XUI v3 renewal state machine.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot that received the renewal input.</param>
    /// <param name="message">
    /// Customer or colleague message containing a renewal command, account identifier, traffic, preset/custom duration,
    /// or confirmation label depending on the current bot-scoped state.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials profile whose Telegram id, colleague role, and selected wallet determine ownership and price.
    /// </param>
    /// <param name="user">Current owned-bot users.db conversation state for the Telegram sender.</param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard restored after cancellation, failure, or completion.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram, users.db, XUI, pricing, and wallet operations.</param>
    /// <returns><c>true</c> when the input belonged to renewal handling; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// For the normal metered service, digit-only Latin, Persian, or Arabic-Indic duration input is saved as
    /// <c>days-N</c>. The duration is revalidated at confirmation against the current catalog before any wallet debit or
    /// XUI update. The standard state is <c>xui-v3-renew / renew-account</c>; legacy update state and <c>/renew_</c>
    /// input remain accepted. Email, SubId/subscription link, UUID, and supported configuration input all resolve
    /// without ownership filtering and store one panel-derived UUID target lock that survives payment-method selection.
    /// A non-owner target pauses at an explicit callback warning before plan selection. Every terminal lookup result
    /// clears only this bot/user state and exposes callback navigation to Home.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (await flowService.TryHandleRenewAsync(
    ///         botClient, message, credentialUser, botScopedUser, mainKeyboard, cancellationToken))
    ///     return;
    /// </code>
    /// </example>
    public async Task<bool> TryHandleRenewAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();
        if (user?.Flow == RenewFlowName)
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
                return true;

            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);
            if (user.LastStep == RenewStepAccount)
            {
                if (IsCancel(text))
                {
                    await _state.ClearUserStatus(user);
                    await botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "تمدید لغو شد.",
                        replyMarkup: mainReplyMarkup,
                        cancellationToken: cancellationToken);
                    return true;
                }

                await StartOwnedRenewSelectionAsync(
                    botClient,
                    message,
                    credUser,
                    user,
                    text,
                    cancellationToken);
                return true;
            }

            if (user.LastStep == RenewStepExternalTargetConfirmation)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "برای ادامه تمدید اکانت شخص دیگر، هشدار قبلی را با دکمه «ادامه تمدید همین اکانت» تأیید کنید یا به منوی اصلی برگردید.",
                    replyMarkup: BuildExternalRenewTargetConfirmationKeyboard(),
                    cancellationToken: cancellationToken);
                return true;
            }

            await HandleRenewFlowStepAsync(botClient, message, credUser, user, mainReplyMarkup, cancellationToken);
            return true;
        }

        if (IsRenewCommand(text))
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
                return true;

            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = RenewFlowName,
                LastStep = RenewStepAccount,
                RenewTargetUuid = string.Empty,
                PaymentMethod = "credit"
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "یکی از شناسه‌های اکانت نسخه ۳ را برای تمدید ارسال کنید:\n" +
                      "• نام اکانت (Email)\n" +
                      "• SubId یا لینک اشتراک\n" +
                      "• UUID\n" +
                      "• یکی از کانفیگ‌های VLESS، VMess، Trojan، Shadowsocks یا Hysteria\n\n" +
                      "تمدید اکانت شخص دیگر ممکن است، اما مالکیت یا دسترسی مدیریتی آن را تغییر نمی‌دهد.",
                replyMarkup: new ReplyKeyboardRemove(),
                cancellationToken: cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "برای خروج از فرایند تمدید از دکمه زیر استفاده کنید.",
                replyMarkup: BuildRenewHomeKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user?.Flow == "update" && user.LastStep == "Renew Existing Account" && !text.StartsWith("/renew_", StringComparison.OrdinalIgnoreCase))
            text = "/renew_" + text;

        if (!text.StartsWith("/renew_", StringComparison.OrdinalIgnoreCase))
            return false;

        if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
            return true;

        await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);

        var accountInput = NormalizeAccountNameInput(text.Substring("/renew_".Length));
        if (string.IsNullOrWhiteSpace(accountInput))
            return false;

        await StartOwnedRenewSelectionAsync(
            botClient,
            message,
            credUser,
            user,
            accountInput,
            cancellationToken);
        return true;
    }

    /// <summary>
    /// Resolves one owned-bot renewal target and advances the bot-scoped state to plan selection.
    /// </summary>
    /// <param name="botClient">Telegram client of the owned bot that received the renewal identifier.</param>
    /// <param name="message">Customer message whose sender and chat own the temporary renewal state.</param>
    /// <param name="credUser">Payer profile used for owner checks, role pricing, and later wallet settlement.</param>
    /// <param name="user">Current bot-scoped state row; legacy callers may pass the old update-flow state.</param>
    /// <param name="input">
    /// Exact account email, raw SubId/subscription link, normalized UUID, or a supported proxy configuration. Any
    /// identifier may locate another user's account, but only for renewal and only after an explicit warning callback.
    /// </param>
    /// <param name="cancellationToken">Token that cancels panel reads, state persistence, logging, and Telegram sends.</param>
    /// <returns>A task that completes after terminal cleanup or delivery of the next renewal selection prompt.</returns>
    /// <remarks>
    /// Raw identifiers and configuration links are never written to callbacks or logs. Exactly one client must match
    /// and expose a valid panel UUID. The email plus canonical UUID are persisted in bot-scoped state and revalidated
    /// before warning confirmation, preview, settlement, and XUI mutation.
    /// </remarks>
    private async Task StartOwnedRenewSelectionAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        string input,
        CancellationToken cancellationToken)
    {
        var lookupKind = "invalid";
        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "لطفاً چند لحظه صبر کنید. اکانت از پنل نسخه ۳ بررسی می‌شود...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
            if (!response.Success)
                throw new InvalidOperationException("The XUI client list request was unsuccessful.");

            var resolution = XuiV3RenewalTargetResolver.Resolve(response.Obj, input);
            lookupKind = resolution.InputKind?.ToString() ?? "invalid";
            var legacyOwnedWithoutUuid =
                resolution.Status == XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid &&
                ClientBelongsToUser(resolution.Client, credUser.TelegramUserId);
            if (!resolution.Success && !legacyOwnedWithoutUuid)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    BuildRenewTargetResolutionFailureText(resolution.Status),
                    cancellationToken);
                return;
            }

            var client = resolution.Client;

            if (!IsClientRenewable(client))
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "این اکانت مربوط به inboundهای فعال پلن‌های فعلی ربات نیست و از طریق ربات قابل تمدید نیست.",
                    cancellationToken);
                return;
            }

            var service = ResolveServiceForClient(client);
            if (service == null)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "برای این اکانت متادیتای سرویس نسخه ۳ پیدا نشد. لطفاً تمدید این اکانت را از بخش مدیریت انجام دهید.",
                    cancellationToken);
                return;
            }

            if (!ClientBelongsToUser(client, credUser.TelegramUserId))
            {
                await SaveOwnedExternalRenewWarningAsync(
                    botClient,
                    message.Chat.Id,
                    message.From.Id,
                    client,
                    service,
                    resolution.CanonicalUuid,
                    messageId: 0,
                    cancellationToken);
                return;
            }

            await StartOwnedRenewPlanSelectionAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                client,
                service,
                resolution.CanonicalUuid,
                credUser.IsColleague,
                messageId: 0,
                cancellationToken);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] renew target lookup failed user={credUser.TelegramUserId}, lookupKind={lookupKind}, errorType={ex.GetType().Name}");
            await _activityLog.LogErrorAsync(
                "xui_v3_renew_start_failed",
                new InvalidOperationException(
                    $"XUI renewal target lookup failed ({ex.GetType().Name})."),
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["lookupKind"] = lookupKind
                },
                cancellationToken);
            await SendOwnedRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                user,
                "در شروع تمدید نسخه ۳ خطا رخ داد. دوباره تلاش کنید.",
                cancellationToken);
        }
    }

    /// <summary>
    /// Maps a renewal target resolver failure to fixed Persian text that contains no customer identifier or panel data.
    /// </summary>
    /// <param name="status">Safe status returned by the shared renewal target resolver.</param>
    /// <returns>User-facing text describing how to retry without exposing email, UUID, SubId, password, or configuration.</returns>
    private static string BuildRenewTargetResolutionFailureText(XuiV3RenewalTargetResolutionStatus status)
    {
        return status switch
        {
            XuiV3RenewalTargetResolutionStatus.InvalidInput =>
                "شناسه ارسالی معتبر نیست. نام اکانت، SubId یا ساب‌لینک، UUID یا یکی از کانفیگ‌های پشتیبانی‌شده را ارسال کنید.",
            XuiV3RenewalTargetResolutionStatus.Ambiguous =>
                "این شناسه با بیش از یک اکانت تطبیق دارد و انتخاب خودکار آن امن نیست. UUID یا یک کانفیگ دقیق همان اکانت را ارسال کنید.",
            XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid =>
                "هویت دقیق این اکانت از پاسخ پنل قابل قفل‌کردن نیست و تمدید امن آن از ربات ممکن نشد.",
            _ => "اکانتی با شناسه ارسال‌شده پیدا نشد."
        };
    }

    /// <summary>
    /// Builds a non-sensitive Persian label for the shape of an exact renewal/search identifier.
    /// </summary>
    /// <param name="inputKind">Parsed input shape, or <c>null</c> when parsing did not complete.</param>
    /// <returns>A display label that never contains the identifier value itself.</returns>
    private static string BuildRenewInputKindLabel(XuiV3RenewalTargetInputKind? inputKind)
    {
        return inputKind switch
        {
            XuiV3RenewalTargetInputKind.Uuid => "UUID",
            XuiV3RenewalTargetInputKind.SubscriptionLink => "لینک اشتراک",
            XuiV3RenewalTargetInputKind.Configuration => "کانفیگ",
            _ => "Email یا SubId"
        };
    }

    /// <summary>
    /// Saves a non-owned renewal target and asks the payer to explicitly confirm the third-party warning.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="chatId">Telegram chat receiving the warning.</param>
    /// <param name="telegramUserId">Telegram id of the payer whose bot-scoped state is replaced.</param>
    /// <param name="client">Unique fresh panel client selected by the shared resolver.</param>
    /// <param name="service">Enabled service resolved from the client's metadata and inbounds.</param>
    /// <param name="canonicalUuid">Panel-derived canonical UUID used with the email to lock the target.</param>
    /// <param name="messageId">Search-result message to replace with the warning, or zero for a new message.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram operations.</param>
    /// <returns>A task that completes after the warning state and inline actions are delivered.</returns>
    /// <remarks>
    /// No wallet, order, ledger, or XUI mutation occurs. The callback contains no target identifier; continuation
    /// reloads this bot/user state and compares the saved email plus UUID with fresh panel data.
    /// </remarks>
    private async Task SaveOwnedExternalRenewWarningAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        long telegramUserId,
        XuiV3Client client,
        XuiV3ServiceDefinition service,
        string canonicalUuid,
        int messageId,
        CancellationToken cancellationToken)
    {
        // Keep the sensitive email/UUID pair only in this bot-scoped row; x3:rgo carries no reusable target identity.
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = telegramUserId,
            Flow = RenewFlowName,
            LastStep = RenewStepExternalTargetConfirmation,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = canonicalUuid,
            PaymentMethod = "credit"
        });

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            "⚠️ <b>هشدار تمدید اکانت شخص دیگر</b>\n\n" +
            $"اکانت پیدا شد: <code>{Html(client.Email)}</code>\n" +
            "این اکانت در این ربات متعلق به حساب شما نیست. پرداخت شما فقط همین اکانت را تمدید می‌کند و " +
            "مالکیت، کانفیگ‌ها یا دسترسی مدیریت آن را به شما منتقل نمی‌کند.\n\n" +
            "اگر شناسه را درست وارد کرده‌اید، ادامه تمدید همین اکانت را تأیید کنید.",
            ParseMode.Html,
            BuildExternalRenewTargetConfirmationKeyboard(),
            cancellationToken);
    }

    /// <summary>
    /// Persists one exact owned-bot renewal target and opens its traffic or unlimited-plan selector.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="chatId">Telegram chat receiving the target confirmation and plan keyboard.</param>
    /// <param name="telegramUserId">Telegram id of the payer whose bot-scoped state is replaced.</param>
    /// <param name="client">Fresh unique panel client to renew.</param>
    /// <param name="service">Current enabled service resolved for the client.</param>
    /// <param name="canonicalUuid">Panel-derived UUID persisted independently from payment method.</param>
    /// <param name="isColleague">Whether colleague pricing and unlimited-plan visibility apply to the payer.</param>
    /// <param name="messageId">Warning message to edit after confirmation, or zero to send a new target message.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram operations.</param>
    /// <returns>A task that completes after state replacement and delivery of the next reply keyboard.</returns>
    /// <remarks>
    /// Every client with a valid panel UUID, including an owned account selected by email, receives the same exact
    /// lock. An owned legacy client without a UUID retains owner checks; a non-owned client without a UUID is rejected.
    /// </remarks>
    private async Task StartOwnedRenewPlanSelectionAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        long telegramUserId,
        XuiV3Client client,
        XuiV3ServiceDefinition service,
        string canonicalUuid,
        bool isColleague,
        int messageId,
        CancellationToken cancellationToken)
    {
        // Replace the warning/search state atomically at the conversation level so stale callbacks cannot change target.
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = telegramUserId,
            Flow = RenewFlowName,
            LastStep = service.IsUnlimited ? RenewStepUnlimitedPlan : RenewStepTraffic,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = canonicalUuid,
            PaymentMethod = "credit"
        });

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            $"اکانت برای تمدید انتخاب شد: <code>{Html(client.Email)}</code>",
            ParseMode.Html,
            BuildRenewHomeKeyboard(),
            cancellationToken);
        await botClient.SendMessage(
            chatId: chatId,
            text: service.IsUnlimited
                ? "پلن تمدید نامحدود را انتخاب کنید:"
                : "حجم تمدید را انتخاب کنید:\nمی‌توانید یکی از دکمه‌ها را بزنید یا حجم دلخواه را به صورت عدد صحیح بفرستید؛ مثلا 7 یا ۷.",
            replyMarkup: service.IsUnlimited
                ? BuildUnlimitedPlanReplyKeyboard(service, isColleague)
                : BuildTrafficReplyKeyboard(service),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Confirms an owned-bot third-party renewal warning and advances only the exact state-bound target.
    /// </summary>
    /// <param name="botClient">Telegram client that received the fixed confirmation callback.</param>
    /// <param name="chatId">Telegram chat containing the warning.</param>
    /// <param name="messageId">Warning message id edited after successful confirmation.</param>
    /// <param name="credUser">Payer profile used for phone verification and colleague plan visibility.</param>
    /// <param name="user">Current bot-scoped state; it must be at the external-target confirmation step.</param>
    /// <param name="cancellationToken">Token that cancels panel, state, and Telegram operations.</param>
    /// <returns>A task that completes after safe rejection or delivery of the plan selector.</returns>
    /// <remarks>
    /// The fixed callback is not authorization. This method requires matching bot-scoped state, reloads by saved email,
    /// compares the exact saved UUID, and checks current plan eligibility before changing the state step.
    /// </remarks>
    private async Task HandleExternalRenewTargetConfirmationAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        User user,
        CancellationToken cancellationToken)
    {
        if (user == null ||
            !string.Equals(user.Flow, RenewFlowName, StringComparison.Ordinal) ||
            !string.Equals(user.LastStep, RenewStepExternalTargetConfirmation, StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(user.ConfigLink) ||
            string.IsNullOrWhiteSpace(user.RenewTargetUuid))
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                chatId,
                user ?? new User { Id = credUser.TelegramUserId },
                "این تایید قدیمی یا نامعتبر است. فرایند تمدید را دوباره شروع کنید.",
                cancellationToken);
            return;
        }

        var client = await GetAuthorizedRenewClientAsync(
            BuildConfiguredPanelServerInfo(),
            user,
            credUser.TelegramUserId,
            cancellationToken);
        var service = client == null || !IsClientRenewable(client) ? null : ResolveServiceForClient(client);
        if (client == null || service == null)
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                chatId,
                user,
                "اکانت هدف حذف شده، شناسه آن تغییر کرده یا دیگر در پلن‌های فعال قابل تمدید نیست.",
                cancellationToken);
            return;
        }

        await StartOwnedRenewPlanSelectionAsync(
            botClient,
            chatId,
            credUser.TelegramUserId,
            client,
            service,
            user.RenewTargetUuid,
            credUser.IsColleague,
            messageId,
            cancellationToken);
    }

    /// <summary>
    /// Builds the explicit third-party renewal confirmation and safe cancellation actions.
    /// </summary>
    /// <returns>An inline keyboard containing a fixed state-bound confirmation callback and the shared Home action.</returns>
    private static InlineKeyboardMarkup BuildExternalRenewTargetConfirmationKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "ادامه تمدید همین اکانت",
                    XuiV3PurchaseCallbacks.ConfirmExternalRenewTarget())
            },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });
    }

    /// <summary>
    /// Clears one owned-bot renewal state and sends a terminal result with an inline route back to the main menu.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="chatId">Telegram chat receiving the terminal renewal result.</param>
    /// <param name="user">Bot-scoped state whose Telegram user id identifies the row to clear.</param>
    /// <param name="text">Persian user-safe result text; it must not contain UUID, SubId, token, or panel response data.</param>
    /// <param name="cancellationToken">Token that cancels state cleanup and Telegram delivery.</param>
    /// <returns>A task that completes after state cleanup and message delivery.</returns>
    /// <remarks>No wallet, order, account, or other bot's state is changed.</remarks>
    private async Task SendOwnedRenewTerminalAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        User user,
        string text,
        CancellationToken cancellationToken)
    {
        await _state.ClearUserStatus(user);
        await botClient.SendMessage(
            chatId: chatId,
            text: text,
            replyMarkup: BuildRenewHomeKeyboard(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Builds the inline navigation attached to direct renewal prompts and terminal results.
    /// </summary>
    /// <returns>An inline keyboard whose callback clears only the current bot/user temporary state and shows home.</returns>
    private static InlineKeyboardMarkup BuildRenewHomeKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });
    }

    /// <summary>
    /// Runs the owned-bot confirmation flow that deletes the user's selected expired XUI v3 accounts.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned bot.</param>
    /// <param name="message">Incoming text used to start, confirm, cancel, or continue the deletion flow.</param>
    /// <param name="credUser">Bot user whose numeric Telegram id is rechecked against every panel account.</param>
    /// <param name="user">Bot-scoped persisted conversation state holding the confirmed account list.</param>
    /// <param name="mainReplyMarkup">Main-menu keyboard restored after cancellation or completion.</param>
    /// <param name="cancellationToken">Token that cancels panel, database, audit, and Telegram operations.</param>
    /// <returns><c>true</c> when the message belongs to this flow; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// The final pass revalidates ownership and expiry before mutation. Its success, partial success, and terminal
    /// failure audits contain accumulated panel API time and total operation time. No wallet is modified.
    /// </remarks>
    public async Task<bool> TryHandleDeleteExpiredAccountsAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();

        if (user?.Flow == DeleteExpiredFlowName && user.LastStep == DeleteExpiredStepConfirm)
        {
            if (IsCancel(text) || string.Equals(text, "انصراف", StringComparison.OrdinalIgnoreCase))
            {
                await _state.ClearUserStatus(user);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "عملیات حذف اکانت‌های منقضی لغو شد.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            if (!string.Equals(text, "تایید حذف اکانت های منقضی", StringComparison.OrdinalIgnoreCase))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "برای حذف اکانت‌های منقضی، دکمه تایید را بزنید یا انصراف دهید.",
                    replyMarkup: BuildDeleteExpiredConfirmKeyboard(),
                    cancellationToken: cancellationToken);
                return true;
            }

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "لطفاً چند لحظه صبر کنید. در حال حذف اکانت‌های منقضی شما از پنل نسخه ۳ هستم...",
                replyMarkup: new ReplyKeyboardRemove(),
                cancellationToken: cancellationToken);

            using var operationTiming = XuiOperationTiming.Start();
            try
            {
                var emails = DeserializeEmailList(user.SubLink);
                if (emails.Count == 0)
                {
                    await _state.ClearUserStatus(user);
                    await botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "لیست اکانت‌های منقضی خالی است. دوباره از منوی مدیریت اکانت اقدام کنید.",
                        replyMarkup: mainReplyMarkup,
                        cancellationToken: cancellationToken);
                    return true;
                }

                var serverInfo = BuildConfiguredPanelServerInfo();
                var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
                if (!clientsResponse.Success)
                {
                    LogXuiOperationOutcome(
                        "حذف انبوه اکانت‌های منقضی نسخه ۳",
                        "دریافت لیست از پنل ناموفق بود",
                        credUser,
                        operationTiming,
                        source: "owned-expired-delete");
                    await _state.ClearUserStatus(user);
                    await botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: $"دریافت اطلاعات اکانت‌ها ناموفق بود.\n{clientsResponse.Msg}",
                        replyMarkup: mainReplyMarkup,
                        cancellationToken: cancellationToken);
                    return true;
                }

                var eligibleClients = clientsResponse.Obj?
                    .Where(client => emails.Contains(client.Email, StringComparer.OrdinalIgnoreCase))
                    .Where(client => ClientBelongsToUser(client, credUser.TelegramUserId))
                    .Where(IsExpiredOrDepleted)
                    .OrderBy(client => client.Email)
                    .ToList() ?? new List<XuiV3Client>();

                if (eligibleClients.Count == 0)
                {
                    await _state.ClearUserStatus(user);
                    await botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "اکانت منقضی قابل حذفی برای شما پیدا نشد.",
                        replyMarkup: mainReplyMarkup,
                        cancellationToken: cancellationToken);
                    return true;
                }

                var eligibleEmails = eligibleClients.Select(client => client.Email).ToList();
                var bulkDeleteResponse = await ApiServicev3.BulkDeleteClientsAsync(serverInfo, _configuration, eligibleEmails, cancellationToken);
                var deleted = bulkDeleteResponse.Success ? eligibleEmails : new List<string>();
                var failed = bulkDeleteResponse.Success ? new List<string>() : eligibleEmails;

                await _state.ClearUserStatus(user);

                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: BuildDeleteExpiredResultText(deleted, failed, false, credUser.TelegramUserId),
                    parseMode: ParseMode.Html,
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);

                if (deleted.Count > 0)
                {
                    await _activityLog.LogBotActionAsync(
                        "xui_v3_expired_accounts_deleted",
                        credUser,
                        false,
                        new Dictionary<string, object>
                        {
                            ["deletedCount"] = deleted.Count,
                            ["failedCount"] = failed.Count,
                            ["deletedAccounts"] = string.Join(",", deleted),
                            ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                            ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
                        },
                        cancellationToken);

                    foreach (var deletedClient in eligibleClients.Where(client => deleted.Contains(client.Email, StringComparer.OrdinalIgnoreCase)))
                    {
                        await QueueGozargahSyncBestEffortAsync(
                            "owned-expired-delete",
                            () => _gozargahSiteSyncService.QueueDeleteAsync(
                                ResolveGozargahSiteOwnerTelegramUserId(credUser),
                                credUser.TelegramUserId,
                                deletedClient,
                                $"delete-expired-{deletedClient.Email}-{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}",
                                ResolveGozargahTenantBotId(),
                                cancellationToken: cancellationToken));
                    }
                }

                LogXuiOperationOutcome(
                    "حذف انبوه اکانت‌های منقضی نسخه ۳",
                    failed.Count == 0 ? "موفق" : deleted.Count > 0 ? "موفقیت جزئی" : "ناموفق",
                    credUser,
                    operationTiming,
                    source: "owned-expired-delete",
                    requestedCount: eligibleEmails.Count,
                    successfulCount: deleted.Count);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XUIv3] delete expired accounts exception user={credUser.TelegramUserId}: {ex}");
                await _activityLog.LogErrorAsync(
                    "xui_v3_delete_expired_accounts_failed",
                    ex,
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["telegramUserId"] = credUser.TelegramUserId
                    },
                    cancellationToken);
                LogXuiOperationOutcome(
                    "حذف انبوه اکانت‌های منقضی نسخه ۳",
                    $"خطا ({ex.GetType().Name})",
                    credUser,
                    operationTiming,
                    source: "owned-expired-delete");
                await _state.ClearUserStatus(user);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "در حذف اکانت‌های منقضی خطا رخ داد. جزئیات در لاگ ثبت شد.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }
        }

        if (!string.Equals(text, "حذف اکانت های منقضی", StringComparison.OrdinalIgnoreCase))
            return false;

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "لطفاً چند لحظه صبر کنید. در حال بررسی اکانت‌های منقضی شما روی پنل نسخه ۳ هستم...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
            if (!response.Success)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: $"دریافت اطلاعات اکانت‌ها ناموفق بود.\n{response.Msg}",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            var expiredClients = response.Obj?
                .Where(client => ClientBelongsToUser(client, credUser.TelegramUserId))
                .Where(IsExpiredOrDepleted)
                .OrderBy(client => client.Email)
                .ToList() ?? new List<XuiV3Client>();

            if (expiredClients.Count == 0)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "هیچ اکانت منقضی یا تمام‌شده‌ای برای شما پیدا نشد.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }

            await _state.ClearUserStatus(new User { Id = message.From.Id });
            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = DeleteExpiredFlowName,
                LastStep = DeleteExpiredStepConfirm,
                SubLink = JsonConvert.SerializeObject(expiredClients.Select(client => client.Email).ToList())
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: BuildDeleteExpiredConfirmationText(expiredClients, false, credUser.TelegramUserId),
                parseMode: ParseMode.Html,
                replyMarkup: BuildDeleteExpiredConfirmKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] delete expired accounts prepare exception user={credUser.TelegramUserId}: {ex}");
            await _activityLog.LogErrorAsync(
                "xui_v3_delete_expired_accounts_prepare_failed",
                ex,
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["telegramUserId"] = credUser.TelegramUserId
                },
                cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "در بررسی اکانت‌های منقضی خطا رخ داد. جزئیات در لاگ ثبت شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }
    }

    /// <summary>
    /// Handles a text step in the owned-bot XUI v3 renewal flow.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client for the currently active owned bot that received the renewal message.
    /// </param>
    /// <param name="message">
    /// Customer or colleague message containing either a cancellation command or a manually entered
    /// renewal traffic amount in GB.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials profile for the Telegram sender. The colleague flag on this profile controls
    /// renewal pricing and wallet checks.
    /// </param>
    /// <param name="user">
    /// Bot-scoped conversation state for the renewal flow. The selected service key and target account
    /// are read from this state and cleared when the flow is cancelled or becomes invalid.
    /// </param>
    /// <param name="mainReplyMarkup">
    /// Reply keyboard used when the renewal flow ends, is cancelled, or must return the user to the main menu.
    /// </param>
    /// <param name="cancellationToken">
    /// Cancellation token for Telegram, database, pricing, and state persistence operations.
    /// </param>
    /// <remarks>
    /// The method validates typed traffic against the service-level minimum and typed duration days against the
    /// current normal-service custom-duration range in <c>xui-v3-service-plans.json</c>. Invalid input keeps the user
    /// inside the same renewal step. A valid custom duration is persisted as <c>days-N</c> and revalidated by the
    /// central resolver before wallet debit or XUI renewal. Before preview, every new target is freshly reloaded and
    /// must still match its saved email plus UUID; legacy states without a lock remain owner-only. The preview also
    /// checks the durable account-level operation lock, so an unresolved prior renewal cannot reach another payment
    /// confirmation while automatic reconciliation is active.
    /// When a duration is disabled between preview and confirmation, an explicit empty string clears only the stored
    /// duration while the bot-scoped target-account UUID lock and the other renewal fields remain intact. A disabled
    /// unlimited sub-plan similarly returns to the current plan keyboard without consuming confirmation or charging.
    /// </remarks>
    /// <returns>A task that completes after the current state transition and Telegram response.</returns>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during Telegram, database, pricing, or panel work.
    /// </exception>
    private async Task HandleRenewFlowStepAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (IsCancel(message.Text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "تمدید لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        var service = FindService(user.SelectedCountry);
        if (service == null)
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                user,
                "سرویس تمدید پیدا نشد. دوباره از منوی تمدید اقدام کنید.",
                cancellationToken);
            return;
        }

        if (user.LastStep == RenewStepTraffic)
        {
            if (!TryGetTrafficGbFromText(message.Text, out var trafficGb) || trafficGb <= 0)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "حجم معتبر نیست. یکی از دکمه‌ها را بزنید یا فقط عدد صحیح بفرستید؛ مثلا 7 یا ۷.",
                    replyMarkup: BuildTrafficReplyKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            if (!XuiV3PurchaseService.MeetsMinimumTraffic(service, trafficGb))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: BuildMinimumTrafficMessage(service),
                    replyMarkup: BuildTrafficReplyKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = RenewFlowName,
                LastStep = RenewStepDuration,
                TotoalGB = trafficGb.ToString()
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: XuiV3PurchaseService.BuildDurationSelectionText(service, "مدت تمدید را انتخاب کنید:"),
                replyMarkup: BuildDurationReplyKeyboard(service),
                cancellationToken: cancellationToken);
            return;
        }

        if (user.LastStep == RenewStepDuration)
        {
            var duration = TryGetDurationFromText(service, message.Text);
            if (duration == null)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        "مدت معتبر نیست. یکی از گزینه‌های لیست را انتخاب کنید."),
                    replyMarkup: BuildDurationReplyKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = RenewFlowName,
                LastStep = RenewStepConfirm,
                SelectedPeriod = duration.Key,
                // Stable exactly-once identity for this confirm step: redelivery, repeated presses, and
                // restarts all resolve to the same renewal operation until the conversation is cleared.
                RenewalSessionId = Guid.NewGuid().ToString("N")
            });

            var refreshedUser = await _state.GetUserStatus(message.From.Id);
            var previewClient = await GetAuthorizedRenewClientAsync(
                BuildConfiguredPanelServerInfo(),
                refreshedUser,
                credUser.TelegramUserId,
                cancellationToken);
            if (previewClient == null)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    refreshedUser,
                    "اکانت هدف تمدید حذف شده یا شناسه آن تغییر کرده است. فرایند را دوباره شروع کنید.",
                    cancellationToken);
                return;
            }

            if (await _renewalOperationStore.FindBlockingOperationAsync(
                    previewClient.Uuid,
                    previewClient.Email,
                    cancellationToken: cancellationToken) != null)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    refreshedUser,
                    "یک تمدید قبلی برای این اکانت در حال بررسی خودکار است. تمدید جدید تا مشخص‌شدن نتیجه موقتاً قفل است.",
                    cancellationToken);
                return;
            }

            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);
            var canUseSiteWallet = await CanUseGozargahSiteWalletAsync(
                credUser.TelegramUserId,
                ResolveRenewPriceToman(refreshedUser, credUser.IsColleague),
                cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: BuildRenewSummary(refreshedUser, credUser.IsColleague, credUser.TelegramUserId, previewClient),
                parseMode: ParseMode.Html,
                replyMarkup: BuildConfirmReplyKeyboard(canUseSiteWallet),
                cancellationToken: cancellationToken);
            return;
        }

        if (user.LastStep == RenewStepUnlimitedPlan)
        {
            var plan = TryGetUnlimitedPlanFromText(service, message.Text, credUser.IsColleague);
            if (plan == null)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "پلن معتبر نیست. یکی از گزینه‌های لیست را انتخاب کنید.",
                    replyMarkup: BuildUnlimitedPlanReplyKeyboard(service, credUser.IsColleague),
                    cancellationToken: cancellationToken);
                return;
            }

            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = RenewFlowName,
                LastStep = RenewStepConfirm,
                Type = plan.Key,
                // Stable exactly-once identity for this confirm step (see the metered duration transition).
                RenewalSessionId = Guid.NewGuid().ToString("N")
            });

            var refreshedUser = await _state.GetUserStatus(message.From.Id);
            var previewClient = await GetAuthorizedRenewClientAsync(
                BuildConfiguredPanelServerInfo(),
                refreshedUser,
                credUser.TelegramUserId,
                cancellationToken);
            if (previewClient == null)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    refreshedUser,
                    "اکانت هدف تمدید حذف شده یا شناسه آن تغییر کرده است. فرایند را دوباره شروع کنید.",
                    cancellationToken);
                return;
            }

            if (await _renewalOperationStore.FindBlockingOperationAsync(
                    previewClient.Uuid,
                    previewClient.Email,
                    cancellationToken: cancellationToken) != null)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    refreshedUser,
                    "یک تمدید قبلی برای این اکانت در حال بررسی خودکار است. تمدید جدید تا مشخص‌شدن نتیجه موقتاً قفل است.",
                    cancellationToken);
                return;
            }

            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);
            var canUseSiteWallet = await CanUseGozargahSiteWalletAsync(
                credUser.TelegramUserId,
                ResolveRenewPriceToman(refreshedUser, credUser.IsColleague),
                cancellationToken);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: BuildRenewSummary(refreshedUser, credUser.IsColleague, credUser.TelegramUserId, previewClient),
                parseMode: ParseMode.Html,
                replyMarkup: BuildConfirmReplyKeyboard(canUseSiteWallet),
                cancellationToken: cancellationToken);
            return;
        }

        if (user.LastStep == RenewStepConfirm)
        {
            var wantsSiteWalletRenew = message.Text.Trim().Equals("تایید تمدید با کیف پول سایت", StringComparison.OrdinalIgnoreCase);
            if (!message.Text.Trim().Equals("تایید تمدید", StringComparison.OrdinalIgnoreCase) && !wantsSiteWalletRenew)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "برای تمدید، گزینه تایید تمدید را بزنید.",
                    replyMarkup: BuildConfirmReplyKeyboard(),
                    cancellationToken: cancellationToken);
                return;
            }

            if (!service.IsUnlimited &&
                !XuiV3PurchaseService.TryResolveDurationKey(service, user.SelectedPeriod, out _))
            {
                user.LastStep = RenewStepDuration;
                user.SelectedPeriod = string.Empty;
                await _state.SaveUserStatus(user);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        "مدت انتخاب‌شده دیگر معتبر نیست. مدت جدید را انتخاب کنید."),
                    replyMarkup: BuildDurationReplyKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            var selectedUnlimitedPlan = service.IsUnlimited
                ? service.UnlimitedPlans?.FirstOrDefault(plan =>
                    string.Equals(plan.Key, user.Type, StringComparison.OrdinalIgnoreCase))
                : null;
            if (service.IsUnlimited &&
                !XuiV3PurchaseService.IsUnlimitedPlanAvailableForOwnedBot(
                    selectedUnlimitedPlan,
                    credUser.IsColleague))
            {
                user.LastStep = RenewStepUnlimitedPlan;
                user.Type = string.Empty;
                await _state.SaveUserStatus(user);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "پلن نامحدود انتخاب‌شده دیگر فعال نیست. پلن جدید را انتخاب کنید.",
                    replyMarkup: BuildUnlimitedPlanReplyKeyboard(service, credUser.IsColleague),
                    cancellationToken: cancellationToken);
                return;
            }

            if (string.Equals(user.PaymentMethod, LegacyExternalUuidRenewPaymentMethod, StringComparison.OrdinalIgnoreCase) &&
                string.IsNullOrWhiteSpace(user.RenewTargetUuid))
            {
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "این درخواست قدیمی تمدید UUID قابل اعتبارسنجی نیست. لطفاً UUID را دوباره ارسال کنید.",
                    cancellationToken);
                return;
            }

            user.PaymentMethod = wantsSiteWalletRenew ? "gozargah_site_wallet" : "credit";
            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);
            await CompleteRenewAsync(botClient, message, credUser, user, mainReplyMarkup, cancellationToken);
        }
    }

    /// <summary>
    /// Applies an owned-bot account renewal on XUI and settles the exact selected wallet after panel success.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot used for progress and result messages.</param>
    /// <param name="message">Customer confirmation message containing the Telegram user and chat identifiers.</param>
    /// <param name="credUser">
    /// Shared credentials profile of the customer or colleague. Its bot-wallet balance is debited when selected
    /// directly or when a selected Gozargah website-wallet debit cannot be completed.
    /// </param>
    /// <param name="user">
    /// Bot-scoped renewal state containing the target account, service, plan, and selected payment method.
    /// </param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard restored after the renewal flow finishes.</param>
    /// <param name="cancellationToken">
    /// Token that cancels Telegram, XUI, website, ledger, and state operations. If it is already cancelled after a
    /// successful XUI update and failed website debit, the compensating local debit and ledger use a non-cancelled token
    /// so cancellation cannot leave the renewal unpaid.
    /// </param>
    /// <returns>A task that completes after renewal, financial settlement, audit logging, and customer notification.</returns>
    /// <remarks>
    /// XUI is updated before a website-wallet debit because the website must not be charged for a failed renewal.
    /// To prevent a successful XUI renewal from becoming free, any unavailable, insufficient, failed, or exceptional
    /// website debit falls back to the bot wallet and may make it negative. Explicit bot/site bans do not use fallback.
    /// The bot-wallet mutation and users.db ledger append are separate database operations; the ledger records the
    /// actual before/after balance and provider so administrators can audit the compensation path. When the selected
    /// bot wallet is insufficient, the customer receives an inline shortcut to the owned-wallet charge flow. After
    /// the panel update and any required counter reset, the volume-reminder cycle is advanced best-effort; failure of
    /// that auxiliary users.db write is logged and never changes the successful renewal or its financial settlement.
    /// Every new renewal reloads the target by email and requires its UUID to equal the independent persisted target
    /// lock before the panel call. The payer is recorded as the renewal actor but never replaces the existing owner,
    /// TgId, SubId, UUID, password, or protocol identity. Legacy states without a lock remain owner-only.
    /// Unlimited selections are resolved through the owned-audience gate immediately before balance and XUI work, so
    /// a role or catalog change cannot turn a colleague-only plan into an ordinary-customer renewal.
    /// The final central audit includes accumulated panel API time and total time from execution start through
    /// settlement and customer delivery; customer decision and payment waiting time are excluded.
    /// </remarks>
    private async Task CompleteRenewAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        var service = FindService(user.SelectedCountry);
        var selection = service.IsUnlimited
            ? new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = user.Type }
            : new XuiV3PurchaseSelection
            {
                ServiceKey = service.Key,
                TrafficGb = int.TryParse(user.TotoalGB, out var trafficGb) ? trafficGb : 0,
                DurationKey = user.SelectedPeriod
            };

        var resolved = _purchaseService.ResolveOwnedPurchase(selection, credUser.IsColleague);
        var useSiteWallet = string.Equals(user.PaymentMethod, "gozargah_site_wallet", StringComparison.OrdinalIgnoreCase);
        if (!useSiteWallet && credUser.AccountBalance < resolved.PriceToman)
        {
            await _activityLog.LogWarningAsync(
                "xui_v3_renew_insufficient_balance",
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["accountEmail"] = user.ConfigLink,
                    ["serviceKey"] = service.Key,
                    ["priceToman"] = resolved.PriceToman,
                    ["balanceToman"] = credUser.AccountBalance
                },
                cancellationToken);

            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "⛔️ موجودی کیف پول شما برای تمدید کافی نیست.\n" +
                      $"💳 موجودی فعلی: {credUser.AccountBalance.FormatCurrency()}\n" +
                      $"💰 مبلغ مورد نیاز: {resolved.PriceToman.FormatCurrency()}\n\n" +
                      "برای ادامه، کیف پول خود را شارژ کنید.",
                replyMarkup: BuildOwnedWalletChargeShortcutKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        GozargahSiteWalletEligibility siteWalletEligibility = null;
        if (useSiteWallet)
        {
            siteWalletEligibility = await _gozargahSiteSyncService.CheckSiteWalletEligibilityAsync(
                credUser.TelegramUserId,
                resolved.PriceToman,
                cancellationToken);
            if (!siteWalletEligibility.CanUse && siteWalletEligibility.IsBlocked)
            {
                await _state.ClearUserStatus(user);
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: $"پرداخت تمدید با کیف پول سایت گذرگاه ممکن نیست.\n{siteWalletEligibility.Message}",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return;
            }
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "در حال تمدید اکانت نسخه ۳...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        using var operationTiming = XuiOperationTiming.Start();
        var serverInfo = BuildConfiguredPanelServerInfo();
        var hasExactTargetLock = !string.IsNullOrWhiteSpace(user.RenewTargetUuid);
        Console.WriteLine(
            $"[XUIv3] renew confirm user={credUser.TelegramUserId}, service={service.Key}, authorization={(hasExactTargetLock ? "target-lock" : "legacy-owner")}");

        // Exactly-once renewal guard: one stable operation row per confirmation session. Telegram redelivery,
        // repeated confirm presses, concurrent duplicate requests, XUI timeouts, and process restarts all resolve
        // to the same row, so only one executor ever sends the XUI mutation and settles the wallet.
        var renewalOperationKey = BuildOwnedRenewalOperationKey(user, service, resolved, credUser);
        var existingOperation = await _renewalOperationStore.GetByKeyAsync(renewalOperationKey, cancellationToken);
        if (existingOperation != null)
        {
            await HandleExistingOwnedRenewalOperationAsync(
                botClient,
                message,
                credUser,
                user,
                mainReplyMarkup,
                service,
                resolved,
                useSiteWallet,
                existingOperation,
                operationTiming,
                cancellationToken);
            return;
        }

        var client = await GetAuthorizedRenewClientAsync(serverInfo, user, credUser.TelegramUserId, cancellationToken);
        client = await LoadFreshRenewClientSnapshotAsync(serverInfo, client, cancellationToken);
        if (client == null)
        {
            LogXuiOperationOutcome(
                "تمدید اکانت نسخه ۳",
                "هدف تمدید پیدا نشد یا تغییر کرده است",
                credUser,
                operationTiming,
                accountEmail: user.ConfigLink,
                source: "renew");
            await SendOwnedRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                user,
                hasExactTargetLock
                    ? "اکانت هدف حذف شده یا شناسه آن تغییر کرده است."
                    : "اکانت برای تمدید پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken);
            return;
        }

        var currentExpiryBeforeRenew = GetExpiryTime(client);

        var blockingOperation = await _renewalOperationStore.FindBlockingOperationAsync(
            client.Uuid,
            client.Email,
            renewalOperationKey,
            cancellationToken);
        if (blockingOperation != null)
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                user,
                "یک تمدید قبلی برای این اکانت هنوز در حال بررسی خودکار است. برای جلوگیری از تمدید تکراری، تمدید جدید این اکانت موقتاً قفل شده است.",
                cancellationToken);
            return;
        }

        var renewal = XuiV3RenewalPolicy.Calculate(
            client,
            resolved,
            hasExactTargetLock ? "locked-target-renew" : "legacy-owner-renew",
            credUser.TelegramUserId,
            allowActorAsOwnerFallback: !hasExactTargetLock);
        var payload = renewal.Payload;
        Console.WriteLine(
            $"[XUIv3] renew payload user={credUser.TelegramUserId}, clientId={client.Id}, durationDays={resolved.DurationDays}, currentExpiry={currentExpiryBeforeRenew}, newExpiry={payload.ExpiryTime}, resetTraffic={renewal.ShouldResetTraffic}, totalBytesAfter={renewal.TotalBytesAfterRenew}, targetAvailableBytes={renewal.TargetAvailableTrafficBytes}");

        // Persist the absolute target exactly once before the mutation. If a concurrent duplicate inserted the
        // same operation first, resolve that row instead of computing or sending anything new.
        XuiV3RenewalOperation renewalOperation;
        try
        {
            renewalOperation = await CreateOwnedRenewalOperationAsync(
                renewalOperationKey,
                user,
                credUser,
                service,
                resolved,
                client,
                renewal,
                useSiteWallet,
                cancellationToken);
        }
        catch (XuiV3RenewalOperationStore.AccountRenewalLockedException)
        {
            // The filtered unique account index is the final guard when two different confirmation sessions race.
            await SendOwnedRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                user,
                "یک تمدید قبلی برای این اکانت هنوز در حال بررسی خودکار است. برای جلوگیری از تمدید تکراری، تمدید جدید این اکانت موقتاً قفل شده است.",
                cancellationToken);
            return;
        }
        if (renewalOperation == null)
        {
            var racedOperation = await _renewalOperationStore.GetByKeyAsync(renewalOperationKey, cancellationToken);
            if (racedOperation != null)
            {
                await HandleExistingOwnedRenewalOperationAsync(
                    botClient,
                    message,
                    credUser,
                    user,
                    mainReplyMarkup,
                    service,
                    resolved,
                    useSiteWallet,
                    racedOperation,
                    operationTiming,
                    cancellationToken);
            }

            return;
        }

        if (!await _renewalOperationStore.TryClaimFreshAsync(renewalOperation, cancellationToken))
        {
            await HandleExistingOwnedRenewalOperationAsync(
                botClient,
                message,
                credUser,
                user,
                mainReplyMarkup,
                service,
                resolved,
                useSiteWallet,
                renewalOperation,
                operationTiming,
                cancellationToken);
            return;
        }

        if (!await _renewalOperationStore.MarkMutationStartedAsync(renewalOperation, cancellationToken))
        {
            await HandleExistingOwnedRenewalOperationAsync(
                botClient, message, credUser, user, mainReplyMarkup, service, resolved, useSiteWallet,
                renewalOperation, operationTiming, cancellationToken);
            return;
        }

        var mutationSucceeded = false;
        try
        {
            // The renewal mutation is sent exactly once with the absolute target; it is never blindly retried.
            var updateResponse = await ApiServicev3.UpdateClientAsync(
                serverInfo,
                _configuration,
                client.Email,
                payload,
                cancellationToken,
                XuiV3RequestRetryMode.NoAutomaticRetry);
            mutationSucceeded = updateResponse.Success;
            if (!mutationSucceeded)
            {
                await _renewalOperationStore.MarkFailedAsync(
                    renewalOperation,
                    SanitizeRenewalFailure(updateResponse.Msg),
                    cancellationToken);

                await _activityLog.LogWarningAsync(
                    "xui_v3_account_renew_failed",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["renewalOperationId"] = renewalOperation.OperationId,
                        ["serviceKey"] = service.Key,
                        ["clientId"] = client.Id,
                        ["result"] = "panel-update-rejected"
                    },
                    cancellationToken);

                LogXuiOperationOutcome(
                    "تمدید اکانت نسخه ۳",
                    "پنل تمدید را رد کرد",
                    credUser,
                    operationTiming,
                    accountEmail: client.Email,
                    source: "renew");

                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "تمدید در پنل انجام نشد. لطفاً دوباره تلاش کنید.",
                    cancellationToken);
                return;
            }
        }
        catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
        {
            // Ambiguous timeout/network failure: never send another update. Read the panel back and compare its
            // state with the stored absolute target; only then decide applied versus ambiguous.
            var (comparison, _) = await _renewalOperationStore.RecoverByReadBackAsync(
                renewalOperation,
                serverInfo,
                _configuration,
                cancellationToken);
            if (comparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Applied)
            {
                mutationSucceeded = true;
                _logger.LogInformation(
                    "XUI v3 renewal recovered after an ambiguous timeout; the panel already holds the target. renewalOperationId={RenewalOperationId}, accountEmail={AccountEmail}",
                    renewalOperation.OperationId,
                    client.Email);
            }
            else
            {
                var ambiguousReason = comparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Unavailable
                    ? "XUI update timed out and the read-back could not determine whether the renewal was applied."
                    : "XUI update timed out and the read-back showed the target was not applied; the panel may still commit it later.";
                await _renewalOperationStore.MarkAmbiguousAsync(
                    renewalOperation,
                    ambiguousReason,
                    cancellationToken,
                    comparison);

                await _activityLog.LogWarningAsync(
                    "xui_v3_renew_ambiguous",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["renewalOperationId"] = renewalOperation.OperationId,
                        ["accountEmail"] = client.Email,
                        ["serviceKey"] = service.Key,
                        ["error"] = ex.Message ?? string.Empty
                    },
                    cancellationToken);

                _logger.LogWarning(
                    ex,
                    "XUI v3 renewal outcome is ambiguous; the mutation will not be replayed. renewalOperationId={RenewalOperationId}, accountEmail={AccountEmail}",
                    renewalOperation.OperationId,
                    client.Email);

                LogXuiOperationOutcome(
                    "تمدید اکانت نسخه ۳",
                    "نتیجه پنل مبهم؛ تمدید تکراری اجرا نشد",
                    credUser,
                    operationTiming,
                    accountEmail: client.Email,
                    source: "renew");

                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "نتیجه تمدید در پنل هنوز قطعی نیست. درخواست به‌صورت خودکار بررسی می‌شود و برای جلوگیری از تمدید تکراری، تمدید جدید این اکانت موقتاً قفل است.",
                    cancellationToken);
                return;
            }
        }

        if (!await _renewalOperationStore.MarkAppliedAsync(renewalOperation, cancellationToken))
        {
            // Another executor already applied this operation (concurrent duplicate or crash take-over).
            await ReconcileAppliedOwnedRenewalAsync(
                botClient,
                message,
                credUser,
                user,
                mainReplyMarkup,
                service,
                resolved,
                useSiteWallet,
                renewalOperation,
                operationTiming,
                cancellationToken);
            return;
        }

        _logger.LogInformation(
            "XUI v3 renewal applied exactly once. renewalOperationId={RenewalOperationId}, accountEmail={AccountEmail}, targetTotalBytes={TargetTotalBytes}, targetExpiryTime={TargetExpiryTime}",
            renewalOperation.OperationId,
            client.Email,
            payload.TotalGB,
            payload.ExpiryTime);

        await CompleteAppliedOwnedRenewalAsync(
            botClient,
            message,
            credUser,
            user,
            mainReplyMarkup,
            service,
            resolved,
            useSiteWallet,
            renewalOperation,
            client,
            renewal,
            payload,
            siteWalletEligibility,
            operationTiming,
            cancellationToken);
    }

    /// <summary>
    /// Builds the stable exactly-once operation key for one owned-bot renewal confirmation.
    /// </summary>
    /// <param name="user">Bot-scoped renewal state containing the target email, UUID lock, and renewal session.</param>
    /// <param name="service">Resolved service definition that priced the renewal.</param>
    /// <param name="resolved">Resolved purchase containing traffic, duration, and price.</param>
    /// <param name="credUser">Payer profile used only for the legacy intent fallback hash.</param>
    /// <returns>
    /// The session-based key when the confirm step has a renewal session, otherwise an intent-hash key so legacy
    /// in-flight confirmations still deduplicate.
    /// </returns>
    /// <remarks>
    /// The session is generated once when the flow enters the confirm step and is cleared with the conversation
    /// after the renewal finishes, so a later legitimate renewal of the same account receives a brand-new key.
    /// </remarks>
    private string BuildOwnedRenewalOperationKey(
        User user,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        CredUser credUser)
    {
        var botId = BotContextAccessor.CurrentBotId;
        if (!string.IsNullOrWhiteSpace(user.RenewalSessionId))
            return "renew-" + botId + "-" + user.RenewalSessionId;

        var intent = string.Join(
            "|",
            botId,
            user.ConfigLink ?? string.Empty,
            user.RenewTargetUuid ?? string.Empty,
            service?.Key ?? string.Empty,
            resolved.TrafficGb.ToString(),
            resolved.IsUnlimited ? user.Type ?? string.Empty : user.SelectedPeriod ?? string.Empty,
            user.PaymentMethod ?? "credit",
            resolved.PriceToman.ToString());
        return "renew-intent-" + StableHash(intent);
    }

    /// <summary>
    /// Computes a stable 40-character SHA-256 hash for legacy renewal intent deduplication.
    /// </summary>
    /// <param name="value">Intent text containing no secrets beyond the existing bot/user/target identifiers.</param>
    /// <returns>A stable lowercase hex prefix of the SHA-256 digest.</returns>
    private static string StableHash(string value)
    {
        using var sha = System.Security.Cryptography.SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(value ?? string.Empty));
        return Convert.ToHexString(bytes)[..40].ToLowerInvariant();
    }

    /// <summary>
    /// Persists a new renewal operation with the exact absolute target before the XUI mutation.
    /// </summary>
    /// <param name="operationKey">Stable deduplication key for this confirmation.</param>
    /// <param name="user">Bot-scoped renewal state supplying the UUID lock and payment method.</param>
    /// <param name="credUser">Payer whose Telegram id is recorded as the operation actor.</param>
    /// <param name="service">Resolved service definition.</param>
    /// <param name="resolved">Resolved purchase containing traffic, duration, and price.</param>
    /// <param name="client">Fresh panel client whose pre-renewal state is snapshotted.</param>
    /// <param name="renewal">Renewal calculation containing the absolute target payload.</param>
    /// <param name="useSiteWallet">Whether the Gozargah site wallet was selected for payment.</param>
    /// <param name="cancellationToken">Token that cancels the users.db insert.</param>
    /// <returns>
    /// The newly created operation, or <c>null</c> when a concurrent duplicate inserted the same key first. Callers
    /// must resolve the existing row instead of mutating XUI when null is returned.
    /// </returns>
    private async Task<XuiV3RenewalOperation> CreateOwnedRenewalOperationAsync(
        string operationKey,
        User user,
        CredUser credUser,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        XuiV3Client client,
        XuiV3RenewalCalculation renewal,
        bool useSiteWallet,
        CancellationToken cancellationToken)
    {
        var draft = new XuiV3RenewalOperationStore.RenewalOperationDraft
        {
            OperationKey = operationKey,
            BotId = BotContextAccessor.CurrentBotId,
            TenantBotId = null,
            TenantBotOrderId = null,
            TelegramUserId = credUser.TelegramUserId,
            TargetEmail = client.Email,
            // The durable account lock always uses the freshly loaded panel identity, including legacy owner flows.
            TargetUuid = client.Uuid ?? string.Empty,
            ServiceKey = service?.Key,
            AddedTrafficGb = resolved.TrafficGb,
            AddedTrafficBytes = resolved.TrafficBytes,
            AddedDurationDays = resolved.DurationDays,
            PriceToman = resolved.PriceToman,
            PaymentMethod = useSiteWallet ? "gozargah_site_wallet" : "credit",
            ExpectedTotalBytesBefore = renewal.CurrentTotalBytes,
            ExpectedExpiryTimeBefore = renewal.CurrentExpiryTime,
            TargetTotalBytes = renewal.Payload.TotalGB,
            TargetExpiryTime = renewal.Payload.ExpiryTime,
            MutationPayloadJson = JsonConvert.SerializeObject(renewal.Payload),
            PreMutationSnapshotJson = XuiV3RenewalOperationStore.BuildPreMutationSnapshotJson(client),
            ShouldResetTraffic = renewal.ShouldResetTraffic,
            IsUnlimited = renewal.IsUnlimited,
            ExpectedInboundIds = client.InboundIds ?? new List<int>()
        };

        var (operation, created) = await _renewalOperationStore.CreateOrGetAsync(draft, cancellationToken);
        return created ? operation : null;
    }

    /// <summary>
    /// Resolves an already-existing renewal operation without sending any new XUI mutation.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="message">Duplicate confirmation message.</param>
    /// <param name="credUser">Payer profile.</param>
    /// <param name="user">Bot-scoped renewal state.</param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard.</param>
    /// <param name="service">Resolved service definition.</param>
    /// <param name="resolved">Resolved purchase containing price and plan.</param>
    /// <param name="useSiteWallet">Whether the site wallet was selected.</param>
    /// <param name="operation">Existing operation row returned by the deduplication lookup.</param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, users.db, and panel operations.</param>
    /// <returns>A task that completes after the duplicate confirmation is resolved without a second mutation.</returns>
    /// <remarks>
    /// Applied operations are reconciled (settlement and single log finish exactly once); ambiguous operations are
    /// reconciled by a read-only read-back; failed operations are terminal; pending/processing operations with a
    /// live or expired lease are reported as locked. Once a mutation may have started, reconciliation is GET-only and
    /// no stored payload is ever replayed.
    /// </remarks>
    private async Task HandleExistingOwnedRenewalOperationAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        bool useSiteWallet,
        XuiV3RenewalOperation operation,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        switch (operation.Status)
        {
            case XuiV3RenewalOperationStatuses.Applied:
                await ReconcileAppliedOwnedRenewalAsync(
                    botClient, message, credUser, user, mainReplyMarkup, service, resolved, useSiteWallet,
                    operation, operationTiming, cancellationToken);
                return;

            case XuiV3RenewalOperationStatuses.Ambiguous:
                await ReconcileAmbiguousOwnedRenewalAsync(
                    botClient, message, credUser, user, mainReplyMarkup, service, resolved, useSiteWallet,
                    operation, operationTiming, cancellationToken);
                return;

            case XuiV3RenewalOperationStatuses.ManualReview:
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "نتیجه تمدید قبلی پس از بررسی خودکار قطعی نشده و برای بررسی دستی ثبت شده است. تمدید جدید این اکانت تا تعیین نتیجه قفل می‌ماند.",
                    cancellationToken);
                return;

            case XuiV3RenewalOperationStatuses.Failed:
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "تمدید قبلی در پنل رد شد و انجام نشد. برای تلاش دوباره، فرایند تمدید را از ابتدا شروع کنید.",
                    cancellationToken);
                return;

            default:
                await SendOwnedRenewTerminalAsync(
                    botClient,
                    message.Chat.Id,
                    user,
                    "تمدید قبلی این اکانت در حال انجام یا بررسی خودکار است. برای جلوگیری از تمدید تکراری، تمدید جدید موقتاً قفل شده است.",
                    cancellationToken);
                return;
        }
    }

    /// <summary>
    /// Reconciles an ambiguous renewal operation with a read-only panel read-back.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="message">Duplicate confirmation message.</param>
    /// <param name="credUser">Payer profile.</param>
    /// <param name="user">Bot-scoped renewal state.</param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard.</param>
    /// <param name="service">Resolved service definition.</param>
    /// <param name="resolved">Resolved purchase containing price and plan.</param>
    /// <param name="useSiteWallet">Whether the site wallet was selected.</param>
    /// <param name="operation">Ambiguous operation row.</param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, users.db, and panel operations.</param>
    /// <returns>A task that completes after the read-only reconciliation.</returns>
    /// <remarks>
    /// This path never sends a mutation. If the panel now holds the target, the operation is marked applied and the
    /// normal settlement/success flow runs; otherwise it stays ambiguous for operator reconciliation.
    /// </remarks>
    private async Task ReconcileAmbiguousOwnedRenewalAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        bool useSiteWallet,
        XuiV3RenewalOperation operation,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        var (comparison, client) = await _renewalOperationStore.RecoverByReadBackAsync(
            operation, serverInfo, _configuration, cancellationToken);
        if (comparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Applied)
        {
            var applied = await _renewalOperationStore.ResolveAmbiguousToAppliedAsync(operation, comparison, cancellationToken);
            if (applied && client != null)
            {
                await CompleteAppliedOwnedRenewalAsync(
                    botClient, message, credUser, user, mainReplyMarkup, service, resolved, useSiteWallet,
                    operation, client, RebuildRenewalForOperation(operation), RebuildPayloadForOperation(operation),
                    null, operationTiming, cancellationToken);
                return;
            }

            if (applied)
            {
                await SendOwnedRenewTerminalAsync(
                    botClient, message.Chat.Id, user,
                    "تمدید قبلاً در پنل اعمال شده است. لطفاً فرایند تمدید را دوباره شروع کنید.", cancellationToken);
                return;
            }
        }

        await SendOwnedRenewTerminalAsync(
            botClient,
            message.Chat.Id,
            user,
            "نتیجه تمدید هنوز قطعی نیست. درخواست به‌صورت خودکار بررسی می‌شود و تمدید جدید این اکانت تا مشخص‌شدن نتیجه موقتاً قفل است.",
            cancellationToken);
    }

    /// <summary>
    /// Reconciles an operation that is already applied, finishing settlement and the single success log exactly once.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="message">Duplicate confirmation message.</param>
    /// <param name="credUser">Payer profile.</param>
    /// <param name="user">Bot-scoped renewal state.</param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard.</param>
    /// <param name="service">Resolved service definition.</param>
    /// <param name="resolved">Resolved purchase containing price and plan.</param>
    /// <param name="useSiteWallet">Whether the site wallet was selected.</param>
    /// <param name="operation">Applied operation row.</param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, users.db, and panel operations.</param>
    /// <returns>A task that completes after settlement/log reconciliation and the duplicate notification.</returns>
    /// <remarks>
    /// No XUI mutation is sent. The operation row is the exactly-once anchor: settlement runs only while its
    /// settlement status is pending and the success log is emitted only once via the operation flag.
    /// </remarks>
    private async Task ReconcileAppliedOwnedRenewalAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        bool useSiteWallet,
        XuiV3RenewalOperation operation,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        var settlement = await SettleOwnedRenewalAsync(
            operation, credUser, resolved, useSiteWallet, null, operation.TargetEmail, cancellationToken);
        if (settlement.InProgress)
        {
            await SendOwnedRenewTerminalAsync(
                botClient, message.Chat.Id, user,
                "تمدید انجام شده است؛ پرداخت در حال انجام است.", cancellationToken);
            return;
        }

        if (settlement.ManualReview)
        {
            await SendOwnedRenewTerminalAsync(
                botClient, message.Chat.Id, user,
                "تمدید انجام شده است؛ پرداخت در انتظار بررسی دستی است. لطفاً با پشتیبانی تماس بگیرید.", cancellationToken);
            return;
        }

        if (await _renewalOperationStore.MarkSuccessLogSentAsync(operation, cancellationToken))
        {
            LogV3Purchase(
                title: "تمدید اکانت نسخه ۳",
                credUser: credUser,
                priceToman: resolved.PriceToman,
                beforeBalance: settlement.BeforeBalance,
                afterBalance: settlement.AfterBalance,
                paymentWalletSource: "کیف پول ربات",
                details: new[]
                {
                    $"نام اکانت `{operation.TargetEmail}`",
                    $"حجم اضافه `{operation.AddedTrafficGb} GB`",
                    $"زمان اضافه `{(operation.AddedDurationDays <= 0 ? "نامحدود" : $"{operation.AddedDurationDays} روز")}`"
                },
                timing: operationTiming.Snapshot());
        }

        await SendOwnedRenewTerminalAsync(
            botClient,
            message.Chat.Id,
            user,
            "تمدید این اکانت قبلاً با موفقیت انجام شده است. برای تمدید مجدد، فرایند تمدید را از ابتدا شروع کنید.",
            cancellationToken);
    }

    /// <summary>
    /// Completes financial settlement for an applied owned-bot renewal discovered by durable background recovery.
    /// </summary>
    /// <param name="botClient">Telegram client for the operation's originating owned bot.</param>
    /// <param name="operation">Applied, non-tenant operation containing the immutable payer, price, and target.</param>
    /// <param name="cancellationToken">Host shutdown token for credentials, ledger, users.db, and notification work.</param>
    /// <returns>
    /// <c>true</c> when settlement is already complete or this call completed it; <c>false</c> when payer state is
    /// unavailable, another executor is settling, or manual financial review is required.
    /// </returns>
    /// <remarks>
    /// This entry point exists outside the Telegram callback state machine so a delayed panel commit can be charged
    /// after restart. It never calls UpdateClient. The same atomic settlement claim and wallet-ledger idempotency key
    /// used by callbacks protect the debit. Telegram delivery failure does not undo a completed settlement.
    /// </remarks>
    /// <example><code>await flow.SettleRecoveredOwnedRenewalAsync(botClient, operation, stoppingToken)</code></example>
    public async Task<bool> SettleRecoveredOwnedRenewalAsync(
        ITelegramBotClient botClient,
        XuiV3RenewalOperation operation,
        CancellationToken cancellationToken)
    {
        using var recoveryTiming = XuiOperationTiming.Start();
        if (operation == null ||
            !string.IsNullOrWhiteSpace(operation.TenantBotOrderId) ||
            operation.Status != XuiV3RenewalOperationStatuses.Applied)
        {
            return false;
        }

        var credUser = await _credentialsDbContext.GetUserStatusWithId(operation.TelegramUserId);
        if (credUser == null)
            return false;

        var resolved = new XuiV3ResolvedPurchase
        {
            Service = new XuiV3ServiceDefinition { Key = operation.ServiceKey },
            TrafficGb = operation.AddedTrafficGb,
            TrafficBytes = operation.AddedTrafficBytes,
            DurationDays = operation.AddedDurationDays,
            PriceToman = operation.PriceToman,
            IsUnlimited = operation.IsUnlimited
        };
        var useSiteWallet = string.Equals(
            operation.PaymentMethod,
            "gozargah_site_wallet",
            StringComparison.OrdinalIgnoreCase);
        var settlement = await SettleOwnedRenewalAsync(
            operation,
            credUser,
            resolved,
            useSiteWallet,
            siteWalletEligibility: null,
            operation.TargetEmail,
            cancellationToken);
        if (settlement.InProgress || settlement.ManualReview)
            return false;

        if (await _renewalOperationStore.MarkSuccessLogSentAsync(operation, cancellationToken))
        {
            LogV3Purchase(
                title: "تمدید اکانت نسخه ۳ (بازیابی خودکار)",
                credUser: credUser,
                priceToman: operation.PriceToman,
                beforeBalance: settlement.BeforeBalance,
                afterBalance: settlement.AfterBalance,
                paymentWalletSource: useSiteWallet ? "کیف پول انتخاب‌شده در عملیات اصلی" : "کیف پول ربات",
                details: new[]
                {
                    $"نام اکانت `{operation.TargetEmail}`",
                    $"حجم اضافه `{operation.AddedTrafficGb} GB`",
                    $"زمان اضافه `{(operation.AddedDurationDays <= 0 ? "نامحدود" : $"{operation.AddedDurationDays} روز")}`"
                },
                timing: recoveryTiming.Snapshot());
        }

        try
        {
            await botClient.SendMessage(
                operation.TelegramUserId,
                "✅ نتیجه تمدید بررسی شد؛ تمدید در پنل اعمال شده بود و تسویه آن با موفقیت تکمیل شد.",
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Recovered renewal was settled but its customer notification failed. renewalOperationId={RenewalOperationId}",
                operation.OperationId);
        }

        return true;
    }

    /// <summary>
    /// Runs the post-apply renewal flow exactly once: traffic reset, volume cycle, guarded settlement, success
    /// message, single central log, activity audit, and Gozargah sync.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="message">Confirmation message that owns this renewal.</param>
    /// <param name="credUser">Payer profile.</param>
    /// <param name="user">Bot-scoped renewal state that is cleared after success.</param>
    /// <param name="mainReplyMarkup">Owned-bot main keyboard.</param>
    /// <param name="service">Resolved service definition.</param>
    /// <param name="resolved">Resolved purchase containing price and plan.</param>
    /// <param name="useSiteWallet">Whether the site wallet was selected.</param>
    /// <param name="renewalOperation">Applied renewal operation whose settlement and log are guarded.</param>
    /// <param name="client">Fresh panel client whose fields mirror the applied payload.</param>
    /// <param name="renewal">Renewal calculation used for reset and display values.</param>
    /// <param name="payload">Absolute replacement payload that was applied to the panel.</param>
    /// <param name="siteWalletEligibility">
    /// Optional preview eligibility retained for call-site compatibility; settlement checks the durable receipt first and reads fresh eligibility.
    /// </param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, users.db, ledger, and panel operations.</param>
    /// <returns>A task that completes after the applied renewal is settled, logged, and notified.</returns>
    /// <remarks>
    /// This method is invoked only by the executor that atomically transitioned the operation to applied, so the
    /// traffic reset, wallet settlement, and central log run once even when duplicates arrive concurrently.
    /// </remarks>
    private async Task CompleteAppliedOwnedRenewalAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        XuiV3ServiceDefinition service,
        XuiV3ResolvedPurchase resolved,
        bool useSiteWallet,
        XuiV3RenewalOperation renewalOperation,
        XuiV3Client client,
        XuiV3RenewalCalculation renewal,
        XuiV3ClientPayload payload,
        GozargahSiteWalletEligibility siteWalletEligibility,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();

        var trafficResetApplied = await ResetRenewedTrafficIfNeededAsync(serverInfo, client.Email, renewal, cancellationToken);
        await _volumeReminderStateStore.TryBeginNewCycleAfterRenewalAsync(
            serverInfo,
            client,
            renewal,
            trafficResetApplied,
            cancellationToken);

        // Settlement is guarded by the operation row: only the executor that applied the renewal may debit the
        // wallet, and a stale settlement claim is parked for manual review so a wallet is never debited twice.
        var settlement = await SettleOwnedRenewalAsync(
            renewalOperation,
            credUser,
            resolved,
            useSiteWallet,
            siteWalletEligibility,
            client.Email,
            cancellationToken);
        var beforeBalance = settlement.BeforeBalance;
        var afterBalance = settlement.AfterBalance;
        var siteWalletDebitResult = settlement.SiteWalletDebitResult;
        var siteWalletFallbackToBot = settlement.SiteWalletFallbackToBot;
        var siteWalletFallbackReason = settlement.SiteWalletFallbackReason;

        if (settlement.InProgress)
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "✅ تمدید با موفقیت انجام شد. پرداخت در حال انجام است و به‌زودی تکمیل می‌شود.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        if (settlement.ManualReview)
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "✅ تمدید انجام شد؛ پرداخت در انتظار بررسی دستی است. لطفاً با پشتیبانی تماس بگیرید.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        await _state.ClearUserStatus(user);

        client.TotalGB = payload.TotalGB;
        client.ExpiryTime = payload.ExpiryTime;
        client.Comment = payload.Comment;
        client.Enable = payload.Enable;
        // Some v3 panel responses omit traffic counters. The panel reset has already been requested;
        // mirror it locally only when counters are present in the response model.
        var traffic = client.Traffic;
        if (trafficResetApplied && traffic != null)
        {
            traffic.Up = 0;
            traffic.Down = 0;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "✅ تمدید با موفقیت انجام شد.\n\n" +
                  BuildSelectedWalletBalanceText(
                      useSiteWallet,
                      beforeBalance,
                      resolved.PriceToman,
                      afterBalance,
                      siteWalletDebitResult,
                      siteWalletFallbackToBot) +
                  "\n\n" +
                  BuildV3ClientInfo(client, serverInfo, credUser.IsColleague),
            parseMode: ParseMode.Html,
            replyMarkup: mainReplyMarkup,
            cancellationToken: cancellationToken);
        // Exactly one central Telegram success log per renewal operation, even when a crash take-over resolves the
        // operation later. If the logger itself fails, the renewal correctness is unaffected.
        if (await _renewalOperationStore.MarkSuccessLogSentAsync(renewalOperation, cancellationToken))
        {
            LogV3Purchase(
                title: "تمدید اکانت نسخه ۳",
                credUser: credUser,
                priceToman: resolved.PriceToman,
                beforeBalance: useSiteWallet && siteWalletDebitResult?.Success == true ? siteWalletDebitResult.BeforeWallet : beforeBalance,
                afterBalance: useSiteWallet && siteWalletDebitResult?.Success == true ? siteWalletDebitResult.AfterWallet : afterBalance,
                paymentWalletSource: siteWalletDebitResult?.Success == true
                    ? "کیف پول سایت گذرگاه"
                    : siteWalletFallbackToBot
                        ? "کیف پول ربات (جایگزین پس از خطای کیف پول سایت)"
                        : "کیف پول ربات",
                details: new[]
                {
                    $"نام اکانت `{client.Email}`",
                    renewal.IsUnlimited
                        ? renewal.ShouldResetTraffic
                            ? $"حجم جدید پس از ریست `{renewal.RenewedTrafficGb} GB`"
                            : $"حجم اضافه `{renewal.RenewedTrafficGb} GB` - حجم کل پس از تمدید `{XuiV3PurchaseService.FormatTrafficSize(renewal.TotalBytesAfterRenew)}`"
                        : $"حجم اضافه `{resolved.TrafficGb} GB`",
                    $"زمان اضافه `{(resolved.DurationDays <= 0 ? "نامحدود" : $"{resolved.DurationDays} روز")}`",
                    $"روش کسر `{(siteWalletDebitResult?.Success == true ? "کیف پول سایت گذرگاه" : siteWalletFallbackToBot ? "کیف پول ربات - جایگزین خطای سایت" : "کیف پول ربات")}`",
                    $"ریست مصرف `{(renewal.ShouldResetTraffic ? (trafficResetApplied ? "انجام شد" : "ناموفق") : "نیاز نبود")}`",
                    $"سابلینک `{ApiServicev3.BuildSubscriptionLink(serverInfo, client.SubId ?? client.Email)}`",
                    $"کامنت `{client.Comment}`"
                },
                timing: operationTiming.Snapshot());
        }

        var renewTiming = operationTiming.Snapshot();
        await _activityLog.LogBotActionAsync(
            "xui_v3_account_renewed",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["renewalOperationId"] = renewalOperation.OperationId,
                ["accountEmail"] = client.Email,
                ["serviceKey"] = service.Key,
                ["serviceName"] = service.DisplayName,
                ["trafficAddedGb"] = resolved.TrafficGb,
                ["targetAvailableGbAfterRenew"] = renewal.TargetAvailableTrafficGb,
                ["durationAddedDays"] = resolved.DurationDays,
                ["finalDurationDays"] = renewal.FinalDurationDays,
                ["trafficResetApplied"] = trafficResetApplied,
                ["priceToman"] = resolved.PriceToman,
                ["balanceBeforeToman"] = siteWalletDebitResult?.Success == true
                    ? siteWalletDebitResult.BeforeWallet
                    : beforeBalance,
                ["balanceAfterToman"] = siteWalletDebitResult?.Success == true
                    ? siteWalletDebitResult.AfterWallet
                    : afterBalance,
                ["paymentSource"] = siteWalletDebitResult?.Success == true
                    ? "gozargah_site_wallet"
                    : siteWalletFallbackToBot
                        ? "gozargah_site_wallet_fallback_bot_wallet"
                        : "bot_wallet",
                ["siteWalletFallbackReason"] = siteWalletFallbackReason ?? string.Empty,
                ["totalGbAfterRenew"] = client.TotalGB.ConvertBytesToGB(),
                ["usedGb"] = GetUsedBytes(client).ConvertBytesToGB(),
                ["expiryShamsi"] = FormatExpiry(client.ExpiryTime),
                ["subLink"] = ApiServicev3.BuildSubscriptionLink(serverInfo, client.SubId ?? client.Email),
                ["panelUrl"] = serverInfo.Url,
                ["rootPath"] = serverInfo.RootPath,
                ["panelApiElapsedMs"] = (long)renewTiming.PanelApiElapsed.TotalMilliseconds,
                ["totalElapsedMs"] = (long)renewTiming.TotalElapsed.TotalMilliseconds
            },
            cancellationToken);

        await QueueGozargahSyncBestEffortAsync(
            "renew",
            () => _gozargahSiteSyncService.QueueUpdateAsync(
                ResolveGozargahSiteOwnerTelegramUserId(credUser),
                credUser.TelegramUserId,
                client,
                serverInfo,
                $"renew-{client.Email}-{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}",
                ResolveGozargahTenantBotId(),
                cancellationToken: cancellationToken));
    }

    /// <summary>
    /// Rebuilds a display-only renewal calculation from a stored operation after a crash take-over.
    /// </summary>
    /// <param name="operation">Operation whose stored target values feed the reconstruction.</param>
    /// <returns>A detached renewal calculation used by reset and display code; it is never sent to XUI again.</returns>
    private static XuiV3RenewalCalculation RebuildRenewalForOperation(XuiV3RenewalOperation operation)
    {
        return new XuiV3RenewalCalculation
        {
            Payload = RebuildPayloadForOperation(operation),
            IsUnlimited = operation.IsUnlimited,
            ShouldResetTraffic = operation.ShouldResetTraffic,
            CurrentTotalBytes = operation.ExpectedTotalBytesBefore,
            CurrentExpiryTime = operation.ExpectedExpiryTimeBefore,
            RenewedTrafficGb = operation.AddedTrafficGb,
            RenewedTrafficBytes = operation.AddedTrafficBytes,
            TotalBytesAfterRenew = operation.TargetTotalBytes,
            UpdatedExpiryTime = operation.TargetExpiryTime,
            AddedDurationDays = operation.AddedDurationDays,
            FinalDurationDays = operation.AddedDurationDays,
            TargetAvailableTrafficGb = operation.AddedTrafficGb,
            TargetAvailableTrafficBytes = operation.AddedTrafficBytes
        };
    }

    /// <summary>
    /// Deserializes the exact mutation payload persisted before the original renewal attempt.
    /// </summary>
    /// <param name="operation">Operation whose stored payload JSON is loaded.</param>
    /// <returns>The exact payload, or <c>null</c> when it is missing or corrupt.</returns>
    private static XuiV3ClientPayload RebuildPayloadForOperation(XuiV3RenewalOperation operation)
    {
        if (string.IsNullOrWhiteSpace(operation.MutationPayloadJson))
            return null;

        try
        {
            return JsonConvert.DeserializeObject<XuiV3ClientPayload>(operation.MutationPayloadJson);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Builds a minimal client view from the stored payload for success-message rendering after a take-over.
    /// </summary>
    /// <param name="payload">Stored absolute payload that was applied to the panel.</param>
    /// <returns>A detached client mirroring the payload fields; counters are unknown and treated as zero.</returns>
    private static XuiV3Client BuildMirroredClientForPayload(XuiV3ClientPayload payload)
    {
        return new XuiV3Client
        {
            Email = payload.Email,
            SubId = payload.SubId,
            TotalGB = payload.TotalGB,
            ExpiryTime = payload.ExpiryTime,
            Comment = payload.Comment,
            Enable = payload.Enable,
            TgId = payload.TgId,
            Uuid = payload.Uuid,
            Traffic = new XuiV3ClientTraffic { Email = payload.Email, TotalGB = payload.TotalGB, ExpiryTime = payload.ExpiryTime, Enable = payload.Enable }
        };
    }

    /// <summary>
    /// Bounds a panel rejection message for storage on the renewal operation row.
    /// </summary>
    /// <param name="panelMessage">Raw panel message that must not contain secrets beyond a bounded length.</param>
    /// <returns>A bounded sanitized message safe for the private diagnostics column.</returns>
    private static string SanitizeRenewalFailure(string panelMessage)
    {
        var value = string.IsNullOrWhiteSpace(panelMessage)
            ? "panel rejected the renewal"
            : panelMessage.Trim();
        return value.Length <= 500 ? value : value[..500];
    }

    /// <summary>
    /// Settlement outcome of one guarded renewal payment.
    /// </summary>
    private sealed class OwnedRenewalSettlementResult
    {
        /// <summary>Settlement was already completed by a previous executor; nothing was debited again.</summary>
        public bool AlreadySettled { get; set; }

        /// <summary>Another executor is currently settling; this executor must not debit.</summary>
        public bool InProgress { get; set; }

        /// <summary>The previous settlement executor crashed; the operation is parked for manual review.</summary>
        public bool ManualReview { get; set; }

        /// <summary>Wallet balance in toman immediately before the debit.</summary>
        public long BeforeBalance { get; set; }

        /// <summary>Wallet balance in toman immediately after the debit.</summary>
        public long AfterBalance { get; set; }

        /// <summary>Gozargah site wallet debit result when the site wallet was selected.</summary>
        public GozargahSiteWalletDebitResult SiteWalletDebitResult { get; set; }

        /// <summary>Whether the bot wallet compensated a failed site-wallet debit.</summary>
        public bool SiteWalletFallbackToBot { get; set; }

        /// <summary>Reason for the bot-wallet fallback, kept for audit.</summary>
        public string SiteWalletFallbackReason { get; set; }
    }

    /// <summary>
    /// Settles a completed renewal exactly once under the operation's settlement claim.
    /// </summary>
    /// <param name="renewalOperation">Applied renewal operation whose settlement status guards the debit.</param>
    /// <param name="credUser">Payer whose bot wallet may be debited (or compensated after a site-wallet failure).</param>
    /// <param name="resolved">Resolved purchase containing the exact price in toman.</param>
    /// <param name="useSiteWallet">Whether the Gozargah site wallet was selected.</param>
    /// <param name="siteWalletEligibility">
    /// Optional preview eligibility retained for compatibility; settlement reads its durable receipt before a fresh eligibility check.
    /// </param>
    /// <param name="clientEmail">XUI client email used as the ledger reference.</param>
    /// <param name="cancellationToken">Token that cancels the wallet, ledger, and users.db operations.</param>
    /// <returns>
    /// The settlement outcome. <see cref="OwnedRenewalSettlementResult.AlreadySettled"/>, InProgress, and ManualReview
    /// indicate that this executor must not debit; otherwise the wallet was debited and the ledger written once.
    /// </returns>
    /// <remarks>
    /// The settlement claim (<c>pending -> settling</c>) is atomic, and a stale claim is parked in manual review
    /// instead of being resumed, so the wallet is never debited twice for one renewal operation. The bot-wallet
    /// financial receipt is keyed by the renewal operation, not the reusable account email. Website admission is shared by owner
    /// with tenant stores. Unknown debit outcomes remain operation-level review and never authorize local-wallet compensation.
    /// </remarks>
    /// <exception cref="SiteWalletDebitUncertainException">The website request may have succeeded; reconcile its persisted receipt before settlement.</exception>
    private async Task<OwnedRenewalSettlementResult> SettleOwnedRenewalAsync(
        XuiV3RenewalOperation renewalOperation,
        CredUser credUser,
        XuiV3ResolvedPurchase resolved,
        bool useSiteWallet,
        GozargahSiteWalletEligibility siteWalletEligibility,
        string clientEmail,
        CancellationToken cancellationToken)
    {
        if (renewalOperation.SettlementStatus == XuiV3RenewalSettlementStatuses.Settled)
        {
            var current = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
            return new OwnedRenewalSettlementResult { AlreadySettled = true, BeforeBalance = current, AfterBalance = current };
        }

        if (!await _renewalOperationStore.TryClaimSettlementAsync(renewalOperation, cancellationToken))
        {
            var state = await _renewalOperationStore.ResolveSettlementStateAsync(renewalOperation, cancellationToken);
            if (state == XuiV3RenewalSettlementStatuses.Settled)
            {
                var current = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
                return new OwnedRenewalSettlementResult { AlreadySettled = true, BeforeBalance = current, AfterBalance = current };
            }

            if (state == XuiV3RenewalSettlementStatuses.ManualReview)
                return new OwnedRenewalSettlementResult { ManualReview = true };

            return new OwnedRenewalSettlementResult { InProgress = true };
        }

        var beforeBalance = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
        var afterBalance = beforeBalance;
        GozargahSiteWalletDebitResult siteWalletDebitResult = null;
        var siteWalletFallbackToBot = false;
        string siteWalletFallbackReason = null;

        if (useSiteWallet)
        {
            // Read the durable receipt before current eligibility: restart may follow an already applied debit.
            // An uncertain or conflicting receipt propagates to operation recovery and never permits compensation.
            var debitResult = await _gozargahSiteSyncService.DeductSiteWalletAfterPanelSuccessAsync(
                credUser.TelegramUserId, resolved.PriceToman, "xui-v3-client", renewalOperation.OperationId,
                $"XuiV3 renewal via Gozargah site wallet: {clientEmail}", cancellationToken);

            siteWalletDebitResult = debitResult;
            if (!debitResult.Success)
            {
                // The panel renewal already succeeded. Apply a compensating local debit even when the bot-wallet
                // balance is insufficient so this external failure cannot turn the renewal into a free operation.
                siteWalletFallbackToBot = true;
                siteWalletFallbackReason = debitResult.ErrorMessage;
                afterBalance = await DebitBotWalletExactlyOnceAsync(
                    renewalOperation,
                    credUser,
                    resolved.PriceToman,
                    beforeBalance,
                    clientEmail,
                    provider: "gozargah_site_wallet_fallback_bot_wallet",
                    description: $"XuiV3 renewal bot-wallet fallback after Gozargah site debit failure: {clientEmail}",
                    cancellationToken: CancellationToken.None);

                await _activityLog.LogWarningAsync(
                    "gozargah_site_wallet_debit_failed_after_renew",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["renewalOperationId"] = renewalOperation.OperationId,
                        ["accountEmail"] = clientEmail,
                        ["priceToman"] = resolved.PriceToman,
                        ["error"] = debitResult.ErrorMessage ?? string.Empty,
                        ["fallbackWallet"] = "bot_wallet",
                        ["botBalanceBeforeToman"] = beforeBalance,
                        ["botBalanceAfterToman"] = afterBalance
                    },
                    CancellationToken.None);
            }
        }
        else
        {
            afterBalance = await DebitBotWalletExactlyOnceAsync(
                renewalOperation,
                credUser,
                resolved.PriceToman,
                beforeBalance,
                clientEmail,
                provider: "wallet",
                description: $"XuiV3 renewal {clientEmail}",
                cancellationToken);
        }

        await _renewalOperationStore.MarkSettledAsync(renewalOperation, cancellationToken);
        return new OwnedRenewalSettlementResult
        {
            BeforeBalance = beforeBalance,
            AfterBalance = afterBalance,
            SiteWalletDebitResult = siteWalletDebitResult,
            SiteWalletFallbackToBot = siteWalletFallbackToBot,
            SiteWalletFallbackReason = siteWalletFallbackReason
        };
    }

    /// <summary>
    /// Debits the bot wallet exactly once for a renewal using an atomic durable wallet receipt.
    /// </summary>
    /// <param name="renewalOperation">Renewal operation whose operation id keys the ledger idempotency.</param>
    /// <param name="credUser">Payer whose bot wallet is debited; negative balances are allowed by business rules.</param>
    /// <param name="amountToman">Positive debit amount in Iranian toman.</param>
    /// <param name="beforeBalance">Legacy caller's display snapshot in toman; deliberately ignored because only the committed receipt proves the balance.</param>
    /// <param name="clientEmail">XUI client email used as the ledger reference.</param>
    /// <param name="provider">Ledger provider such as <c>wallet</c> or the site-wallet fallback key.</param>
    /// <param name="description">Human-readable ledger description.</param>
    /// <param name="cancellationToken">Token that cancels the users.db ledger operations.</param>
    /// <returns>The persisted wallet balance after the single debit.</returns>
    /// <remarks>
    /// The credentials.db receipt and balance commit together before the users.db ledger is appended. Retries
    /// recover the original receipt even if other bots changed this wallet afterward. A historical ledger without
    /// a receipt requires manual review; current balance comparisons never authorize a second debit.
    /// </remarks>
    private async Task<long> DebitBotWalletExactlyOnceAsync(
        XuiV3RenewalOperation renewalOperation,
        CredUser credUser,
        long amountToman,
        long beforeBalance,
        string clientEmail,
        string provider,
        string description,
        CancellationToken cancellationToken)
    {
        var key = XuiV3RenewalOperationStore.BuildSettlementLedgerKey(renewalOperation);
        var receipt = await _credentialsDbContext.GetWalletOperationAsync(key, cancellationToken);
        var ledgerKey = XuiV3RenewalOperationStore.BuildSettlementLedgerKey(renewalOperation);
        if (receipt == null && await _walletLedgerService.GetByKeyAsync(ledgerKey, cancellationToken) != null)
            throw new InvalidOperationException("Historical renewal debit requires manual review; no durable wallet receipt exists.");
        receipt ??= await _credentialsDbContext.MutateWalletAsync(credUser.TelegramUserId, -amountToman, key, cancellationToken);
        if (receipt == null) throw new InvalidOperationException("Renewal wallet owner does not exist.");
        credUser.AccountBalance = receipt.AfterBalance;
        await _walletLedgerService.RecordAsync(credUser.TelegramUserId, WalletLedgerDirections.Debit,
            amountToman, receipt.BeforeBalance, receipt.AfterBalance, WalletLedgerReasons.AccountRenew,
            provider: provider, referenceType: "xui-v3-client", referenceId: clientEmail,
            description: description, idempotencyKey: ledgerKey, cancellationToken: cancellationToken);
        return receipt.AfterBalance;
    }

    /// <summary>
    /// Resets panel traffic counters only when the central renewal policy marks the previous cycle expired.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor used for the authenticated reset calls.</param>
    /// <param name="email">Exact account email used only as the panel API target; it is never written to diagnostics.</param>
    /// <param name="renewal">Calculated renewal whose reset flag controls whether any panel call is made.</param>
    /// <param name="cancellationToken">Token that cancels primary and fallback panel calls.</param>
    /// <returns>
    /// <c>true</c> when reset was required and either reset endpoint succeeded; <c>false</c> when no reset was required
    /// or both safe attempts failed.
    /// </returns>
    /// <remarks>
    /// The fallback writes zero counters. Raw panel responses and identifier-bearing request details are deliberately
    /// omitted from logs; callers use the boolean only for reminder-cycle reconciliation.
    /// </remarks>
    private async Task<bool> ResetRenewedTrafficIfNeededAsync(
        ServerInfo serverInfo,
        string email,
        XuiV3RenewalCalculation renewal,
        CancellationToken cancellationToken)
    {
        if (renewal?.ShouldResetTraffic != true)
            return false;

        var resetResponse = await ApiServicev3.ResetClientTrafficAsync(serverInfo, _configuration, email, cancellationToken);
        if (resetResponse.Success)
            return true;

        Console.WriteLine("[XUIv3] renew traffic reset failed; trying updateTraffic fallback.");
        var fallbackResponse = await ApiServicev3.UpdateClientTrafficAsync(serverInfo, _configuration, email, 0, 0, cancellationToken);
        if (fallbackResponse.Success)
            return true;

        Console.WriteLine("[XUIv3] renew traffic reset fallback failed.");
        return false;
    }

    /// <summary>
    /// Starts the regular XUI v3 purchase flow for an owned bot or tenant storefront customer.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the purchase request.</param>
    /// <param name="message">Incoming Telegram message that requested a new account purchase.</param>
    /// <param name="credUser">Shared credentials profile of the buyer, including phone verification and wallet role.</param>
    /// <param name="user">Bot-scoped conversation state row that will be reset and moved into the purchase flow.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram and users.db operations.</param>
    /// <returns>
    /// <c>true</c> when the request was handled by the v3 purchase flow; <c>false</c> when the v3 purchase flow is disabled.
    /// </returns>
    /// <remarks>
    /// The method first removes the persistent reply keyboard before sending inline service buttons. This prevents owned-bot
    /// users from pressing main-menu buttons in the middle of service, traffic, duration, or unlimited-plan selection.
    /// Users can still return to the main menu with <c>/start</c>, which is exposed in the owned-bot command menu.
    /// </remarks>
    public async Task<bool> TryStartPurchaseAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow())
            return false;

        if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
        {
            await _state.ClearUserStatus(user);
            return true;
        }

        await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);

        await _state.ClearUserStatus(user);
        var selection = new XuiV3PurchaseSelection();
        _sessionStore.Set(credUser.TelegramUserId, selection);

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "فرایند خرید شروع شد. برای برگشت به منوی اصلی از /start استفاده کنید.",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "نوع سرویس را انتخاب کنید:",
            replyMarkup: _purchaseService.BuildServiceKeyboard(),
            cancellationToken: cancellationToken);

        user.Flow = PurchaseFlowName;
        user.LastStep = PurchaseStepSelectService;
        user.PurchaseSessionId = Guid.NewGuid().ToString("N");
        user.SelectedCountry = null;
        user.SelectedPeriod = null;
        user.Type = null;
        user.TotoalGB = null;
        user.ConfigLink = null;
        user.SubLink = null;
        user._ConfigPrice = null;
        user.PendingAccountCount = 0;
        user.PendingUserComment = "";
        await _state.SaveUserStatus(user);
        return true;
    }

    /// <summary>
    /// Handles text replies that belong to the XUI v3 purchase state machine.
    /// </summary>
    /// <param name="botClient">
    /// Telegram bot client for the active owned bot or tenant storefront that received the message.
    /// </param>
    /// <param name="message">
    /// Incoming Telegram message from the buyer. The method only consumes text messages while the bot-scoped
    /// <paramref name="user"/> state is in the XUI v3 purchase flow.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials profile for the Telegram sender. The profile supplies wallet balance, colleague pricing,
    /// phone verification state, and the numeric Telegram user id used by the in-memory purchase session.
    /// </param>
    /// <param name="user">
    /// Bot-scoped conversation state from <c>users.db</c>. The state is used as the durable fallback when the in-memory
    /// purchase session was lost after a restart or when another bot instance handles the next purchase step.
    /// </param>
    /// <param name="mainReplyMarkup">
    /// Reply keyboard that returns the sender to the current bot's main menu after cancel, validation failure, or completion.
    /// </param>
    /// <param name="cancellationToken">
    /// Cancellation token for Telegram, database, payment-precheck, and state-save operations.
    /// </param>
    /// <returns>
    /// <c>true</c> when the message belonged to the XUI v3 purchase flow and was handled; otherwise <c>false</c> so the
    /// outer dispatcher can continue with other handlers.
    /// </returns>
    /// <remarks>
    /// The method keeps purchase selection in an in-memory session for compact callback data, but critical fields such as
    /// selected service and pending account count are also persisted in <paramref name="user"/>. Before building the final
    /// summary, the service key is rehydrated from the durable state when the session value is blank, preventing crashes
    /// such as "Service plan '' was not found" after a process restart or cross-instance dispatch.
    ///
    /// Metered traffic and custom duration days typed by the user are validated through the shared purchase policy,
    /// so owned bots and tenant bots apply the same plan-file ranges and pricing. Durable traffic and duration fields
    /// are rehydrated before later steps so a process restart cannot discard a <c>days-N</c> selection. Every restored
    /// service, traffic, duration, and unlimited-plan value is checked against the live catalog before count, comment,
    /// or confirmation text is consumed. Invalid state is lazily reset in the current bot only and the triggering text
    /// is not saved as an order value. A valid comment preview resolves pricing once and reuses that snapshot for the
    /// summary, total amount, and site-wallet eligibility; confirmation resolves the live catalog again before effects.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during Telegram, database, or payment-precheck work.
    /// </exception>
    public async Task<bool> TryHandlePurchaseTextAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || message?.Text == null || user?.Flow != PurchaseFlowName)
            return false;

        if (IsCancel(message.Text))
        {
            _sessionStore.Clear(credUser.TelegramUserId);
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "فرایند خرید لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
            return true;

        await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);

        var selection = _sessionStore.GetOrCreate(credUser.TelegramUserId);
        var serviceKey = string.IsNullOrWhiteSpace(selection.ServiceKey)
            ? user.SelectedCountry
            : selection.ServiceKey;
        var service = FindService(serviceKey);
        if (service != null)
            RehydratePurchaseSelectionFromState(selection, service, user);

        if (service == null &&
            string.Equals(user.LastStep, PurchaseStepSelectService, StringComparison.Ordinal) &&
            string.IsNullOrWhiteSpace(serviceKey))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "نوع سرویس را از دکمه‌های فعال انتخاب کنید.",
                replyMarkup: _purchaseService.BuildServiceKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        var recoveryTarget = DeterminePurchaseRecoveryTarget(
            service,
            selection,
            user.LastStep,
            credUser.IsColleague);
        if (recoveryTarget != PurchaseRecoveryTarget.None)
        {
            await RecoverPurchaseStateAsync(
                botClient,
                message.Chat.Id,
                0,
                credUser,
                user,
                selection,
                service,
                recoveryTarget,
                cancellationToken);
            return true;
        }

        if (user.LastStep == PurchaseStepSelectDuration)
        {
            if (!XuiV3PurchaseService.TryResolveDurationInput(service, message.Text, out var duration))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        "مدت معتبر نیست. یکی از گزینه‌های فعال را انتخاب کنید."),
                    replyMarkup: _purchaseService.BuildDurationKeyboard(service.Key, selection.TrafficGb.Value),
                    cancellationToken: cancellationToken);
                return true;
            }

            selection.ServiceKey = service.Key;
            selection.DurationKey = duration.Key;
            selection.UnlimitedPlanKey = null;
            selection.AccountCount = 1;
            selection.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selection);

            await _state.ResetUserStatus(new User
            {
                Id = message.From.Id,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepAccountCount,
                SelectedCountry = service.Key,
                TotoalGB = selection.TrafficGb.Value.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = duration.Key,
                PendingUserComment = string.Empty
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"تعداد اکانت مورد نظر را وارد کنید. حداکثر تعداد در هر سفارش {XuiV3PurchaseService.MaxBulkAccountCount} است.",
                replyMarkup: BuildAccountCountInlineKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep == PurchaseStepAccountCount)
        {
            if (!TryGetIntFromText(message.Text, out var accountCount) ||
                accountCount <= 0 ||
                accountCount > XuiV3PurchaseService.MaxBulkAccountCount)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: $"تعداد اکانت معتبر نیست. یک عدد بین 1 تا {XuiV3PurchaseService.MaxBulkAccountCount} بفرستید.",
                    replyMarkup: BuildAccountCountReplyKeyboard(),
                    cancellationToken: cancellationToken);
                return true;
            }

            selection.AccountCount = accountCount;
            _sessionStore.Set(credUser.TelegramUserId, selection);

            await _state.ResetUserStatus(new User
            {
                Id = message.From.Id,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepUserComment,
                SelectedCountry = service.Key,
                TotoalGB = selection.TrafficGb?.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = selection.DurationKey ?? string.Empty,
                Type = selection.UnlimitedPlanKey ?? string.Empty,
                PendingAccountCount = accountCount
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "اگر برای این سفارش کامنتی دارید، متن آن را بفرستید. این کامنت روی اکانت ذخیره می‌شود و بعداً در وضعیت اکانت نمایش داده می‌شود.\n\nاگر کامنتی ندارید، گزینه «ادامه بدون کامنت» را بزنید.",
                replyMarkup: BuildOptionalCommentReplyKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep == PurchaseStepUserComment)
        {
            // Resolve once before consuming the message so the preview, payable total, and site-wallet eligibility all
            // use the same live-catalog snapshot. Confirmation deliberately resolves again immediately before effects.
            selection.ServiceKey = service.Key;
            selection.AccountCount = XuiV3PurchaseService.NormalizeAccountCount(user.PendingAccountCount);
            var resolved = _purchaseService.ResolveOwnedPurchase(selection, credUser.IsColleague);
            var totalPrice = resolved.PriceToman * selection.AccountCount;
            var canUseSiteWallet = await CanUseGozargahSiteWalletAsync(
                credUser.TelegramUserId,
                totalPrice,
                cancellationToken);

            var userComment = IsSkipCommentText(message.Text)
                ? string.Empty
                : NormalizeUserComment(message.Text);

            selection.UserComment = userComment;
            _sessionStore.Set(credUser.TelegramUserId, selection);

            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepConfirm,
                PendingUserComment = userComment
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: _purchaseService.BuildSummaryText(selection, resolved),
                parseMode: ParseMode.Html,
                replyMarkup: BuildPurchaseConfirmKeyboard(selection, canUseSiteWallet),
                cancellationToken: cancellationToken);
            return true;
        }

        if (service.IsUnlimited)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "برای سرویس نامحدود، یکی از پلن‌های نمایش داده شده را انتخاب کنید.",
                replyMarkup: _purchaseService.BuildUnlimitedPlanKeyboard(service.Key, credUser.IsColleague),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep == PurchaseStepSelectTraffic)
        {
            if (!TryGetTrafficGbFromText(message.Text, out var trafficGb) || trafficGb <= 0)
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "حجم معتبر نیست. فقط عدد صحیح وارد کنید؛ مثلا 7 یا ۷. سپس دوباره تلاش کنید.",
                    replyMarkup: _purchaseService.BuildTrafficKeyboard(service.Key),
                    cancellationToken: cancellationToken);
                return true;
            }

            if (!XuiV3PurchaseService.MeetsMinimumTraffic(service, trafficGb))
            {
                await botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: BuildMinimumTrafficMessage(service),
                    replyMarkup: _purchaseService.BuildTrafficKeyboard(service.Key),
                    cancellationToken: cancellationToken);
                return true;
            }

            selection.ServiceKey = service.Key;
            selection.TrafficGb = trafficGb;
            selection.DurationKey = null;
            selection.UnlimitedPlanKey = null;
            _sessionStore.Set(credUser.TelegramUserId, selection);

            await _state.ResetUserStatus(new User
            {
                Id = message.From.Id,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepSelectDuration,
                SelectedCountry = service.Key,
                TotoalGB = trafficGb.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = string.Empty,
                Type = string.Empty,
                PendingUserComment = string.Empty
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: XuiV3PurchaseService.BuildDurationSelectionText(
                    service,
                    $"حجم انتخاب شد: {trafficGb} GB\nحالا مدت را انتخاب کنید:"),
                replyMarkup: _purchaseService.BuildDurationKeyboard(service.Key, trafficGb),
                cancellationToken: cancellationToken);
            return true;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "برای ادامه از دکمه‌های پیام سفارش استفاده کنید.",
            cancellationToken: cancellationToken);
        return true;
    }

    /// <summary>
    /// Handles the owned-bot XUI v3 free-trial flow for regular customers.
    /// </summary>
    /// <param name="botClient">
    /// Telegram bot client for the active owned bot that received the message. The method sends all trial prompts
    /// and final account details through this client.
    /// </param>
    /// <param name="message">
    /// Text message from the Telegram user. The message may start the trial flow with the free-account keyboard
    /// button, select the trial service, cancel the flow, or continue an existing trial state.
    /// </param>
    /// <param name="credUser">
    /// Shared credentials user profile for the sender. The numeric Telegram id is used for trial cooldown checks,
    /// phone verification, account metadata, and clearing any stale purchase session.
    /// </param>
    /// <param name="user">
    /// Bot-scoped conversation state from <c>users.db</c>. When the sender starts a trial from another flow, the
    /// previous flow is replaced with the trial flow.
    /// </param>
    /// <param name="mainReplyMarkup">
    /// Reply keyboard shown after cancel, rejection, cooldown messages, or successful trial delivery.
    /// </param>
    /// <param name="cancellationToken">
    /// Cancellation token for Telegram sends, database updates, and XUI panel calls.
    /// </param>
    /// <returns>
    /// <c>true</c> when the message belonged to the trial flow and was handled; otherwise <c>false</c> so the outer
    /// dispatcher can continue with purchase, renewal, search, or legacy handlers.
    /// </returns>
    /// <remarks>
    /// Both menus display «اکانت تست»; the previous free-account label is accepted only as a legacy input alias.
    /// Owned and tenant menus share this policy: non-colleagues with verified phones, 100 MiB national or 1 GiB normal,
    /// three days, and a separate thirty-day cooldown per type in the current bot/user state. Creation is durable and
    /// free of order, wallet debit or partner-profit effects; no cross-bot quota is introduced.
    /// Starting a trial from the main keyboard intentionally clears any half-built purchase session for the same
    /// Telegram user. Without that reset, a metered purchase could later reach the summary step without
    /// <c>TrafficGb</c> and throw an exception. Once creation begins, accepted and rejected panel outcomes are audited
    /// with accumulated panel API time and total delivery time.
    /// </remarks>
    public async Task<bool> TryHandleFreeTrialAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!IsEnabledForPurchaseFlow() || string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();
        var isTrialStart = text.Contains("اکانت تست", StringComparison.OrdinalIgnoreCase) ||
                           text.Contains("اکانت رایگان", StringComparison.OrdinalIgnoreCase);

        if (user?.Flow != TrialFlowName && !isTrialStart)
            return false;

        if (isTrialStart && user?.Flow != TrialFlowName)
        {
            // Starting a trial from a main keyboard button intentionally cancels any half-built purchase session.
            _sessionStore.Clear(credUser.TelegramUserId);
        }

        if (IsCancel(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "فرایند دریافت اکانت تست لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (credUser.IsColleague)
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "اکانت تست نسخه ۳ فقط برای کاربران عادی فعال است.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (!await EnsurePhoneVerifiedAsync(botClient, message.Chat.Id, credUser, cancellationToken))
            return true;

        if (user?.Flow != TrialFlowName)
        {
            await _state.ClearUserStatus(user);
            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = TrialFlowName,
                LastStep = TrialStepSelectService
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "نوع اکانت تست را انتخاب کنید:",
                replyMarkup: BuildTrialServiceReplyKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep != TrialStepSelectService)
            return false;

        var serviceKey = TryGetTrialServiceKey(text);
        if (string.IsNullOrWhiteSpace(serviceKey))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "نوع تست معتبر نیست. یکی از گزینه‌های نمایش داده شده را انتخاب کنید.",
                replyMarkup: BuildTrialServiceReplyKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        var lastTrial = serviceKey == "national" ? user.LastFreeNationalAcc : user.LastFreeNormalAcc;
        var now = DateTime.UtcNow;
        if (lastTrial > DateTime.MinValue && (now - lastTrial).TotalDays < 30)
        {
            var remainingDays = Math.Max(1, 30 - (int)Math.Floor((now - lastTrial).TotalDays));
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"شما تست این سرویس را در ۳۰ روز گذشته دریافت کرده‌اید. لطفاً {remainingDays} روز دیگر دوباره تلاش کنید.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            await _state.ClearUserStatus(user);
            return true;
        }

        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "در حال ساخت اکانت تست نسخه ۳، لطفاً چند لحظه صبر کنید...",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);

        using var operationTiming = XuiOperationTiming.Start();
        var serverInfo = BuildConfiguredPanelServerInfo();
        var trafficBytes = serviceKey == "national" ? NationalTrialBytes : NormalTrialBytes;
        var displayTrafficGb = 1;
        var trialKey = serviceKey == "national" ? "national-monthly-free" : "normal-monthly-free";
        var creation = await _purchaseService.CreateTrialAccountAsync(
            credUser,
            serverInfo,
            serviceKey,
            displayTrafficGb,
            trafficBytes,
            TrialDays,
            trialKey,
            $"trial:{BotContextAccessor.CurrentBotId}:{credUser.TelegramUserId}:{serviceKey}:{lastTrial.Ticks}",
            cancellationToken);

        if (!creation.Success)
        {
            await _activityLog.LogWarningAsync(
                "xui_v3_trial_create_failed",
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["serviceKey"] = serviceKey,
                    ["message"] = creation.Message ?? string.Empty,
                    ["panelUrl"] = serverInfo.Url,
                    ["rootPath"] = serverInfo.RootPath
                },
                cancellationToken);

            LogXuiOperationOutcome(
                "ساخت اکانت تست نسخه ۳",
                "ناموفق",
                credUser,
                operationTiming,
                source: serviceKey);

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: $"ساخت اکانت تست ناموفق بود.\n{XuiV3UserSafeError.ForAccountCreation(creation.Message)}",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            await _state.ClearUserStatus(user);
            return true;
        }

        if (serviceKey == "national")
            await _state.SaveUserStatus(new User { Id = message.From.Id, LastFreeNationalAcc = now });
        else
            await _state.SaveUserStatus(new User { Id = message.From.Id, LastFreeNormalAcc = now });

        var accountText = _purchaseService.BuildCreatedAccountText(creation);
        if (!string.IsNullOrWhiteSpace(creation.SubLink))
        {
            using var qrStream = new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(creation.SubLink, 200));
            await botClient.SendPhoto(
                chatId: message.Chat.Id,
                photo: InputFile.FromStream(qrStream, "trial-subscription-qr.png"),
                caption: "✅ اکانت تست شما ساخته شد.\n\n" + accountText,
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "✅ اکانت تست شما ساخته شد.\n\n" + accountText,
                parseMode: ParseMode.Html,
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
        }

        await _state.ClearUserStatus(user);
        LogXuiOperationOutcome(
            "ساخت اکانت تست نسخه ۳",
            "موفق",
            credUser,
            operationTiming,
            accountEmail: creation.Email,
            source: serviceKey,
            requestedCount: 1,
            successfulCount: 1);
        return true;
    }

    /// <summary>Routes a pending colleague-role request using this bot/user conversation state.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="message">Incoming Telegram message from the current actor; required unless the route explicitly declines missing text.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="user">Detached current bot/user state; explicit store writes reload their targets and never attach this snapshot.</param>
    /// <param name="mainReplyMarkup">Reply markup selected for the current bot and user role, or null when no keyboard is required.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>True when this flow consumed the input, including handled validation or cancellation; false lets another route try it.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    public async Task<bool> TryHandleColleagueRequestAsync(
        ITelegramBotClient botClient,
        Message message,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(message?.Text))
            return false;

        var text = message.Text.Trim();
        var isStart = string.Equals(text, "🤝 درخواست همکاری", StringComparison.OrdinalIgnoreCase) ||
                      string.Equals(text, "درخواست همکاری", StringComparison.OrdinalIgnoreCase);

        if (user?.Flow != ColleagueRequestFlowName && !isStart)
            return false;

        if (IsCancel(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "درخواست همکاری لغو شد.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (credUser?.IsColleague == true)
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "حساب شما هم‌اکنون از نوع همکار است و نیازی به ثبت درخواست جدید نیست.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (user?.Flow != ColleagueRequestFlowName)
        {
            await _state.ClearUserStatus(user);
            await _state.SaveUserStatus(new User
            {
                Id = message.From.Id,
                Flow = ColleagueRequestFlowName,
                LastStep = ColleagueRequestStepConfirm
            });

            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "برای ثبت درخواست همکاری باید تایید کنید که فروش هفتگی شما حداقل ۵,۰۰۰,۰۰۰ تومان است.\n\nاگر فروش هفتگی شما کمتر از این مقدار باشد، حساب شما کاربر عادی محسوب می‌شود و امکان خرید با قیمت همکار برای شما فعال نخواهد شد.",
                replyMarkup: BuildColleagueRequestConfirmKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (user.LastStep != ColleagueRequestStepConfirm)
            return false;

        if (!string.Equals(text, "شرایط را قبول دارم و درخواست همکاری می‌فرستم", StringComparison.OrdinalIgnoreCase))
        {
            await botClient.SendMessage(
                chatId: message.Chat.Id,
                text: "برای ثبت درخواست همکاری، دکمه تایید شرایط را بزنید یا انصراف دهید.",
                replyMarkup: BuildColleagueRequestConfirmKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        _logger.LogTelegramHtml(BuildColleagueRequestLogMessage(credUser));

        await _activityLog.LogBotActionAsync(
            "colleague_request_submitted",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["minimumWeeklySalesToman"] = MinimumWeeklyColleagueSalesToman,
                ["chatId"] = credUser?.ChatID ?? message.Chat.Id,
                ["phoneNumber"] = credUser?.PhoneNumber ?? string.Empty,
                ["accountBalanceToman"] = credUser?.AccountBalance ?? 0
            },
            cancellationToken);

        await _state.ClearUserStatus(user);
        await botClient.SendMessage(
            chatId: message.Chat.Id,
            text: "درخواست همکاری شما ثبت شد و برای بررسی به سوپرادمین‌ها ارسال شد.\nبعد از بررسی، نتیجه از طریق پشتیبانی یا همین ربات به شما اطلاع داده می‌شود.",
            replyMarkup: mainReplyMarkup,
            cancellationToken: cancellationToken);

        return true;
    }

    /// <summary>
    /// Routes one owned- or tenant-bot XUI callback after acknowledging it exactly once.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the callback.</param>
    /// <param name="callbackQuery">Telegram callback containing compact XUI action data and the source message.</param>
    /// <param name="credUser">Shared credentials profile of the callback sender.</param>
    /// <param name="user">Bot-scoped conversation state for the current bot and Telegram user.</param>
    /// <param name="mainReplyMarkup">Main-menu keyboard restored by home actions.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, database, and XUI work.</param>
    /// <returns><c>true</c> when the callback belongs to the XUI flow; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// Link-change callbacks carry only a durable operation key. Duplicate confirmations can display persisted state
    /// but cannot replay a panel mutation because users.db owns the atomic confirmation transition. Owned purchase
    /// confirmations with insufficient bot-wallet balance expose a separate callback handled by TelegramBotService;
    /// it is deliberately not parsed here because it abandons the XUI selection and starts wallet charging. Purchase
    /// confirmation is accepted only while the persisted bot-scoped state is still at the active confirmation step.
    /// After a process restart, the full selection is rebuilt from that bot-scoped row rather than
    /// callback plan fields, so an old button cannot replace an active service, duration, plan, count, or comment.
    /// Metered duration callbacks and canonical <c>days-N</c> selections are checked against the freshly loaded preset
    /// flags and custom-duration range before purchase state advances and again at confirmation. A catalog toggle
    /// therefore returns the buyer to current duration choices without a wallet, ledger, website, or XUI side effect.
    /// Once final execution starts, create success, partial success, and terminal failure audits report accumulated
    /// panel API time plus total settlement/delivery time; time spent waiting for user confirmation is excluded.
    /// A zero-account creation result or failed post-provision site-wallet settlement clears the purchase conversation
    /// and sends the applicable main menu after the safe error, while the exact durable operation remains recoverable.
    /// Service, traffic, duration, unlimited-plan, account-count, and back callbacks replace durable transient state
    /// explicitly, so values cleared in memory cannot survive through partial-update null semantics.
    /// The read-only <c>acfg</c> route carries only a numeric client id; it reloads panel data and verifies Telegram
    /// ownership before any SubId or configuration URL is requested, then sends the result in a separate message/file.
    /// The external <c>auren</c> route additionally requires current bot-scoped direct-search state matching the same
    /// client. TenantBotService intercepts all renewal callback variants before this owned-wallet dispatcher.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during Telegram, database, or panel work.
    /// </exception>
    /// <example>
    /// <code>
    /// var handled = await flowService.TryHandleCallbackAsync(
    ///     botClient, callbackQuery, credentialUser, botScopedUser, mainKeyboard, cancellationToken);
    /// </code>
    /// </example>
    public async Task<bool> TryHandleCallbackAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (!XuiV3PurchaseCallbacks.TryParse(callbackQuery.Data, out var callback))
            return false;

        var chatId = callbackQuery.Message?.Chat.Id ?? credUser.ChatID;
        var messageId = callbackQuery.Message?.MessageId ?? 0;
        await AnswerCallbackSafelyAsync(botClient, callbackQuery.Id, cancellationToken);

        if (ShouldRefreshColleagueRoleForPurchaseCallback(callback.Action))
            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);

        if (callback.Action == "home")
        {
            await ReturnToMainMenuAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                user,
                mainReplyMarkup,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asrch")
        {
            await StartAccountSearchAsync(
                botClient,
                chatId,
                credUser.TelegramUserId,
                cancellationToken,
                messageId);
            return true;
        }

        if (callback.Action == "asl")
        {
            var query = user?.ConfigLink;
            if (string.IsNullOrWhiteSpace(query))
            {
                await StartAccountSearchAsync(botClient, chatId, credUser.TelegramUserId, cancellationToken, messageId);
                return true;
            }

            await SendAccountSearchResultsAsync(
                botClient,
                chatId,
                credUser,
                query,
                callback.Page ?? 0,
                cancellationToken,
                messageId);
            return true;
        }

        if (callback.Action == "asv")
        {
            await HandleAccountSearchViewCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asren")
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, chatId, credUser, cancellationToken))
                return true;

            await HandleAccountSearchRenewCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                user,
                callback.ClientId,
                callback.Page ?? 0,
                false,
                cancellationToken);
            return true;
        }

        if (callback.Action == "auren")
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, chatId, credUser, cancellationToken))
                return true;

            await HandleAccountSearchRenewCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                user,
                callback.ClientId,
                callback.Page ?? 0,
                true,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asdelask")
        {
            await HandleAccountSearchDeleteAskCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asdel")
        {
            await HandleAccountSearchDeleteConfirmCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asacct")
        {
            await HandleAccountSearchStateCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                string.Equals(callback.AccountOperation, "en", StringComparison.OrdinalIgnoreCase),
                cancellationToken);
            return true;
        }

        if (callback.Action == "rgo")
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, chatId, credUser, cancellationToken))
                return true;

            await RefreshOwnedBotColleagueRoleFromGozargahAsync(credUser, cancellationToken);
            await HandleExternalRenewTargetConfirmationAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                user,
                cancellationToken);
            return true;
        }

        if (callback.Action == "chok")
        {
            await HandleAccountChangeLinkConfirmCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.OperationKey,
                cancellationToken);
            return true;
        }

        if (callback.Action == "chcancel")
        {
            await HandleAccountChangeLinkCancelCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.OperationKey,
                cancellationToken);
            return true;
        }

        if (callback.Action == "chstatus")
        {
            await HandleAccountChangeLinkStatusCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.OperationKey,
                cancellationToken);
            return true;
        }

        if (callback.Action == "asch")
        {
            await HandleAccountChangeLinkCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                true,
                cancellationToken);
            return true;
        }

        if (callback.Action == "ascom")
        {
            await HandleAccountCommentStartCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                true,
                cancellationToken);
            return true;
        }

        if (callback.Action == "acfg")
        {
            await HandleAccountConfigsCallbackAsync(
                botClient,
                chatId,
                credUser,
                callback.ClientId,
                cancellationToken);
            return true;
        }

        if (callback.Action == "acct")
        {
            await HandleAccountStateCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                string.Equals(callback.AccountOperation, "en", StringComparison.OrdinalIgnoreCase),
                cancellationToken);
            return true;
        }

        if (callback.Action == "alist")
        {
            await SendV3AccountListPageAsync(
                botClient,
                chatId,
                callback.Page ?? 0,
                credUser,
                cancellationToken,
                messageId);
            return true;
        }

        if (callback.Action == "aview")
        {
            await HandleAccountViewCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "ach")
        {
            await HandleAccountChangeLinkCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                false,
                cancellationToken);
            return true;
        }

        if (callback.Action == "acom")
        {
            await HandleAccountCommentStartCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                false,
                cancellationToken);
            return true;
        }

        if (callback.Action == "aren")
        {
            if (!await EnsurePhoneVerifiedAsync(botClient, chatId, credUser, cancellationToken))
                return true;

            await HandleAccountRenewCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                user,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "adelask")
        {
            await HandleAccountDeleteAskCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "adel")
        {
            await HandleAccountDeleteConfirmCallbackAsync(
                botClient,
                chatId,
                messageId,
                credUser,
                callback.ClientId,
                callback.Page ?? 0,
                cancellationToken);
            return true;
        }

        if (callback.Action == "cancel")
        {
            _sessionStore.Clear(credUser.TelegramUserId);
            user.Flow = null;
            user.LastStep = null;
            user.SelectedCountry = null;
            user.SelectedPeriod = null;
            user.Type = null;
            user.TotoalGB = null;
            user._ConfigPrice = null;
            await _state.ClearUserStatus(user);

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: "فرایند خرید لغو شد.",
                    cancellationToken: cancellationToken);
            }

            await botClient.SendMessage(
                chatId: chatId,
                text: "به منوی اصلی برگشتید.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return true;
        }

        if (!await EnsurePhoneVerifiedAsync(botClient, chatId, credUser, cancellationToken))
            return true;

        if (callback.Action == "back")
        {
            var selection = _sessionStore.GetOrCreate(credUser.TelegramUserId);
            selection.ServiceKey = null;
            selection.TrafficGb = null;
            selection.DurationKey = null;
            selection.UnlimitedPlanKey = null;
            selection.AccountCount = 1;
            selection.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selection);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepSelectService,
                SelectedCountry = string.Empty,
                SelectedPeriod = string.Empty,
                Type = string.Empty,
                TotoalGB = string.Empty,
                PendingUserComment = string.Empty
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: "نوع سرویس را انتخاب کنید:",
                    replyMarkup: _purchaseService.BuildServiceKeyboard(),
                    cancellationToken: cancellationToken);
            }
            return true;
        }

        var selectionState = _sessionStore.GetOrCreate(credUser.TelegramUserId);

        if (callback.Action == "cnt")
        {
            var serviceKey = string.IsNullOrWhiteSpace(selectionState.ServiceKey)
                ? user.SelectedCountry
                : selectionState.ServiceKey;
            var service = string.Equals(user.Flow, PurchaseFlowName, StringComparison.Ordinal)
                ? FindService(serviceKey)
                : null;
            if (service != null)
                RehydratePurchaseSelectionFromState(selectionState, service, user);

            var target = DeterminePurchaseRecoveryTarget(
                service,
                selectionState,
                PurchaseStepAccountCount,
                credUser.IsColleague);
            if (target != PurchaseRecoveryTarget.None)
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    service,
                    target,
                    cancellationToken);
                return true;
            }

            var count = XuiV3PurchaseService.NormalizeAccountCount(callback.AccountCount ?? 1);
            selectionState.AccountCount = count;
            _sessionStore.Set(credUser.TelegramUserId, selectionState);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepUserComment,
                SelectedCountry = service.Key,
                TotoalGB = selectionState.TrafficGb?.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = selectionState.DurationKey ?? string.Empty,
                Type = selectionState.UnlimitedPlanKey ?? string.Empty,
                PendingAccountCount = count
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: $"تعداد انتخاب شد: {count}",
                    cancellationToken: cancellationToken);
            }

            await botClient.SendMessage(
                chatId: chatId,
                text: "اگر برای این سفارش کامنتی دارید بفرستید. این کامنت روی اکانت ذخیره می‌شود و بعداً در وضعیت اکانت نمایش داده می‌شود.",
                replyMarkup: BuildOptionalCommentReplyKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        if (callback.Action == "svc")
        {
            var service = FindService(callback.ServiceKey);
            if (service == null)
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    null,
                    PurchaseRecoveryTarget.Service,
                    cancellationToken);
                return true;
            }

            selectionState.ServiceKey = callback.ServiceKey;
            selectionState.TrafficGb = null;
            selectionState.DurationKey = null;
            selectionState.UnlimitedPlanKey = null;
            selectionState.AccountCount = 1;
            selectionState.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selectionState);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = service.IsUnlimited ? PurchaseStepSelectUnlimitedPlan : PurchaseStepSelectTraffic,
                SelectedCountry = service.Key,
                SelectedPeriod = string.Empty,
                Type = string.Empty,
                TotoalGB = string.Empty,
                PendingUserComment = string.Empty
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: service.IsUnlimited
                        ? $"سرویس انتخاب شد: {service.DisplayName}\nحالا یکی از پلن‌های نامحدود را انتخاب کنید:"
                        : $"سرویس انتخاب شد: {service.DisplayName}\nحالا یکی از دکمه‌های حجم را بزنید یا حجم دلخواه را به صورت عدد صحیح بفرستید؛ مثلا 7 یا ۷.",
                    replyMarkup: service.IsUnlimited
                        ? _purchaseService.BuildUnlimitedPlanKeyboard(service.Key, credUser.IsColleague)
                        : _purchaseService.BuildTrafficKeyboard(service.Key),
                    cancellationToken: cancellationToken);
            }

            return true;
        }

        if (callback.Action == "gb")
        {
            var service = FindService(callback.ServiceKey);
            if (service == null || service.IsUnlimited || !callback.TrafficGb.HasValue ||
                !XuiV3PurchaseService.MeetsMinimumTraffic(service, callback.TrafficGb.Value))
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    service,
                    service == null
                        ? PurchaseRecoveryTarget.Service
                        : service.IsUnlimited
                            ? PurchaseRecoveryTarget.UnlimitedPlan
                            : PurchaseRecoveryTarget.Traffic,
                    cancellationToken);
                return true;
            }

            selectionState.ServiceKey = callback.ServiceKey;
            selectionState.TrafficGb = callback.TrafficGb;
            selectionState.DurationKey = null;
            selectionState.UnlimitedPlanKey = null;
            selectionState.AccountCount = 1;
            selectionState.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selectionState);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepSelectDuration,
                SelectedCountry = service.Key,
                TotoalGB = callback.TrafficGb.Value.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = string.Empty,
                Type = string.Empty,
                PendingUserComment = string.Empty
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        $"حجم انتخاب شد: {callback.TrafficGb} GB\nحالا مدت را انتخاب کنید:"),
                    replyMarkup: _purchaseService.BuildDurationKeyboard(callback.ServiceKey, callback.TrafficGb ?? 0),
                    cancellationToken: cancellationToken);
            }
            return true;
        }

        if (callback.Action == "dur")
        {
            var service = FindService(callback.ServiceKey);
            if (service == null || service.IsUnlimited || !callback.TrafficGb.HasValue ||
                !XuiV3PurchaseService.MeetsMinimumTraffic(service, callback.TrafficGb.Value))
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    service,
                    service == null
                        ? PurchaseRecoveryTarget.Service
                        : service.IsUnlimited
                            ? PurchaseRecoveryTarget.UnlimitedPlan
                            : PurchaseRecoveryTarget.Traffic,
                    cancellationToken);
                return true;
            }

            selectionState.ServiceKey = service.Key;
            selectionState.TrafficGb = callback.TrafficGb;

            var duration = XuiV3PurchaseService.GetEnabledDurationOptions(service).FirstOrDefault(option =>
                string.Equals(option.Key, callback.DurationKey, StringComparison.OrdinalIgnoreCase));
            if (duration == null)
            {
                // Telegram buttons can outlive catalog edits; durable and in-memory values must be cleared together.
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    service,
                    PurchaseRecoveryTarget.Duration,
                    cancellationToken);
                return true;
            }

            selectionState.ServiceKey = callback.ServiceKey;
            selectionState.TrafficGb = callback.TrafficGb;
            selectionState.DurationKey = callback.DurationKey;
            selectionState.UnlimitedPlanKey = null;
            selectionState.AccountCount = 1;
            selectionState.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selectionState);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepAccountCount,
                SelectedCountry = service.Key,
                TotoalGB = callback.TrafficGb.Value.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = duration.Key,
                Type = string.Empty,
                PendingUserComment = string.Empty
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: $"تعداد اکانت مورد نظر را وارد کنید. حداکثر تعداد در هر سفارش {XuiV3PurchaseService.MaxBulkAccountCount} است.",
                    replyMarkup: BuildAccountCountInlineKeyboard(),
                    cancellationToken: cancellationToken);
            }
            return true;
        }

        if (callback.Action == "upl")
        {
            var service = FindService(callback.ServiceKey);
            if (service == null || !service.IsUnlimited)
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    null,
                    PurchaseRecoveryTarget.Service,
                    cancellationToken);
                return true;
            }

            selectionState.ServiceKey = service.Key;
            selectionState.TrafficGb = null;
            selectionState.DurationKey = null;
            selectionState.UnlimitedPlanKey = callback.UnlimitedPlanKey;

            var unlimitedPlan = service.UnlimitedPlans?.FirstOrDefault(plan =>
                string.Equals(plan.Key, callback.UnlimitedPlanKey, StringComparison.OrdinalIgnoreCase));
            if (!XuiV3PurchaseService.IsUnlimitedPlanAvailableForOwnedBot(
                    unlimitedPlan,
                    credUser.IsColleague))
            {
                unlimitedPlan = null;
            }
            if (unlimitedPlan == null)
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selectionState,
                    service,
                    PurchaseRecoveryTarget.UnlimitedPlan,
                    cancellationToken);
                return true;
            }

            selectionState.AccountCount = 1;
            selectionState.UserComment = null;
            _sessionStore.Set(credUser.TelegramUserId, selectionState);

            await _state.ResetUserStatus(new User
            {
                Id = credUser.TelegramUserId,
                Flow = PurchaseFlowName,
                LastStep = PurchaseStepAccountCount,
                SelectedCountry = service.Key,
                SelectedPeriod = string.Empty,
                Type = unlimitedPlan.Key,
                TotoalGB = string.Empty,
                PendingUserComment = string.Empty
            });

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: $"تعداد اکانت مورد نظر را وارد کنید. حداکثر تعداد در هر سفارش {XuiV3PurchaseService.MaxBulkAccountCount} است.",
                    replyMarkup: BuildAccountCountInlineKeyboard(),
                    cancellationToken: cancellationToken);
            }
            return true;
        }

        if (callback.Action == "ok" || callback.Action == "sitepay")
        {
            if (!string.Equals(user.Flow, PurchaseFlowName, StringComparison.Ordinal) ||
                !string.Equals(user.LastStep, PurchaseStepConfirm, StringComparison.Ordinal))
            {
                // Confirmation data contains enough plan detail to recover from a process restart. The persisted
                // confirmation state is therefore the authority that distinguishes a recoverable callback from one
                // abandoned through wallet charging, cancellation, or another bot-scoped flow.
                _sessionStore.Clear(credUser.TelegramUserId);
                if (messageId != 0)
                {
                    await SafeEditMessageTextAsync(
                        botClient,
                        chatId: chatId,
                        messageId: messageId,
                        text: "این درخواست خرید منقضی شده است. لطفاً خرید را از ابتدا آغاز کنید.",
                        cancellationToken: cancellationToken);
                }

                return true;
            }

            var hasSession = _sessionStore.TryGet(credUser.TelegramUserId, out var selection);
            if (!hasSession || selection == null || string.IsNullOrWhiteSpace(selection.ServiceKey))
            {
                // Callback payloads are presentation data and can outlive another purchase. Rebuild from the active
                // bot-scoped confirmation row so an older button cannot replace the service, duration, plan, or count.
                selection = new XuiV3PurchaseSelection
                {
                    ServiceKey = user.SelectedCountry,
                    AccountCount = XuiV3PurchaseService.NormalizeAccountCount(user.PendingAccountCount),
                    UserComment = user.PendingUserComment
                };
                Console.WriteLine($"[XUIv3] confirm fallback from bot-scoped state for user {credUser.TelegramUserId}");
            }

            if (selection == null || string.IsNullOrWhiteSpace(selection.ServiceKey))
            {
                Console.WriteLine($"[XUIv3] confirm failed: selection is still empty for user {credUser.TelegramUserId}");
                return true;
            }

            var confirmationService = FindService(selection.ServiceKey);
            if (confirmationService != null)
                RehydratePurchaseSelectionFromState(selection, confirmationService, user);

            var confirmationRecoveryTarget = DeterminePurchaseRecoveryTarget(
                confirmationService,
                selection,
                PurchaseStepConfirm,
                credUser.IsColleague);
            if (confirmationRecoveryTarget != PurchaseRecoveryTarget.None)
            {
                await RecoverPurchaseStateAsync(
                    botClient,
                    chatId,
                    messageId,
                    credUser,
                    user,
                    selection,
                    confirmationService,
                    confirmationRecoveryTarget,
                    cancellationToken);
                return true;
            }

            XuiOperationTiming operationTiming = null;
            try
            {
                if (selection.AccountCount <= 0)
                    selection.AccountCount = XuiV3PurchaseService.NormalizeAccountCount(user.PendingAccountCount);
                if (selection.UserComment == null)
                    selection.UserComment = user.PendingUserComment;

                var resolved = _purchaseService.ResolveOwnedPurchase(selection, credUser.IsColleague);
                var accountCount = XuiV3PurchaseService.NormalizeAccountCount(selection.AccountCount);
                var totalPrice = resolved.PriceToman * accountCount;
                var useSiteWallet = callback.Action == "sitepay";
                Console.WriteLine($"[XUIv3] confirm start user={credUser.TelegramUserId} service={resolved.Service.Key} trafficGb={resolved.TrafficGb} durationDays={resolved.DurationDays} count={accountCount} unitPrice={resolved.PriceToman} totalPrice={totalPrice}");

                if (!useSiteWallet && credUser.AccountBalance < totalPrice)
                {
                    Console.WriteLine($"[XUIv3] insufficient balance user={credUser.TelegramUserId} balance={credUser.AccountBalance} price={totalPrice}");
                    await _activityLog.LogWarningAsync(
                        "xui_v3_create_insufficient_balance",
                        credUser,
                        false,
                        new Dictionary<string, object>
                        {
                            ["serviceKey"] = resolved.Service.Key,
                            ["trafficGb"] = resolved.TrafficGb,
                            ["durationDays"] = resolved.DurationDays,
                            ["accountCount"] = accountCount,
                            ["priceToman"] = totalPrice,
                            ["balanceToman"] = credUser.AccountBalance
                        },
                        cancellationToken);

                    if (messageId != 0)
                    {
                        await SafeEditMessageTextAsync(
                            botClient,
                            chatId: chatId,
                            messageId: messageId,
                            text: "⛔️ موجودی کیف پول شما برای خرید کافی نیست.\n" +
                                  $"💳 موجودی فعلی: {credUser.AccountBalance.FormatCurrency()}\n" +
                                  $"💰 مبلغ مورد نیاز: {totalPrice.FormatCurrency()}\n\n" +
                                  "برای ادامه، کیف پول خود را شارژ کنید.",
                            replyMarkup: BuildPurchaseInsufficientBalanceKeyboard(),
                            cancellationToken: cancellationToken);
                    }
                    return true;
                }

                if (useSiteWallet)
                {
                    var eligibility = await _gozargahSiteSyncService.CheckSiteWalletEligibilityAsync(
                        credUser.TelegramUserId,
                        totalPrice,
                        cancellationToken);
                    if (!eligibility.CanUse)
                    {
                        if (messageId != 0)
                        {
                            await SafeEditMessageTextAsync(
                                botClient,
                                chatId: chatId,
                                messageId: messageId,
                                text: $"پرداخت با کیف پول سایت گذرگاه ممکن نیست.\n{eligibility.Message}",
                                replyMarkup: BuildPurchaseConfirmKeyboard(selection),
                                cancellationToken: cancellationToken);
                        }
                        return true;
                    }
                }

                // Begin actual execution only after plan and wallet eligibility are valid. This deliberately excludes
                // the time the customer spent reviewing or confirming the purchase.
                operationTiming = XuiOperationTiming.Start();

                if (messageId != 0)
                {
                    await SafeEditMessageTextAsync(
                        botClient,
                        chatId: chatId,
                        messageId: messageId,
                        text: "در حال ساخت اکانت، لطفاً چند لحظه صبر کنید...",
                        cancellationToken: cancellationToken);
                }

                var serverInfo = BuildConfiguredPanelServerInfo();
                Console.WriteLine($"[XUIv3] using configured panel url={serverInfo.Url}, rootPath={serverInfo.RootPath}, token={(string.IsNullOrWhiteSpace(serverInfo.ApiToken) ? "missing" : "set")}");

                if (string.IsNullOrWhiteSpace(user.PurchaseSessionId))
                {
                    user.PurchaseSessionId = Guid.NewGuid().ToString("N");
                    await _state.SaveUserStatus(user);
                }

                var bulkResult = await _purchaseService.CreateBulkAccountsAsync(
                    credUser,
                    serverInfo,
                    selection,
                    serverInfo.Url,
                    new XuiV3BulkCreateOptions
                    {
                        BulkOrderId = $"purchase:{BotContextAccessor.CurrentBotId}:{user.PurchaseSessionId}",
                        AccountCount = accountCount,
                        UserComment = selection.UserComment,
                        CreatedByTelegramUserId = credUser.TelegramUserId,
                        LastUpdatedByTelegramUserId = credUser.TelegramUserId,
                        LastAction = "customer-create",
                        NextAccountCounter = user.AccountCounter + 1,
                        SaveUserStatus = true
                    },
                    cancellationToken);

                Console.WriteLine($"[XUIv3] bulk create result user={credUser.TelegramUserId} success={bulkResult.Success} requested={bulkResult.RequestedCount} created={bulkResult.SuccessfulCount} failures={bulkResult.Failures.Count} serverUrl={serverInfo.Url} rootPath={serverInfo.RootPath}");

                if (bulkResult.SuccessfulCount == 0)
                {
                    var failureMessage = XuiV3UserSafeError.ForAccountCreation(
                        bulkResult.Failures.FirstOrDefault()?.Message);
                    await _activityLog.LogWarningAsync(
                        "xui_v3_bulk_account_create_failed",
                        credUser,
                        false,
                        new Dictionary<string, object>
                        {
                            ["serviceKey"] = resolved.Service.Key,
                            ["trafficGb"] = resolved.TrafficGb,
                            ["durationDays"] = resolved.DurationDays,
                            ["accountCount"] = accountCount,
                            ["priceToman"] = totalPrice,
                            ["message"] = failureMessage,
                            ["panelUrl"] = serverInfo.Url,
                            ["rootPath"] = serverInfo.RootPath
                        },
                        cancellationToken);

                    LogXuiOperationOutcome(
                        accountCount > 1 ? "ساخت انبوه اکانت نسخه ۳" : "ساخت اکانت نسخه ۳",
                        "ناموفق",
                        credUser,
                        operationTiming,
                        source: "purchase",
                        requestedCount: bulkResult.RequestedCount,
                        successfulCount: 0);

                    if (messageId != 0)
                    {
                        await SafeEditMessageTextAsync(
                            botClient,
                            chatId: chatId,
                            messageId: messageId,
                            text: $"ساخت اکانت ناموفق بود.\n{failureMessage}",
                            cancellationToken: cancellationToken);
                    }
                    await ReturnToMainMenuAsync(
                        botClient, chatId, 0, credUser, user, mainReplyMarkup, cancellationToken);
                    return true;
                }

                GozargahSiteWalletDebitResult siteWalletDebitResult = null;
                if (useSiteWallet)
                {
                    var debitResult = await _gozargahSiteSyncService.DeductSiteWalletAfterPanelSuccessAsync(
                        credUser.TelegramUserId,
                        bulkResult.TotalSuccessfulPriceToman,
                        "xui-v3-bulk",
                        bulkResult.BulkOrderId,
                        $"XuiV3 purchase via Gozargah site wallet: {string.Join(", ", bulkResult.CreatedAccounts.Select(x => x.Email).Take(10))}",
                        cancellationToken);
                    if (!debitResult.Success)
                    {
                        await TryRollbackCreatedAccountsAsync(serverInfo, bulkResult.CreatedAccounts, cancellationToken);
                        await _activityLog.LogWarningAsync(
                            "gozargah_site_wallet_debit_failed_after_create",
                            credUser,
                            false,
                            new Dictionary<string, object>
                            {
                                ["bulkOrderId"] = bulkResult.BulkOrderId,
                                ["priceToman"] = bulkResult.TotalSuccessfulPriceToman,
                                ["createdAccounts"] = string.Join(",", bulkResult.CreatedAccounts.Select(x => x.Email)),
                                ["error"] = debitResult.ErrorMessage ?? string.Empty
                            },
                            cancellationToken);

                        LogXuiOperationOutcome(
                            accountCount > 1 ? "ساخت انبوه اکانت نسخه ۳" : "ساخت اکانت نسخه ۳",
                            "ساخته شد و پس از خطای تسویه برگشت خورد",
                            credUser,
                            operationTiming,
                            source: "purchase-site-wallet",
                            requestedCount: bulkResult.RequestedCount,
                            successfulCount: bulkResult.SuccessfulCount);

                        if (messageId != 0)
                        {
                            await SafeEditMessageTextAsync(
                                botClient,
                                chatId: chatId,
                                messageId: messageId,
                                text: "ساخت اکانت روی پنل انجام شد، اما کسر کیف پول سایت گذرگاه ناموفق بود. اکانت‌های ساخته‌شده برای جلوگیری از تحویل بدون پرداخت حذف شدند و موضوع برای بررسی ثبت شد.",
                                cancellationToken: cancellationToken);
                        }
                        await ReturnToMainMenuAsync(
                            botClient, chatId, 0, credUser, user, mainReplyMarkup, cancellationToken);
                        return true;
                    }

                    siteWalletDebitResult = debitResult;
                }

                var bulkBeforeBalance = useSiteWallet && siteWalletDebitResult?.Success == true
                    ? siteWalletDebitResult.BeforeWallet
                    : credUser.AccountBalance;
                var bulkAfterBalance = useSiteWallet && siteWalletDebitResult?.Success == true
                    ? siteWalletDebitResult.AfterWallet
                    : bulkBeforeBalance;
                if (!useSiteWallet)
                {
                    if (bulkResult.TotalSuccessfulPriceToman > 0)
                        await _credentialsDbContext.Pay(credUser, bulkResult.TotalSuccessfulPriceToman, $"purchase:{bulkResult.BulkOrderId}:debit");
                    bulkAfterBalance = await _credentialsDbContext.GetAccountBalance(credUser.TelegramUserId);
                    // One ledger row represents the whole successful bulk purchase so the order can be
                    // audited without creating a noisy transaction per generated account.
                    await _walletLedgerService.RecordAsync(
                        credUser.TelegramUserId,
                        WalletLedgerDirections.Debit,
                        bulkResult.TotalSuccessfulPriceToman,
                        bulkBeforeBalance,
                        bulkAfterBalance,
                        WalletLedgerReasons.AccountPurchase,
                        provider: "wallet",
                        referenceType: "xui-v3-bulk",
                        referenceId: bulkResult.BulkOrderId,
                        orderId: bulkResult.BulkOrderId,
                        description: string.Join(", ", bulkResult.CreatedAccounts.Select(x => x.Email).Take(10)),
                        idempotencyKey: $"purchase:{bulkResult.BulkOrderId}:debit",
                        cancellationToken: cancellationToken);
                }

                if (messageId != 0)
                {
                    await SafeEditMessageTextAsync(
                        botClient,
                        chatId: chatId,
                        messageId: messageId,
                        text: bulkResult.Success
                            ? $"✅ {bulkResult.SuccessfulCount} اکانت ساخته شد. مشخصات و QR Code در پیام‌های بعدی ارسال می‌شود."
                            : $"⚠️ {bulkResult.SuccessfulCount} اکانت ساخته شد، اما ادامه ساخت متوقف شد. مشخصات اکانت‌های موفق ارسال می‌شود.",
                        parseMode: ParseMode.Html,
                        cancellationToken: cancellationToken);
                }

                foreach (var createdAccount in bulkResult.CreatedAccounts)
                {
                    await QueueGozargahSyncBestEffortAsync(
                        "create",
                        () => _gozargahSiteSyncService.QueueCreateAsync(
                            ResolveGozargahSiteOwnerTelegramUserId(credUser),
                            credUser.TelegramUserId,
                            createdAccount,
                            bulkResult.BulkOrderId,
                            ResolveGozargahTenantBotId(),
                            cancellationToken: cancellationToken));

                    var createdAccountText = _purchaseService.BuildCreatedAccountText(createdAccount);
                    if (!string.IsNullOrWhiteSpace(createdAccount.SubLink))
                    {
                        using var qrStream = new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(createdAccount.SubLink, 200));
                        await botClient.SendPhoto(
                            chatId: chatId,
                            photo: InputFile.FromStream(qrStream, "subscription-qr.png"),
                            caption: createdAccountText,
                            parseMode: ParseMode.Html,
                            cancellationToken: cancellationToken);
                    }
                    else
                    {
                        await botClient.SendMessage(
                            chatId: chatId,
                            text: createdAccountText,
                            parseMode: ParseMode.Html,
                            cancellationToken: cancellationToken);
                    }

                    await Task.Delay(250, cancellationToken);
                }

                if (bulkResult.Failures.Count > 0)
                {
                    await botClient.SendMessage(
                        chatId: chatId,
                        text: BuildBulkFailureText(bulkResult),
                        parseMode: ParseMode.Html,
                        cancellationToken: cancellationToken);
                }

                LogV3Purchase(
                    title: accountCount > 1 ? "ساخت انبوه اکانت نسخه ۳" : "ساخت اکانت نسخه ۳",
                    credUser: credUser,
                    priceToman: bulkResult.TotalSuccessfulPriceToman,
                    beforeBalance: bulkBeforeBalance,
                    afterBalance: bulkAfterBalance,
                    paymentWalletSource: useSiteWallet && siteWalletDebitResult?.Success == true
                        ? "کیف پول سایت گذرگاه"
                        : "کیف پول ربات",
                    details: BuildBulkPurchaseLogDetails(bulkResult, selection.UserComment),
                    timing: operationTiming.Snapshot());

                var purchaseTiming = operationTiming.Snapshot();

                await _activityLog.LogBotActionAsync(
                    accountCount > 1 ? "xui_v3_bulk_accounts_created" : "xui_v3_account_created",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["bulkOrderId"] = bulkResult.BulkOrderId,
                        ["requestedCount"] = bulkResult.RequestedCount,
                        ["successfulCount"] = bulkResult.SuccessfulCount,
                        ["accountEmails"] = bulkResult.CreatedAccounts.Select(item => item.Email).ToList(),
                        ["serviceKey"] = resolved.Service.Key,
                        ["serviceName"] = resolved.Service.DisplayName,
                        ["trafficGb"] = resolved.TrafficGb,
                        ["trafficBytes"] = bulkResult.TrafficBytes,
                        ["durationDays"] = resolved.DurationDays,
                        ["unitPriceToman"] = bulkResult.UnitPriceToman,
                        ["priceToman"] = bulkResult.TotalSuccessfulPriceToman,
                        ["balanceBeforeToman"] = bulkBeforeBalance,
                        ["balanceAfterToman"] = bulkAfterBalance,
                        ["paymentSource"] = useSiteWallet && siteWalletDebitResult?.Success == true
                            ? "gozargah_site_wallet"
                            : "bot_wallet",
                        ["panelUrl"] = serverInfo.Url,
                        ["rootPath"] = serverInfo.RootPath,
                        ["userComment"] = selection.UserComment ?? string.Empty,
                        ["panelApiElapsedMs"] = (long)purchaseTiming.PanelApiElapsed.TotalMilliseconds,
                        ["totalElapsedMs"] = (long)purchaseTiming.TotalElapsed.TotalMilliseconds
                    },
                    cancellationToken);

                _sessionStore.Clear(credUser.TelegramUserId);
                await _state.ClearUserStatus(user);
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "✅ خرید با موفقیت انجام شد.\n\n" +
                          BuildSelectedWalletBalanceText(useSiteWallet, bulkBeforeBalance, bulkResult.TotalSuccessfulPriceToman, bulkAfterBalance, siteWalletDebitResult) +
                          "\n\nمنوی اصلی",
                    parseMode: ParseMode.Html,
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: cancellationToken);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XUIv3] confirm exception user={credUser.TelegramUserId}: {ex}");
                await _activityLog.LogErrorAsync(
                    "xui_v3_confirm_failed",
                    ex,
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["callbackData"] = callbackQuery.Data ?? string.Empty
                    },
                    cancellationToken);
                LogXuiOperationOutcome(
                    "ساخت اکانت نسخه ۳",
                    $"خطا ({ex.GetType().Name})",
                    credUser,
                    operationTiming,
                    source: "purchase");
                if (messageId != 0)
                {
                    await SafeEditMessageTextAsync(
                        botClient,
                        chatId: chatId,
                        messageId: messageId,
                        text: "در ساخت اکانت خطا رخ داد. جزئیات در ترمینال ثبت شد.",
                        cancellationToken: cancellationToken);
                }
            }
            finally
            {
                operationTiming?.Dispose();
            }
            return true;
        }

        return false;
    }

    /// <summary>Starts an account-search conversation for the specified user in the active bot.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="chatId">Telegram destination chat id in the active bot, not an internal user or tenant database id.</param>
    /// <param name="telegramUserId">Positive Telegram actor id owning the conversation in the active bot.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <param name="messageId">Telegram message id to edit; zero or null, as allowed by the signature, requests a new message.</param>
    /// <returns>A task completing after the documented state transition and any required Telegram or panel work.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task StartAccountSearchAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        long telegramUserId,
        CancellationToken cancellationToken,
        int messageId = 0)
    {
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = telegramUserId,
            Flow = AccountSearchFlowName,
            LastStep = AccountSearchStepQuery,
            ConfigLink = null
        });

        const string text = "عبارت جستجو را بفرستید.\n\n" +
                            "می‌توانید نام اکانت، شماره اکانت، بخشی از کامنت، UUID، ساب‌لینک، Subscription ID، لینک vless یا لینک vmess را ارسال کنید.\n\n" +
                            "اگر اکانت پیدا شده متعلق به شما نباشد، فقط امکان تمدید آن فعال می‌شود.";

        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: text,
                replyMarkup: BuildSearchStartKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: text,
            replyMarkup: BuildSearchStartKeyboard(),
            cancellationToken: cancellationToken);
    }

    /// <summary>Clears the current conversation and displays the applicable customer main menu.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="chatId">Telegram destination chat id in the active bot, not an internal user or tenant database id.</param>
    /// <param name="messageId">Telegram message id to edit; zero or null, as allowed by the signature, requests a new message.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="user">Detached current bot/user state; explicit store writes reload their targets and never attach this snapshot.</param>
    /// <param name="mainReplyMarkup">Reply markup selected for the current bot and user role, or null when no keyboard is required.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>A task completing after the documented state transition and any required Telegram or panel work.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task ReturnToMainMenuAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        if (credUser != null)
            _sessionStore.Clear(credUser.TelegramUserId);

        var userId = user?.Id ?? credUser?.TelegramUserId ?? 0;
        if (userId > 0)
            await _state.ClearUserStatus(user ?? new User { Id = userId });

        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: "به منوی اصلی برگشتید.",
                cancellationToken: cancellationToken);
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: "منوی اصلی",
            replyMarkup: mainReplyMarkup,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Resolves and renders paged account search results, including direct UUID and subscription-id lookups.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned or tenant storefront bot.</param>
    /// <param name="chatId">Telegram chat that receives or owns the editable search result.</param>
    /// <param name="credUser">Bot-scoped requester whose Telegram id is used for ownership filtering.</param>
    /// <param name="query">User-supplied account text, UUID, SubId, email, comment, or supported search fragment.</param>
    /// <param name="page">Zero-based search-result page to render.</param>
    /// <param name="cancellationToken">Token that cancels state persistence, panel reads, and Telegram delivery.</param>
    /// <param name="messageId">Existing Telegram message to edit, or zero to send a separate result message.</param>
    /// <returns>A task that completes after the search state and result UI have been delivered.</returns>
    /// <remarks>
    /// Normal fuzzy results are restricted to accounts owned by the requester. Any of the four exact renewal
    /// identifiers may produce a non-owner renewal-only card, but only owner matches receive private usage details and
    /// the complete management/configuration menu. Sensitive direct identifiers are never echoed or placed in callbacks.
    /// </remarks>
    private async Task SendAccountSearchResultsAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CredUser credUser,
        string query,
        int page,
        CancellationToken cancellationToken,
        int messageId = 0)
    {
        var normalizedQuery = NormalizeSearchText(query);
        if (string.IsNullOrWhiteSpace(normalizedQuery))
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "عبارت جستجو معتبر نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
        if (!response.Success)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                $"دریافت اکانت‌ها ناموفق بود.\n{response.Msg}",
                cancellationToken: cancellationToken);
            return;
        }

        var allClients = response.Obj ?? new List<XuiV3Client>();
        await _state.SaveUserStatus(new User
        {
            Id = credUser.TelegramUserId,
            Flow = AccountSearchFlowName,
            LastStep = AccountSearchStepResults,
            ConfigLink = query
        });

        var directResolution = XuiV3RenewalTargetResolver.Resolve(allClients, query);
        var directOwnedWithoutUuid =
            directResolution.Status == XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid &&
            ClientBelongsToUser(directResolution.Client, credUser.TelegramUserId);
        if (directResolution.Success || directOwnedWithoutUuid)
        {
            var directClient = directResolution.Client;
            var isOwner = ClientBelongsToUser(directClient, credUser.TelegramUserId);
            var text = BuildDirectSearchResultText(
                directClient,
                serverInfo,
                isOwner,
                BuildRenewInputKindLabel(directResolution.InputKind));
            var keyboard = isOwner
                ? BuildAccountDetailsKeyboard(directClient, page, IsClientRenewable(directClient), fromSearch: true)
                : BuildExternalSearchResultKeyboard(
                    directClient,
                    IsClientRenewable(directClient) && SearchQueryAuthorizesExternalRenew(query, directClient));

            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                text,
                ParseMode.Html,
                keyboard,
                cancellationToken);
            return;
        }

        if (directResolution.Status == XuiV3RenewalTargetResolutionStatus.Ambiguous ||
            directResolution.Status == XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                BuildRenewTargetResolutionFailureText(directResolution.Status),
                replyMarkup: BuildSearchEmptyKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        if (XuiV3RenewalTargetParser.TryParse(query, out var parsedDirectInput) &&
            parsedDirectInput.InputKind != XuiV3RenewalTargetInputKind.EmailOrSubscriptionId)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "هیچ اکانتی با شناسه دقیق ارسال‌شده پیدا نشد.",
                replyMarkup: BuildSearchEmptyKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        if (directResolution.Status == XuiV3RenewalTargetResolutionStatus.InvalidInput &&
            query.Contains("://", StringComparison.Ordinal))
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "کانفیگ یا لینک ارسال‌شده معتبر و قابل شناسایی نیست.",
                replyMarkup: BuildSearchEmptyKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        var results = allClients
            .Where(client => ClientBelongsToUser(client, credUser.TelegramUserId))
            .Where(client => ClientMatchesSearchQuery(client, normalizedQuery))
            .OrderBy(client => IsExpiredOrDepleted(client) ? 0 : 1)
            .ThenBy(client => client.Email)
            .ToList();

        if (results.Count == 0)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                $"برای عبارت زیر اکانتی بین اکانت‌های شما پیدا نشد:\n<code>{Html(query)}</code>",
                ParseMode.Html,
                BuildSearchEmptyKeyboard(),
                cancellationToken);
            return;
        }

        var totalPages = Math.Max(1, (int)Math.Ceiling(results.Count / (double)AccountListPageSize));
        page = Math.Clamp(page, 0, totalPages - 1);
        var pageAccounts = results
            .Skip(page * AccountListPageSize)
            .Take(AccountListPageSize)
            .ToList();

        var resultText = BuildAccountSearchListText(query, results.Count, page, totalPages);
        var resultKeyboard = BuildAccountSearchListKeyboard(pageAccounts, page, totalPages);

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            resultText,
            ParseMode.Html,
            resultKeyboard,
            cancellationToken);
    }

    private async Task SendV3AccountListPageAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int page,
        CredUser credUser,
        CancellationToken cancellationToken,
        int messageId = 0)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: $"دریافت اکانت‌ها ناموفق بود.\n{response.Msg}",
                cancellationToken: cancellationToken);
            return;
        }

        var accounts = response.Obj?
            .Where(client => ClientBelongsToUser(client, credUser.TelegramUserId))
            .OrderBy(client => IsExpiredOrDepleted(client) ? 0 : 1)
            .ThenBy(client => client.Email)
            .ToList() ?? new List<XuiV3Client>();

        if (accounts.Count == 0)
        {
            const string emptyText = "شما هنوز هیچ اکانتی از مجموعه ما ندارید.";
            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: emptyText,
                    cancellationToken: cancellationToken);
            }
            else
            {
                await botClient.SendMessage(
                    chatId: chatId,
                    text: emptyText,
                    cancellationToken: cancellationToken);
            }
            return;
        }

        var totalPages = Math.Max(1, (int)Math.Ceiling(accounts.Count / (double)AccountListPageSize));
        page = Math.Clamp(page, 0, totalPages - 1);
        var pageAccounts = accounts
            .Skip(page * AccountListPageSize)
            .Take(AccountListPageSize)
            .ToList();

        var text = BuildAccountListText(accounts.Count, page, totalPages);
        var keyboard = BuildAccountListKeyboard(pageAccounts, page, totalPages);

        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Reloads one list-selected account, verifies ownership, and renders its complete source-aware action card.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the list callback.</param>
    /// <param name="chatId">Telegram chat containing the selected account list.</param>
    /// <param name="messageId">List message id to edit, or zero to send a new account card.</param>
    /// <param name="credUser">Current bot user whose Telegram id must own the panel client.</param>
    /// <param name="clientId">Numeric panel client id selected from the account list.</param>
    /// <param name="page">Zero-based account-list page restored by later actions.</param>
    /// <param name="cancellationToken">Token that cancels panel lookup and Telegram delivery.</param>
    /// <returns>A task that completes after ownership rejection or account-card delivery.</returns>
    /// <remarks>
    /// Ownership is rechecked after the callback is received. The resulting menu is shared with search cards but uses
    /// list-specific renewal, mutation, state, and navigation callbacks.
    /// </remarks>
    private async Task HandleAccountViewCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var canRenew = IsClientRenewable(client);
        var text = BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, canRenew);
        var keyboard = BuildAccountDetailsKeyboard(client, page, canRenew);

        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Starts an owner-authorized renewal from an account-list callback and stores an exact panel UUID target lock.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned or tenant-routed bot.</param>
    /// <param name="chatId">Telegram chat containing the selected account card.</param>
    /// <param name="messageId">Account-card message id to edit, or zero to send a new result.</param>
    /// <param name="credUser">Current payer whose Telegram id must own the selected panel client.</param>
    /// <param name="user">Current bot-scoped state; it is cleared before the renewal selection is stored.</param>
    /// <param name="clientId">Numeric XUI client id transported by the callback.</param>
    /// <param name="page">Zero-based account-list page restored by the back button.</param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, and Telegram operations.</param>
    /// <returns>A task that completes after rejection or delivery of the renewal traffic/plan selector.</returns>
    /// <remarks>
    /// This route remains owner-only because numeric client ids are routing data, not one of the four customer proofs.
    /// A fresh panel UUID is still persisted so email reuse cannot redirect later preview or settlement.
    /// TenantBotService intercepts tenant renewal callbacks before they reach this owned-wallet state machine.
    /// </remarks>
    private async Task HandleAccountRenewCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        User user,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                chatId,
                user ?? new User { Id = credUser.TelegramUserId },
                "اکانت مورد نظر برای تمدید پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken);
            return;
        }

        if (!IsClientRenewable(client))
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                chatId,
                user ?? new User { Id = credUser.TelegramUserId },
                "این اکانت مربوط به inboundهای فعال پلن‌های فعلی ربات نیست و از طریق ربات قابل تمدید نیست.",
                cancellationToken);
            return;
        }

        var service = ResolveServiceForClient(client);
        if (service == null)
        {
            await SendOwnedRenewTerminalAsync(
                botClient,
                chatId,
                user ?? new User { Id = credUser.TelegramUserId },
                "سرویس این اکانت قابل تشخیص نیست و تمدید شروع نشد.",
                cancellationToken);
            return;
        }

        var targetUuid = TryNormalizeClientUuid(client.Uuid, out var normalizedTargetUuid)
            ? normalizedTargetUuid
            : string.Empty;

        await _state.ClearUserStatus(new User { Id = credUser.TelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = credUser.TelegramUserId,
            Flow = RenewFlowName,
            LastStep = service.IsUnlimited ? RenewStepUnlimitedPlan : RenewStepTraffic,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = targetUuid,
            PaymentMethod = "credit"
        });

        var text = service.IsUnlimited
            ? $"اکانت انتخاب شد: <code>{Html(client.Email)}</code>\nپلن تمدید نامحدود را انتخاب کنید."
            : $"اکانت انتخاب شد: <code>{Html(client.Email)}</code>\nحجم اضافه را به گیگابایت بفرستید.\nمی‌توانید عدد دلخواه مثل <code>7</code> یا <code>۷</code> وارد کنید.";

        var navigationKeyboard = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست", XuiV3PurchaseCallbacks.AccountList(page)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });

        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: navigationKeyboard,
                cancellationToken: cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: text,
                parseMode: ParseMode.Html,
                replyMarkup: navigationKeyboard,
                cancellationToken: cancellationToken);
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: service.IsUnlimited ? "یکی از پلن‌های زیر را انتخاب کنید:" : "یکی از حجم‌های زیر را انتخاب کنید یا عدد دلخواه بفرستید:",
            replyMarkup: service.IsUnlimited
                ? BuildUnlimitedPlanReplyKeyboard(service, credUser.IsColleague)
                : BuildTrafficReplyKeyboard(service),
            cancellationToken: cancellationToken);
    }

    private async Task HandleAccountDeleteAskCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای حذف پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var text = $"آیا از حذف این اکانت مطمئن هستید؟\n\nاکانت: <code>{Html(client.Email)}</code>\n\nاین عملیات فقط همین اکانت را حذف می‌کند.";
        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("تایید حذف", XuiV3PurchaseCallbacks.AccountDeleteConfirm(client.Id, page)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.AccountView(client.Id, page)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });

        await SafeEditMessageTextAsync(
            botClient,
            chatId: chatId,
            messageId: messageId,
            text: text,
            parseMode: ParseMode.Html,
            replyMarkup: keyboard,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Confirms deletion of one owned account selected from the paged account list and audits the measured outcome.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the callback.</param>
    /// <param name="chatId">Telegram chat containing the source account card.</param>
    /// <param name="messageId">Message id edited with the terminal deletion result.</param>
    /// <param name="credUser">Current user whose Telegram id must still own the panel account.</param>
    /// <param name="clientId">Numeric XUI client id encoded by the account-list callback.</param>
    /// <param name="page">Zero-based account-list page restored by result navigation.</param>
    /// <param name="cancellationToken">Token that cancels panel, activity-log, website-sync, and Telegram work.</param>
    /// <returns>A task that completes after safe rejection or the delete result is delivered.</returns>
    /// <remarks>
    /// Ownership is revalidated immediately before deletion. The audit reports API and total elapsed duration but
    /// never includes UUID, SubId, configuration data, token, or raw panel response content.
    /// </remarks>
    private async Task HandleAccountDeleteConfirmCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        using var operationTiming = XuiOperationTiming.Start();
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            LogXuiOperationOutcome(
                "حذف اکانت نسخه ۳",
                "اکانت پیدا نشد یا قبلاً حذف شده است",
                credUser,
                operationTiming,
                source: "list");
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای حذف پیدا نشد یا قبلاً حذف شده است.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var deleteResponse = await ApiServicev3.DeleteClientAsync(serverInfo, _configuration, client.Email, cancellationToken);
        if (!deleteResponse.Success)
        {
            LogXuiOperationOutcome(
                "حذف اکانت نسخه ۳",
                "پنل حذف را رد کرد",
                credUser,
                operationTiming,
                accountEmail: client.Email,
                source: "list");
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: $"حذف اکانت ناموفق بود.\n{deleteResponse.Msg}",
                replyMarkup: new InlineKeyboardMarkup(new[]
                {
                    new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.AccountView(client.Id, page)) },
                    new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
                }),
                cancellationToken: cancellationToken);
            return;
        }

        await _activityLog.LogBotActionAsync(
            "xui_v3_account_deleted_by_user",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["accountEmail"] = client.Email,
                ["panelUrl"] = serverInfo.Url,
                ["rootPath"] = serverInfo.RootPath,
                ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
            },
            cancellationToken);
        LogAccountDelete(client, credUser, "list", operationTiming.Snapshot());
        await QueueGozargahSyncBestEffortAsync(
            "delete",
            () => _gozargahSiteSyncService.QueueDeleteAsync(
                ResolveGozargahSiteOwnerTelegramUserId(credUser),
                credUser.TelegramUserId,
                client,
                $"delete-{client.Email}-{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}",
                ResolveGozargahTenantBotId(),
                cancellationToken: cancellationToken));

        await SafeEditMessageTextAsync(
            botClient,
            chatId: chatId,
            messageId: messageId,
            text: $"اکانت با موفقیت حذف شد.\n\nاکانت: <code>{Html(client.Email)}</code>",
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست", XuiV3PurchaseCallbacks.AccountList(page)) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            }),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Prepares an explicit, durable confirmation for changing one XUI account link without mutating the panel.
    /// </summary>
    /// <param name="botClient">Telegram client of the owned or tenant bot that received the callback.</param>
    /// <param name="chatId">Telegram chat id that receives progress, success, or partial-failure messages.</param>
    /// <param name="messageId">Editable Telegram message id, or zero when a new message must be sent.</param>
    /// <param name="credUser">
    /// Shared credentials profile of the customer. Its numeric Telegram id is used as the ownership guard and audit actor.
    /// </param>
    /// <param name="clientId">Numeric XUI v3 client id selected from the account list or search results.</param>
    /// <param name="page">Zero-based account-list/search page restored in result keyboards.</param>
    /// <param name="fromSearch">Whether the callback originated from account search rather than the account list.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, XUI, website-sync, and activity-log operations.</param>
    /// <returns>A task that completes after the confirmation or existing-operation status is displayed.</returns>
    /// <remarks>
    /// Legacy <c>ach/asch</c> callback buttons terminate here. They can only create or reuse an awaiting-confirmation
    /// row and therefore can never rename an account directly. The users.db unique index prevents a second active
    /// operation for the same physical panel client even when several owned or tenant bots receive duplicate clicks.
    /// </remarks>
    private async Task HandleAccountChangeLinkCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        bool fromSearch,
        CancellationToken cancellationToken)
    {
        if (clientId == null || clientId <= 0)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "شناسه اکانت معتبر نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            "⏳ در حال آماده‌سازی تأیید تغییر لینک...",
            cancellationToken: cancellationToken);

        try
        {
            var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken, XuiV3RequestExecutionPolicy.ForegroundRead);
            var client = clientsResponse.Obj?.FirstOrDefault(item =>
                item.Id == clientId.Value && ClientBelongsToUser(item, credUser.TelegramUserId));
            if (!clientsResponse.Success || client == null)
            {
                await SendOrEditTextAsync(
                    botClient,
                    chatId,
                    messageId,
                    "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                    replyMarkup: BuildChangeLinkResultKeyboard(clientId.Value, page, fromSearch),
                    cancellationToken: cancellationToken);
                return;
            }

            var candidate = new XuiV3LinkChangeOperation
            {
                OperationKey = Guid.NewGuid().ToString("N"),
                PanelKey = XuiV3LinkChangeOperationStore.BuildPanelKey(serverInfo),
                BotId = BotContextAccessor.CurrentBotId,
                BotUsername = BotContextAccessor.CurrentBotUsername,
                BotType = BotContextAccessor.CurrentBotType,
                TelegramUserId = credUser.TelegramUserId,
                ChatId = chatId.Identifier ?? credUser.ChatID,
                MessageId = messageId,
                ClientId = client.Id,
                Source = fromSearch ? AccountCommentSourceSearch : AccountCommentSourceList,
                Page = page,
                OldEmail = client.Email,
                OldUuid = client.Uuid,
                OldSubId = string.IsNullOrWhiteSpace(client.SubId) ? client.Email : client.SubId
            };
            var operation = await _linkChangeOperationStore.CreateOrGetActiveAsync(candidate, cancellationToken);

            if (operation.TelegramUserId != credUser.TelegramUserId)
            {
                await SendOrEditTextAsync(
                    botClient,
                    chatId,
                    messageId,
                    "این اکانت در حال حاضر یک عملیات تغییر لینک فعال دارد. تا پایان بررسی پنل امکان شروع عملیات جدید وجود ندارد.",
                    cancellationToken: cancellationToken);
                return;
            }

            if (operation.Status == XuiV3LinkChangeStatuses.AwaitingConfirmation &&
                string.Equals(operation.BotId, BotContextAccessor.CurrentBotId, StringComparison.OrdinalIgnoreCase))
            {
                await SendOrEditTextAsync(
                    botClient,
                    chatId,
                    messageId,
                    BuildChangeLinkConfirmationText(operation),
                    ParseMode.Html,
                    BuildChangeLinkConfirmationKeyboard(operation),
                    cancellationToken);
                return;
            }

            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                BuildChangeLinkOperationStatusText(operation),
                ParseMode.Html,
                BuildChangeLinkStatusKeyboard(operation),
                cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "XUI link-change confirmation preparation failed. botId={BotId}, clientId={ClientId}",
                BotContextAccessor.CurrentBotId,
                clientId);
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "ارتباط با پنل برای آماده‌سازی تغییر لینک برقرار نشد. هیچ تغییری روی اکانت انجام نشده است؛ لطفاً کمی بعد دوباره تلاش کنید.",
                replyMarkup: BuildChangeLinkResultKeyboard(clientId.Value, page, fromSearch),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Confirms one unexpired operation exactly once and starts its foreground processing lease.
    /// </summary>
    /// <param name="botClient">Telegram client that received the confirmation callback.</param>
    /// <param name="chatId">Telegram chat containing the editable confirmation message.</param>
    /// <param name="messageId">Message id that will display progress and the final result.</param>
    /// <param name="credUser">Credentials profile whose numeric Telegram id must own the operation.</param>
    /// <param name="operationKey">Random callback-safe users.db operation key.</param>
    /// <param name="cancellationToken">Token that cancels database, panel, and Telegram work.</param>
    /// <returns>A task that completes after processing starts or the existing operation status is displayed.</returns>
    /// <remarks>
    /// Only the callback that atomically transitions the row to <c>processing</c> may call the panel. Duplicate
    /// confirmation callbacks receive the persisted status and cannot replay the mutation.
    /// </remarks>
    private async Task HandleAccountChangeLinkConfirmCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        string operationKey,
        CancellationToken cancellationToken)
    {
        var claim = await _linkChangeOperationStore.ConfirmAsync(
            operationKey,
            BotContextAccessor.CurrentBotId,
            credUser.TelegramUserId,
            cancellationToken);
        if (claim.Operation == null || claim.Operation.TelegramUserId != credUser.TelegramUserId)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "درخواست تغییر لینک معتبر نیست یا به این حساب تعلق ندارد.",
                cancellationToken: cancellationToken);
            return;
        }

        if (!claim.Claimed)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                BuildChangeLinkOperationStatusText(claim.Operation),
                ParseMode.Html,
                BuildChangeLinkStatusKeyboard(claim.Operation),
                cancellationToken);
            return;
        }

        await UpdateChangeLinkProgressAsync(
            botClient,
            claim.Operation,
            "تأیید دریافت شد",
            "عملیات فقط یک‌بار آغاز شد. تا نمایش نتیجه، دوباره روی تغییر لینک نزنید.",
            cancellationToken);
        await ProcessAccountChangeLinkOperationAsync(botClient, claim.Operation, credUser, cancellationToken);
    }

    /// <summary>
    /// Cancels a link-change confirmation only while no panel mutation has started.
    /// </summary>
    /// <param name="botClient">Telegram client that received the cancellation callback.</param>
    /// <param name="chatId">Telegram chat containing the confirmation.</param>
    /// <param name="messageId">Editable confirmation message id.</param>
    /// <param name="credUser">Credentials profile used as the operation ownership guard.</param>
    /// <param name="operationKey">Random users.db operation key.</param>
    /// <param name="cancellationToken">Token that cancels database and Telegram work.</param>
    /// <returns>A task that completes after cancellation or current-status display.</returns>
    private async Task HandleAccountChangeLinkCancelCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        string operationKey,
        CancellationToken cancellationToken)
    {
        var operation = await _linkChangeOperationStore.GetAsync(operationKey, cancellationToken);
        if (operation == null || operation.TelegramUserId != credUser.TelegramUserId)
            return;

        var cancelled = await _linkChangeOperationStore.CancelAsync(
            operationKey,
            BotContextAccessor.CurrentBotId,
            credUser.TelegramUserId,
            cancellationToken);
        if (!cancelled)
        {
            operation = await _linkChangeOperationStore.GetAsync(operationKey, cancellationToken);
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                BuildChangeLinkOperationStatusText(operation),
                ParseMode.Html,
                BuildChangeLinkStatusKeyboard(operation),
                cancellationToken);
            return;
        }

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            "تغییر لینک لغو شد و هیچ تغییری روی اکانت انجام نشد.",
            replyMarkup: BuildChangeLinkResultKeyboard(operation.ClientId, operation.Page, IsChangeLinkSearchSource(operation)),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Displays the persisted status and requeues the same operation when recovery is pending or awaiting manual review.
    /// </summary>
    /// <param name="botClient">Telegram client used to edit the status message.</param>
    /// <param name="chatId">Telegram chat containing the status message.</param>
    /// <param name="messageId">Editable status message id.</param>
    /// <param name="credUser">Credentials profile whose Telegram id must own the operation.</param>
    /// <param name="operationKey">Random users.db operation key; no XUI identity is carried by the callback.</param>
    /// <param name="cancellationToken">Token that cancels database and Telegram work.</param>
    /// <returns>A task that completes after the same operation is displayed or requeued.</returns>
    private async Task HandleAccountChangeLinkStatusCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        string operationKey,
        CancellationToken cancellationToken)
    {
        var operation = await _linkChangeOperationStore.GetAsync(operationKey, cancellationToken);
        if (operation == null || operation.TelegramUserId != credUser.TelegramUserId)
        {
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                "عملیات تغییر لینک پیدا نشد یا متعلق به این حساب نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        if (operation.Status == XuiV3LinkChangeStatuses.RecoveryPending ||
            operation.Status == XuiV3LinkChangeStatuses.ManualReview)
        {
            await _linkChangeOperationStore.RequeueAsync(operation.OperationKey, credUser.TelegramUserId, cancellationToken);
            operation = await _linkChangeOperationStore.GetAsync(operation.OperationKey, cancellationToken);
        }

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            BuildChangeLinkOperationStatusText(operation),
            ParseMode.Html,
            BuildChangeLinkStatusKeyboard(operation),
            cancellationToken);
    }

    /// <summary>
    /// Continues one operation claimed by the background recovery worker using its original bot context and identity.
    /// </summary>
    /// <param name="botClient">Telegram client of the bot that originally created the operation.</param>
    /// <param name="operation">Claimed users.db operation with an active exclusive lease.</param>
    /// <param name="credUser">Credentials profile of the original Telegram account owner.</param>
    /// <param name="cancellationToken">Application shutdown token.</param>
    /// <returns>A task that completes after recovery succeeds or is durably rescheduled.</returns>
    /// <remarks>
    /// This is intentionally the same processor used by foreground confirmation. Recovery never invokes the original
    /// callback and therefore cannot generate a second email, UUID, or subscription id.
    /// </remarks>
    public Task RecoverAccountChangeLinkAsync(
        ITelegramBotClient botClient,
        XuiV3LinkChangeOperation operation,
        CredUser credUser,
        CancellationToken cancellationToken)
    {
        return ProcessAccountChangeLinkOperationAsync(botClient, operation, credUser, cancellationToken);
    }

    /// <summary>
    /// Applies the one saved XUI identity mutation and reconciles the immutable pre-change account snapshot.
    /// </summary>
    /// <param name="botClient">Telegram client used for best-effort progress and final notification.</param>
    /// <param name="operation">Persisted operation that owns the per-client database lock and generated identity.</param>
    /// <param name="credUser">Credentials profile of the account owner and audit actor.</param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, audit, and Telegram operations.</param>
    /// <returns>A task that completes after success, safe pre-mutation failure, or durable recovery scheduling.</returns>
    /// <remarks>
    /// The method can be called by the confirmation callback or recovery worker. Snapshot and replacement identifiers
    /// are generated only when absent and persisted before the first POST. Every later call reuses those exact values.
    /// Panel API time covers the current attempt. Total time uses the durable confirmation timestamp so a recovery
    /// after restart still exposes end-to-end latency; API time lost with a crashed process is not guessed.
    /// </remarks>
    private async Task ProcessAccountChangeLinkOperationAsync(
        ITelegramBotClient botClient,
        XuiV3LinkChangeOperation operation,
        CredUser credUser,
        CancellationToken cancellationToken)
    {
        var clientId = (int?)operation?.ClientId;
        var page = operation?.Page ?? 0;
        var fromSearch = string.Equals(operation?.Source, AccountCommentSourceSearch, StringComparison.Ordinal);
        var chatId = new ChatId(operation?.ChatId ?? credUser.ChatID);
        var messageId = operation?.MessageId ?? 0;
        if (operation == null || clientId == null || clientId <= 0)
            return;

        using var operationTiming = XuiOperationTiming.Start();
        var serverInfo = BuildConfiguredPanelServerInfo();

        if (!string.Equals(
                XuiV3LinkChangeOperationStore.BuildPanelKey(serverInfo),
                operation.PanelKey,
                StringComparison.Ordinal))
        {
            await ScheduleUnknownLinkChangeAsync(
                botClient,
                operation,
                "panel-configuration-changed",
                "The configured panel fingerprint differs from the panel that owns this operation.",
                cancellationToken);
            LogLinkChangeOutcome(operation, credUser, operationTiming, "پیکربندی پنل تغییر کرده؛ در انتظار بررسی");
            return;
        }

        using var leaseHeartbeatCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var leaseHeartbeatTask = MaintainLinkChangeLeaseAsync(
            operation.OperationKey,
            leaseHeartbeatCancellation.Token);

        try
        {
            XuiV3LinkChangeSnapshot snapshot;
            XuiV3ClientPayload payload;
            XuiV3Client client;
            if (string.IsNullOrWhiteSpace(operation.SnapshotJson) || string.IsNullOrWhiteSpace(operation.PayloadJson))
            {
                await UpdateChangeLinkProgressAsync(
                    botClient,
                    operation,
                    "دریافت وضعیت زنده اکانت",
                    "در حال دریافت inboundها، مصرف و محدودیت‌های فعلی از پنل...",
                    cancellationToken);

                var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
                var allClients = clientsResponse.Obj ?? new List<XuiV3Client>();
                client = allClients.FirstOrDefault(item =>
                    item.Id == clientId.Value && ClientBelongsToUser(item, credUser.TelegramUserId));
                if (!clientsResponse.Success || client == null)
                {
                    await _linkChangeOperationStore.MarkFailedBeforeMutationAsync(
                        operation.OperationKey,
                        "snapshot-client-not-found",
                        "The owned client could not be read before mutation.",
                        cancellationToken);
                    await SendOrEditTextAsync(
                        botClient,
                        chatId,
                        messageId,
                        "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست. هیچ تغییری روی پنل انجام نشد.",
                        replyMarkup: BuildChangeLinkResultKeyboard(clientId.Value, page, fromSearch),
                        cancellationToken: cancellationToken);
                    LogLinkChangeOutcome(operation, credUser, operationTiming, "دریافت اکانت از پنل ناموفق بود");
                    return;
                }

                var snapshotResult = await CaptureChangeLinkSnapshotAsync(serverInfo, client, cancellationToken);
                if (snapshotResult.Snapshot == null)
                {
                    await _linkChangeOperationStore.MarkFailedBeforeMutationAsync(
                        operation.OperationKey,
                        "snapshot-incomplete",
                        snapshotResult.ErrorMessage,
                        cancellationToken);
                    await SendOrEditTextAsync(
                        botClient,
                        chatId,
                        messageId,
                        "برای جلوگیری از حذف اطلاعات اکانت، تغییر لینک انجام نشد؛ وضعیت کامل inboundها یا مصرف از پنل دریافت نشد. هیچ تغییری روی اکانت اعمال نشده است.",
                        replyMarkup: BuildChangeLinkResultKeyboard(client.Id, page, fromSearch),
                        cancellationToken: cancellationToken);
                    LogLinkChangeOutcome(operation, credUser, operationTiming, "اطلاعات کامل پنل دریافت نشد");
                    return;
                }

                snapshot = snapshotResult.Snapshot;
                client = snapshot.Client;
                var generatedEmail = GenerateReplacementAccountEmail(allClients, client.Email);
                var generatedUuid = await GenerateReplacementUuidAsync(serverInfo, cancellationToken);
                payload = BuildChangeLinkPayload(snapshot, generatedEmail, generatedUuid, credUser.TelegramUserId);
                operation = await _linkChangeOperationStore.SavePreparedMutationAsync(
                    operation.OperationKey,
                    client.Email,
                    client.Uuid,
                    string.IsNullOrWhiteSpace(client.SubId) ? client.Email : client.SubId,
                    generatedEmail,
                    generatedUuid,
                    generatedEmail,
                    JsonConvert.SerializeObject(snapshot, Formatting.None),
                    JsonConvert.SerializeObject(payload, Formatting.None),
                    cancellationToken);
            }
            else
            {
                snapshot = JsonConvert.DeserializeObject<XuiV3LinkChangeSnapshot>(operation.SnapshotJson);
                payload = JsonConvert.DeserializeObject<XuiV3ClientPayload>(operation.PayloadJson);
                client = snapshot?.Client;
                if (snapshot == null || payload == null || client == null)
                    throw new InvalidOperationException("Saved link-change snapshot could not be restored.");
            }

            // The operation columns are the immutable source of truth for the replacement identity. Older payloads
            // may contain response-only extension keys that shadow typed JSON properties after deserialization.
            NormalizePersistedChangeLinkPayload(operation, payload);

            var oldEmail = operation.OldEmail ?? client.Email ?? string.Empty;
            var oldUuid = operation.OldUuid ?? client.Uuid ?? string.Empty;
            var oldSubId = string.IsNullOrWhiteSpace(operation.OldSubId) ? oldEmail : operation.OldSubId;
            var oldSubLink = ApiServicev3.BuildSubscriptionLink(serverInfo, oldSubId);
            var newEmail = operation.NewEmail;
            var newUuid = operation.NewUuid;
            var newSubId = operation.NewSubId;
            var newSubLink = ApiServicev3.BuildSubscriptionLink(serverInfo, newSubId);

            var identityChanged = operation.IdentityCommitted;
            XuiV3ApiResponse<Newtonsoft.Json.Linq.JToken> updateResponse = null;
            Exception updateException = null;
            if (!identityChanged)
            {
                var newIdentityObservation = await ObserveChangedLinkIdentityAsync(
                    serverInfo,
                    newEmail,
                    snapshot.ClientId,
                    cancellationToken);
                if (newIdentityObservation == XuiV3LinkChangeObservationStatus.Observed)
                {
                    identityChanged = true;
                }
                else
                {
                    var oldIdentityObservation = await ObserveChangedLinkIdentityAsync(
                        serverInfo,
                        oldEmail,
                        snapshot.ClientId,
                        cancellationToken);
                    if (newIdentityObservation == XuiV3LinkChangeObservationStatus.Unknown ||
                        oldIdentityObservation == XuiV3LinkChangeObservationStatus.Unknown)
                    {
                        await ScheduleUnknownLinkChangeAsync(
                            botClient,
                            operation,
                            "identity-observation-unknown",
                            "The panel could not establish whether the saved identity was committed.",
                            cancellationToken);
                        LogLinkChangeOutcome(operation, credUser, operationTiming, "نتیجه پنل مبهم؛ در انتظار بازیابی");
                        return;
                    }

                    if (oldIdentityObservation != XuiV3LinkChangeObservationStatus.Observed)
                    {
                        await ScheduleUnknownLinkChangeAsync(
                            botClient,
                            operation,
                            "identity-not-found",
                            "Neither the old nor the saved new identity could be proved on the panel.",
                            cancellationToken);
                        LogLinkChangeOutcome(operation, credUser, operationTiming, "هویت اکانت قابل اثبات نیست؛ در انتظار بازیابی");
                        return;
                    }

                    await UpdateChangeLinkProgressAsync(
                        botClient,
                        operation,
                        "ثبت شناسه‌های جدید",
                        "در حال ثبت یک‌باره email، UUID و subscription id جدید...",
                        cancellationToken);
                    await _linkChangeOperationStore.UpdateStageAsync(
                        operation.OperationKey,
                        "identity-update-sent",
                        false,
                        cancellationToken);
                    try
                    {
                        // A link rename is not safely replayable after timeout. Recovery always reads the panel before
                        // sending the exact persisted payload again.
                        updateResponse = await ApiServicev3.UpdateClientAsync(
                            serverInfo,
                            _configuration,
                            oldEmail,
                            payload,
                            cancellationToken,
                            XuiV3RequestRetryMode.NoAutomaticRetry);
                    }
                    catch (Exception ex)
                    {
                        updateException = ex;
                    }

                    identityChanged = updateResponse?.Success == true;
                    if (!identityChanged)
                    {
                        newIdentityObservation = await ObserveChangedLinkIdentityAsync(
                            serverInfo,
                            newEmail,
                            snapshot.ClientId,
                            cancellationToken);
                        identityChanged = newIdentityObservation == XuiV3LinkChangeObservationStatus.Observed;
                    }

                    if (!identityChanged)
                    {
                        if (updateException != null && ApiServicev3.IsTransientXuiTransportException(updateException, cancellationToken))
                        {
                            await ScheduleUnknownLinkChangeAsync(
                                botClient,
                                operation,
                                "identity-update-ambiguous",
                                "The panel response was interrupted before the identity result could be verified.",
                                cancellationToken);
                            LogLinkChangeOutcome(operation, credUser, operationTiming, "پاسخ تغییر لینک مبهم؛ در انتظار بازیابی");
                            return;
                        }

                        var safeFailure = updateException != null
                            ? XuiV3UserSafeError.ForAccountCreation(updateException)
                            : XuiV3UserSafeError.ForAccountCreation(updateResponse?.Msg);
                        await _linkChangeOperationStore.MarkFailedBeforeMutationAsync(
                            operation.OperationKey,
                            "identity-update-rejected",
                            safeFailure,
                            cancellationToken);
                        await SendOrEditTextAsync(
                            botClient,
                            chatId,
                            messageId,
                            "پنل تغییر لینک را نپذیرفت و هیچ شناسه‌ای تغییر نکرد. لطفاً بعداً دوباره تلاش کنید.",
                            replyMarkup: BuildChangeLinkResultKeyboard(client.Id, page, fromSearch),
                            cancellationToken: cancellationToken);
                        LogLinkChangeOutcome(operation, credUser, operationTiming, "پنل تغییر لینک را رد کرد");
                        return;
                    }
                }
            }

            await _linkChangeOperationStore.UpdateStageAsync(
                operation.OperationKey,
                "identity-committed",
                true,
                cancellationToken);
            operation.IdentityCommitted = true;

            if (updateException != null || updateResponse?.Success == false)
            {
                _logger.LogWarning(
                    updateException,
                    "XUI link-change update response was ambiguous, but the saved identity was found. operationKey={OperationKey}, clientId={ClientId}, oldEmail={OldEmail}, newEmail={NewEmail}",
                    operation.OperationKey,
                    snapshot.ClientId,
                    oldEmail,
                    newEmail);
            }

            await UpdateChangeLinkProgressAsync(
                botClient,
                operation,
                "تطبیق اطلاعات اکانت",
                "در حال بررسی inboundها، مصرف، حجم، انقضا و محدودیت‌های ذخیره‌شده...",
                cancellationToken);
            await _linkChangeOperationStore.UpdateStageAsync(
                operation.OperationKey,
                "reconciling-account-state",
                true,
                cancellationToken);

            XuiV3LinkChangePreservationResult preservation;
            try
            {
                preservation = await ReconcileChangedLinkStateAsync(
                    serverInfo,
                    snapshot,
                    payload,
                    newEmail,
                    operation.OperationKey,
                    cancellationToken);
            }
            catch (Exception ex)
            {
                preservation = XuiV3LinkChangePreservationResult.Failed(
                    "reconcile-exception",
                    ex.Message);
            }
            if (!preservation.Success)
            {
                var expectedInboundIds = string.Join(",", snapshot.InboundIds);
                var actualInboundIds = preservation.ObservationStatus == XuiV3LinkChangeObservationStatus.Unknown
                    ? "unknown"
                    : string.Join(",", preservation.ActualInboundIds ?? new List<int>());
                var fieldDifferences = preservation.Differences == null || preservation.Differences.Count == 0
                    ? "-"
                    : string.Join("; ", preservation.Differences.Select(x => x.ToDiagnosticText()));
                var failure = new InvalidOperationException(
                    $"XUI link identity changed but account preservation failed at stage '{preservation.Stage}': {preservation.Message}");

                _logger.LogCritical(
                    failure,
                    "XUI link-change preservation requires recovery. operationKey={OperationKey}, botId={BotId}, clientId={ClientId}, oldEmail={OldEmail}, newEmail={NewEmail}, stage={Stage}, observation={Observation}, differences={Differences}, expectedInboundIds={ExpectedInboundIds}, actualInboundIds={ActualInboundIds}, expectedUp={ExpectedUp}, expectedDown={ExpectedDown}, actualUp={ActualUp}, actualDown={ActualDown}",
                    operation.OperationKey,
                    BotContextAccessor.CurrentBotId,
                    snapshot.ClientId,
                    oldEmail,
                    newEmail,
                    preservation.Stage,
                    preservation.ObservationStatus,
                    fieldDifferences,
                    expectedInboundIds,
                    actualInboundIds,
                    snapshot.Up,
                    snapshot.Down,
                    preservation.Traffic?.Up,
                    preservation.Traffic?.Down);

                await _activityLog.LogErrorAsync(
                    "xui_v3_change_link_preservation_failed",
                    failure,
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["clientId"] = snapshot.ClientId,
                        ["oldEmail"] = oldEmail,
                        ["newEmail"] = newEmail,
                        ["stage"] = preservation.Stage ?? string.Empty,
                        ["operationKey"] = operation.OperationKey,
                        ["observation"] = preservation.ObservationStatus.ToString(),
                        ["fieldDifferences"] = fieldDifferences,
                        ["expectedInboundIds"] = expectedInboundIds,
                        ["actualInboundIds"] = actualInboundIds,
                        ["expectedUp"] = snapshot.Up,
                        ["expectedDown"] = snapshot.Down,
                        ["actualUp"] = preservation.Traffic?.Up ?? -1,
                        ["actualDown"] = preservation.Traffic?.Down ?? -1,
                        ["panelUrl"] = serverInfo.Url,
                        ["rootPath"] = serverInfo.RootPath
                    },
                    cancellationToken);

                await ScheduleUnknownLinkChangeAsync(
                    botClient,
                    operation,
                    preservation.Stage,
                    preservation.Message,
                    cancellationToken);
                LogLinkChangeOutcome(operation, credUser, operationTiming, "تطبیق اطلاعات ناموفق؛ در انتظار بازیابی");
                return;
            }

            client = preservation.Client;
            await _linkChangeOperationStore.MarkSucceededAsync(operation.OperationKey, cancellationToken);
            operation.Status = XuiV3LinkChangeStatuses.Succeeded;

            if (!operation.SiteSyncQueued)
            {
                try
                {
                    await _gozargahSiteSyncService.QueueRenameAsync(
                        ResolveGozargahSiteOwnerTelegramUserId(credUser),
                        credUser.TelegramUserId,
                        oldEmail,
                        client,
                        serverInfo,
                        $"change-link-{operation.OperationKey}",
                        ResolveGozargahTenantBotId(),
                        cancellationToken: cancellationToken);
                    await _linkChangeOperationStore.MarkPostActionsAsync(
                        operation.OperationKey,
                        siteSyncQueued: true,
                        auditLogged: false,
                        notificationSent: false,
                        cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Verified XUI link change could not queue site sync. operationKey={OperationKey}", operation.OperationKey);
                }
            }

            if (!operation.SuccessAuditLogged)
            {
                try
                {
                    var linkChangeTiming = BuildLinkChangeTimingSnapshot(operation, operationTiming);
                    await _activityLog.LogBotActionAsync(
                        "xui_v3_account_link_changed",
                        credUser,
                        false,
                        new Dictionary<string, object>
                        {
                            ["operationKey"] = operation.OperationKey,
                            ["clientId"] = client.Id,
                            ["ownerTelegramUserId"] = GetClientOwnerTelegramId(client),
                            ["oldEmail"] = oldEmail,
                            ["newEmail"] = newEmail,
                            ["oldUuid"] = oldUuid,
                            ["newUuid"] = newUuid,
                            ["oldSubId"] = oldSubId,
                            ["newSubId"] = newSubId,
                            ["inboundIdsBefore"] = string.Join(",", snapshot.InboundIds),
                            ["inboundIdsAfter"] = string.Join(",", preservation.ActualInboundIds),
                            ["usedBytesBefore"] = snapshot.Up + snapshot.Down,
                            ["usedBytesAfter"] = (preservation.Traffic?.Up ?? 0) + (preservation.Traffic?.Down ?? 0),
                            ["usedGb"] = GetUsedBytes(client).ConvertBytesToGB(),
                            ["totalGb"] = GetTotalBytes(client).ConvertBytesToGB(),
                            ["expiryShamsi"] = FormatExpiry(GetExpiryTime(client)),
                            ["panelApiElapsedMs"] = (long)linkChangeTiming.PanelApiElapsed.TotalMilliseconds,
                            ["totalElapsedMs"] = (long)linkChangeTiming.TotalElapsed.TotalMilliseconds
                        },
                        cancellationToken);

                    _logger.LogTelegramHtml(BuildChangeLinkLogMessage(
                        credUser,
                        client,
                        oldEmail,
                        oldUuid,
                        oldSubId,
                        oldSubLink,
                        newEmail,
                        newUuid,
                        newSubId,
                        newSubLink,
                        serverInfo,
                        linkChangeTiming));
                    await _linkChangeOperationStore.MarkPostActionsAsync(
                        operation.OperationKey,
                        siteSyncQueued: false,
                        auditLogged: true,
                        notificationSent: false,
                        cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Verified XUI link change success audit failed. operationKey={OperationKey}", operation.OperationKey);
                }
            }

            if (!operation.SuccessNotificationSent)
            {
                try
                {
                    await SendOrEditTextAsync(
                        botClient,
                        chatId,
                        messageId,
                        BuildChangeLinkSuccessText(oldEmail, oldUuid, oldSubId, newEmail, newUuid, newSubId, newSubLink),
                        ParseMode.Html,
                        BuildChangeLinkResultKeyboard(client.Id, page, fromSearch),
                        cancellationToken);
                    await _linkChangeOperationStore.MarkPostActionsAsync(
                        operation.OperationKey,
                        siteSyncQueued: false,
                        auditLogged: false,
                        notificationSent: true,
                        cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Verified XUI link change notification failed. operationKey={OperationKey}", operation.OperationKey);
                }
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            var failedTiming = BuildLinkChangeTimingSnapshot(operation, operationTiming);
            _logger.LogError(
                ex,
                "XUI link-change processing failed. operationKey={OperationKey}, botId={BotId}, clientId={ClientId}, panelApiElapsed={PanelApiElapsed}, totalElapsed={TotalElapsed}",
                operation.OperationKey,
                operation.BotId,
                clientId,
                XuiOperationTiming.Format(failedTiming.PanelApiElapsed),
                XuiOperationTiming.Format(failedTiming.TotalElapsed));
            await _activityLog.LogErrorAsync(
                "xui_v3_change_link_exception",
                ex,
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["operationKey"] = operation.OperationKey,
                    ["clientId"] = clientId,
                    ["panelUrl"] = serverInfo.Url,
                    ["rootPath"] = serverInfo.RootPath
                },
                cancellationToken);

            if (operation.IdentityCommitted || !string.IsNullOrWhiteSpace(operation.SnapshotJson))
            {
                await ScheduleUnknownLinkChangeAsync(
                    botClient,
                    operation,
                    "processing-exception",
                    "The saved operation encountered an unexpected error and requires recovery.",
                    cancellationToken);
            }
            else
            {
                await _linkChangeOperationStore.MarkFailedBeforeMutationAsync(
                    operation.OperationKey,
                    "processing-exception-before-mutation",
                    "The operation failed before a panel mutation was sent.",
                    cancellationToken);
                await SendOrEditTextAsync(
                    botClient,
                    chatId,
                    messageId,
                    "تغییر لینک انجام نشد و هیچ تغییری روی اکانت ثبت نشده است. لطفاً کمی بعد دوباره تلاش کنید.",
                    replyMarkup: BuildChangeLinkResultKeyboard(clientId.Value, page, fromSearch),
                    cancellationToken: cancellationToken);
            }
        }
        finally
        {
            leaseHeartbeatCancellation.Cancel();
            try
            {
                await leaseHeartbeatTask;
            }
            catch (OperationCanceledException) when (leaseHeartbeatCancellation.IsCancellationRequested)
            {
                // Normal completion stops the heartbeat after the durable operation transition has been saved.
            }
        }
    }

    /// <summary>
    /// Keeps one users.db processing lease alive while slow XUI requests and read-back verification are running.
    /// </summary>
    /// <param name="operationKey">Durable operation key whose generated identity and panel client are locked.</param>
    /// <param name="cancellationToken">Token cancelled when processing completes or the host stops.</param>
    /// <returns>A task that ends when processing leaves the <c>processing</c> state or cancellation is requested.</returns>
    /// <remarks>
    /// Renewal uses independent per-operation DbContexts. It never changes the XUI stage, retry count, or identity and
    /// therefore cannot replay a Telegram update or panel mutation.
    /// </remarks>
    private async Task MaintainLinkChangeLeaseAsync(string operationKey, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            await Task.Delay(TimeSpan.FromSeconds(15), cancellationToken);
            try
            {
                if (!await _linkChangeOperationStore.RenewLeaseAsync(operationKey, cancellationToken))
                    return;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "XUI link-change lease heartbeat failed. operationKey={OperationKey}",
                    operationKey);
            }
        }
    }

    /// <summary>
    /// Reloads one search-selected account, verifies ownership, and renders the complete search action card.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned or tenant storefront bot.</param>
    /// <param name="chatId">Telegram chat containing the search result.</param>
    /// <param name="messageId">Search message id to edit, or zero to send a new card.</param>
    /// <param name="credUser">Current bot user whose Telegram id must own the selected panel client.</param>
    /// <param name="clientId">Numeric panel client id selected from an owned search-result row.</param>
    /// <param name="page">Zero-based search page restored by later actions.</param>
    /// <param name="cancellationToken">Token that cancels panel lookup and Telegram delivery.</param>
    /// <returns>A task that completes after ownership rejection or account-card delivery.</returns>
    /// <remarks>
    /// The common account keyboard selects search-specific mutation and navigation callbacks while exposing the same
    /// safe configuration action as the account-list card.
    /// </remarks>
    private async Task HandleAccountSearchViewCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, IsClientRenewable(client)),
            ParseMode.Html,
            BuildAccountDetailsKeyboard(client, page, IsClientRenewable(client), fromSearch: true),
            cancellationToken);
    }

    /// <summary>
    /// Starts renewal from a search result after reloading an owned client or a client proven by an exact identifier.
    /// </summary>
    /// <param name="botClient">Telegram client of the current owned bot.</param>
    /// <param name="chatId">Telegram chat containing the search result.</param>
    /// <param name="messageId">Search-card message id to edit, or zero to send a new selection card.</param>
    /// <param name="credUser">Payer profile whose Telegram id is required for owner-only search results.</param>
    /// <param name="user">Bot-scoped search state containing the original direct UUID/SubId query when applicable.</param>
    /// <param name="clientId">Numeric panel client id from the compact callback; it is never authorization alone.</param>
    /// <param name="page">Zero-based search-result page restored by the back callback.</param>
    /// <param name="allowExternalRenew">
    /// <c>true</c> only for <c>auren</c>, which requires the saved direct-search proof to resolve the same client.
    /// </param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, and Telegram operations.</param>
    /// <returns>A task that completes after terminal cleanup or delivery of the renewal plan selector.</returns>
    /// <remarks>
    /// Every successful selection persists a normalized UUID separately from <see cref="User.PaymentMethod"/>.
    /// A non-owner result pauses at the explicit third-party warning before plan selection. Rejection clears temporary
    /// state and causes no wallet, order, configuration-disclosure, ownership, or panel side effect.
    /// </remarks>
    private async Task HandleAccountSearchRenewCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        User user,
        int? clientId,
        int page,
        bool allowExternalRenew,
        CancellationToken cancellationToken)
    {
        var client = allowExternalRenew
            ? await GetExternallyAuthorizedSearchClientAsync(user, clientId, cancellationToken)
            : await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);

        if (client == null)
        {
            await SendOwnedRenewSearchTerminalAsync(
                botClient,
                chatId,
                user,
                allowExternalRenew
                    ? "درخواست تمدید معتبر نیست. UUID یا SubId را دوباره از بخش جستجو ارسال کنید."
                    : "اکانت مورد نظر برای تمدید پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken);
            return;
        }

        if (!IsClientRenewable(client))
        {
            await SendOwnedRenewSearchTerminalAsync(
                botClient,
                chatId,
                user,
                "این اکانت مربوط به inboundهای فعال پلن‌های فعلی ربات نیست و از طریق ربات قابل تمدید نیست.",
                cancellationToken);
            return;
        }

        var service = ResolveServiceForClient(client);
        if (service == null)
        {
            await SendOwnedRenewSearchTerminalAsync(
                botClient,
                chatId,
                user,
                "سرویس این اکانت قابل تشخیص نیست و تمدید از سرچ انجام نشد.",
                cancellationToken);
            return;
        }

        var isOwner = ClientBelongsToUser(client, credUser.TelegramUserId);
        if (!TryNormalizeClientUuid(client.Uuid, out var targetUuid) && !isOwner)
        {
            await SendOwnedRenewSearchTerminalAsync(
                botClient,
                chatId,
                user,
                "UUID اکانت در پاسخ پنل معتبر نیست و تمدید امن آن ممکن نشد.",
                cancellationToken);
            return;
        }

        if (!isOwner)
        {
            await SaveOwnedExternalRenewWarningAsync(
                botClient,
                chatId,
                credUser.TelegramUserId,
                client,
                service,
                targetUuid,
                messageId,
                cancellationToken);
            return;
        }

        await _state.ClearUserStatus(new User { Id = credUser.TelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = credUser.TelegramUserId,
            Flow = RenewFlowName,
            LastStep = service.IsUnlimited ? RenewStepUnlimitedPlan : RenewStepTraffic,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = targetUuid,
            PaymentMethod = "credit"
        });

        var text = service.IsUnlimited
            ? $"اکانت انتخاب شد: <code>{Html(client.Email)}</code>\nپلن تمدید نامحدود را انتخاب کنید."
            : $"اکانت انتخاب شد: <code>{Html(client.Email)}</code>\nحجم اضافه را به گیگابایت بفرستید.\nمی‌توانید عدد دلخواه مثل <code>7</code> یا <code>۷</code> وارد کنید.";

        var backKeyboard = allowExternalRenew
            ? new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart()) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            })
            : new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به نتایج جستجو", XuiV3PurchaseCallbacks.AccountSearchList(page)) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            });

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            text,
            ParseMode.Html,
            backKeyboard,
            cancellationToken);

        await botClient.SendMessage(
            chatId: chatId,
            text: service.IsUnlimited
                ? "یکی از پلن‌های زیر را انتخاب کنید:"
                : "یکی از حجم‌های زیر را انتخاب کنید یا عدد دلخواه بفرستید:",
            replyMarkup: service.IsUnlimited
                ? BuildUnlimitedPlanReplyKeyboard(service, credUser.IsColleague)
                : BuildTrafficReplyKeyboard(service),
            cancellationToken: cancellationToken);
    }

    private async Task HandleAccountSearchDeleteAskCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای حذف پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var text = $"آیا از حذف این اکانت مطمئن هستید؟\n\nاکانت: <code>{Html(client.Email)}</code>\n\nاین عملیات فقط همین اکانت را حذف می‌کند.";
        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("تایید حذف", XuiV3PurchaseCallbacks.AccountSearchDeleteConfirm(client.Id, page)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.AccountSearchView(client.Id, page)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            text,
            ParseMode.Html,
            keyboard,
            cancellationToken);
    }

    /// <summary>
    /// Confirms deletion of one owned account selected through search and audits the measured panel result.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the search callback.</param>
    /// <param name="chatId">Telegram chat containing the search-result card.</param>
    /// <param name="messageId">Message id edited with the terminal deletion result.</param>
    /// <param name="credUser">Current user whose Telegram id must still own the panel account.</param>
    /// <param name="clientId">Numeric XUI client id selected by the search callback.</param>
    /// <param name="page">Zero-based search page restored by result navigation.</param>
    /// <param name="cancellationToken">Token that cancels panel, activity-log, website-sync, and Telegram work.</param>
    /// <returns>A task that completes after safe rejection or the delete result is delivered.</returns>
    /// <remarks>
    /// Ownership is revalidated before deletion. Failure and success are centrally logged with API and end-to-end
    /// duration, without exposing account credentials or raw provider responses.
    /// </remarks>
    private async Task HandleAccountSearchDeleteConfirmCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        CancellationToken cancellationToken)
    {
        using var operationTiming = XuiOperationTiming.Start();
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            LogXuiOperationOutcome(
                "حذف اکانت نسخه ۳",
                "اکانت پیدا نشد یا قبلاً حذف شده است",
                credUser,
                operationTiming,
                source: "search");
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای حذف پیدا نشد یا قبلاً حذف شده است.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var deleteResponse = await ApiServicev3.DeleteClientAsync(serverInfo, _configuration, client.Email, cancellationToken);
        if (!deleteResponse.Success)
        {
            LogXuiOperationOutcome(
                "حذف اکانت نسخه ۳",
                "پنل حذف را رد کرد",
                credUser,
                operationTiming,
                accountEmail: client.Email,
                source: "search");
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                $"حذف اکانت ناموفق بود.\n{deleteResponse.Msg}",
                replyMarkup: new InlineKeyboardMarkup(new[]
                {
                    new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.AccountSearchView(client.Id, page)) },
                    new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
                }),
                cancellationToken: cancellationToken);
            return;
        }

        await _activityLog.LogBotActionAsync(
            "xui_v3_account_deleted_by_user_search",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["accountEmail"] = client.Email,
                ["panelUrl"] = serverInfo.Url,
                ["rootPath"] = serverInfo.RootPath,
                ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
            },
            cancellationToken);
        LogAccountDelete(client, credUser, "search", operationTiming.Snapshot());
        await QueueGozargahSyncBestEffortAsync(
            "search-delete",
            () => _gozargahSiteSyncService.QueueDeleteAsync(
                ResolveGozargahSiteOwnerTelegramUserId(credUser),
                credUser.TelegramUserId,
                client,
                $"delete-search-{client.Email}-{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}",
                ResolveGozargahTenantBotId(),
                cancellationToken: cancellationToken));

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            $"اکانت با موفقیت حذف شد.\n\nاکانت: <code>{Html(client.Email)}</code>",
            ParseMode.Html,
            new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به نتایج جستجو", XuiV3PurchaseCallbacks.AccountSearchList(page)) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0)) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            }),
            cancellationToken);
    }

    /// <summary>
    /// Enables or disables an ownership-verified search result and rebuilds the same complete search account card.
    /// </summary>
    /// <param name="botClient">Telegram client for the bot that received the search-state callback.</param>
    /// <param name="chatId">Telegram chat containing the selected account card.</param>
    /// <param name="messageId">Account-card message id to edit, or zero to send a new card.</param>
    /// <param name="credUser">Current bot user whose Telegram id must own the panel client.</param>
    /// <param name="clientId">Numeric XUI client id selected from the search result.</param>
    /// <param name="page">Zero-based search page retained by the rebuilt action menu.</param>
    /// <param name="enable"><c>true</c> to enable the account; <c>false</c> to disable it.</param>
    /// <param name="cancellationToken">Token that cancels panel, audit-log, and Telegram operations.</param>
    /// <returns>A task that completes after rejection, panel failure, or updated-card delivery.</returns>
    /// <remarks>
    /// Ownership is revalidated before the panel mutation. Wallets, orders, and conversation state are unchanged. On
    /// success the shared menu preserves search navigation and restores configuration retrieval for either state.
    /// Terminal outcomes are centrally audited with panel API and total elapsed durations.
    /// </remarks>
    private async Task HandleAccountSearchStateCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        bool enable,
        CancellationToken cancellationToken)
    {
        using var operationTiming = XuiOperationTiming.Start();
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                "اکانت پیدا نشد یا مجاز نبود",
                credUser,
                operationTiming,
                source: "search");
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var updateResponse = await ApiServicev3.SetClientEnabledAsync(
            serverInfo,
            _configuration,
            client.Email,
            enable,
            credUser.TelegramUserId,
            cancellationToken);
        if (!updateResponse.Success)
        {
            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                "پنل تغییر را رد کرد",
                credUser,
                operationTiming,
                accountEmail: client.Email,
                source: "search");
            await SendOrEditTextAsync(
                botClient,
                chatId,
                messageId,
                $"متاسفانه عملیات مورد نظر انجام نشد.\n{updateResponse.Msg}",
                replyMarkup: BuildAccountDetailsKeyboard(client, page, IsClientRenewable(client), fromSearch: true),
                cancellationToken: cancellationToken);
            return;
        }

        await _activityLog.LogBotActionAsync(
            enable ? "xui_v3_account_enabled_search" : "xui_v3_account_disabled_search",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["accountEmail"] = client.Email,
                ["panelUrl"] = serverInfo.Url,
                ["rootPath"] = serverInfo.RootPath,
                ["source"] = "account_search_callback",
                ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
            },
            cancellationToken);

        client.Enable = enable;
        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, IsClientRenewable(client)),
            ParseMode.Html,
            BuildAccountDetailsKeyboard(client, page, IsClientRenewable(client), fromSearch: true),
            cancellationToken);
        LogXuiOperationOutcome(
            enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
            "موفق",
            credUser,
            operationTiming,
            accountEmail: client.Email,
            source: "search");
    }

    /// <summary>Verifies the selected account and prepares this user's bot-scoped comment-entry step.</summary>
    /// <param name="botClient">Client for the active owned or tenant bot; required and never persisted in conversation state.</param>
    /// <param name="chatId">Telegram destination chat id in the active bot, not an internal user or tenant database id.</param>
    /// <param name="messageId">Telegram message id to edit; zero or null, as allowed by the signature, requests a new message.</param>
    /// <param name="credUser">Detached global credentials profile for the actor; wallet balances and personal fields must not enter diagnostics.</param>
    /// <param name="clientId">Positive external XUI client id selected by the account callback; ownership is checked before allowing edits.</param>
    /// <param name="page">Zero-based account-list page used when returning from comment entry.</param>
    /// <param name="fromSearch">True restores account-search navigation; false restores the paged account list.</param>
    /// <param name="cancellationToken">Cancellation of state persistence, panel lookups or mutations, and Telegram delivery for this execution.</param>
    /// <returns>A task completing after the documented state transition and any required Telegram or panel work.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task HandleAccountCommentStartCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        bool fromSearch,
        CancellationToken cancellationToken)
    {
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای تغییر کامنت پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        await _state.SaveUserStatus(new User
        {
            Id = credUser.TelegramUserId,
            Flow = AccountCommentFlowName,
            LastStep = AccountCommentStepText,
            ConfigLink = client.Id.ToString(),
            SubLink = page.ToString(),
            SelectedCountry = fromSearch ? AccountCommentSourceSearch : AccountCommentSourceList
        });

        var metadata = TryReadMetadata(client.Comment);
        var currentComment = string.IsNullOrWhiteSpace(metadata?.UserComment)
            ? "ثبت نشده"
            : metadata.UserComment.Trim();
        var backCallback = fromSearch
            ? XuiV3PurchaseCallbacks.AccountSearchView(client.Id, page)
            : XuiV3PurchaseCallbacks.AccountView(client.Id, page);

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            $"اکانت: <code>{Html(client.Email)}</code>\nکامنت فعلی: <code>{Html(currentComment)}</code>\n\nکامنت جدید را ارسال کنید. کامنت خالی یا «بدون کامنت» پذیرفته نمی‌شود.",
            ParseMode.Html,
            new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت", backCallback) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            }),
            cancellationToken);
    }

    /// <summary>
    /// Updates one ownership-verified account comment and sends a refreshed card with the common action menu.
    /// </summary>
    /// <param name="botClient">Telegram client for the current owned or tenant storefront bot.</param>
    /// <param name="chatId">Telegram chat that receives the result card.</param>
    /// <param name="messageId">Source message id retained for flow context; the success result is sent separately.</param>
    /// <param name="credUser">Current bot user whose Telegram id must own the panel client.</param>
    /// <param name="clientId">Numeric XUI client id saved by the comment flow.</param>
    /// <param name="page">Zero-based list or search page restored by the refreshed menu.</param>
    /// <param name="fromSearch"><c>true</c> for search callbacks; <c>false</c> for account-list callbacks.</param>
    /// <param name="newComment">Validated non-empty customer comment text to merge with bot metadata.</param>
    /// <param name="mainReplyMarkup">Fallback main-menu keyboard used when ownership or panel update fails.</param>
    /// <param name="cancellationToken">Token that cancels panel, audit-log, and Telegram operations.</param>
    /// <returns>A task that completes after rejection, panel failure, or refreshed-card delivery.</returns>
    /// <remarks>
    /// The panel client is reloaded and ownership is checked before update. Bot metadata is preserved by the payload
    /// builder. A successful card uses the common menu, preserving the original list/search navigation and exposing
    /// configuration retrieval without placing the account's SubId or URLs in callback data. Rejected and accepted
    /// mutations are centrally audited with API and end-to-end durations.
    /// </remarks>
    private async Task ApplyAccountCommentAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int clientId,
        int page,
        bool fromSearch,
        string newComment,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        using var operationTiming = XuiOperationTiming.Start();
        var client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        if (client == null)
        {
            LogXuiOperationOutcome(
                "تغییر کامنت اکانت نسخه ۳",
                "اکانت پیدا نشد یا مجاز نبود",
                credUser,
                operationTiming,
                source: fromSearch ? "search" : "list");
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر برای تغییر کامنت پیدا نشد یا متعلق به حساب شما نیست.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var payload = BuildUpdateCommentPayload(client, newComment, credUser.TelegramUserId);
        var updateResponse = await ApiServicev3.UpdateClientAsync(serverInfo, _configuration, client.Email, payload, cancellationToken);
        if (!updateResponse.Success)
        {
            LogXuiOperationOutcome(
                "تغییر کامنت اکانت نسخه ۳",
                "پنل تغییر را رد کرد",
                credUser,
                operationTiming,
                accountEmail: client.Email,
                source: fromSearch ? "search" : "list");
            await botClient.SendMessage(
                chatId: chatId,
                text: $"تغییر کامنت ناموفق بود.\n{updateResponse.Msg}",
                replyMarkup: mainReplyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        await _activityLog.LogBotActionAsync(
            fromSearch ? "xui_v3_account_comment_updated_search" : "xui_v3_account_comment_updated",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["accountEmail"] = client.Email,
                ["newComment"] = newComment,
                ["panelUrl"] = serverInfo.Url,
                ["rootPath"] = serverInfo.RootPath,
                ["source"] = fromSearch ? "account_search" : "account_list",
                ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
            },
            cancellationToken);

        client.Comment = payload.Comment;
        await botClient.SendMessage(
            chatId: chatId,
            text: "✅ کامنت اکانت با موفقیت تغییر کرد.\n\n" +
                  BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, IsClientRenewable(client)),
            parseMode: ParseMode.Html,
            replyMarkup: BuildAccountDetailsKeyboard(
                client,
                page,
                IsClientRenewable(client),
                fromSearch),
            cancellationToken: cancellationToken);
        LogXuiOperationOutcome(
            "تغییر کامنت اکانت نسخه ۳",
            "موفق",
            credUser,
            operationTiming,
            accountEmail: client.Email,
            source: fromSearch ? "search" : "list");
    }

    /// <summary>
    /// Retrieves and delivers the protocol configuration URLs for one account owned by the current Telegram user.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned or tenant bot that received the account callback.</param>
    /// <param name="chatId">Telegram chat that receives a separate configuration message or UTF-8 document.</param>
    /// <param name="credUser">
    /// Bot-scoped credential record for the requesting customer. Its numeric Telegram id is the ownership boundary.
    /// </param>
    /// <param name="clientId">
    /// Numeric XUI client id carried by the callback. The value is not trusted until the panel client is reloaded and
    /// matched to <paramref name="credUser"/>.
    /// </param>
    /// <param name="cancellationToken">Token that cancels panel reads and Telegram delivery.</param>
    /// <returns>A task that completes after a safe rejection, explanatory empty result, message, or document is sent.</returns>
    /// <remarks>
    /// This operation is read-only: it does not change conversation state, wallet balances, orders, or panel clients.
    /// It first uses the client's private SubId with the panel subLinks endpoint, then falls back to the email links
    /// endpoint when SubId is absent or the first endpoint fails or returns no URLs. Neither SubId nor returned URLs,
    /// bearer tokens, response bodies, or request URIs are written to callbacks or logs. A forged callback for another
    /// Telegram owner is rejected before either link endpoint is called.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled so receiver shutdown is not reported as a
    /// customer-visible panel failure.
    /// </exception>
    private async Task HandleAccountConfigsCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CredUser credUser,
        int? clientId,
        CancellationToken cancellationToken)
    {
        XuiV3Client client;
        try
        {
            client = await GetOwnedClientByIdAsync(credUser.TelegramUserId, clientId, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "XUI v3 account ownership lookup failed before configuration retrieval. clientId={ClientId}, failureType={FailureType}",
                clientId,
                ex.GetType().Name);
            await botClient.SendMessage(
                chatId: chatId,
                text: "دریافت اطلاعات اکانت موقتاً انجام نشد. لطفاً کمی بعد دوباره تلاش کنید.",
                cancellationToken: cancellationToken);
            return;
        }

        if (client == null)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var links = new List<string>();

        // These identifier-bearing reads use one attempt so the shared retry diagnostic never records SubId/email URI.
        if (!string.IsNullOrWhiteSpace(client.SubId))
        {
            try
            {
                var subLinksResponse = await ApiServicev3.GetClientSubLinksAsync(
                    serverInfo,
                    _configuration,
                    client.SubId,
                    cancellationToken,
                    suppressIdentifierBearingRetryLogs: true);
                if (subLinksResponse.Success)
                {
                    links = NormalizeAccountConfigLinks(subLinksResponse.Obj);
                }
                else
                {
                    _logger.LogWarning(
                        "XUI v3 account subLinks request was unsuccessful. clientId={ClientId}, failureType={FailureType}",
                        client.Id,
                        "panel_response");
                }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                // Deliberately log only the exception type and numeric client id: the request path contains SubId.
                _logger.LogWarning(
                    "XUI v3 account subLinks request failed. clientId={ClientId}, failureType={FailureType}",
                    client.Id,
                    ex.GetType().Name);
            }
        }

        if (links.Count == 0)
        {
            if (string.IsNullOrWhiteSpace(client.Email))
            {
                _logger.LogWarning(
                    "XUI v3 account links fallback skipped because the owned client has no email. clientId={ClientId}",
                    client.Id);
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "این اکانت شناسهٔ معتبری برای دریافت کانفیگ ندارد.",
                    cancellationToken: cancellationToken);
                return;
            }

            try
            {
                var emailLinksResponse = await ApiServicev3.GetClientLinksAsync(
                    serverInfo,
                    _configuration,
                    client.Email,
                    cancellationToken,
                    suppressIdentifierBearingRetryLogs: true);
                if (!emailLinksResponse.Success)
                {
                    _logger.LogWarning(
                        "XUI v3 account links fallback was unsuccessful. clientId={ClientId}, failureType={FailureType}",
                        client.Id,
                        "panel_response");
                    await botClient.SendMessage(
                        chatId: chatId,
                        text: "دریافت کانفیگ‌ها موقتاً انجام نشد. لطفاً کمی بعد دوباره تلاش کنید.",
                        cancellationToken: cancellationToken);
                    return;
                }

                links = NormalizeAccountConfigLinks(emailLinksResponse.Obj);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                // Do not attach the exception object: its private diagnostic properties may include the email path.
                _logger.LogWarning(
                    "XUI v3 account links fallback failed. clientId={ClientId}, failureType={FailureType}",
                    client.Id,
                    ex.GetType().Name);
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "دریافت کانفیگ‌ها موقتاً انجام نشد. لطفاً کمی بعد دوباره تلاش کنید.",
                    cancellationToken: cancellationToken);
                return;
            }
        }

        if (links.Count == 0)
        {
            var emptyText = client.Enable
                ? "پنل برای این اکانت هیچ کانفیگ فعالی برنگرداند. ممکن است اکانت هنوز به ورودی فعالی متصل نباشد."
                : "این اکانت غیرفعال است و پنل کانفیگ فعالی برای آن برنگرداند. ابتدا اکانت را فعال کنید و دوباره تلاش کنید.";
            await botClient.SendMessage(
                chatId: chatId,
                text: emptyText,
                cancellationToken: cancellationToken);
            return;
        }

        var html = BuildAccountConfigsHtml(client.Email, links);
        if (html.Length <= MaxAccountConfigsHtmlLength)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: html,
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
            return;
        }

        var documentBytes = Encoding.UTF8.GetBytes(string.Join(Environment.NewLine, links));
        await using var documentStream = new MemoryStream(documentBytes, writable: false);
        await botClient.SendDocument(
            chatId: chatId,
            document: InputFile.FromStream(documentStream, $"configs-{client.Id}.txt"),
            caption: "📥 <b>کانفیگ‌های اکانت</b>\n" +
                     $"اکانت: <code>{Html(client.Email)}</code>\n" +
                     $"تعداد: <code>{links.Count}</code>\n\n" +
                     "به‌دلیل طول زیاد، کانفیگ‌ها در فایل UTF-8 ارسال شدند.",
            parseMode: ParseMode.Html,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Clears bot-scoped search/renewal state and sends a terminal search result with restart and Home callbacks.
    /// </summary>
    /// <param name="botClient">Telegram client of the active owned bot.</param>
    /// <param name="chatId">Telegram chat receiving the safe result.</param>
    /// <param name="user">Current bot-scoped state to clear; callers pass the state used to authorize the search.</param>
    /// <param name="text">Customer-safe Persian result that contains no UUID, SubId, link, or raw panel response.</param>
    /// <param name="cancellationToken">Token that cancels state cleanup and Telegram delivery.</param>
    /// <returns>A task that completes after cleanup and message delivery.</returns>
    /// <remarks>The method has no wallet, order, ownership, or panel mutation side effects.</remarks>
    private async Task SendOwnedRenewSearchTerminalAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        User user,
        string text,
        CancellationToken cancellationToken)
    {
        await _state.ClearUserStatus(user);

        await botClient.SendMessage(
            chatId,
            text,
            replyMarkup: BuildSearchEmptyKeyboard(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Normalizes panel configuration URLs while preserving their original order.
    /// </summary>
    /// <param name="links">
    /// Raw URL collection returned by an authenticated XUI endpoint. The collection and its items may be null or blank.
    /// </param>
    /// <returns>
    /// A new list containing trimmed, non-empty, ordinally distinct URLs in first-seen panel order. The list may be
    /// empty and must be treated as a normal panel result rather than exposing the raw provider response.
    /// </returns>
    /// <remarks>
    /// Ordinal comparison is intentional because proxy URLs and their encoded fragments are case-sensitive payloads.
    /// The returned values remain sensitive customer configurations and must not be logged.
    /// </remarks>
    /// <example>
    /// <code>
    /// var links = NormalizeAccountConfigLinks(new[] { " vless://one ", "vless://one", "vmess://two" });
    /// // links contains vless://one followed by vmess://two.
    /// </code>
    /// </example>
    private static List<string> NormalizeAccountConfigLinks(IEnumerable<string> links)
    {
        var normalized = new List<string>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var link in links ?? Enumerable.Empty<string>())
        {
            var value = link?.Trim();
            if (!string.IsNullOrWhiteSpace(value) && seen.Add(value))
                normalized.Add(value);
        }

        return normalized;
    }

    /// <summary>
    /// Formats a copy-safe Telegram HTML message containing all normalized configuration URLs for one account.
    /// </summary>
    /// <param name="email">Panel client email/name shown as the account label; it may contain HTML-sensitive text.</param>
    /// <param name="links">
    /// Ordered, normalized proxy URLs. Callers must provide at least one item and must not log the collection.
    /// </param>
    /// <returns>
    /// Telegram-safe HTML with the account label and every URL escaped inside a separate <c>&lt;code&gt;</c> block.
    /// The caller must compare its length with <see cref="MaxAccountConfigsHtmlLength"/> before sending.
    /// </returns>
    /// <remarks>
    /// HTML escaping prevents account names and URL query fragments from changing Telegram markup while preserving
    /// the decoded, copyable URL displayed to the customer.
    /// </remarks>
    /// <example>
    /// <code>
    /// var html = BuildAccountConfigsHtml("sample", new[] { "vless://id@example.test?x=1&amp;y=2" });
    /// </code>
    /// </example>
    /// <exception cref="ArgumentNullException">Thrown when <paramref name="links"/> is <c>null</c>.</exception>
    private static string BuildAccountConfigsHtml(string email, IReadOnlyList<string> links)
    {
        ArgumentNullException.ThrowIfNull(links);

        var builder = new StringBuilder();
        builder.AppendLine("📥 <b>کانفیگ‌های اکانت</b>");
        builder.AppendLine($"اکانت: <code>{Html(email)}</code>");
        builder.AppendLine($"تعداد: <code>{links.Count}</code>");
        builder.AppendLine();

        for (var index = 0; index < links.Count; index++)
        {
            builder.AppendLine($"<b>{index + 1}</b>");
            builder.AppendLine($"<code>{Html(links[index])}</code>");
            if (index < links.Count - 1)
                builder.AppendLine();
        }

        return builder.ToString();
    }

    private async Task<XuiV3Client> GetOwnedClientByIdAsync(
        long telegramUserId,
        int? clientId,
        CancellationToken cancellationToken)
    {
        if (clientId == null || clientId <= 0)
            return null;

        var serverInfo = BuildConfiguredPanelServerInfo();
        var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!clientsResponse.Success)
            return null;

        return clientsResponse.Obj?
            .FirstOrDefault(client => client.Id == clientId.Value && ClientBelongsToUser(client, telegramUserId));
    }

    private async Task<XuiV3Client> GetAnyClientByIdAsync(
        int? clientId,
        CancellationToken cancellationToken)
    {
        if (clientId == null || clientId <= 0)
            return null;

        var serverInfo = BuildConfiguredPanelServerInfo();
        var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!clientsResponse.Success)
            return null;

        return clientsResponse.Obj?.FirstOrDefault(client => client.Id == clientId.Value);
    }

    /// <summary>
    /// Reloads a callback-selected client only when current bot-scoped search state resolves to that exact client.
    /// </summary>
    /// <param name="user">
    /// Current bot/user state created by direct account search. It must still contain the original query and the
    /// <c>xui-v3-account-search</c> result step; null or unrelated state is rejected.
    /// </param>
    /// <param name="clientId">Numeric XUI client id carried by the compact callback; it is never trusted by itself.</param>
    /// <param name="cancellationToken">Token that cancels the single panel-list read.</param>
    /// <returns>
    /// The detached panel client when the saved direct identifier resolves to exactly the callback client; otherwise
    /// <c>null</c>. The returned client is not proof for configuration delivery or mutation actions.
    /// </returns>
    /// <remarks>
    /// This closes the forged-<c>auren</c> gap: knowing a small numeric client id is insufficient to begin someone
    /// else's renewal. The saved email, SubId/subscription URL, UUID, or supported configuration must resolve to the
    /// same client, and the query plus resolved credential are deliberately not logged.
    /// </remarks>
    private async Task<XuiV3Client> GetExternallyAuthorizedSearchClientAsync(
        User user,
        int? clientId,
        CancellationToken cancellationToken)
    {
        if (user == null ||
            !string.Equals(user.Flow, AccountSearchFlowName, StringComparison.Ordinal) ||
            !string.Equals(user.LastStep, AccountSearchStepResults, StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(user.ConfigLink))
        {
            return null;
        }

        var client = await GetAnyClientByIdAsync(clientId, cancellationToken);
        return SearchQueryAuthorizesExternalRenew(user.ConfigLink, client) ? client : null;
    }

    /// <summary>
    /// Resolves a list/search renewal callback for an owned or tenant flow without changing state or charging money.
    /// </summary>
    /// <param name="user">
    /// Current bot-scoped state. External exact-identifier callbacks require the unmodified direct-search query stored here;
    /// owner callbacks do not consume its search fields.
    /// </param>
    /// <param name="telegramUserId">Numeric Telegram id that must own the client for normal list/search renewals.</param>
    /// <param name="clientId">Numeric XUI client id carried by the callback; it is reloaded from the panel.</param>
    /// <param name="allowExternalRenew">
    /// <c>true</c> only for the restricted <c>auren</c> callback displayed after a direct exact-identifier result;
    /// <c>false</c> for normal account-list and owned-search renewal actions.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the panel-list read.</param>
    /// <returns>
    /// Fresh detached client authorized for renewal, or <c>null</c> when ownership, bot-scoped search proof, client id,
    /// or panel lookup fails. The result must still be checked for plan eligibility and exact UUID at settlement.
    /// </returns>
    /// <remarks>
    /// TenantBotService uses this method before starting its own order-based renewal state machine. The method grants
    /// no access to configurations or other mutations and writes no UUID/SubId to logs.
    /// </remarks>
    /// <example>
    /// <code>
    /// var target = await flowService.ResolveRenewCallbackTargetAsync(
    ///     botScopedUser, telegramUserId, callback.ClientId, allowExternalRenew: true, cancellationToken);
    /// if (target == null)
    ///     return;
    /// </code>
    /// </example>
    public Task<XuiV3Client> ResolveRenewCallbackTargetAsync(
        User user,
        long telegramUserId,
        int? clientId,
        bool allowExternalRenew,
        CancellationToken cancellationToken)
    {
        return allowExternalRenew
            ? GetExternallyAuthorizedSearchClientAsync(user, clientId, cancellationToken)
            : GetOwnedClientByIdAsync(telegramUserId, clientId, cancellationToken);
    }

    private static string BuildAccountListText(int totalAccounts, int page, int totalPages)
    {
        var builder = new StringBuilder();
        builder.AppendLine("اکانت‌های من");
        builder.AppendLine();
        builder.AppendLine($"تعداد کل: <code>{totalAccounts}</code>");
        builder.AppendLine($"صفحه: <code>{page + 1}</code> از <code>{totalPages}</code>");
        builder.AppendLine();
        builder.AppendLine("برای دیدن مشخصات، تمدید یا حذف تکی، یکی از اکانت‌ها را انتخاب کنید.");
        builder.AppendLine("علامت باتری خالی یعنی اکانت منقضی شده یا حجم آن تمام شده است.");
        return builder.ToString();
    }

    private static string BuildAccountSearchListText(string query, int totalAccounts, int page, int totalPages)
    {
        var builder = new StringBuilder();
        builder.AppendLine("نتایج جستجوی اکانت");
        builder.AppendLine();
        builder.AppendLine($"عبارت: <code>{Html(query)}</code>");
        builder.AppendLine($"تعداد نتیجه: <code>{totalAccounts}</code>");
        builder.AppendLine($"صفحه: <code>{page + 1}</code> از <code>{totalPages}</code>");
        builder.AppendLine();
        builder.AppendLine("برای دیدن مشخصات کامل، تمدید، حذف یا فعال/غیرفعال‌سازی، یکی از اکانت‌ها را انتخاب کنید.");
        builder.AppendLine("علامت باتری خالی یعنی اکانت منقضی شده یا حجم آن تمام شده است.");
        return builder.ToString();
    }

    /// <summary>
    /// Builds an owner-aware direct exact-identifier search result without echoing the sensitive identifier.
    /// </summary>
    /// <param name="client">Matched XUI client.</param>
    /// <param name="serverInfo">Panel descriptor used to rebuild the subscription link.</param>
    /// <param name="isOwner">Whether the matched account belongs to the Telegram user who searched.</param>
    /// <param name="identifierLabel">Non-sensitive label for the input shape, such as UUID or کانفیگ.</param>
    /// <returns>
    /// HTML-formatted owner details, or a minimal email plus renewal-only warning for a non-owner match.
    /// </returns>
    /// <remarks>
    /// This method is an instance member because owned details need the configured service catalog. Non-owner results
    /// deliberately omit usage, quota, expiry, SubId, configurations, comments, owner identity, and management data.
    /// </remarks>
    private string BuildDirectSearchResultText(
        XuiV3Client client,
        ServerInfo serverInfo,
        bool isOwner,
        string identifierLabel)
    {
        var builder = new StringBuilder();
        builder.AppendLine("نتیجه جستجوی اکانت");
        builder.AppendLine($"نوع شناسه: <code>{Html(identifierLabel)}</code>");
        builder.AppendLine();
        if (!isOwner)
        {
            builder.AppendLine($"اکانت پیدا شد: <code>{Html(client.Email)}</code>");
            builder.AppendLine("این اکانت متعلق به حساب شما نیست؛ فقط امکان شروع تمدید آن فعال است.");
            builder.AppendLine("برای ادامه باید هشدار تمدید اکانت شخص دیگر را جداگانه تأیید کنید.");
            return builder.ToString();
        }

        builder.AppendLine("این اکانت متعلق به حساب شماست.");
        builder.AppendLine();
        builder.Append(BuildV3ClientInfo(client, serverInfo, false, false));
        return builder.ToString();
    }

    private static InlineKeyboardMarkup BuildAccountListKeyboard(
        IReadOnlyList<XuiV3Client> pageAccounts,
        int page,
        int totalPages)
    {
        var rows = new List<InlineKeyboardButton[]>();
        foreach (var client in pageAccounts)
        {
            var marker = IsExpiredOrDepleted(client) ? "🪫 " : "";
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    $"{marker}{client.Email}",
                    XuiV3PurchaseCallbacks.AccountView(client.Id, page))
            });
        }

        var nav = new List<InlineKeyboardButton>();
        if (page > 0)
            nav.Add(InlineKeyboardButton.WithCallbackData("قبلی", XuiV3PurchaseCallbacks.AccountList(page - 1)));
        if (page < totalPages - 1)
            nav.Add(InlineKeyboardButton.WithCallbackData("بعدی", XuiV3PurchaseCallbacks.AccountList(page + 1)));
        if (nav.Count > 0)
            rows.Add(nav.ToArray());

        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("🔎 جستجوی اکانت", XuiV3PurchaseCallbacks.AccountSearchStart()) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) });

        return new InlineKeyboardMarkup(rows);
    }

    private static InlineKeyboardMarkup BuildAccountSearchListKeyboard(
        IReadOnlyList<XuiV3Client> pageAccounts,
        int page,
        int totalPages)
    {
        var rows = new List<InlineKeyboardButton[]>();
        foreach (var client in pageAccounts)
        {
            var marker = IsExpiredOrDepleted(client) ? "🪫 " : "";
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    $"{marker}{client.Email}",
                    XuiV3PurchaseCallbacks.AccountSearchView(client.Id, page))
            });
        }

        var nav = new List<InlineKeyboardButton>();
        if (page > 0)
            nav.Add(InlineKeyboardButton.WithCallbackData("قبلی", XuiV3PurchaseCallbacks.AccountSearchList(page - 1)));
        if (page < totalPages - 1)
            nav.Add(InlineKeyboardButton.WithCallbackData("بعدی", XuiV3PurchaseCallbacks.AccountSearchList(page + 1)));
        if (nav.Count > 0)
            rows.Add(nav.ToArray());

        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart()) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0)) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) });

        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the complete owned-account action menu for both list and search result cards.
    /// </summary>
    /// <param name="client">
    /// Panel client already verified as belonging to the Telegram user who will receive the keyboard.
    /// </param>
    /// <param name="page">
    /// Zero-based source page restored by subsequent account actions. Negative values are normalized by callback
    /// builders.
    /// </param>
    /// <param name="canRenew">
    /// <c>true</c> when the client's inbound belongs to an enabled service plan and renewal may be offered.
    /// </param>
    /// <param name="fromSearch">
    /// <c>true</c> when the card came from account search; <c>false</c> when it came from the paged account list.
    /// This selects source-aware mutation and navigation callbacks without changing the available account actions.
    /// </param>
    /// <returns>
    /// A Telegram inline keyboard with renewal when allowed, read-only configuration retrieval, account mutations,
    /// state toggle, and source-appropriate navigation rows.
    /// </returns>
    /// <remarks>
    /// Configuration retrieval is deliberately available for both active and inactive owned accounts. This builder
    /// never establishes authorization by itself; every callback handler reloads the numeric client id and rechecks
    /// Telegram ownership before reading or changing panel data. UUID/SubId results that are not owned by the current
    /// user continue to use the restricted search keyboard and therefore never receive this action menu.
    /// </remarks>
    /// <exception cref="ArgumentNullException">Thrown when <paramref name="client"/> is <c>null</c>.</exception>
    /// <example>
    /// <code>
    /// var keyboard = BuildAccountDetailsKeyboard(client, page: 1, canRenew: true, fromSearch: true);
    /// </code>
    /// </example>
    private static InlineKeyboardMarkup BuildAccountDetailsKeyboard(
        XuiV3Client client,
        int page,
        bool canRenew,
        bool fromSearch = false)
    {
        ArgumentNullException.ThrowIfNull(client);

        var rows = new List<InlineKeyboardButton[]>();
        if (canRenew)
        {
            var renewCallback = fromSearch
                ? XuiV3PurchaseCallbacks.AccountSearchRenew(client.Id, page)
                : XuiV3PurchaseCallbacks.AccountRenew(client.Id, page);
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("تمدید اکانت", renewCallback) });
        }

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData(
                "دریافت کانفیگ‌ها",
                XuiV3PurchaseCallbacks.AccountConfigs(client.Id))
        });
        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData(
                "تغییر لینک",
                fromSearch
                    ? XuiV3PurchaseCallbacks.AccountSearchChangeLink(client.Id, page)
                    : XuiV3PurchaseCallbacks.AccountChangeLink(client.Id, page))
        });
        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData(
                "تغییر کامنت",
                fromSearch
                    ? XuiV3PurchaseCallbacks.AccountSearchComment(client.Id, page)
                    : XuiV3PurchaseCallbacks.AccountComment(client.Id, page))
        });
        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData(
                "حذف همین اکانت",
                fromSearch
                    ? XuiV3PurchaseCallbacks.AccountSearchDeleteAsk(client.Id, page)
                    : XuiV3PurchaseCallbacks.AccountDeleteAsk(client.Id, page))
        });

        var actionText = client.Enable ? "غیرفعال کردن" : "فعال کردن";
        var stateCallback = fromSearch
            ? XuiV3PurchaseCallbacks.AccountSearchState(client.Id, !client.Enable, page)
            : XuiV3PurchaseCallbacks.AccountState(client.Id, !client.Enable, page);
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData(actionText, stateCallback) });

        if (fromSearch)
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "بازگشت به نتایج جستجو",
                    XuiV3PurchaseCallbacks.AccountSearchList(page))
            });
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0))
            });
        }
        else
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData("بازگشت به لیست", XuiV3PurchaseCallbacks.AccountList(page))
            });
        }

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home())
        });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the renewal-only keyboard for a non-owned account found through one exact saved identifier.
    /// </summary>
    /// <param name="client">Unique panel client whose numeric id is routing data only.</param>
    /// <param name="canRenew">Whether the client remains eligible and the saved query resolves to this exact row.</param>
    /// <returns>A keyboard with optional renewal plus search/list/Home navigation and no management action.</returns>
    /// <remarks>
    /// The <c>auren</c> callback remains a wire-compatible historical name. Its handler requires bot-scoped email,
    /// SubId/subscription URL, UUID, or configuration search state and then shows the explicit third-party warning.
    /// </remarks>
    private static InlineKeyboardMarkup BuildExternalSearchResultKeyboard(XuiV3Client client, bool canRenew)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (canRenew)
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("تمدید اکانت", XuiV3PurchaseCallbacks.AccountUuidRenew(client.Id)) });

        rows.AddRange(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart()) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });

        return new InlineKeyboardMarkup(rows);
    }

    private static InlineKeyboardMarkup BuildSearchStartKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });
    }

    private static InlineKeyboardMarkup BuildSearchEmptyKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart()) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به لیست کلی", XuiV3PurchaseCallbacks.AccountList(0)) },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });
    }

    /// <summary>
    /// Sends a sequence of prefiltered owned account cards using the same complete action keyboard as paged lists.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned or tenant bot receiving the account-status request.</param>
    /// <param name="chatId">Telegram chat that receives the heading and one message per account.</param>
    /// <param name="isColleague">Whether colleague-specific account presentation rules apply to card text.</param>
    /// <param name="serverInfo">Configured XUI server used to build each displayed subscription link.</param>
    /// <param name="clients">
    /// Clients already filtered to the requesting Telegram owner. The collection may be empty but must not include
    /// accounts belonging to another user because the full action keyboard assumes an owned card.
    /// </param>
    /// <param name="cancellationToken">Token that cancels Telegram delivery.</param>
    /// <returns>A task that completes after the heading and all account cards have been sent.</returns>
    /// <remarks>
    /// This presentation helper performs no panel read or mutation. Callback handlers still revalidate ownership when
    /// a button is clicked, including the read-only configuration action available to active and inactive accounts.
    /// </remarks>
    private async Task SendV3AccountsInfoAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        bool isColleague,
        ServerInfo serverInfo,
        List<XuiV3Client> clients,
        CancellationToken cancellationToken)
    {
        await botClient.SendMessage(
            chatId: chatId,
            text: "✅ وضعیت اکانت‌های شما به شرح زیر است:",
            cancellationToken: cancellationToken);

        foreach (var client in clients)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: BuildV3ClientInfo(client, serverInfo, isColleague, IsClientRenewable(client)),
                parseMode: ParseMode.Html,
                replyMarkup: BuildAccountDetailsKeyboard(client, 0, IsClientRenewable(client)),
                cancellationToken: cancellationToken);
        }
    }

    private XuiV3ServiceDefinition FindService(string serviceKey)
    {
        if (string.IsNullOrWhiteSpace(serviceKey))
            return null;

        return _purchaseService.GetEnabledServices().FirstOrDefault(service =>
            string.Equals(service.Key, serviceKey, StringComparison.OrdinalIgnoreCase));
    }

    private bool IsClientRenewable(XuiV3Client client)
    {
        return XuiV3ClientPlanEligibility.IsClientInActiveServiceInbounds(
            client,
            _purchaseService.GetEnabledServices());
    }

    private static string FormatExpiry(long expiryTime)
    {
        if (expiryTime < 0)
            return $"{FormatFirstUseDurationDays(expiryTime)} روز بعد از اولین اتصال";

        if (expiryTime == 0)
            return "نامحدود";

        return DateTimeOffset
            .FromUnixTimeMilliseconds(expiryTime)
            .UtcDateTime
            .AddMinutes(210)
            .ConvertToHijriShamsi();
    }

    /// <summary>
    /// Sends the central audit log for a successful owned-bot XUI v3 purchase or renewal.
    /// </summary>
    /// <param name="title">The human-readable operation title shown in the private logger channel.</param>
    /// <param name="credUser">The owned-bot customer or colleague whose account was purchased or renewed.</param>
    /// <param name="priceToman">The amount actually charged for the successful operation, in Iranian toman.</param>
    /// <param name="beforeBalance">
    /// The balance of the wallet that actually paid immediately before settlement, or <see langword="null"/> when
    /// the operation has no auditable wallet snapshot.
    /// </param>
    /// <param name="afterBalance">
    /// The balance of the wallet that actually paid immediately after settlement, or <see langword="null"/> when
    /// the operation has no auditable wallet snapshot.
    /// </param>
    /// <param name="paymentWalletSource">
    /// The user-facing name of the wallet that was actually debited, such as the bot wallet or the Gozargah site
    /// wallet. This value must describe the completed debit result rather than the payment button selected earlier.
    /// </param>
    /// <param name="details">Additional purchase details such as plan, account email, and subscription link.</param>
    /// <param name="timing">
    /// Monotonic duration snapshot for the completed activity. Panel time includes all XUI v3 calls and retries made
    /// after execution began; total time also includes settlement, persistence, and any Telegram delivery completed
    /// before the financial audit is emitted.
    /// </param>
    /// <remarks>
    /// This method preserves the existing purchase metadata and adds the actual wallet source to the same central
    /// payment log. When a site-wallet debit fails after a renewal and the local bot wallet is used as compensation,
    /// callers must report the bot wallet as the source and mention the fallback in the supplied label.
    /// </remarks>
    /// <example>
    /// <code>
    /// LogV3Purchase(
    ///     "ساخت اکانت نسخه ۳",
    ///     user,
    ///     100_000,
    ///     500_000,
    ///     400_000,
    ///     "کیف پول ربات",
    ///     details,
    ///     timing.Snapshot());
    /// </code>
    /// </example>
    private void LogV3Purchase(
        string title,
        CredUser credUser,
        long priceToman,
        long? beforeBalance,
        long? afterBalance,
        string paymentWalletSource,
        IEnumerable<string> details,
        XuiOperationTimingSnapshot timing)
    {
        var message = new StringBuilder();
        var normalizedDetails = new List<string>();
        XuiV3ClientMetadata metadataFromComment = null;

        foreach (var detail in details ?? Array.Empty<string>())
        {
            if (string.IsNullOrWhiteSpace(detail))
                continue;

            if (IsCommentLogDetail(detail))
            {
                metadataFromComment ??= TryReadMetadata(ExtractCodeValue(detail));
                continue;
            }

            normalizedDetails.Add(detail);
        }

        message.AppendLine(Html(title));

        var userSummary = FormatCredUserSummary(credUser);
        if (!string.IsNullOrWhiteSpace(userSummary))
            message.AppendLine(userSummary);
        message.Append(BuildCurrentBotPurchaseLogContext());

        message.AppendLine($"مبلغ <code>{Html(priceToman.FormatCurrency())}</code>");

        if (beforeBalance.HasValue)
            message.AppendLine($"موجودی قبل از خرید <code>{Html(beforeBalance.Value.FormatCurrency())}</code>");

        if (afterBalance.HasValue)
            message.AppendLine($"موجودی پس از خرید <code>{Html(afterBalance.Value.FormatCurrency())}</code>");

        if (!string.IsNullOrWhiteSpace(paymentWalletSource))
            message.AppendLine($"کیف پول پرداخت <code>{Html(paymentWalletSource)}</code>");

        if (metadataFromComment != null)
        {
            message.AppendLine($"تاریخ ساخت <code>{Html(FormatMetadataCreatedAt(metadataFromComment))}</code>");

            if (!string.IsNullOrWhiteSpace(metadataFromComment.ServiceName))
                message.AppendLine($"سرویس <code>{Html(metadataFromComment.ServiceName)}</code>");
        }

        foreach (var detail in normalizedDetails)
        {
            message.AppendLine(HtmlLogDetail(detail));
        }

        message.AppendLine();
        message.Append(XuiOperationTiming.BuildHtmlLines(timing));

        _logger.LogPayment(message.ToString());
    }

    /// <summary>
    /// Writes one safe non-financial XUI operation outcome to the central Telegram logger channel with API and total durations.
    /// </summary>
    /// <param name="title">Fixed Persian activity title such as account comment change or account activation.</param>
    /// <param name="result">Fixed coarse result such as successful, rejected, partial, or exception type.</param>
    /// <param name="credUser">Telegram actor whose id and public profile are included in the audit.</param>
    /// <param name="timing">Active monotonic operation timer captured immediately before the log is emitted.</param>
    /// <param name="accountEmail">
    /// Optional panel email/name safe for the private admin channel. UUID, SubId, configuration URLs, tokens, and raw
    /// panel responses must not be passed here.
    /// </param>
    /// <param name="source">Optional fixed UI source such as list, search, command, or trial.</param>
    /// <param name="requestedCount">Optional number of accounts requested by a bulk operation.</param>
    /// <param name="successfulCount">Optional number of accounts completed by a bulk operation.</param>
    /// <remarks>
    /// This audit is operational and therefore uses HTML logging without the payment logger's database-backup side
    /// effect. It must be called for both accepted and terminally failed panel mutations so the timings remain useful
    /// for API-health comparison.
    /// </remarks>
    private void LogXuiOperationOutcome(
        string title,
        string result,
        CredUser credUser,
        XuiOperationTiming timing,
        string accountEmail = null,
        string source = null,
        int? requestedCount = null,
        int? successfulCount = null)
    {
        if (timing == null)
            return;

        LogXuiOperationOutcomeSnapshot(
            title,
            result,
            credUser,
            timing.Snapshot(),
            accountEmail,
            source,
            requestedCount,
            successfulCount);
    }

    /// <summary>
    /// Writes one operational XUI audit from an immutable timing snapshot.
    /// </summary>
    /// <param name="title">Fixed activity title displayed in the private Telegram logger channel.</param>
    /// <param name="result">Coarse safe outcome that excludes provider response bodies and exception messages.</param>
    /// <param name="credUser">Telegram actor whose public identity is included in the audit.</param>
    /// <param name="timing">API and end-to-end durations already captured for the activity.</param>
    /// <param name="accountEmail">Optional panel email/name; credentials and subscription identifiers are forbidden.</param>
    /// <param name="source">Optional stable route label such as list, search, purchase, or recovery.</param>
    /// <param name="requestedCount">Optional number of requested accounts for bulk activity.</param>
    /// <param name="successfulCount">Optional number of successful accounts for bulk activity.</param>
    /// <remarks>
    /// Snapshot input is required for durable workflows such as link-change recovery, where total time can span a
    /// process restart and cannot be represented by the current in-memory timer alone.
    /// </remarks>
    private void LogXuiOperationOutcomeSnapshot(
        string title,
        string result,
        CredUser credUser,
        XuiOperationTimingSnapshot timing,
        string accountEmail = null,
        string source = null,
        int? requestedCount = null,
        int? successfulCount = null)
    {
        var builder = new StringBuilder();
        builder.AppendLine($"<b>{Html(title)}</b>");
        builder.AppendLine();
        builder.AppendLine(TelegramUserLinkFormatter.HtmlSummary(credUser));
        builder.AppendLine($"نتیجه: <code>{Html(result)}</code>");
        if (!string.IsNullOrWhiteSpace(accountEmail))
            builder.AppendLine($"اکانت: <code>{Html(accountEmail)}</code>");
        if (!string.IsNullOrWhiteSpace(source))
            builder.AppendLine($"مسیر: <code>{Html(source)}</code>");
        if (requestedCount.HasValue)
            builder.AppendLine($"تعداد درخواستی: <code>{requestedCount.Value}</code>");
        if (successfulCount.HasValue)
            builder.AppendLine($"تعداد موفق: <code>{successfulCount.Value}</code>");
        builder.AppendLine($"BotId: <code>{Html(BotContextAccessor.CurrentBotId)}</code>");
        builder.AppendLine($"BotType: <code>{Html(BotContextAccessor.CurrentBotType)}</code>");
        builder.AppendLine();
        builder.Append(XuiOperationTiming.BuildHtmlLines(timing));
        _logger.LogTelegramHtml(builder.ToString());
    }

    /// <summary>
    /// Builds the current bot metadata block added to owned-bot XUI purchase and renewal logs.
    /// </summary>
    /// <returns>
    /// HTML-safe lines that identify the bot id, public username, brand, type, configured channels, and support
    /// contact for the bot that handled the purchase.
    /// </returns>
    /// <remarks>
    /// The Telegram logger sends payment logs through the default owned bot, so the message itself must include the
    /// originating bot metadata. Without this block, successful purchases from non-default owned bots look like they
    /// came from the default brand.
    /// </remarks>
    private string BuildCurrentBotPurchaseLogContext()
    {
        var bot = _botContextAccessor.Current?.Config;
        var botId = bot?.Id ?? BotContextAccessor.CurrentBotId;
        var username = string.IsNullOrWhiteSpace(bot?.Username)
            ? BotContextAccessor.CurrentBotUsername
            : bot.Username.Trim().TrimStart('@');
        var type = bot?.Type ?? BotContextAccessor.CurrentBotType;
        var channels = string.Equals(type, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase)
            ? bot?.TenantChannelIds
            : bot?.ChannelIds;

        var builder = new StringBuilder();
        builder.AppendLine($"BotId: <code>{Html(botId)}</code>");
        builder.AppendLine($"BotUsername: {FormatTelegramReference(string.IsNullOrWhiteSpace(username) ? null : "@" + username)}");
        builder.AppendLine($"Brand: <code>{Html(bot?.BrandName)}</code>");
        builder.AppendLine($"BotType: <code>{Html(type)}</code>");
        builder.AppendLine($"Channels: {FormatTelegramReferences(channels)}");
        builder.AppendLine($"Support: {FormatTelegramReference(bot?.SupportAccount)}");
        if (bot?.OwnerTelegramUserId.HasValue == true)
            builder.AppendLine($"TenantOwner: <a href=\"tg://user?id={bot.OwnerTelegramUserId.Value}\">{bot.OwnerTelegramUserId.Value}</a>");
        return builder.ToString();
    }

    /// <summary>
    /// Formats a list of Telegram channel/support references for an HTML purchase log.
    /// </summary>
    /// <param name="references">Configured channel ids, usernames, or Telegram links for the current bot.</param>
    /// <returns>Comma-separated HTML-safe references, or <c>-</c> when no references are configured.</returns>
    private static string FormatTelegramReferences(IEnumerable<string> references)
    {
        var formatted = (references ?? Array.Empty<string>())
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Select(FormatTelegramReference)
            .ToArray();
        return formatted.Length == 0 ? "<code>-</code>" : string.Join(", ", formatted);
    }

    /// <summary>
    /// Formats one Telegram username, t.me link, private id, or free-form value for an HTML purchase log.
    /// </summary>
    /// <param name="reference">Raw channel or support value from bot configuration.</param>
    /// <returns>Clickable HTML when the value is public Telegram username/link; otherwise HTML-safe text.</returns>
    private static string FormatTelegramReference(string reference)
    {
        var value = reference?.Trim();
        if (string.IsNullOrWhiteSpace(value))
            return "<code>-</code>";

        if (value.StartsWith("@", StringComparison.Ordinal) && value.Length > 1)
        {
            var username = value.TrimStart('@');
            return $"<a href=\"https://t.me/{HtmlAttribute(username)}\">@{Html(username)}</a>";
        }

        if (Uri.TryCreate(value, UriKind.Absolute, out var uri) &&
            (string.Equals(uri.Host, "t.me", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(uri.Host, "telegram.me", StringComparison.OrdinalIgnoreCase)))
        {
            var username = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            var visible = string.IsNullOrWhiteSpace(username) ? value : "@" + username;
            return $"<a href=\"{HtmlAttribute(uri.ToString())}\">{Html(visible)}</a>";
        }

        return long.TryParse(value, out _)
            ? $"<code>{Html(value)}</code>"
            : Html(value);
    }

    /// <summary>
    /// Encodes a value for a Telegram HTML attribute.
    /// </summary>
    /// <param name="value">Raw attribute value.</param>
    /// <returns>HTML-encoded attribute value.</returns>
    private static string HtmlAttribute(string value)
    {
        return System.Net.WebUtility.HtmlEncode(value ?? string.Empty);
    }

    private static string BuildBulkFailureText(XuiV3BulkCreationResult result)
    {
        var builder = new StringBuilder();
        builder.AppendLine("⚠️ بخشی از ساخت اکانت ناموفق بود.");
        builder.AppendLine($"تعداد درخواستی: <code>{result.RequestedCount}</code>");
        builder.AppendLine($"تعداد ساخته‌شده: <code>{result.SuccessfulCount}</code>");

        foreach (var failure in result.Failures)
        {
            builder.AppendLine();
            builder.AppendLine($"ردیف: <code>{failure.Index}</code>");
            builder.AppendLine($"خطا: <code>{Html(XuiV3UserSafeError.ForAccountCreation(failure.Message))}</code>");
        }

        return builder.ToString();
    }

    private static IEnumerable<string> BuildBulkPurchaseLogDetails(
        XuiV3BulkCreationResult result,
        string userComment)
    {
        var details = new List<string>
        {
            $"شناسه سفارش `{result.BulkOrderId}`",
            $"تعداد درخواستی `{result.RequestedCount}`",
            $"تعداد ساخته‌شده `{result.SuccessfulCount}`",
            $"سرویس `{result.ServiceName}`",
            $"حجم هر اکانت `{XuiV3PurchaseService.FormatTrafficSize(result.TrafficBytes, result.TrafficGb)}`"
        };

        if (result.IsUnlimited && details.Count > 4)
            details[4] = $"حد مصرف منصفانه هر اکانت `{XuiV3PurchaseService.FormatTrafficSize(result.TrafficBytes, result.TrafficGb)}`";

        if (result.DurationDays <= 0)
            details.Add("انقضا `نامحدود`");
        else
            details.Add($"مدت `{result.DurationDays} روز`");

        if (!string.IsNullOrWhiteSpace(userComment))
            details.Add($"کامنت کاربر `{ShortenForLog(userComment, 120)}`");

        foreach (var account in result.CreatedAccounts)
        {
            details.Add($"اکانت `{account.Email}`");
            details.Add($"سابلینک `{account.SubLink}`");
        }

        if (result.Failures.Count > 0)
        {
            foreach (var failure in result.Failures)
                details.Add($"خطای ردیف {failure.Index} `{ShortenForLog(failure.Message, 120)}`");
        }

        return details;
    }

    private static string ShortenForLog(string value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var normalized = value.Replace("\r", " ").Replace("\n", " ").Trim();
        return normalized.Length <= maxLength
            ? normalized
            : normalized.Substring(0, maxLength) + "...";
    }

    private static bool IsCommentLogDetail(string detail)
    {
        return detail.StartsWith("کامنت `", StringComparison.Ordinal) ||
               detail.StartsWith("comment `", StringComparison.OrdinalIgnoreCase);
    }

    private static string ExtractCodeValue(string detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return string.Empty;

        var firstTick = detail.IndexOf('`');
        var lastTick = detail.LastIndexOf('`');
        if (firstTick < 0 || lastTick <= firstTick)
            return string.Empty;

        return detail.Substring(firstTick + 1, lastTick - firstTick - 1);
    }

    private static string FormatMetadataCreatedAt(XuiV3ClientMetadata metadata)
    {
        if (metadata == null)
            return "نامشخص";

        return metadata.CreatedAtUtc.AddMinutes(210).ConvertToHijriShamsi();
    }

    private static string BuildHtmlBalanceDeductionText(long beforeBalance, long deductedAmount, long afterBalance)
    {
        return $"💳 موجودی قبل: <code>{Html(beforeBalance.FormatCurrency())}</code>\n" +
               $"💸 مبلغ کسر شده: <code>{Html(deductedAmount.FormatCurrency())}</code>\n" +
               $"💰 موجودی باقی‌مانده: <code>{Html(afterBalance.FormatCurrency())}</code>";
    }

    /// <summary>
    /// Builds the customer-facing balance summary for the wallet that actually paid for the XUI v3 operation.
    /// </summary>
    /// <param name="useSiteWallet">
    /// <c>true</c> when the selected payment source was the Gozargah website wallet; <c>false</c> for the bot wallet.
    /// </param>
    /// <param name="botBeforeBalance">Bot wallet balance in toman before a bot-wallet debit, or fallback display balance.</param>
    /// <param name="deductedAmount">Paid amount in Iranian toman.</param>
    /// <param name="botAfterBalance">Bot wallet balance in toman after a bot-wallet debit, or fallback display balance.</param>
    /// <param name="siteWalletDebitResult">
    /// Website wallet debit result. Required for site-wallet messages because it contains the website before/after balance.
    /// </param>
    /// <param name="siteWalletFallbackToBot">
    /// <c>true</c> when the customer selected the website wallet but the debit failed after renewal and the amount was
    /// instead debited from the bot wallet, possibly making it negative.
    /// </param>
    /// <returns>
    /// HTML-safe balance text that names the selected wallet, preventing site-wallet purchases from looking like bot-wallet
    /// debits.
    /// </returns>
    /// <remarks>
    /// The bot wallet and website wallet have different sources of truth. User-facing messages must not show
    /// <c>credentials.db</c> balances after a website-wallet payment, because that incorrectly suggests a double charge.
    /// When website debit fails and the caller explicitly applied local fallback, the bot-wallet balances are the real
    /// source of truth and the warning explains why the selected wallet differs from the wallet actually charged.
    /// </remarks>
    private static string BuildSelectedWalletBalanceText(
        bool useSiteWallet,
        long botBeforeBalance,
        long deductedAmount,
        long botAfterBalance,
        GozargahSiteWalletDebitResult siteWalletDebitResult,
        bool siteWalletFallbackToBot = false)
    {
        if (useSiteWallet && siteWalletDebitResult?.Success == true)
        {
            return $"💳 موجودی کیف پول سایت قبل: <code>{Html(siteWalletDebitResult.BeforeWallet.FormatCurrency())}</code>\n" +
                   $"💸 مبلغ کسر شده از سایت: <code>{Html(deductedAmount.FormatCurrency())}</code>\n" +
                   $"💰 موجودی کیف پول سایت بعد: <code>{Html(siteWalletDebitResult.AfterWallet.FormatCurrency())}</code>";
        }

        if (useSiteWallet && siteWalletFallbackToBot)
        {
            return "⚠️ کسر مبلغ از کیف پول سایت گذرگاه انجام نشد؛ مبلغ از کیف پول ربات کسر شد.\n" +
                   BuildHtmlBalanceDeductionText(botBeforeBalance, deductedAmount, botAfterBalance);
        }

        return BuildHtmlBalanceDeductionText(botBeforeBalance, deductedAmount, botAfterBalance);
    }

    private static string HtmlLogDetail(string detail)
    {
        if (string.IsNullOrWhiteSpace(detail))
            return string.Empty;

        var parts = detail.Split('`');
        if (parts.Length == 1)
            return Html(detail);

        var builder = new StringBuilder();
        for (var i = 0; i < parts.Length; i++)
        {
            if (i % 2 == 0)
                builder.Append(Html(parts[i]));
            else
                builder.Append("<code>").Append(Html(parts[i])).Append("</code>");
        }

        return builder.ToString();
    }

    private static string FormatCredUserSummary(CredUser credUser)
    {
        if (credUser == null)
            return string.Empty;

        return TelegramUserLinkFormatter.HtmlSummary(credUser);
    }

    private static string BuildColleagueRequestLogMessage(CredUser credUser)
    {
        var phone = string.IsNullOrWhiteSpace(credUser?.PhoneNumber)
            ? "ثبت نشده"
            : credUser.PhoneNumber.Trim();

        var email = string.IsNullOrWhiteSpace(credUser?.Email)
            ? "ثبت نشده"
            : credUser.Email.Trim();

        var now = DateTime.UtcNow.AddMinutes(210).ConvertToHijriShamsi();

        return "🤝 <b>درخواست همکاری جدید</b>\n\n" +
               $"👤 نام: {TelegramUserLinkFormatter.HtmlUserLink(credUser)}\n" +
               $"🔹 یوزرنیم: {TelegramUserLinkFormatter.HtmlUsername(credUser)}\n" +
               $"🆔 آیدی عددی: <code>{credUser?.TelegramUserId ?? 0}</code>\n" +
               $"💬 Chat ID: <code>{credUser?.ChatID ?? 0}</code>\n" +
               $"📱 شماره تلفن: <code>{Html(phone)}</code>\n" +
               $"📧 ایمیل: <code>{Html(email)}</code>\n" +
               $"💰 موجودی: <code>{Html((credUser?.AccountBalance ?? 0).FormatCurrency())}</code>\n" +
               $"👥 نوع فعلی: <code>{(credUser?.IsColleague == true ? "همکار" : "کاربر عادی")}</code>\n" +
               $"📌 شرط اعلام‌شده: <code>حداقل فروش هفتگی {MinimumWeeklyColleagueSalesToman.FormatCurrency()}</code>\n" +
               $"🕒 زمان درخواست: <code>{Html(now)}</code>";
    }

    /// <summary>
    /// Resolves the configured XUI v3 service for an existing client.
    /// </summary>
    /// <param name="client">
    /// XUI client read from the panel. The client may contain full JSON metadata, only inbound ids, or only
    /// legacy panel fields after a link-change/update operation.
    /// </param>
    /// <returns>
    /// The enabled service definition that best matches the client, or <c>null</c> when the account is outside
    /// all active service inbounds and has no usable metadata.
    /// </returns>
    /// <remarks>
    /// Metadata is trusted before inbound fallback because normal and unlimited services can share the same
    /// public inbounds. When metadata is missing, negative expiry is used as the unlimited signal; otherwise
    /// shared public inbounds resolve to the normal metered service so changed-link metered accounts do not
    /// accidentally show unlimited renewal choices.
    /// </remarks>
    private XuiV3ServiceDefinition ResolveServiceForClient(XuiV3Client client)
    {
        var metadata = TryReadMetadata(client.Comment);
        var services = _purchaseService.GetEnabledServices();
        var clientInboundIds = GetClientInboundIds(client, metadata);

        var metadataService = FindService(metadata?.ServiceKey);
        if (metadataService != null)
        {
            Console.WriteLine($"[XUIv3] resolve service by metadata email={client?.Email}, service={metadataService.Key}");
            return metadataService;
        }

        if (clientInboundIds.Count == 0)
            return null;

        var nationalService = services.FirstOrDefault(service =>
            IsNationalService(service) && HasAnyInbound(clientInboundIds, service));
        if (nationalService != null)
        {
            Console.WriteLine($"[XUIv3] resolve service by inbound priority email={client.Email}, service={nationalService.Key}, inboundIds=[{string.Join(",", clientInboundIds)}]");
            return nationalService;
        }

        var normalService = services.FirstOrDefault(service =>
            IsNormalService(service) && HasAnyInbound(clientInboundIds, service));
        if (normalService != null && !LooksLikeUnlimitedClient(client, metadata))
        {
            Console.WriteLine($"[XUIv3] resolve service by inbound priority email={client.Email}, service={normalService.Key}, inboundIds=[{string.Join(",", clientInboundIds)}]");
            return normalService;
        }

        var unlimitedService = services.FirstOrDefault(service =>
            service.IsUnlimited && HasAnyInbound(clientInboundIds, service));
        if (unlimitedService != null)
        {
            Console.WriteLine($"[XUIv3] resolve service by inbound priority email={client.Email}, service={unlimitedService.Key}, inboundIds=[{string.Join(",", clientInboundIds)}]");
            return unlimitedService;
        }

        var meteredService = services.FirstOrDefault(service =>
            !service.IsUnlimited &&
            !IsNationalService(service) &&
            !IsNormalService(service) &&
            IsOnlyInServiceInbounds(clientInboundIds, service) &&
            HasAnyInbound(clientInboundIds, service));
        if (meteredService != null)
        {
            Console.WriteLine($"[XUIv3] resolve service by inbound fallback email={client.Email}, service={meteredService.Key}, inboundIds=[{string.Join(",", clientInboundIds)}]");
            return meteredService;
        }

        return null;
    }

    /// <summary>
    /// Infers whether an XUI client is likely an unlimited account when metadata is unavailable.
    /// </summary>
    /// <param name="client">XUI client read from the panel.</param>
    /// <param name="metadata">Parsed JSON metadata from the client comment, when available.</param>
    /// <returns>
    /// <c>true</c> when metadata explicitly marks the service as unlimited or the panel expiry is negative,
    /// which is the 3x-ui first-use-duration convention used by unlimited plans.
    /// </returns>
    private static bool LooksLikeUnlimitedClient(XuiV3Client client, XuiV3ClientMetadata metadata)
    {
        if (string.Equals(metadata?.ServiceKind, XuiV3ServiceKinds.Unlimited, StringComparison.OrdinalIgnoreCase))
            return true;

        if (string.Equals(metadata?.ServiceKey, "unlimited", StringComparison.OrdinalIgnoreCase))
            return true;

        return GetExpiryTime(client) < 0;
    }

    private static List<int> GetClientInboundIds(XuiV3Client client, XuiV3ClientMetadata metadata)
    {
        var inboundIds = new HashSet<int>();

        if (client?.InboundIds != null)
        {
            foreach (var id in client.InboundIds.Where(id => id > 0))
                inboundIds.Add(id);
        }

        if (metadata?.InboundIds != null)
        {
            foreach (var id in metadata.InboundIds.Where(id => id > 0))
                inboundIds.Add(id);
        }

        return inboundIds.OrderBy(id => id).ToList();
    }

    private static bool HasAnyInbound(IReadOnlyCollection<int> clientInboundIds, XuiV3ServiceDefinition service)
    {
        return service?.InboundIds != null &&
               service.InboundIds.Any(id => clientInboundIds.Contains(id));
    }

    private static bool IsOnlyInServiceInbounds(IReadOnlyCollection<int> clientInboundIds, XuiV3ServiceDefinition service)
    {
        if (clientInboundIds == null || clientInboundIds.Count == 0)
            return false;

        var serviceInboundIds = service?.InboundIds?
            .Where(id => id > 0)
            .ToHashSet() ?? new HashSet<int>();

        return serviceInboundIds.Count > 0 &&
               clientInboundIds.All(serviceInboundIds.Contains);
    }

    private static bool IsNationalService(XuiV3ServiceDefinition service)
    {
        return string.Equals(service?.Key, "national", StringComparison.OrdinalIgnoreCase) ||
               (service?.InboundProfileKeys?.Any(key => string.Equals(key, "national", StringComparison.OrdinalIgnoreCase)) ?? false);
    }

    private static bool IsNormalService(XuiV3ServiceDefinition service)
    {
        return string.Equals(service?.Key, "normal", StringComparison.OrdinalIgnoreCase) ||
               (service?.InboundProfileKeys?.Any(key => string.Equals(key, "normal", StringComparison.OrdinalIgnoreCase)) ?? false);
    }

    /// <summary>
    /// Reloads the renewal target and applies an exact email-plus-UUID lock or the legacy owner-only fallback.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor used for the fresh account read.</param>
    /// <param name="user">
    /// Current bot-scoped renewal state containing target email and a normalized UUID lock for every new renewal. A
    /// legacy state may leave the UUID empty and is then authorized by ownership only.
    /// </param>
    /// <param name="telegramUserId">Numeric Telegram id of the payer used only for legacy states without a UUID lock.</param>
    /// <param name="cancellationToken">Token that cancels direct and list panel reads.</param>
    /// <returns>
    /// The fresh detached client when its email and authorization still match; otherwise <c>null</c>. Callers must stop
    /// before preview, wallet, order, or XUI effects when null is returned.
    /// </returns>
    /// <remarks>
    /// The exact target lock is valid for renewal only. It does not authorize configuration reads, link/comment
    /// changes, deletion, state changes, or any other account action. Duplicate email rows fail closed unless the same
    /// row also has the persisted UUID.
    /// </remarks>
    private async Task<XuiV3Client> GetAuthorizedRenewClientAsync(
        ServerInfo serverInfo,
        User user,
        long telegramUserId,
        CancellationToken cancellationToken)
    {
        if (user == null || string.IsNullOrWhiteSpace(user.ConfigLink))
            return null;

        if (string.IsNullOrWhiteSpace(user.RenewTargetUuid))
        {
            var legacyClient = await FindClientByEmailAsync(serverInfo, user.ConfigLink, telegramUserId, cancellationToken);
            return ClientBelongsToUser(legacyClient, telegramUserId) ? legacyClient : null;
        }

        if (!TryNormalizeClientUuid(user.RenewTargetUuid, out var targetUuid))
            return null;

        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
            return null;

        var matches = response.Obj?
            .Where(client => EmailEquals(client.Email, user.ConfigLink) && ClientUuidEquals(client, targetUuid))
            .Take(2)
            .ToList() ?? new List<XuiV3Client>();
        return matches.Count == 1 ? matches[0] : null;
    }

    /// <summary>
    /// Reloads an authorized owned renewal target from the complete read-only client list for snapshot consistency.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor used only for the client-list GET.</param>
    /// <param name="authorizedClient">Previously authorized client whose email and UUID identify the exact target.</param>
    /// <param name="cancellationToken">Token that cancels the authenticated read-only panel request.</param>
    /// <returns>
    /// The unique fresh identity match, or null when the panel cannot prove a single exact target. The detached client
    /// is suitable for the durable pre-mutation snapshot even when it has no inbound attachment.
    /// </returns>
    /// <remarks>
    /// Renewal does not modify inbound membership, so attachment state is deliberately not a precondition or target
    /// criterion. This method performs no wallet, operation, or panel mutation.
    /// </remarks>
    /// <example><code>client = await LoadFreshRenewClientSnapshotAsync(server, client, token)</code></example>
    private async Task<XuiV3Client> LoadFreshRenewClientSnapshotAsync(
        ServerInfo serverInfo,
        XuiV3Client authorizedClient,
        CancellationToken cancellationToken)
    {
        if (authorizedClient == null)
            return null;

        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
            return null;

        var normalizedUuid = XuiV3RenewalOperationStore.NormalizeUuid(authorizedClient.Uuid);
        var normalizedEmail = XuiV3RenewalOperationStore.NormalizeEmail(authorizedClient.Email);
        var matches = (response.Obj ?? new List<XuiV3Client>())
            .Where(x =>
                string.Equals(
                    XuiV3RenewalOperationStore.NormalizeEmail(x.Email),
                    normalizedEmail,
                    StringComparison.Ordinal) &&
                (string.IsNullOrEmpty(normalizedUuid) ||
                 string.Equals(
                     XuiV3RenewalOperationStore.NormalizeUuid(x.Uuid),
                     normalizedUuid,
                     StringComparison.Ordinal)))
            .Take(2)
            .ToList();
        return matches.Count == 1 ? matches[0] : null;
    }

    /// <summary>
    /// Finds an XUI client by normalized account email while preferring a match owned by the requesting Telegram user.
    /// </summary>
    /// <param name="serverInfo">Configured panel descriptor for direct and list API calls.</param>
    /// <param name="email">Account email/name only; UUIDs and configuration links must be resolved before calling.</param>
    /// <param name="telegramUserId">Numeric Telegram id used to prefer the owned match when duplicate emails exist.</param>
    /// <param name="cancellationToken">Token that cancels panel reads.</param>
    /// <returns>
    /// The owned matching client when available, otherwise another exact-email match for the caller to authorize, or
    /// <c>null</c> when no exact match exists.
    /// </returns>
    /// <remarks>
    /// Returning a non-owner match is intentional so callers can produce a generic mismatch result. This method grants
    /// no authorization by itself and never accepts UUID possession as ownership. Account names, response messages,
    /// UUIDs, SubIds, metadata values, and identifier-bearing request URIs are omitted from diagnostics.
    /// </remarks>
    private async Task<XuiV3Client> FindClientByEmailAsync(
        ServerInfo serverInfo,
        string email,
        long telegramUserId,
        CancellationToken cancellationToken)
    {
        var normalizedEmail = NormalizeAccountNameInput(email);
        XuiV3Client directClient = null;

        try
        {
            var directResponse = await ApiServicev3.GetClientAsync(serverInfo, _configuration, normalizedEmail, cancellationToken);
            directClient = directResponse.Obj;
            if (directClient != null && !EmailEquals(directClient.Email, normalizedEmail))
                directClient = null;
            Console.WriteLine(
                $"[XUIv3] find client direct user={telegramUserId}, success={directResponse.Success}, found={(directClient == null ? "no" : "yes")}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] find client direct failed user={telegramUserId}, errorType={ex.GetType().Name}");
        }

        if (directClient != null && EmailEquals(directClient.Email, normalizedEmail) && ClientBelongsToUser(directClient, telegramUserId))
            return directClient;

        var listResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        var matches = listResponse.Obj?
            .Where(client => EmailEquals(client.Email, normalizedEmail))
            .ToList() ?? new List<XuiV3Client>();

        Console.WriteLine(
            $"[XUIv3] find client list user={telegramUserId}, success={listResponse.Success}, total={listResponse.Obj?.Count ?? 0}, matches={matches.Count}, ownerMatches={matches.Count(client => ClientBelongsToUser(client, telegramUserId))}");

        var ownerMatch = matches.FirstOrDefault(client => ClientBelongsToUser(client, telegramUserId));
        if (ownerMatch != null)
            return ownerMatch;

        if (matches.Count > 0)
            return matches[0];

        return directClient;
    }

    private static bool ClientBelongsToUser(XuiV3Client client, long telegramUserId)
    {
        if (client == null)
            return false;

        if (client.TgId == telegramUserId)
            return true;

        var metadata = TryReadMetadata(client.Comment);
        return metadata?.TelegramUserId == telegramUserId;
    }

    private static bool ClientHasAccountCounter(XuiV3Client client, int accountCounter)
    {
        if (client == null || accountCounter <= 0)
            return false;

        var metadata = TryReadMetadata(client.Comment);
        if (metadata?.AccountCounter == accountCounter)
            return true;

        var normalizedEmail = NormalizeDigits(client.Email ?? string.Empty).Trim();
        return normalizedEmail.EndsWith("_" + accountCounter, StringComparison.OrdinalIgnoreCase);
    }

    private static bool EmailEquals(string left, string right)
    {
        return string.Equals(
            NormalizeAccountNameInput(left),
            NormalizeAccountNameInput(right),
            StringComparison.OrdinalIgnoreCase);
    }

    private static string NormalizeAccountNameInput(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var normalized = NormalizeDigits(value).Trim();
        return new string(normalized.Where(ch => !char.IsControl(ch) && ch != '\u200e' && ch != '\u200f').ToArray()).Trim();
    }

    /// <summary>
    /// Builds the reply keyboard used when a customer chooses or types metered traffic during owned-bot purchase or renewal.
    /// </summary>
    /// <param name="service">
    /// Metered service definition loaded from the XUI v3 plan file. Its <c>minimumTrafficGb</c> setting controls
    /// which preset buttons are shown.
    /// </param>
    /// <returns>
    /// A reply keyboard containing visible traffic presets greater than or equal to the service minimum and an
    /// <c>انصراف</c> row. The returned keyboard may contain only cancel when no presets are configured.
    /// </returns>
    /// <remarks>
    /// Customers can still type any integer GB amount; typed values are validated separately against the same
    /// minimum before a duration or invoice is shown.
    /// </remarks>
    private static ReplyKeyboardMarkup BuildTrafficReplyKeyboard(XuiV3ServiceDefinition service)
    {
        var rows = XuiV3PurchaseService.GetVisibleTrafficOptions(service)
            .Select(gb => new KeyboardButton($"{gb} GB"))
            .Chunk(3)
            .Select(chunk => chunk.ToArray())
            .Append(new[] { new KeyboardButton("انصراف") });

        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the customer-facing validation message shown when a metered traffic amount is below the plan minimum.
    /// </summary>
    /// <param name="service">Metered service whose minimum traffic rule rejected the input.</param>
    /// <returns>Persian text explaining the minimum allowed traffic in GB.</returns>
    /// <remarks>
    /// The text is used before calling the shared resolver so typed values and stale callback buttons fail with a
    /// readable Telegram message instead of surfacing an internal validation exception.
    /// </remarks>
    private static string BuildMinimumTrafficMessage(XuiV3ServiceDefinition service)
    {
        return $"حداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(service)} GB است. لطفاً حجم بیشتری وارد کنید.";
    }

    /// <summary>
    /// Finds the earliest safe purchase step for a selection restored from bot-scoped durable state.
    /// </summary>
    /// <param name="service">
    /// Enabled live-catalog service resolved from the saved key, or <see langword="null"/> when the key was removed,
    /// disabled, or absent.
    /// </param>
    /// <param name="selection">
    /// Restored in-memory selection for the current bot and Telegram user. It may contain values saved under an older
    /// catalog revision.
    /// </param>
    /// <param name="requiredStep">
    /// Purchase step about to consume the incoming text or callback. Use the durable state step for text messages and
    /// the destination step for callbacks such as account count.
    /// </param>
    /// <param name="isColleague">
    /// Current owned-bot buyer role used to reject an enabled unlimited plan that is restricted to colleagues.
    /// </param>
    /// <returns>
    /// <see cref="PurchaseRecoveryTarget.None"/> when every value required by the step is valid in the live catalog;
    /// otherwise the earliest step that can safely preserve valid service or traffic choices.
    /// </returns>
    /// <remarks>
    /// This method performs no I/O and no price calculation. The central resolver remains fail-closed and is still
    /// called before preview and confirmation; this check exists to turn stale UI state into a recoverable prompt
    /// before user text can be consumed as a count or comment.
    /// </remarks>
    /// <example>
    /// <code>
    /// var target = DeterminePurchaseRecoveryTarget(
    ///     service,
    ///     selection,
    ///     "select-user-comment",
    ///     credUser.IsColleague);
    /// </code>
    /// </example>
    private static PurchaseRecoveryTarget DeterminePurchaseRecoveryTarget(
        XuiV3ServiceDefinition service,
        XuiV3PurchaseSelection selection,
        string requiredStep,
        bool isColleague)
    {
        if (service == null || selection == null)
            return PurchaseRecoveryTarget.Service;

        if (string.Equals(requiredStep, PurchaseStepSelectService, StringComparison.Ordinal))
            return PurchaseRecoveryTarget.Service;

        if (service.IsUnlimited)
        {
            if (string.Equals(requiredStep, PurchaseStepSelectUnlimitedPlan, StringComparison.Ordinal))
                return PurchaseRecoveryTarget.None;

            if (!string.Equals(requiredStep, PurchaseStepAccountCount, StringComparison.Ordinal) &&
                !string.Equals(requiredStep, PurchaseStepUserComment, StringComparison.Ordinal) &&
                !string.Equals(requiredStep, PurchaseStepConfirm, StringComparison.Ordinal))
            {
                return PurchaseRecoveryTarget.UnlimitedPlan;
            }

            var selectedPlan = service.UnlimitedPlans?.FirstOrDefault(plan =>
                string.Equals(plan.Key, selection.UnlimitedPlanKey, StringComparison.OrdinalIgnoreCase));
            return XuiV3PurchaseService.IsUnlimitedPlanAvailableForOwnedBot(selectedPlan, isColleague)
                ? PurchaseRecoveryTarget.None
                : PurchaseRecoveryTarget.UnlimitedPlan;
        }

        if (string.Equals(requiredStep, PurchaseStepSelectTraffic, StringComparison.Ordinal))
            return PurchaseRecoveryTarget.None;

        if (!selection.TrafficGb.HasValue ||
            !XuiV3PurchaseService.MeetsMinimumTraffic(service, selection.TrafficGb.Value))
        {
            return PurchaseRecoveryTarget.Traffic;
        }

        if (string.Equals(requiredStep, PurchaseStepSelectDuration, StringComparison.Ordinal))
            return PurchaseRecoveryTarget.None;

        if (!string.Equals(requiredStep, PurchaseStepAccountCount, StringComparison.Ordinal) &&
            !string.Equals(requiredStep, PurchaseStepUserComment, StringComparison.Ordinal) &&
            !string.Equals(requiredStep, PurchaseStepConfirm, StringComparison.Ordinal))
        {
            return PurchaseRecoveryTarget.Duration;
        }

        return XuiV3PurchaseService.TryResolveDurationKey(service, selection.DurationKey, out _)
            ? PurchaseRecoveryTarget.None
            : PurchaseRecoveryTarget.Duration;
    }

    /// <summary>
    /// Replaces an invalid owned-purchase state with the earliest safe step and shows the current catalog choices.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned bot that received the stale text or callback.</param>
    /// <param name="chatId">Telegram chat id from the active update; it is used only for the recovery prompt.</param>
    /// <param name="messageId">
    /// Source Telegram message id for callback recovery, or zero for a text-message recovery that must send a new
    /// message instead of editing user content.
    /// </param>
    /// <param name="credUser">
    /// Shared credential profile for the current Telegram user. Only its user id, role, and safe audit identity are used.
    /// </param>
    /// <param name="user">
    /// Bot-scoped durable conversation loaded for the bot that received the update. Its previous step is logged without
    /// user-entered text or sensitive plan/payment data.
    /// </param>
    /// <param name="selection">
    /// Bot-scoped in-memory selection to synchronize with the recovered durable state. Valid service and traffic values
    /// are preserved when the target permits them.
    /// </param>
    /// <param name="service">Current enabled service, or <see langword="null"/> when service selection must restart.</param>
    /// <param name="target">Earliest safe recovery step returned by <see cref="DeterminePurchaseRecoveryTarget"/>.</param>
    /// <param name="cancellationToken">Token that cancels the users.db reset, audit write, or Telegram prompt.</param>
    /// <returns>A task that completes after the state and prompt have been synchronized.</returns>
    /// <remarks>
    /// The database reset is scoped by the ambient bot id plus Telegram user id. It clears only transient conversation
    /// values; wallets, ledger entries, orders, payments, XUI accounts, and states in other bots are untouched. The
    /// triggering user message is intentionally not reused after recovery, preventing ordinary text from becoming an
    /// order comment under a stale catalog selection.
    /// </remarks>
    /// <example>
    /// <code>
    /// await RecoverPurchaseStateAsync(
    ///     botClient, chatId, 0, credUser, user, selection, service,
    ///     PurchaseRecoveryTarget.Duration, cancellationToken);
    /// </code>
    /// </example>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during users.db, audit, or Telegram work.
    /// </exception>
    private async Task RecoverPurchaseStateAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        User user,
        XuiV3PurchaseSelection selection,
        XuiV3ServiceDefinition service,
        PurchaseRecoveryTarget target,
        CancellationToken cancellationToken)
    {
        if (target == PurchaseRecoveryTarget.None)
            return;

        selection ??= new XuiV3PurchaseSelection();
        if (target == PurchaseRecoveryTarget.Duration &&
            (service == null || !selection.TrafficGb.HasValue ||
             !XuiV3PurchaseService.MeetsMinimumTraffic(service, selection.TrafficGb.Value)))
        {
            target = PurchaseRecoveryTarget.Traffic;
        }

        if ((target == PurchaseRecoveryTarget.Traffic ||
             target == PurchaseRecoveryTarget.Duration ||
             target == PurchaseRecoveryTarget.UnlimitedPlan) && service == null)
        {
            target = PurchaseRecoveryTarget.Service;
        }

        var previousStep = user?.LastStep ?? string.Empty;
        selection.AccountCount = 1;
        selection.UserComment = null;

        var replacement = new User
        {
            Id = credUser.TelegramUserId,
            Flow = PurchaseFlowName,
            PendingAccountCount = 0,
            PendingUserComment = string.Empty,
            SelectedPeriod = string.Empty,
            Type = string.Empty,
            TotoalGB = string.Empty
        };

        string prompt;
        InlineKeyboardMarkup keyboard;
        switch (target)
        {
            case PurchaseRecoveryTarget.Traffic:
                selection.ServiceKey = service.Key;
                selection.TrafficGb = null;
                selection.DurationKey = null;
                selection.UnlimitedPlanKey = null;
                replacement.LastStep = PurchaseStepSelectTraffic;
                replacement.SelectedCountry = service.Key;
                prompt = "حجم انتخاب‌شده قبلی دیگر معتبر نیست. لطفاً حجم جدید را انتخاب یا به‌صورت عدد صحیح ارسال کنید.";
                keyboard = _purchaseService.BuildTrafficKeyboard(service.Key);
                break;

            case PurchaseRecoveryTarget.Duration:
                selection.ServiceKey = service.Key;
                selection.DurationKey = null;
                selection.UnlimitedPlanKey = null;
                replacement.LastStep = PurchaseStepSelectDuration;
                replacement.SelectedCountry = service.Key;
                replacement.TotoalGB = selection.TrafficGb.Value.ToString(CultureInfo.InvariantCulture);
                prompt = XuiV3PurchaseService.BuildDurationSelectionText(
                    service,
                    "مدت انتخاب‌شده قبلی دیگر فعال یا معتبر نیست. لطفاً یک مدت جدید انتخاب کنید.");
                keyboard = _purchaseService.BuildDurationKeyboard(service.Key, selection.TrafficGb.Value);
                break;

            case PurchaseRecoveryTarget.UnlimitedPlan:
                selection.ServiceKey = service.Key;
                selection.TrafficGb = null;
                selection.DurationKey = null;
                selection.UnlimitedPlanKey = null;
                replacement.LastStep = PurchaseStepSelectUnlimitedPlan;
                replacement.SelectedCountry = service.Key;
                prompt = "پلن نامحدود انتخاب‌شده قبلی دیگر برای حساب شما فعال یا قابل انتخاب نیست. لطفاً یک پلن معتبر انتخاب کنید.";
                keyboard = _purchaseService.BuildUnlimitedPlanKeyboard(service.Key, credUser.IsColleague);
                break;

            default:
                selection.ServiceKey = null;
                selection.TrafficGb = null;
                selection.DurationKey = null;
                selection.UnlimitedPlanKey = null;
                replacement.LastStep = PurchaseStepSelectService;
                replacement.SelectedCountry = string.Empty;
                prompt = "انتخاب قبلی شما دیگر فعال نیست. لطفاً نوع سرویس را دوباره انتخاب کنید.";
                keyboard = _purchaseService.BuildServiceKeyboard();
                break;
        }

        _sessionStore.Set(credUser.TelegramUserId, selection);
        await _state.ResetUserStatus(replacement);
        await _activityLog.LogWarningAsync(
            "xui_v3_purchase_state_recovered",
            credUser,
            false,
            new Dictionary<string, object>
            {
                ["previousStep"] = previousStep,
                ["recoveryTarget"] = target.ToString(),
                ["serviceKey"] = service?.Key ?? string.Empty
            },
            cancellationToken);

        await SendOrEditTextAsync(
            botClient,
            chatId,
            messageId,
            prompt,
            replyMarkup: keyboard,
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Restores durable purchase fields into the in-memory owned-bot selection after a restart or instance handoff.
    /// </summary>
    /// <param name="selection">
    /// Mutable bot-scoped in-memory selection for the current Telegram user. The object is updated in place and must
    /// not be shared with another bot context or Telegram user.
    /// </param>
    /// <param name="service">Current enabled global service resolved from the durable service key.</param>
    /// <param name="user">
    /// Bot-scoped users.db state containing traffic in GB, configured or <c>days-N</c> duration, unlimited plan key,
    /// and later-step values saved by the active owned bot.
    /// </param>
    /// <remarks>
    /// This method performs no database write. The central resolver still validates every restored value before wallet,
    /// ledger, site-wallet, tenant, or XUI effects, so durable state cannot bypass a later catalog change.
    /// </remarks>
    private static void RehydratePurchaseSelectionFromState(
        XuiV3PurchaseSelection selection,
        XuiV3ServiceDefinition service,
        User user)
    {
        if (selection == null || service == null || user == null)
            return;

        selection.ServiceKey = service.Key;
        if (service.IsUnlimited)
        {
            if (string.IsNullOrWhiteSpace(selection.UnlimitedPlanKey))
                selection.UnlimitedPlanKey = user.Type;
            selection.TrafficGb = null;
            selection.DurationKey = null;
            return;
        }

        if (!selection.TrafficGb.HasValue &&
            int.TryParse(user.TotoalGB, NumberStyles.Integer, CultureInfo.InvariantCulture, out var trafficGb) &&
            trafficGb > 0)
        {
            selection.TrafficGb = trafficGb;
        }

        if (string.IsNullOrWhiteSpace(selection.DurationKey))
            selection.DurationKey = user.SelectedPeriod;
        selection.UnlimitedPlanKey = null;
    }

    /// <summary>
    /// Builds the owned-bot renewal keyboard for enabled metered durations.
    /// </summary>
    /// <param name="service">
    /// Enabled global metered service that owns the renewal options. The value must come from the current catalog,
    /// not from persisted user state alone.
    /// </param>
    /// <returns>
    /// A Telegram reply keyboard containing enabled duration labels in ascending day order plus a cancellation row.
    /// The keyboard can contain only cancellation when no duration is enabled.
    /// </returns>
    /// <remarks>
    /// Buttons are presentation hints and can remain visible in old messages after configuration changes. Text
    /// parsing and the central resolver repeat the enabled check before any wallet or XUI side effect.
    /// </remarks>
    private static ReplyKeyboardMarkup BuildDurationReplyKeyboard(XuiV3ServiceDefinition service)
    {
        var rows = XuiV3PurchaseService.GetEnabledDurationOptions(service)
            .OrderBy(duration => duration.Days)
            .Select(duration => new KeyboardButton($"{duration.DisplayName} [{duration.Key}]"))
            .Chunk(2)
            .Select(chunk => chunk.ToArray())
            .Append(new[] { new KeyboardButton("انصراف") });

        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the owned-bot reply keyboard for unlimited purchase and renewal plan selection.
    /// </summary>
    /// <param name="service">Enabled unlimited service loaded from the current global catalog.</param>
    /// <param name="isColleague">
    /// Current owned-bot customer role used for both audience filtering and the displayed role price.
    /// </param>
    /// <returns>
    /// A reply keyboard containing only plans available to the owned customer, followed by an explicit cancel row.
    /// </returns>
    /// <remarks>
    /// Typed text and final state are revalidated separately; hiding a reply button is not treated as authorization.
    /// This method has no persistence, wallet, Telegram-send, payment, or XUI side effects.
    /// </remarks>
    /// <example>
    /// <code>
    /// var keyboard = BuildUnlimitedPlanReplyKeyboard(service, credUser.IsColleague);
    /// </code>
    /// </example>
    private static ReplyKeyboardMarkup BuildUnlimitedPlanReplyKeyboard(XuiV3ServiceDefinition service, bool isColleague)
    {
        var rows = XuiV3PurchaseService.GetUnlimitedPlansForOwnedBot(service, isColleague)
            .Select(plan => new KeyboardButton($"{plan.DisplayName} [{plan.Key}] - {plan.Price.GetForRole(isColleague).FormatCurrency()}"))
            .Chunk(1)
            .Select(chunk => chunk.ToArray())
            .Append(new[] { new KeyboardButton("انصراف") });

        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the renewal confirmation reply keyboard for the current account renewal state.
    /// </summary>
    /// <param name="canUseSiteWallet">
    /// <c>true</c> when the Gozargah website wallet precheck passed and the site-wallet renewal button may be shown.
    /// </param>
    /// <returns>A Telegram reply keyboard with normal renewal confirmation, optional site-wallet renewal, and cancel.</returns>
    /// <remarks>
    /// This method only controls button visibility. The final renewal handler repeats the website wallet validation
    /// before updating 3x-ui because the site balance or ban status can change after the keyboard is rendered.
    /// </remarks>
    private ReplyKeyboardMarkup BuildConfirmReplyKeyboard(bool canUseSiteWallet = false)
    {
        var rows = new List<KeyboardButton[]>
        {
            new[] { new KeyboardButton("تایید تمدید") },
            new[] { new KeyboardButton("انصراف") }
        };

        if (canUseSiteWallet)
            rows.Insert(1, new[] { new KeyboardButton("تایید تمدید با کیف پول سایت") });

        return new ReplyKeyboardMarkup(rows)
        {
            ResizeKeyboard = true
        };
    }

    /// <summary>
    /// Builds the final purchase confirmation keyboard and optionally exposes the Gozargah site wallet.
    /// </summary>
    /// <param name="selection">Current XUI v3 purchase selection encoded into callback data.</param>
    /// <param name="canUseSiteWallet">
    /// <c>true</c> when the latest Gozargah website wallet precheck found an existing, non-banned user with
    /// enough balance for the selected purchase amount.
    /// </param>
    /// <returns>
    /// Inline keyboard with the normal bot-wallet confirmation, optional site-wallet confirmation, and cancel/back actions.
    /// </returns>
    /// <remarks>
    /// The callback handler repeats the website wallet precheck because balances can change after this keyboard is rendered.
    /// </remarks>
    private InlineKeyboardMarkup BuildPurchaseConfirmKeyboard(XuiV3PurchaseSelection selection, bool canUseSiteWallet = false)
    {
        var rows = new List<InlineKeyboardButton[]>
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("تایید با کیف پول ربات", XuiV3PurchaseCallbacks.Confirm(selection)),
                InlineKeyboardButton.WithCallbackData("انصراف", XuiV3PurchaseCallbacks.Cancel())
            }
        };

        if (canUseSiteWallet)
            rows.Insert(0, new[] { InlineKeyboardButton.WithCallbackData("پرداخت با کیف پول سایت گذرگاه", XuiV3PurchaseCallbacks.SiteWalletConfirm(selection)) });

        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.BackToServices()) });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the owned renewal shortcut that abandons the current XUI state and opens wallet charging.
    /// </summary>
    /// <returns>An inline keyboard containing only the safe wallet-charge routing callback.</returns>
    /// <remarks>
    /// No user id, amount, or payment proof is encoded in the callback. TelegramBotService resolves the sender from the
    /// callback envelope, clears bot-scoped state, and displays the live charge menu without creating an invoice.
    /// </remarks>
    private static InlineKeyboardMarkup BuildOwnedWalletChargeShortcutKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    TelegramBotService.WalletChargeShortcutLabel,
                    TelegramBotService.WalletChargeShortcutCallback)
            }
        });
    }

    /// <summary>
    /// Builds the insufficient-balance keyboard for a final XUI v3 purchase confirmation.
    /// </summary>
    /// <returns>
    /// Charge, back, and cancel actions for owned bots; back and cancel only for any non-owned context.
    /// </returns>
    /// <remarks>
    /// Tenant storefront customers never use the platform wallet. The explicit runtime-type check prevents an owned
    /// charge shortcut from appearing if a stale shared XUI callback is delivered through a tenant bot.
    /// </remarks>
    private InlineKeyboardMarkup BuildPurchaseInsufficientBalanceKeyboard()
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase))
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    TelegramBotService.WalletChargeShortcutLabel,
                    TelegramBotService.WalletChargeShortcutCallback)
            });
        }

        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", XuiV3PurchaseCallbacks.BackToServices()) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("انصراف", XuiV3PurchaseCallbacks.Cancel()) });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Checks whether the Gozargah website wallet should be offered for the current final purchase or renewal step.
    /// </summary>
    /// <param name="telegramUserId">
    /// Numeric Telegram user id of the buyer. The Gozargah website API uses this id to find the matching user row.
    /// </param>
    /// <param name="amountToman">
    /// Required payment amount in Iranian toman. Values less than or equal to zero never show the site-wallet button.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the website API precheck.</param>
    /// <returns>
    /// <c>true</c> when the website wallet can be displayed; otherwise <c>false</c>. API failures, banned users,
    /// missing users, and insufficient balances are all treated as hidden-button conditions.
    /// </returns>
    /// <remarks>
    /// This method controls only Telegram button visibility. The payment callback repeats the same eligibility check
    /// immediately before account delivery so a stale keyboard cannot spend an insufficient or banned website wallet.
    /// </remarks>
    private async Task<bool> CanUseGozargahSiteWalletAsync(long telegramUserId, long amountToman, CancellationToken cancellationToken)
    {
        if (amountToman <= 0)
            return false;

        var eligibility = await _gozargahSiteSyncService.CheckSiteWalletEligibilityAsync(
            telegramUserId,
            amountToman,
            cancellationToken);

        return eligibility.CanUse;
    }

    /// <summary>
    /// Refreshes colleague pricing for an owned-bot user from the Gozargah website account state.
    /// </summary>
    /// <param name="credUser">
    /// Shared credentials profile of the Telegram user whose pricing is about to be calculated. The object is updated
    /// in memory when the website lookup promotes the database row to colleague.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the website lookup and credentials database update.</param>
    /// <returns>A task that completes after the optional role refresh has finished.</returns>
    /// <remarks>
    /// This is intentionally limited to owned bots. Tenant storefront customers pay the storefront sale price chosen by
    /// the tenant owner; auto-promoting those buyers would bypass tenant pricing and break owner profit accounting.
    /// </remarks>
    private async Task RefreshOwnedBotColleagueRoleFromGozargahAsync(CredUser credUser, CancellationToken cancellationToken)
    {
        if (!ShouldAutoPromoteColleagueFromGozargah())
            return;

        await _gozargahSiteSyncService.PromoteToColleagueIfConnectedSiteUserAsync(credUser, cancellationToken);
    }

    /// <summary>
    /// Determines whether the active bot may use the Gozargah website account to promote the current user.
    /// </summary>
    /// <returns>
    /// <c>true</c> for owned bots; <c>false</c> for tenant storefronts, the sales-assistant bot, and unknown contexts.
    /// </returns>
    /// <remarks>
    /// Owned bots sell directly for the platform, so a linked website account maps to colleague pricing. Tenant bots are
    /// indirect storefronts and must keep their customer pricing isolated from the platform colleague role.
    /// </remarks>
    private bool ShouldAutoPromoteColleagueFromGozargah()
    {
        var type = _botContextAccessor.Current?.Config?.Type ?? BotContextAccessor.CurrentBotType;
        return string.Equals(type, BotInstanceTypes.Owned, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Detects purchase callbacks whose pricing can be affected by a late Gozargah colleague-role refresh.
    /// </summary>
    /// <param name="action">Parsed XUI v3 callback action.</param>
    /// <returns><c>true</c> when the callback may build a price, summary, wallet button, or final debit.</returns>
    private static bool ShouldRefreshColleagueRoleForPurchaseCallback(string action)
    {
        return string.Equals(action, "svc", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "gb", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "dur", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "upl", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "cnt", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "ok", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "sitepay", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "aren", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "asren", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(action, "auren", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Resolves the current renewal state's payable amount in toman.
    /// </summary>
    /// <param name="user">
    /// Bot-scoped renewal state row containing the selected service, traffic, duration, or unlimited plan key.
    /// </param>
    /// <param name="isColleague">Whether colleague pricing should be used from the XUI v3 service plan file.</param>
    /// <returns>
    /// Renewal price in Iranian toman, or <c>0</c> when the state is incomplete and no site-wallet button should be shown.
    /// </returns>
    /// <remarks>
    /// The method mirrors renewal summary selection resolution without reading the panel and applies the owned audience
    /// policy. Final renewal still recalculates price, target identity, and renewal policy before updating 3x-ui.
    /// </remarks>
    private long ResolveRenewPriceToman(User user, bool isColleague)
    {
        if (user == null || string.IsNullOrWhiteSpace(user.SelectedCountry))
            return 0;

        var service = FindService(user.SelectedCountry);
        var selection = service.IsUnlimited
            ? new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = user.Type }
            : new XuiV3PurchaseSelection
            {
                ServiceKey = service.Key,
                TrafficGb = int.TryParse(user.TotoalGB, out var trafficGb) ? trafficGb : 0,
                DurationKey = user.SelectedPeriod
            };

        return _purchaseService.ResolveOwnedPurchase(selection, isColleague).PriceToman;
    }

    /// <summary>
    /// Resolves the Telegram id that should own a synced website order for the current bot runtime.
    /// </summary>
    /// <param name="credUser">Credentials profile of the Telegram user performing the account operation.</param>
    /// <returns>
    /// Tenant owner Telegram id when the current bot is a tenant storefront; otherwise the acting user's Telegram id.
    /// </returns>
    /// <remarks>
    /// Gozargah website records for tenant storefront purchases belong to the colleague owner, while the buyer is kept
    /// separately in the sync event. Owned bots use the buyer as the website owner.
    /// </remarks>
    private static long ResolveGozargahSiteOwnerTelegramUserId(CredUser credUser)
    {
        if (string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase))
        {
            // A tenant order belongs to the storefront owner on Gozargah. Never fall back to the buyer when a
            // tenant context is incomplete; doing so would silently register the order under the wrong website user.
            return BotContextAccessor.CurrentBotOwnerTelegramUserId.GetValueOrDefault();
        }

        return credUser?.TelegramUserId ?? 0;
    }

    /// <summary>
    /// Resolves the tenant bot id that should be stored with a website sync event.
    /// </summary>
    /// <returns>The current bot id for tenant storefronts; otherwise <c>null</c> for owned bots.</returns>
    /// <remarks>
    /// The value keeps shared-flow account operations isolated by tenant when a customer uses purchase, renewal,
    /// delete, or link-change features from a tenant bot.
    /// </remarks>
    private static string ResolveGozargahTenantBotId()
    {
        return string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase)
            ? BotContextAccessor.CurrentBotId
            : null;
    }

    /// <summary>
    /// Queues an optional Gozargah lifecycle mirror without changing the user-facing XUI operation result.
    /// </summary>
    /// <param name="operation">Short operation label used only for diagnostics.</param>
    /// <param name="enqueue">Outbox enqueue/send delegate executed after the panel mutation succeeds.</param>
    /// <returns>A task that completes after the best-effort mirror attempt.</returns>
    /// <remarks>
    /// The panel operation is authoritative for the customer flow. A website lookup, outbox, or network error is
    /// therefore logged and left for a later explicit recovery rather than being surfaced as a failed account action.
    /// </remarks>
    private async Task QueueGozargahSyncBestEffortAsync(string operation, Func<Task> enqueue)
    {
        try
        {
            await enqueue();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Gozargah sync enqueue failed after XUI operation. operation={Operation}",
                operation);
        }
    }

    /// <summary>
    /// Deletes accounts that were created before a post-create website-wallet debit failed.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor.</param>
    /// <param name="createdAccounts">Accounts created in the current purchase attempt.</param>
    /// <param name="cancellationToken">Cancellation token for panel delete calls.</param>
    /// <returns>A task that completes after best-effort rollback attempts finish.</returns>
    /// <remarks>
    /// This is a compensation path, not a transaction. It prevents accidental delivery after unpaid site-wallet
    /// failures, but failures are logged and still require admin review.
    /// </remarks>
    private async Task TryRollbackCreatedAccountsAsync(
        ServerInfo serverInfo,
        IEnumerable<XuiV3AccountCreationResult> createdAccounts,
        CancellationToken cancellationToken)
    {
        foreach (var account in createdAccounts ?? Enumerable.Empty<XuiV3AccountCreationResult>())
        {
            if (string.IsNullOrWhiteSpace(account.Email))
                continue;

            try
            {
                var deleteResponse = await ApiServicev3.DeleteClientAsync(serverInfo, _configuration, account.Email, cancellationToken);
                if (!deleteResponse.Success)
                    _logger.LogWarning("Rollback delete failed for Gozargah site wallet purchase. email={Email}, msg={Message}", account.Email, deleteResponse.Msg);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Rollback delete threw for Gozargah site wallet purchase. email={Email}", account.Email);
            }
        }
    }

    private static InlineKeyboardMarkup BuildAccountCountInlineKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("1", XuiV3PurchaseCallbacks.AccountCount(1)),
                InlineKeyboardButton.WithCallbackData("2", XuiV3PurchaseCallbacks.AccountCount(2)),
                InlineKeyboardButton.WithCallbackData("3", XuiV3PurchaseCallbacks.AccountCount(3))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("5", XuiV3PurchaseCallbacks.AccountCount(5)),
                InlineKeyboardButton.WithCallbackData("10", XuiV3PurchaseCallbacks.AccountCount(10))
            },
            new[] { InlineKeyboardButton.WithCallbackData("انصراف", XuiV3PurchaseCallbacks.Cancel()) }
        });
    }

    private static ReplyKeyboardMarkup BuildAccountCountReplyKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("1"), new KeyboardButton("2"), new KeyboardButton("3") },
            new[] { new KeyboardButton("5"), new KeyboardButton("10") },
            new[] { new KeyboardButton("انصراف") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    private static ReplyKeyboardMarkup BuildOptionalCommentReplyKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton(SkipCommentText) },
            new[] { new KeyboardButton("انصراف") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    private static ReplyKeyboardMarkup BuildColleagueRequestConfirmKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("شرایط را قبول دارم و درخواست همکاری می‌فرستم") },
            new[] { new KeyboardButton("انصراف") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    private static ReplyKeyboardMarkup BuildTrialServiceReplyKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("تست نت ملی") },
            new[] { new KeyboardButton("تست نت عادی") },
            new[] { new KeyboardButton("انصراف") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    private static string TryGetTrialServiceKey(string text)
    {
        var key = ExtractBracketValue(text);
        if (string.Equals(key, "national", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(text?.Trim(), "national", StringComparison.OrdinalIgnoreCase) ||
            text?.Contains("ملی", StringComparison.OrdinalIgnoreCase) == true)
            return "national";

        if (string.Equals(key, "normal", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(text?.Trim(), "normal", StringComparison.OrdinalIgnoreCase) ||
            text?.Contains("عادی", StringComparison.OrdinalIgnoreCase) == true)
            return "normal";

        return null;
    }

    /// <summary>
    /// Ensures an owned-bot customer has a previously verified phone number before starting a purchase or renewal.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client for the active owned bot. Tenant storefront updates do not enter this flow.
    /// </param>
    /// <param name="chatId">Private Telegram chat id that receives the contact-request keyboard.</param>
    /// <param name="credUser">
    /// Shared credentials profile for the Telegram customer. A non-empty <c>PhoneNumber</c> means verification has
    /// already completed through automatic Iranian contact validation or the super-admin manual override.
    /// </param>
    /// <param name="cancellationToken">Polling cancellation token used for the Telegram request.</param>
    /// <returns>
    /// <c>true</c> when a verified phone is already stored; otherwise <c>false</c> after sending the Iranian-number
    /// requirement and contact keyboard.
    /// </returns>
    /// <remarks>
    /// Automatic verification accepts only the sender's own Iranian mobile contact. Foreign and virtual numbers are
    /// rejected by the common owned-bot contact handler and redirected to the active bot's configured support account.
    /// A super-admin may still verify those numbers through the separate audited manual flow.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (!await EnsurePhoneVerifiedAsync(client, message.Chat.Id, credUser, cancellationToken))
    ///     return true;
    /// </code>
    /// </example>
    private async Task<bool> EnsurePhoneVerifiedAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        CredUser credUser,
        CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(credUser?.PhoneNumber))
            return true;

        await botClient.SendMessage(
            chatId: chatId,
            text:
                "برای خرید یا تمدید اکانت، ابتدا باید شماره تلفن خودتان را تأیید کنید.\n\n" +
                "تأیید خودکار فقط با شماره موبایل ایران انجام می‌شود و شماره ارسالی باید متعلق به همین حساب تلگرام باشد. " +
                "لطفاً فقط از دکمه پایین پیام استفاده کنید.",
            replyMarkup: BuildPhoneNumberKeyboard(),
            cancellationToken: cancellationToken);

        return false;
    }

    /// <summary>
    /// Builds the one-time owned-bot keyboard that requests the sender's own Telegram contact.
    /// </summary>
    /// <returns>A contact-request row plus a cancellation row for returning from phone verification.</returns>
    /// <remarks>
    /// Telegram supplies the contact owner id with this button. The common owned-bot contact validator still checks
    /// ownership and normalizes only Iranian mobile forms before anything is persisted.
    /// </remarks>
    private static ReplyKeyboardMarkup BuildPhoneNumberKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { KeyboardButton.WithRequestContact("ارسال شماره تلفن") },
            new[] { new KeyboardButton("لغو") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    /// <summary>
    /// Builds the owned-bot renewal preview from the selected plan and the latest XUI client state.
    /// </summary>
    /// <param name="user">
    /// Bot-scoped conversation state containing the target account email, service key, and selected renewal plan.
    /// The state belongs to the active owned bot and Telegram user and must not be reused across bots.
    /// </param>
    /// <param name="isColleague">
    /// Whether colleague pricing applies to this renewal. The value must come from the current credential profile
    /// after any enabled Gozargah-site colleague promotion check.
    /// </param>
    /// <param name="telegramUserId">
    /// Numeric Telegram id of the customer requesting the preview. It is used for ownership-aware panel lookup and
    /// audit metadata, not as an XUI inbound or client id.
    /// </param>
    /// <param name="client">
    /// Fresh panel client already authorized by an exact target lock or legacy ownership. Callers must stop the flow instead of
    /// passing null when the target no longer matches.
    /// </param>
    /// <returns>
    /// HTML-safe Persian preview text showing exact traffic addition/replacement, duration addition, reset behavior,
    /// authoritative price components, and total price.
    /// </returns>
    /// <remarks>
    /// The method is read-only and performs no panel request. Unlimited previews follow <see cref="XuiV3RenewalPolicy"/>: active accounts show the
    /// exact selected traffic added to the existing quota, while expired accounts show traffic replacement after reset.
    /// Metered price details are formatted from the resolver's stored breakdown, so the displayed rates and subtotals
    /// cannot drift from the amount later debited from the selected owned-bot wallet.
    /// </remarks>
    private string BuildRenewSummary(
        User user,
        bool isColleague,
        long telegramUserId,
        XuiV3Client client)
    {
        var service = FindService(user.SelectedCountry);
        var selection = service.IsUnlimited
            ? new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = user.Type }
            : new XuiV3PurchaseSelection
            {
                ServiceKey = service.Key,
                TrafficGb = int.TryParse(user.TotoalGB, out var trafficGb) ? trafficGb : 0,
                DurationKey = user.SelectedPeriod
            };

        var resolved = _purchaseService.ResolveOwnedPurchase(selection, isColleague);
        var durationText = resolved.DurationDays <= 0 ? "نامحدود / لایف‌تایم" : $"{resolved.DurationDays} روز";
        var hasExactTargetLock = !string.IsNullOrWhiteSpace(user.RenewTargetUuid);
        var renewal = XuiV3RenewalPolicy.Calculate(
            client,
            resolved,
            "renew-summary",
            telegramUserId,
            allowActorAsOwnerFallback: !hasExactTargetLock);
        var usedBytes = renewal.UsedBytes;

        var totalAfterRenewBytes = renewal?.TotalBytesAfterRenew ?? 0;
        var trafficLine = renewal == null
            ? resolved.IsUnlimited
                ? $"📦 حجم پلن تمدید: <code>{Html(XuiV3PurchaseService.FormatTrafficSize(resolved.TrafficBytes, resolved.TrafficGb))}</code>"
                : $"📦 حجم اضافه: <code>{resolved.TrafficGb} GB</code>"
            : renewal.IsUnlimited
                ? renewal.ShouldResetTraffic
                    ? $"📦 حجم جدید بعد از ریست مصرف: <code>{Html(FormatGb(renewal.RenewedTrafficBytes))}</code>"
                    : $"📦 حجم اضافه: <code>{Html(FormatGb(renewal.RenewedTrafficBytes))}</code>\n📦 حجم کل بعد از تمدید: <code>{Html(FormatGb(renewal.TotalBytesAfterRenew))}</code>"
                : renewal.ShouldResetTraffic
                ? $"📦 حجم جدید بعد از ریست مصرف: <code>{Html(FormatGb(renewal.TargetAvailableTrafficBytes))}</code>"
                : $"📦 حجم کلی بعد از تمدید: <code>{Html(FormatGb(totalAfterRenewBytes))}</code>";

        var text = new StringBuilder();
        text.AppendLine("✅ وضعیت تمدید");
        text.AppendLine();
        text.AppendLine($"👤 اکانت: <code>{Html(user.ConfigLink)}</code>");
        text.AppendLine($"🧩 سرویس: <code>{Html(resolved.Service.DisplayName)}</code>");
        text.AppendLine(resolved.IsUnlimited
            ? $"📦 حجم پلن تمدید: <code>{Html(XuiV3PurchaseService.FormatTrafficSize(resolved.TrafficBytes, resolved.TrafficGb))}</code>"
            : $"📦 حجم اضافه: <code>{resolved.TrafficGb} GB</code>");
        text.AppendLine(trafficLine);
        text.AppendLine($"🔋 مصرف شده تا کنون: <code>{Html(FormatGb(usedBytes, zeroAsUnknown: false))}</code>");
        if (renewal?.ShouldResetTraffic == true)
            text.AppendLine("🔄 اکانت منقضی شده است؛ مصرف قبلی ریست می‌شود و حجم تمدید جایگزین حجم قبلی خواهد شد.");
        text.AppendLine($"⏳ زمان اضافه: <code>{Html(durationText)}</code>");
        var priceBreakdownText = XuiV3PurchaseService.BuildMeteredPriceBreakdownText(resolved);
        if (!string.IsNullOrWhiteSpace(priceBreakdownText))
        {
            text.AppendLine();
            text.AppendLine(priceBreakdownText);
        }
        text.AppendLine($"💰 قیمت: <code>{Html(resolved.PriceToman.FormatCurrency())}</code>");
        return text.ToString();
    }

    /// <summary>
    /// Matches an owned-bot renewal reply against an enabled preset or allowed custom-day duration.
    /// </summary>
    /// <param name="service">Current global metered service containing the allowed duration keys and labels.</param>
    /// <param name="text">
    /// Telegram message text entered by the customer. It may contain a bracketed key, raw key, display label, or a
    /// digit-only Latin, Persian, or Arabic-Indic custom day count.
    /// </param>
    /// <returns>
    /// The enabled configured or detached custom duration that matches the message, or <c>null</c> when the value is
    /// unknown, outside the custom range, or disabled by the current catalog policy.
    /// </returns>
    /// <remarks>This method has no persistence, wallet, Telegram-send, or XUI side effects.</remarks>
    private static XuiV3DurationOption TryGetDurationFromText(XuiV3ServiceDefinition service, string text)
    {
        return XuiV3PurchaseService.TryResolveDurationInput(service, text, out var duration)
            ? duration
            : null;
    }

    /// <summary>
    /// Matches owned-bot reply text to an unlimited plan that remains available to the current buyer role.
    /// </summary>
    /// <param name="service">Current enabled unlimited service definition.</param>
    /// <param name="text">
    /// Telegram reply text containing a bracketed plan key, raw key, or exact display name. Null values do not match.
    /// </param>
    /// <param name="isColleague">Current owned-bot buyer role used for the centralized audience check.</param>
    /// <returns>The matching authorized plan, or <c>null</c> for unknown, disabled, or role-forbidden text.</returns>
    /// <remarks>
    /// The comparison is case-insensitive for stable keys and display text. It performs no state or financial mutation.
    /// </remarks>
    /// <example>
    /// <code>
    /// var plan = TryGetUnlimitedPlanFromText(service, message.Text, credUser.IsColleague);
    /// </code>
    /// </example>
    private static XuiV3UnlimitedPlan TryGetUnlimitedPlanFromText(
        XuiV3ServiceDefinition service,
        string text,
        bool isColleague)
    {
        var key = ExtractBracketValue(text);
        return XuiV3PurchaseService.GetUnlimitedPlansForOwnedBot(service, isColleague).FirstOrDefault(plan =>
            (string.Equals(plan.Key, key, StringComparison.OrdinalIgnoreCase) ||
             string.Equals(plan.Key, text?.Trim(), StringComparison.OrdinalIgnoreCase) ||
             string.Equals(plan.DisplayName, text?.Trim(), StringComparison.OrdinalIgnoreCase)));
    }

    private static bool TryGetIntFromText(string text, out int value)
    {
        value = 0;
        var normalized = NormalizeDigits(text);
        var digits = new string((normalized ?? string.Empty).Where(char.IsDigit).ToArray());
        return !string.IsNullOrWhiteSpace(digits) && int.TryParse(digits, out value);
    }

    private static bool TryParseAccountCounterLookup(string text, out int accountCounter)
    {
        accountCounter = 0;
        var normalized = NormalizeDigits(text ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(normalized))
            return false;

        normalized = normalized
            .Replace("\u064a", "\u06cc")
            .Replace("\u0643", "\u06a9");

        var match = System.Text.RegularExpressions.Regex.Match(
            normalized,
            @"^(?:/account_|اکانت\s*)?(?<counter>\d+)$",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase |
            System.Text.RegularExpressions.RegexOptions.CultureInvariant);

        return match.Success && int.TryParse(match.Groups["counter"].Value, out accountCounter) && accountCounter > 0;
    }

    private static bool TryGetTrafficGbFromText(string text, out int value)
    {
        value = 0;
        var normalized = NormalizeDigits(text)?.Trim();
        if (string.IsNullOrWhiteSpace(normalized))
            return false;

        var match = System.Text.RegularExpressions.Regex.Match(
            normalized,
            @"^\s*(?<value>\d+)\s*(?<unit>.*)?$",
            System.Text.RegularExpressions.RegexOptions.CultureInvariant);

        if (!match.Success || !int.TryParse(match.Groups["value"].Value, out value))
            return false;

        var unit = (match.Groups["unit"].Value ?? string.Empty)
            .Trim()
            .Replace(" ", string.Empty)
            .Replace("\u064a", "\u06cc")
            .Replace("\u0643", "\u06a9");

        return string.IsNullOrWhiteSpace(unit) ||
               unit.Equals("gb", StringComparison.OrdinalIgnoreCase) ||
               unit.Equals("g", StringComparison.OrdinalIgnoreCase) ||
               unit.Contains("\u06af\u06cc\u06af", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsCancel(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return false;

        var value = text.Trim();
        return value.Equals("انصراف", StringComparison.OrdinalIgnoreCase) ||
               value.Equals("لغو", StringComparison.OrdinalIgnoreCase) ||
               value.Equals("منوی اصلی", StringComparison.OrdinalIgnoreCase) ||
               value.Equals("/start", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsSkipCommentText(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return false;

        var value = text.Trim();
        return value.Equals(SkipCommentText, StringComparison.OrdinalIgnoreCase) ||
               value.Equals("رد کردن", StringComparison.OrdinalIgnoreCase) ||
               value.Equals("بدون کامنت", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsBlankCommentInput(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return true;

        var value = text.Trim();
        return value.Equals(SkipCommentText, StringComparison.OrdinalIgnoreCase) ||
               value.Equals("بدون کامنت", StringComparison.OrdinalIgnoreCase);
    }

    private static XuiV3ClientMetadata TryReadMetadata(string comment)
    {
        if (string.IsNullOrWhiteSpace(comment))
            return null;

        try
        {
            return JsonConvert.DeserializeObject<XuiV3ClientMetadata>(comment);
        }
        catch
        {
            return null;
        }
    }

    private static string ExtractBracketValue(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return null;

        var start = text.LastIndexOf('[');
        var end = text.LastIndexOf(']');
        return start >= 0 && end > start
            ? text.Substring(start + 1, end - start - 1).Trim()
            : null;
    }

    private static string NormalizeDigits(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return text;

        var builder = new StringBuilder(text.Length);
        foreach (var ch in text)
        {
            var numericValue = char.GetNumericValue(ch);
            if (numericValue >= 0 && numericValue <= 9 && Math.Floor(numericValue) == numericValue)
                builder.Append((char)('0' + (int)numericValue));
            else
                builder.Append(ch);
        }

        return builder.ToString();
    }

    private static string NormalizeSearchText(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return string.Empty;

        return NormalizeDigits(text)
            .Trim()
            .Replace("\u064a", "\u06cc")
            .Replace("\u0643", "\u06a9")
            .ToLowerInvariant();
    }

    /// <summary>
    /// Extracts and canonicalizes a renewal UUID from raw text, VLESS text, or VMess base64 JSON.
    /// </summary>
    /// <param name="text">Untrusted Telegram input or panel UUID field; empty and malformed values are rejected.</param>
    /// <param name="uuid">Lowercase canonical UUID when extraction succeeds; otherwise an empty string.</param>
    /// <returns><c>true</c> only when <paramref name="text"/> contains a syntactically valid UUID.</returns>
    /// <remarks>
    /// This compatibility wrapper delegates to <see cref="XuiV3RenewalTargetParser"/> and performs no logging,
    /// persistence, authorization, panel call, or financial operation.
    /// </remarks>
    private static bool TryExtractUuidQuery(string text, out string uuid)
    {
        return XuiV3RenewalTargetParser.TryExtractUuid(text, out uuid);
    }

    private static bool TryExtractSubIdQuery(string text, out string subId)
    {
        subId = null;
        if (string.IsNullOrWhiteSpace(text))
            return false;

        var value = text.Trim();
        if (value.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase) ||
            value.StartsWith("vless://", StringComparison.OrdinalIgnoreCase))
            return false;

        if (Uri.TryCreate(value, UriKind.Absolute, out var uri) &&
            (uri.Scheme.Equals("http", StringComparison.OrdinalIgnoreCase) ||
             uri.Scheme.Equals("https", StringComparison.OrdinalIgnoreCase)))
        {
            var segments = uri.AbsolutePath
                .Split('/', StringSplitOptions.RemoveEmptyEntries)
                .Select(Uri.UnescapeDataString)
                .Where(segment => !string.IsNullOrWhiteSpace(segment))
                .ToList();

            if (segments.Count == 0)
                return false;

            subId = segments[^1].Trim();
            return !string.IsNullOrWhiteSpace(subId);
        }

        if (value.Contains(' ') || value.Contains('\n') || value.Contains('\r'))
            return false;

        subId = value.Trim().Trim('/');
        return !string.IsNullOrWhiteSpace(subId);
    }

    private static bool ClientUuidEquals(XuiV3Client client, string uuid)
    {
        return client != null &&
               !string.IsNullOrWhiteSpace(client.Uuid) &&
               string.Equals(client.Uuid.Trim(), uuid, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Normalizes an XUI client UUID to the canonical dashed GUID representation.
    /// </summary>
    /// <param name="value">Raw UUID read from trusted panel data or extracted from customer input.</param>
    /// <param name="uuid">Canonical lower-case dashed UUID when parsing succeeds; otherwise an empty string.</param>
    /// <returns><c>true</c> when <paramref name="value"/> is a valid non-empty GUID; otherwise <c>false</c>.</returns>
    /// <remarks>The method is side-effect free and must be used before persisting a renewal UUID target lock.</remarks>
    private static bool TryNormalizeClientUuid(string value, out string uuid)
    {
        uuid = string.Empty;
        if (!Guid.TryParse(value?.Trim(), out var parsed) || parsed == Guid.Empty)
            return false;

        uuid = parsed.ToString();
        return true;
    }

    /// <summary>
    /// Determines whether a saved direct-search query resolves to one exact callback-selected renewal client.
    /// </summary>
    /// <param name="query">Original bot-scoped email, SubId/subscription URL, UUID, or supported configuration.</param>
    /// <param name="client">Fresh panel client selected by the callback's numeric id.</param>
    /// <returns>
    /// <c>true</c> when the shared four-identifier resolver maps the query to this exact client; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This permission applies to renewal only. The method never grants configuration or management access and never
    /// logs or exposes the sensitive query. Numeric callback ids remain insufficient without matching saved search state.
    /// </remarks>
    private static bool SearchQueryAuthorizesExternalRenew(string query, XuiV3Client client)
    {
        if (client == null || string.IsNullOrWhiteSpace(query))
            return false;

        var resolution = XuiV3RenewalTargetResolver.Resolve(new[] { client }, query);
        return resolution.Success &&
               resolution.Client != null &&
               resolution.Client.Id == client.Id;
    }

    private static bool ClientSubIdEquals(XuiV3Client client, string subId)
    {
        if (client == null || string.IsNullOrWhiteSpace(subId))
            return false;

        var normalized = subId.Trim().Trim('/');
        return (!string.IsNullOrWhiteSpace(client.SubId) &&
                string.Equals(client.SubId.Trim(), normalized, StringComparison.OrdinalIgnoreCase)) ||
               (!string.IsNullOrWhiteSpace(client.Email) &&
                string.Equals(client.Email.Trim(), normalized, StringComparison.OrdinalIgnoreCase));
    }

    private static bool ClientMatchesSearchQuery(XuiV3Client client, string normalizedQuery)
    {
        if (client == null || string.IsNullOrWhiteSpace(normalizedQuery))
            return false;

        var email = NormalizeSearchText(client.Email);
        if (!string.IsNullOrWhiteSpace(email) && email.Contains(normalizedQuery, StringComparison.OrdinalIgnoreCase))
            return true;

        var metadata = TryReadMetadata(client.Comment);
        var userComment = NormalizeSearchText(metadata?.UserComment);
        return !string.IsNullOrWhiteSpace(userComment) &&
               userComment.Contains(normalizedQuery, StringComparison.OrdinalIgnoreCase);
    }

    private static async Task SendOrEditTextAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        string text,
        ParseMode? parseMode = null,
        InlineKeyboardMarkup replyMarkup = null,
        CancellationToken cancellationToken = default)
    {
        if (messageId != 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId: chatId,
                messageId: messageId,
                text: text,
                parseMode: parseMode,
                replyMarkup: replyMarkup,
                cancellationToken: cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: chatId,
            text: text,
            parseMode: parseMode ?? ParseMode.None,
            replyMarkup: replyMarkup,
            cancellationToken: cancellationToken);
    }

    private static async Task SafeEditMessageTextAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        string text,
        ParseMode? parseMode = null,
        InlineKeyboardMarkup replyMarkup = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await botClient.EditMessageText(
                chatId: chatId,
                messageId: messageId,
                text: text,
                parseMode: parseMode ?? ParseMode.None,
                replyMarkup: replyMarkup,
                cancellationToken: cancellationToken);
        }
        catch (ApiRequestException ex) when (
            ex.ErrorCode == 400 &&
            ex.Message.Contains("message is not modified", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"[XUIv3] Telegram edit ignored: message is not modified. messageId={messageId}");
        }
    }

    private async Task AnswerCallbackSafelyAsync(
        ITelegramBotClient botClient,
        string callbackQueryId,
        CancellationToken cancellationToken)
    {
        await TelegramCallbackAnswerPolicy.TryAnswerAsync(
            botClient,
            callbackQueryId,
            cancellationToken: cancellationToken,
            logger: _logger,
            botId: BotContextAccessor.CurrentBotId,
            timeout: _interactionTimeouts.CallbackAnswer);
    }

    private static string GenerateReplacementAccountEmail(IReadOnlyCollection<XuiV3Client> clients, string oldEmail)
    {
        var suffix = ExtractAccountCounterSuffix(oldEmail);
        var existingEmails = (clients ?? Array.Empty<XuiV3Client>())
            .Select(client => client.Email)
            .Where(email => !string.IsNullOrWhiteSpace(email))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        for (var attempt = 0; attempt < 50; attempt++)
        {
            var candidate = AccountGenerator.GenerateRandomAccountName() + suffix;
            if (!existingEmails.Contains(candidate))
                return candidate;
        }

        return AccountGenerator.GenerateRandomAccountName() + suffix;
    }

    private static string ExtractAccountCounterSuffix(string email)
    {
        var match = System.Text.RegularExpressions.Regex.Match(
            email ?? string.Empty,
            @"_(?<counter>\d+)$",
            System.Text.RegularExpressions.RegexOptions.CultureInvariant);

        return match.Success ? "_" + match.Groups["counter"].Value : string.Empty;
    }

    private async Task<string> GenerateReplacementUuidAsync(ServerInfo serverInfo, CancellationToken cancellationToken)
    {
        try
        {
            var uuidResponse = await ApiServicev3.GetNewUuidAsync(serverInfo, _configuration, cancellationToken);
            var token = uuidResponse.Obj;
            var candidate = token?.Type == Newtonsoft.Json.Linq.JTokenType.String
                ? token.ToObject<string>()
                : token?["uuid"]?.ToString()
                  ?? token?["id"]?.ToString()
                  ?? token?.ToString();

            if (uuidResponse.Success && Guid.TryParse(candidate, out var parsed))
                return parsed.ToString();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] get new uuid failed, fallback to local guid: {ex.Message}");
        }

        return Guid.NewGuid().ToString();
    }

    /// <summary>
    /// Captures an immutable, live panel snapshot required before an account identity can be changed safely.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel that owns the selected client.</param>
    /// <param name="listClient">
    /// Client selected from the live <c>clients/list</c> response after ownership validation. Metadata-only inbound
    /// information is intentionally ignored.
    /// </param>
    /// <param name="cancellationToken">Token that cancels direct client and traffic reads from XUI.</param>
    /// <returns>
    /// A capture result containing the immutable snapshot, or an error message with a null snapshot when live inbound
    /// ids or traffic counters cannot be established. Callers must not mutate the account when the snapshot is null.
    /// </returns>
    /// <remarks>
    /// The list and direct-client responses are merged because 3x-ui versions can omit different fields from either
    /// endpoint. At least one live inbound id and a real traffic object are mandatory; comment metadata is never used
    /// as a fallback for those safety-critical values.
    /// </remarks>
    private async Task<XuiV3LinkChangeSnapshotCaptureResult> CaptureChangeLinkSnapshotAsync(
        ServerInfo serverInfo,
        XuiV3Client listClient,
        CancellationToken cancellationToken)
    {
        XuiV3LinkChangeLiveStateResult liveState;
        try
        {
            liveState = await ReadLiveChangeLinkStateAsync(
                serverInfo,
                listClient?.Email,
                listClient,
                requireInboundIds: true,
                requireTraffic: true,
                cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "XUI link-change snapshot read failed before mutation. clientId={ClientId}, email={Email}",
                listClient?.Id,
                listClient?.Email);
            return XuiV3LinkChangeSnapshotCaptureResult.Failed(ex.Message);
        }
        if (liveState.State == null)
            return XuiV3LinkChangeSnapshotCaptureResult.Failed(liveState.ErrorMessage);
        if (!liveState.State.InboundIdsObserved || liveState.State.InboundIds.Count == 0)
            return XuiV3LinkChangeSnapshotCaptureResult.Failed("No authoritative attached inbound ids were captured before mutation.");
        if (!liveState.State.TrafficObserved || liveState.State.Traffic == null)
            return XuiV3LinkChangeSnapshotCaptureResult.Failed("No authoritative traffic counters were captured before mutation.");

        return XuiV3LinkChangeSnapshotCaptureResult.Captured(new XuiV3LinkChangeSnapshot
        {
            ClientId = liveState.State.Client.Id,
            Client = CloneChangeLinkClient(liveState.State.Client),
            InboundIds = liveState.State.InboundIds.ToList(),
            Up = liveState.State.Traffic.Up,
            Down = liveState.State.Traffic.Down
        });
    }

    /// <summary>
    /// Observes whether an ambiguous XUI update committed the requested account identity without collapsing read
    /// failures into a false not-found result.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel on which the update was attempted.</param>
    /// <param name="newEmail">New email used as the identity lookup key after the uncertain update response.</param>
    /// <param name="expectedClientId">Original numeric XUI client id that must still identify the renamed account.</param>
    /// <param name="cancellationToken">Token that cancels the recovery read without changing panel state.</param>
    /// <returns>
    /// <see cref="XuiV3LinkChangeObservationStatus.Observed"/> when the email resolves to the same numeric client id,
    /// <see cref="XuiV3LinkChangeObservationStatus.NotFound"/> after authoritative absence, or
    /// <see cref="XuiV3LinkChangeObservationStatus.Unknown"/> after timeout, TLS, HTTP 520, or incomplete data.
    /// </returns>
    /// <remarks>
    /// XUI can commit an update before a TLS or timeout failure reaches the bot. This read-only probe prevents such
    /// an account from bypassing the mandatory inbound and traffic reconciliation. It never retries the identity
    /// mutation and therefore cannot create a duplicate rename.
    /// </remarks>
    private async Task<XuiV3LinkChangeObservationStatus> ObserveChangedLinkIdentityAsync(
        ServerInfo serverInfo,
        string newEmail,
        int expectedClientId,
        CancellationToken cancellationToken)
    {
        try
        {
            var liveResult = await ReadLiveChangeLinkStateAsync(
                serverInfo,
                newEmail,
                knownListClient: null,
                requireInboundIds: false,
                requireTraffic: false,
                cancellationToken);
            if (liveResult.ObservationStatus != XuiV3LinkChangeObservationStatus.Observed)
                return liveResult.ObservationStatus;
            return liveResult.State?.Client?.Id == expectedClientId
                ? XuiV3LinkChangeObservationStatus.Observed
                : XuiV3LinkChangeObservationStatus.NotFound;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "XUI link-change ambiguous update probe failed. clientId={ClientId}, newEmail={NewEmail}",
                expectedClientId,
                newEmail);
            return XuiV3LinkChangeObservationStatus.Unknown;
        }
    }

    /// <summary>
    /// Reads and merges current client, inbound, and traffic state from live XUI endpoints.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor.</param>
    /// <param name="email">Current XUI client email used by direct client and traffic endpoints.</param>
    /// <param name="knownListClient">
    /// Optional client already obtained from the same operation's live list response. Pass null after identity update
    /// so this method refreshes the list by the new email.
    /// </param>
    /// <param name="requireInboundIds">Whether an empty live inbound set must make the read fail.</param>
    /// <param name="requireTraffic">Whether absence of a live traffic object must make the read fail.</param>
    /// <param name="cancellationToken">Token that cancels XUI list, direct-client, and traffic requests.</param>
    /// <returns>
    /// A live-state result. Its client is a detached canonical merge and may have an empty inbound list or null traffic
    /// only when the corresponding requirement parameter is false.
    /// </returns>
    /// <remarks>
    /// This method never reads inbound ids from the JSON comment. It is used both for the pre-change fail-closed
    /// snapshot and post-change repair reads where an empty set is precisely the condition that must be repaired.
    /// </remarks>
    private async Task<XuiV3LinkChangeLiveStateResult> ReadLiveChangeLinkStateAsync(
        ServerInfo serverInfo,
        string email,
        XuiV3Client knownListClient,
        bool requireInboundIds,
        bool requireTraffic,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(email))
            return XuiV3LinkChangeLiveStateResult.NotFound("Client email is missing.");

        XuiV3Client listClient = knownListClient;
        var listObserved = knownListClient != null;
        var directObserved = false;
        var hadUnknownRead = false;
        if (listClient == null || !string.Equals(listClient.Email, email, StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                var listResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
                listObserved = listResponse.Success;
                if (listResponse.Success)
                {
                    listClient = listResponse.Obj?.FirstOrDefault(item =>
                        string.Equals(item.Email?.Trim(), email.Trim(), StringComparison.OrdinalIgnoreCase));
                }
            }
            catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
            {
                hadUnknownRead = true;
                _logger.LogWarning(ex, "XUI link-change list observation is unknown. email={Email}", email);
            }
        }

        XuiV3Client directClient = null;
        try
        {
            var directResponse = await ApiServicev3.GetClientAsync(serverInfo, _configuration, email, cancellationToken);
            directObserved = directResponse.Success;
            if (directResponse.Success)
                directClient = directResponse.Obj;
        }
        catch (XuiV3ApiException ex) when (ex.StatusCode == 404)
        {
            directObserved = true;
        }
        catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
        {
            hadUnknownRead = true;
            _logger.LogWarning(ex, "XUI link-change direct observation is unknown. email={Email}", email);
        }

        if (directClient == null && listClient != null)
        {
            return XuiV3LinkChangeLiveStateResult.Unknown(
                "The direct client endpoint did not return the stable client fields required for verification.");
        }

        if (listClient == null && directClient == null)
        {
            if (hadUnknownRead || (!listObserved && !directObserved))
                return XuiV3LinkChangeLiveStateResult.Unknown("Panel reads could not establish whether the client exists.");
            return XuiV3LinkChangeLiveStateResult.NotFound("Client was not found by authoritative panel reads.");
        }

        var inboundIds = (listClient?.InboundIds ?? Enumerable.Empty<int>())
            .Concat(directClient?.InboundIds ?? Enumerable.Empty<int>())
            .Where(id => id > 0)
            .Distinct()
            .OrderBy(id => id)
            .ToList();
        var inboundObservationSucceeded = listObserved && listClient != null;
        if (requireInboundIds && !inboundObservationSucceeded)
            return XuiV3LinkChangeLiveStateResult.Unknown("Attached inbound membership was not authoritatively observed.");

        XuiV3ClientTraffic traffic = null;
        var trafficObserved = false;
        try
        {
            var trafficResponse = await ApiServicev3.GetClientTrafficAsync(serverInfo, _configuration, email, cancellationToken);
            if (trafficResponse.Success && trafficResponse.Obj != null)
            {
                traffic = CloneClientTraffic(trafficResponse.Obj);
                trafficObserved = true;
            }
        }
        catch (XuiV3ApiException ex) when (ex.StatusCode == 404)
        {
            // Some 3x-ui builds omit the dedicated traffic row while embedding the same authoritative counters in
            // the full client list. The fallback below is safe because the list response was read in this operation.
        }
        catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
        {
            hadUnknownRead = true;
            _logger.LogWarning(ex, "XUI link-change traffic observation is unknown. email={Email}", email);
        }

        if (traffic == null && listClient?.Traffic != null)
        {
            traffic = CloneClientTraffic(listClient.Traffic);
            trafficObserved = true;
        }
        else if (traffic == null && directClient?.Traffic != null)
        {
            traffic = CloneClientTraffic(directClient.Traffic);
            trafficObserved = true;
        }

        if (requireTraffic && !trafficObserved)
            return XuiV3LinkChangeLiveStateResult.Unknown("Traffic counters were not authoritatively observed.");

        var canonicalClient = BuildCanonicalChangeLinkClient(listClient, directClient, inboundIds, traffic);
        return XuiV3LinkChangeLiveStateResult.Loaded(new XuiV3LinkChangeLiveState
        {
            Client = canonicalClient,
            InboundIds = inboundIds,
            Traffic = traffic,
            InboundIdsObserved = inboundObservationSucceeded,
            TrafficObserved = trafficObserved
        });
    }

    /// <summary>
    /// Reconciles every preserved field after XUI accepts a new email, subId, and UUID, then performs a final read-back.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel that contains the renamed client.</param>
    /// <param name="snapshot">Immutable pre-change snapshot containing expected fields, inbounds, and traffic.</param>
    /// <param name="expectedPayload">Replacement payload with the new identity and all preserved snapshot fields.</param>
    /// <param name="newEmail">New XUI email used for all post-change endpoints.</param>
    /// <param name="operationKey">Random non-secret durable operation key used to correlate recovery and cleanup logs.</param>
    /// <param name="cancellationToken">Token that cancels repair and verification API calls.</param>
    /// <returns>
    /// Success with the final verified client, inbound ids, and traffic; otherwise a stage-specific failure that keeps
    /// the new identity in place and gives the caller enough non-secret context for critical logging.
    /// </returns>
    /// <remarks>
    /// One corrective client update is allowed before inbound repair. Missing inbounds are attached and unexpected
    /// inbounds are detached. Traffic is restored only when a counter decreased, using the greater of current and
    /// snapshot values so legitimate traffic accrued during the operation is never reduced.
    /// </remarks>
    private async Task<XuiV3LinkChangePreservationResult> ReconcileChangedLinkStateAsync(
        ServerInfo serverInfo,
        XuiV3LinkChangeSnapshot snapshot,
        XuiV3ClientPayload expectedPayload,
        string newEmail,
        string operationKey,
        CancellationToken cancellationToken)
    {
        var stateResult = await ReadLiveChangeLinkStateAsync(
            serverInfo,
            newEmail,
            knownListClient: null,
            requireInboundIds: false,
            requireTraffic: false,
            cancellationToken);
        if (stateResult.State == null)
            return XuiV3LinkChangePreservationResult.Failed(
                "post-update-read",
                stateResult.ErrorMessage,
                observationStatus: stateResult.ObservationStatus);

        var state = stateResult.State;
        var differences = GetPreservedChangeLinkDifferences(state.Client, snapshot.ClientId, expectedPayload);
        if (differences.HasCriticalDifferences)
        {
            XuiV3ApiResponse<Newtonsoft.Json.Linq.JToken> correctiveResponse;
            try
            {
                correctiveResponse = await ApiServicev3.UpdateClientAsync(
                    serverInfo,
                    _configuration,
                    newEmail,
                    expectedPayload,
                    cancellationToken,
                    XuiV3RequestRetryMode.NoAutomaticRetry);
            }
            catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
            {
                return XuiV3LinkChangePreservationResult.Failed(
                    "corrective-update-unknown",
                    "Corrective update response was interrupted.",
                    state,
                    XuiV3LinkChangeObservationStatus.Unknown,
                    differences.Differences);
            }
            if (!correctiveResponse.Success)
            {
                return XuiV3LinkChangePreservationResult.Failed(
                    "corrective-update",
                    correctiveResponse.Msg,
                    state,
                    differences: differences.Differences);
            }

            stateResult = await ReadLiveChangeLinkStateAsync(
                serverInfo,
                newEmail,
                knownListClient: null,
                requireInboundIds: false,
                requireTraffic: false,
                cancellationToken);
            if (stateResult.State == null)
                return XuiV3LinkChangePreservationResult.Failed(
                    "corrective-read",
                    stateResult.ErrorMessage,
                    observationStatus: stateResult.ObservationStatus,
                    differences: differences.Differences);
            state = stateResult.State;
            differences = GetPreservedChangeLinkDifferences(state.Client, snapshot.ClientId, expectedPayload);
        }

        var expectedInboundIds = snapshot.InboundIds.OrderBy(id => id).ToList();
        if (!state.InboundIdsObserved)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "inbounds-unknown",
                "Attached inbound membership was not authoritatively observed.",
                state,
                XuiV3LinkChangeObservationStatus.Unknown,
                differences.Differences);
        }

        var missingInboundIds = expectedInboundIds.Except(state.InboundIds).ToList();
        if (missingInboundIds.Count > 0)
        {
            XuiV3ApiResponse<Newtonsoft.Json.Linq.JToken> attachResponse;
            try
            {
                attachResponse = await ApiServicev3.AttachClientAsync(
                    serverInfo,
                    _configuration,
                    newEmail,
                    missingInboundIds,
                    cancellationToken,
                    XuiV3RequestRetryMode.NoAutomaticRetry);
            }
            catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
            {
                return XuiV3LinkChangePreservationResult.Failed(
                    "attach-inbounds-unknown",
                    "Attach response was interrupted and requires read-back.",
                    state,
                    XuiV3LinkChangeObservationStatus.Unknown,
                    differences.Differences);
            }
            if (!attachResponse.Success)
                return XuiV3LinkChangePreservationResult.Failed("attach-inbounds", attachResponse.Msg, state);
        }

        var unexpectedInboundIds = state.InboundIds.Except(expectedInboundIds).ToList();
        if (unexpectedInboundIds.Count > 0)
        {
            XuiV3ApiResponse<Newtonsoft.Json.Linq.JToken> detachResponse;
            try
            {
                detachResponse = await ApiServicev3.DetachClientAsync(
                    serverInfo,
                    _configuration,
                    newEmail,
                    unexpectedInboundIds,
                    cancellationToken,
                    XuiV3RequestRetryMode.NoAutomaticRetry);
            }
            catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
            {
                return XuiV3LinkChangePreservationResult.Failed(
                    "detach-inbounds-unknown",
                    "Detach response was interrupted and requires read-back.",
                    state,
                    XuiV3LinkChangeObservationStatus.Unknown,
                    differences.Differences);
            }
            if (!detachResponse.Success)
                return XuiV3LinkChangePreservationResult.Failed("detach-inbounds", detachResponse.Msg, state);
        }

        stateResult = await ReadLiveChangeLinkStateAsync(
            serverInfo,
            newEmail,
            knownListClient: null,
            requireInboundIds: true,
            requireTraffic: true,
            cancellationToken);
        if (stateResult.State == null)
            return XuiV3LinkChangePreservationResult.Failed(
                "post-inbound-read",
                stateResult.ErrorMessage,
                observationStatus: stateResult.ObservationStatus,
                differences: differences.Differences);
        state = stateResult.State;

        if (state.Traffic.Up < snapshot.Up || state.Traffic.Down < snapshot.Down)
        {
            var preservedUp = Math.Max(state.Traffic.Up, snapshot.Up);
            var preservedDown = Math.Max(state.Traffic.Down, snapshot.Down);
            XuiV3ApiResponse<Newtonsoft.Json.Linq.JToken> trafficResponse;
            try
            {
                trafficResponse = await ApiServicev3.UpdateClientTrafficAsync(
                    serverInfo,
                    _configuration,
                    newEmail,
                    preservedUp,
                    preservedDown,
                    cancellationToken,
                    XuiV3RequestRetryMode.NoAutomaticRetry);
            }
            catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
            {
                return XuiV3LinkChangePreservationResult.Failed(
                    "restore-traffic-unknown",
                    "Traffic update response was interrupted and requires read-back.",
                    state,
                    XuiV3LinkChangeObservationStatus.Unknown,
                    differences.Differences);
            }
            if (!trafficResponse.Success)
                return XuiV3LinkChangePreservationResult.Failed("restore-traffic", trafficResponse.Msg, state);
        }

        var finalResult = await ReadLiveChangeLinkStateAsync(
            serverInfo,
            newEmail,
            knownListClient: null,
            requireInboundIds: true,
            requireTraffic: true,
            cancellationToken);
        if (finalResult.State == null)
            return XuiV3LinkChangePreservationResult.Failed(
                "final-read",
                finalResult.ErrorMessage,
                state,
                finalResult.ObservationStatus,
                differences.Differences);

        var finalState = finalResult.State;
        differences = GetPreservedChangeLinkDifferences(finalState.Client, snapshot.ClientId, expectedPayload);
        if (differences.HasCriticalDifferences)
            return XuiV3LinkChangePreservationResult.Failed(
                "final-fields",
                "Critical preserved client fields differ after correction.",
                finalState,
                differences: differences.Differences);
        if (!finalState.InboundIds.SequenceEqual(expectedInboundIds))
            return XuiV3LinkChangePreservationResult.Failed("final-inbounds", "Attached inbound ids differ from the pre-change snapshot.", finalState);
        if (finalState.Traffic.Up < snapshot.Up || finalState.Traffic.Down < snapshot.Down)
            return XuiV3LinkChangePreservationResult.Failed("final-traffic", "Traffic counters are lower than the pre-change snapshot.", finalState);

        var orphanCleanupFailure = await VerifyAndDeleteDetachedOldIdentityAsync(
            serverInfo,
            snapshot,
            newEmail,
            finalState,
            operationKey,
            cancellationToken);
        if (orphanCleanupFailure != null)
            return orphanCleanupFailure;

        return XuiV3LinkChangePreservationResult.Verified(finalState);
    }

    /// <summary>
    /// Removes the detached old-email record that 3x-ui 3.4.x can recreate while a global client identity is renamed.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel that owns both the saved old and new identities.</param>
    /// <param name="snapshot">
    /// Immutable pre-change snapshot containing the original email, UUID, numeric client id, inbound set, and traffic.
    /// </param>
    /// <param name="newEmail">Persisted replacement email that has already passed full field, inbound, and traffic verification.</param>
    /// <param name="verifiedNewState">
    /// Fully observed post-change state. Its numeric client id must still equal the snapshot id before any old record is removed.
    /// </param>
    /// <param name="operationKey">Random non-secret durable operation key used to correlate cleanup diagnostics.</param>
    /// <param name="cancellationToken">Token that cancels panel reads and the guarded orphan deletion.</param>
    /// <returns>
    /// Null when the old identity is absent or its proven detached orphan was deleted; otherwise a stage-specific failure
    /// that leaves the old record untouched and keeps the durable operation eligible for recovery or manual review.
    /// </returns>
    /// <remarks>
    /// 3x-ui updates the global ClientRecord email before rewriting every inbound. During that multi-step update, an
    /// inbound synchronization can recreate the old email as a new numeric ClientRecord with no attachments. Cleanup is
    /// intentionally fail-closed: it runs only after the new identity is completely verified, and only when the old row
    /// has a different numeric id, the original UUID, and an authoritatively empty inbound set. Traffic is preserved.
    /// A timeout never triggers a second blind delete; the old email is read back first.
    /// </remarks>
    /// <example>
    /// <code>
    /// var failure = await VerifyAndDeleteDetachedOldIdentityAsync(
    ///     serverInfo,
    ///     snapshot,
    ///     newEmail,
    ///     verifiedState,
    ///     operationKey,
    ///     cancellationToken);
    /// if (failure != null)
    ///     return failure;
    /// </code>
    /// </example>
    private async Task<XuiV3LinkChangePreservationResult> VerifyAndDeleteDetachedOldIdentityAsync(
        ServerInfo serverInfo,
        XuiV3LinkChangeSnapshot snapshot,
        string newEmail,
        XuiV3LinkChangeLiveState verifiedNewState,
        string operationKey,
        CancellationToken cancellationToken)
    {
        var oldEmail = snapshot?.Client?.Email?.Trim();
        if (string.IsNullOrWhiteSpace(oldEmail) ||
            string.Equals(oldEmail, newEmail?.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        if (verifiedNewState?.Client == null || verifiedNewState.Client.Id != snapshot.ClientId)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-new-identity",
                "The verified replacement no longer matches the original numeric client id.",
                verifiedNewState);
        }

        var oldIdentityResult = await ReadLiveChangeLinkStateAsync(
            serverInfo,
            oldEmail,
            knownListClient: null,
            requireInboundIds: true,
            requireTraffic: false,
            cancellationToken);
        if (oldIdentityResult.ObservationStatus == XuiV3LinkChangeObservationStatus.NotFound)
            return null;
        if (oldIdentityResult.State == null)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-read-unknown",
                oldIdentityResult.ErrorMessage,
                verifiedNewState,
                oldIdentityResult.ObservationStatus);
        }

        var oldState = oldIdentityResult.State;
        if (oldState.Client.Id == snapshot.ClientId)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-id-conflict",
                "Both old and new emails resolve to the original numeric client id.",
                verifiedNewState);
        }

        if (!ChangeLinkTextEquals(snapshot.Client.Uuid, oldState.Client.Uuid))
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-ownership",
                "The detached old email no longer has the original UUID and was not deleted.",
                verifiedNewState);
        }

        if (!oldState.InboundIdsObserved)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-inbounds-unknown",
                "The old email inbound membership could not be verified.",
                verifiedNewState,
                XuiV3LinkChangeObservationStatus.Unknown);
        }

        if (oldState.InboundIds.Count > 0)
        {
            return XuiV3LinkChangePreservationResult.Failed(
                "orphan-cleanup-still-attached",
                "The old email is still attached to one or more inbounds and was not deleted.",
                verifiedNewState);
        }

        try
        {
            // The replacement has already been verified. Deleting only the distinct detached row with keepTraffic=1
            // prevents the panel's rename-side orphan from appearing as a second account without risking usage data.
            await ApiServicev3.DeleteClientPreservingTrafficAsync(
                serverInfo,
                _configuration,
                oldEmail,
                cancellationToken,
                XuiV3RequestRetryMode.NoAutomaticRetry);
        }
        catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
        {
            _logger.LogWarning(
                ex,
                "XUI link-change orphan cleanup response was ambiguous; read-back will decide the result. operationKey={OperationKey}, oldEmail={OldEmail}, oldClientId={OldClientId}, newEmail={NewEmail}, newClientId={NewClientId}",
                operationKey,
                oldEmail,
                oldState.Client.Id,
                newEmail,
                verifiedNewState.Client.Id);
        }

        var cleanupReadBack = await ReadLiveChangeLinkStateAsync(
            serverInfo,
            oldEmail,
            knownListClient: null,
            requireInboundIds: false,
            requireTraffic: false,
            cancellationToken);
        if (cleanupReadBack.ObservationStatus == XuiV3LinkChangeObservationStatus.NotFound)
        {
            _logger.LogInformation(
                "XUI link-change detached old identity was removed safely. operationKey={OperationKey}, oldEmail={OldEmail}, oldClientId={OldClientId}, newEmail={NewEmail}, newClientId={NewClientId}",
                operationKey,
                oldEmail,
                oldState.Client.Id,
                newEmail,
                verifiedNewState.Client.Id);
            return null;
        }

        return XuiV3LinkChangePreservationResult.Failed(
            cleanupReadBack.State == null ? "orphan-cleanup-result-unknown" : "orphan-cleanup-not-applied",
            cleanupReadBack.State == null
                ? cleanupReadBack.ErrorMessage
                : "The detached old client record still exists after cleanup.",
            verifiedNewState,
            cleanupReadBack.State == null
                ? cleanupReadBack.ObservationStatus
                : XuiV3LinkChangeObservationStatus.Observed);
    }

    /// <summary>
    /// Builds a canonical detached client from list and direct XUI responses without using comment metadata for live state.
    /// </summary>
    /// <param name="listClient">Client returned by the live list endpoint, or null.</param>
    /// <param name="directClient">Client returned by the direct email endpoint, or null.</param>
    /// <param name="inboundIds">Union of positive inbound ids returned by live XUI endpoints.</param>
    /// <param name="traffic">Traffic counters returned by the traffic/list/direct endpoint, or null during repair reads.</param>
    /// <returns>A detached client containing the richest available panel fields and cloned mutable JSON values.</returns>
    private static XuiV3Client BuildCanonicalChangeLinkClient(
        XuiV3Client listClient,
        XuiV3Client directClient,
        IReadOnlyCollection<int> inboundIds,
        XuiV3ClientTraffic traffic)
    {
        // The direct endpoint is the authoritative source for stable client fields. The list endpoint primarily
        // supplies inbound membership and traffic and may deserialize omitted scalar fields to misleading defaults.
        var primary = directClient ?? listClient;
        var secondary = ReferenceEquals(primary, directClient) ? listClient : directClient;
        var primaryTotal = GetTotalBytes(primary);
        var secondaryTotal = GetTotalBytes(secondary);
        var primaryExpiry = GetExpiryTime(primary);
        var secondaryExpiry = GetExpiryTime(secondary);
        var ownerTelegramUserId = GetClientOwnerTelegramId(primary);
        if (ownerTelegramUserId <= 0)
            ownerTelegramUserId = GetClientOwnerTelegramId(secondary);

        return new XuiV3Client
        {
            Id = primary?.Id > 0 ? primary.Id : secondary?.Id ?? 0,
            Email = FirstChangeLinkValue(primary?.Email, secondary?.Email),
            Uuid = FirstChangeLinkValue(primary?.Uuid, secondary?.Uuid),
            Password = FirstChangeLinkValue(primary?.Password, secondary?.Password),
            TotalGB = primaryTotal != 0 ? primaryTotal : secondaryTotal,
            ExpiryTime = primaryExpiry != 0 ? primaryExpiry : secondaryExpiry,
            TgId = ownerTelegramUserId,
            LimitIp = primary?.LimitIp ?? secondary?.LimitIp ?? 0,
            Enable = primary?.Enable ?? secondary?.Enable ?? true,
            SubId = FirstChangeLinkValue(primary?.SubId, secondary?.SubId, primary?.Email, secondary?.Email),
            Flow = FirstChangeLinkValue(primary?.Flow, secondary?.Flow),
            Comment = FirstChangeLinkValue(primary?.Comment, secondary?.Comment),
            Group = FirstChangeLinkValue(primary?.Group, secondary?.Group),
            Reverse = (primary?.Reverse ?? secondary?.Reverse)?.DeepClone(),
            Extra = MergeChangeLinkExtra(secondary?.Extra, primary?.Extra),
            InboundIds = inboundIds?.Where(id => id > 0).Distinct().OrderBy(id => id).ToList() ?? new List<int>(),
            Traffic = CloneClientTraffic(traffic)
        };
    }

    /// <summary>
    /// Compares the post-change client with the saved payload and reports field-level semantic differences.
    /// </summary>
    /// <param name="actualClient">Live post-change client read from XUI.</param>
    /// <param name="expectedClientId">Numeric XUI client id captured before the identity change.</param>
    /// <param name="expectedPayload">Payload containing the new identity and preserved snapshot values.</param>
    /// <returns>
    /// A structured report whose critical entries require correction or recovery. Empty and representation-only
    /// differences are normalized before entries are added.
    /// </returns>
    private static XuiV3LinkChangeDifferenceReport GetPreservedChangeLinkDifferences(
        XuiV3Client actualClient,
        int expectedClientId,
        XuiV3ClientPayload expectedPayload)
    {
        var report = new XuiV3LinkChangeDifferenceReport();
        if (actualClient == null || expectedPayload == null)
        {
            report.Add("client", "present", "missing", true);
            return report;
        }

        report.AddWhenDifferent("id", expectedClientId, actualClient.Id, true);
        report.AddTextWhenDifferent("email", expectedPayload.Email, actualClient.Email, true);
        report.AddTextWhenDifferent("uuid", expectedPayload.Uuid, actualClient.Uuid, true);
        report.AddTextWhenDifferent("password", expectedPayload.Password, actualClient.Password, true);
        report.AddWhenDifferent("totalGB", expectedPayload.TotalGB, GetTotalBytes(actualClient), true);
        report.AddWhenDifferent("expiryTime", expectedPayload.ExpiryTime, GetExpiryTime(actualClient), true);
        report.AddWhenDifferent("tgId", expectedPayload.TgId, GetClientOwnerTelegramId(actualClient), true);
        report.AddWhenDifferent("limitIp", expectedPayload.LimitIp, actualClient.LimitIp, true);
        report.AddWhenDifferent("enable", expectedPayload.Enable, actualClient.Enable, true);
        report.AddTextWhenDifferent("subId", expectedPayload.SubId, actualClient.SubId, true);
        report.AddTextWhenDifferent("flow", expectedPayload.Flow, actualClient.Flow, true);
        report.AddTextWhenDifferent("group", expectedPayload.Group, actualClient.Group, true);

        if (!ChangeLinkJsonTextEquals(expectedPayload.Comment, actualClient.Comment))
            report.Add("comment", "preserved-json", "different-json", true);
        if (!ChangeLinkTokenEquals(expectedPayload.Reverse, actualClient.Reverse))
            report.Add("reverse", CanonicalChangeLinkToken(expectedPayload.Reverse), CanonicalChangeLinkToken(actualClient.Reverse), true);

        foreach (var difference in GetChangeLinkExtraDifferences(expectedPayload.Extra, actualClient.Extra))
            report.Differences.Add(difference);
        return report;
    }

    /// <summary>
    /// Checks expected panel extension-data keys while tolerating panel-added fields and equivalent allowed-IP shapes.
    /// </summary>
    /// <param name="expected">Extension data captured before the identity change.</param>
    /// <param name="actual">Extension data returned after the identity change.</param>
    /// <returns><c>true</c> when every stable expected key remains semantically equivalent.</returns>
    /// <remarks>
    /// Dynamic traffic keys are verified through the dedicated traffic endpoint and are excluded here. The
    /// <c>allowedIPs</c> field may be normalized by the shared API boundary from a string to an array.
    /// </remarks>
    private static IReadOnlyList<XuiV3LinkChangeFieldDifference> GetChangeLinkExtraDifferences(
        IDictionary<string, Newtonsoft.Json.Linq.JToken> expected,
        IDictionary<string, Newtonsoft.Json.Linq.JToken> actual)
    {
        var differences = new List<XuiV3LinkChangeFieldDifference>();
        if (expected == null || expected.Count == 0)
            return differences;
        if (actual == null)
        {
            if (expected.Keys.Any(key => string.Equals(key, "allowedIPs", StringComparison.OrdinalIgnoreCase)))
                differences.Add(new XuiV3LinkChangeFieldDifference("extra.allowedIPs", "preserved", "missing", true));
            return differences;
        }

        foreach (var pair in expected)
        {
            if (IsDynamicChangeLinkExtraKey(pair.Key))
                continue;

            var actualPair = actual.FirstOrDefault(item =>
                string.Equals(item.Key, pair.Key, StringComparison.OrdinalIgnoreCase));
            if (string.IsNullOrWhiteSpace(actualPair.Key))
            {
                // Only allowed IPs are an access-control setting. Other extension fields can be server-generated or
                // omitted by a newer response shape and are reported without triggering a destructive correction.
                differences.Add(new XuiV3LinkChangeFieldDifference(
                    $"extra.{pair.Key}",
                    CanonicalChangeLinkToken(pair.Value),
                    "missing",
                    string.Equals(pair.Key, "allowedIPs", StringComparison.OrdinalIgnoreCase)));
                continue;
            }

            if (string.Equals(pair.Key, "allowedIPs", StringComparison.OrdinalIgnoreCase))
            {
                if (!NormalizeAllowedIpToken(pair.Value).SequenceEqual(NormalizeAllowedIpToken(actualPair.Value)))
                {
                    differences.Add(new XuiV3LinkChangeFieldDifference(
                        "extra.allowedIPs",
                        string.Join(",", NormalizeAllowedIpToken(pair.Value)),
                        string.Join(",", NormalizeAllowedIpToken(actualPair.Value)),
                        true));
                }
                continue;
            }

            if (!ChangeLinkTokenEquals(pair.Value, actualPair.Value))
            {
                differences.Add(new XuiV3LinkChangeFieldDifference(
                    $"extra.{pair.Key}",
                    CanonicalChangeLinkToken(pair.Value),
                    CanonicalChangeLinkToken(actualPair.Value),
                    false));
            }
        }

        return differences;
    }

    /// <summary>
    /// Creates the replacement payload that changes only email, subId, UUID, and audit metadata.
    /// </summary>
    /// <param name="snapshot">Immutable live snapshot captured before mutation.</param>
    /// <param name="newEmail">New unique XUI email and subscription id.</param>
    /// <param name="newUuid">New XUI protocol UUID generated by the panel or secure local fallback.</param>
    /// <param name="actorTelegramUserId">Numeric Telegram id of the customer requesting the link change.</param>
    /// <returns>A complete replacement payload preserving all non-identity fields from the snapshot.</returns>
    /// <remarks>
    /// Parsed metadata receives only link-change audit updates and the live inbound snapshot. User comments, tenant
    /// ownership, plan fields, historical renewals, limits, and all other metadata remain unchanged.
    /// </remarks>
    private static XuiV3ClientPayload BuildChangeLinkPayload(
        XuiV3LinkChangeSnapshot snapshot,
        string newEmail,
        string newUuid,
        long actorTelegramUserId)
    {
        var client = snapshot.Client;
        var metadata = TryReadMetadata(client.Comment);
        var comment = client.Comment;
        if (metadata != null)
        {
            metadata.LastUpdatedByTelegramUserId = actorTelegramUserId;
            metadata.LastUpdatedByBotId = BotContextAccessor.CurrentBotId;
            metadata.LastAction = "change-link";
            metadata.InboundIds = snapshot.InboundIds.ToList();
            comment = JsonConvert.SerializeObject(metadata, Formatting.None);
        }

        var ownerTelegramUserId = GetClientOwnerTelegramId(client);
        if (ownerTelegramUserId <= 0)
            ownerTelegramUserId = actorTelegramUserId > 0 ? actorTelegramUserId : client.TgId;
        if (metadata != null)
        {
            if (metadata.TelegramUserId <= 0)
                metadata.TelegramUserId = ownerTelegramUserId;
            comment = JsonConvert.SerializeObject(metadata, Formatting.None);
        }

        return new XuiV3ClientPayload
        {
            Email = newEmail,
            Uuid = newUuid,
            Password = client.Password,
            TotalGB = GetTotalBytes(client),
            ExpiryTime = GetExpiryTime(client),
            TgId = ownerTelegramUserId,
            LimitIp = client.LimitIp,
            Enable = client.Enable,
            SubId = newEmail,
            Flow = client.Flow,
            Comment = comment,
            Group = client.Group,
            Reverse = client.Reverse?.DeepClone(),
            Extra = CloneChangeLinkPayloadExtra(client.Extra)
        };
    }

    /// <summary>
    /// Reapplies the immutable target identity from a durable operation to its restored XUI update payload.
    /// </summary>
    /// <param name="operation">
    /// Persisted users.db operation whose <c>NewEmail</c>, <c>NewUuid</c>, and <c>NewSubId</c> values were generated
    /// once before the first panel mutation and must be reused by every recovery attempt.
    /// </param>
    /// <param name="payload">
    /// Deserialized XUI client payload to normalize in place. The value is required and is used only for the same
    /// panel client represented by <paramref name="operation"/>.
    /// </param>
    /// <remarks>
    /// Json.NET extension data can preserve response wrappers or duplicate identity keys from older panel response
    /// shapes. Reapplying the operation columns prevents such keys from replacing the saved target UUID during
    /// verification and removes response-only fields before any corrective update is considered.
    /// </remarks>
    /// <example>
    /// <code>
    /// var payload = JsonConvert.DeserializeObject&lt;XuiV3ClientPayload&gt;(operation.PayloadJson);
    /// NormalizePersistedChangeLinkPayload(operation, payload);
    /// </code>
    /// </example>
    private static void NormalizePersistedChangeLinkPayload(
        XuiV3LinkChangeOperation operation,
        XuiV3ClientPayload payload)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(payload);

        payload.Email = operation.NewEmail;
        payload.Uuid = operation.NewUuid;
        payload.SubId = operation.NewSubId;
        payload.Extra = CloneChangeLinkPayloadExtra(payload.Extra);
    }

    /// <summary>
    /// Clones XUI extension data while excluding typed client properties and response-only wrapper fields.
    /// </summary>
    /// <param name="source">
    /// Extension data captured from a live XUI client. Null and empty dictionaries are allowed. Security-sensitive
    /// panel endpoint data is not expected here and must never be added by callers.
    /// </param>
    /// <returns>
    /// A detached ordinal-key dictionary containing only genuine extension settings, or <c>null</c> when no such
    /// settings remain. Meaningful fields such as <c>allowedIPs</c> are retained.
    /// </returns>
    /// <remarks>
    /// The filtered names already have strongly typed properties on <see cref="XuiV3ClientPayload"/> or belong only
    /// to read responses. Keeping them in <c>JsonExtensionData</c> can emit duplicate JSON names and make recovery
    /// compare the new panel identity with stale pre-change values.
    /// </remarks>
    private static IDictionary<string, Newtonsoft.Json.Linq.JToken> CloneChangeLinkPayloadExtra(
        IDictionary<string, Newtonsoft.Json.Linq.JToken> source)
    {
        if (source == null || source.Count == 0)
            return null;

        var excludedKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "id", "client", "inboundIds", "traffic",
            "email", "uuid", "password", "totalGB", "expiryTime", "tgId", "limitIp", "enable",
            "subId", "flow", "comment", "group", "reverse"
        };
        var clone = source
            .Where(pair => !excludedKeys.Contains(pair.Key))
            .ToDictionary(
                pair => pair.Key,
                pair => pair.Value?.DeepClone(),
                StringComparer.Ordinal);
        return clone.Count == 0 ? null : clone;
    }

    /// <summary>
    /// Returns the first non-empty string from panel response candidates.
    /// </summary>
    /// <param name="values">Ordered candidate values from list and direct XUI responses.</param>
    /// <returns>The first non-whitespace value, or null when all candidates are empty.</returns>
    private static string FirstChangeLinkValue(params string[] values)
        => values?.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value));

    /// <summary>
    /// Compares nullable panel strings while treating null and empty values as equivalent.
    /// </summary>
    /// <param name="left">First panel value.</param>
    /// <param name="right">Second panel value.</param>
    /// <returns><c>true</c> when trimmed values are ordinally equal.</returns>
    private static bool ChangeLinkTextEquals(string left, string right)
        => string.Equals((left ?? string.Empty).Trim(), (right ?? string.Empty).Trim(), StringComparison.Ordinal);

    /// <summary>
    /// Compares comment text as canonical JSON when both values are JSON, with trimmed text as a safe fallback.
    /// </summary>
    /// <param name="expected">Saved pre-change comment or metadata JSON.</param>
    /// <param name="actual">Comment returned by the panel after update.</param>
    /// <returns><c>true</c> when both values are semantically equal despite property order or JSON formatting.</returns>
    private static bool ChangeLinkJsonTextEquals(string expected, string actual)
    {
        if (ChangeLinkTextEquals(expected, actual))
            return true;

        try
        {
            var expectedToken = Newtonsoft.Json.Linq.JToken.Parse(expected ?? "null");
            var actualToken = Newtonsoft.Json.Linq.JToken.Parse(actual ?? "null");
            return ChangeLinkTokenEquals(expectedToken, actualToken);
        }
        catch (Newtonsoft.Json.JsonException)
        {
            return false;
        }
    }

    /// <summary>
    /// Compares JSON tokens after normalizing empty containers and scalar string/number/bool representations.
    /// </summary>
    /// <param name="expected">Expected token from the persisted update payload.</param>
    /// <param name="actual">Token observed in the post-change panel response.</param>
    /// <returns><c>true</c> when the values are semantically equivalent.</returns>
    private static bool ChangeLinkTokenEquals(
        Newtonsoft.Json.Linq.JToken expected,
        Newtonsoft.Json.Linq.JToken actual)
    {
        var expectedCanonical = CanonicalChangeLinkToken(expected);
        var actualCanonical = CanonicalChangeLinkToken(actual);
        return string.Equals(expectedCanonical, actualCanonical, StringComparison.Ordinal);
    }

    /// <summary>
    /// Converts one JSON token into a deterministic representation used only for safe semantic comparison.
    /// </summary>
    /// <param name="token">Panel extension, reverse, or metadata token; null is allowed.</param>
    /// <returns>Canonical compact text with object keys sorted ordinally and equivalent empty values collapsed.</returns>
    private static string CanonicalChangeLinkToken(Newtonsoft.Json.Linq.JToken token)
    {
        if (token == null || token.Type is Newtonsoft.Json.Linq.JTokenType.Null or Newtonsoft.Json.Linq.JTokenType.Undefined)
            return string.Empty;
        if (token is Newtonsoft.Json.Linq.JObject obj)
        {
            if (!obj.Properties().Any())
                return string.Empty;
            return "{" + string.Join(",", obj.Properties()
                .OrderBy(property => property.Name, StringComparer.Ordinal)
                .Select(property => $"{property.Name}:{CanonicalChangeLinkToken(property.Value)}")) + "}";
        }
        if (token is Newtonsoft.Json.Linq.JArray array)
        {
            if (array.Count == 0)
                return string.Empty;
            return "[" + string.Join(",", array.Select(CanonicalChangeLinkToken)) + "]";
        }

        var raw = token.ToString(Newtonsoft.Json.Formatting.None).Trim().Trim('"');
        if (bool.TryParse(raw, out var boolean))
            return boolean ? "true" : "false";
        if (decimal.TryParse(raw, NumberStyles.Number, CultureInfo.InvariantCulture, out var number))
            return number.ToString("0.############################", CultureInfo.InvariantCulture);
        return raw;
    }

    /// <summary>
    /// Clones and merges extension data without exposing or mutating the source panel objects.
    /// </summary>
    /// <param name="fallback">Lower-priority extension data, usually from the direct endpoint.</param>
    /// <param name="preferred">Higher-priority extension data, usually from the list endpoint.</param>
    /// <returns>A detached ordinal-key dictionary, or null when both inputs are empty.</returns>
    private static IDictionary<string, Newtonsoft.Json.Linq.JToken> MergeChangeLinkExtra(
        IDictionary<string, Newtonsoft.Json.Linq.JToken> fallback,
        IDictionary<string, Newtonsoft.Json.Linq.JToken> preferred)
    {
        if ((fallback == null || fallback.Count == 0) && (preferred == null || preferred.Count == 0))
            return null;

        var result = new Dictionary<string, Newtonsoft.Json.Linq.JToken>(StringComparer.Ordinal);
        foreach (var pair in fallback ?? new Dictionary<string, Newtonsoft.Json.Linq.JToken>())
            result[pair.Key] = pair.Value?.DeepClone();
        foreach (var pair in preferred ?? new Dictionary<string, Newtonsoft.Json.Linq.JToken>())
            result[pair.Key] = pair.Value?.DeepClone();
        return result;
    }

    /// <summary>
    /// Clones one extension-data dictionary for an immutable snapshot or outgoing replacement payload.
    /// </summary>
    /// <param name="source">Panel extension data that may contain protocol-specific values.</param>
    /// <returns>A detached clone, or null when the source is null.</returns>
    private static IDictionary<string, Newtonsoft.Json.Linq.JToken> CloneChangeLinkExtra(
        IDictionary<string, Newtonsoft.Json.Linq.JToken> source)
        => source?.ToDictionary(pair => pair.Key, pair => pair.Value?.DeepClone(), StringComparer.Ordinal);

    /// <summary>
    /// Deep-clones a canonical client so later update responses cannot mutate the pre-change snapshot.
    /// </summary>
    /// <param name="client">Canonical live client captured before mutation.</param>
    /// <returns>A detached client preserving scalar, JSON, inbound, and traffic values.</returns>
    private static XuiV3Client CloneChangeLinkClient(XuiV3Client client)
    {
        if (client == null)
            return null;

        return new XuiV3Client
        {
            Id = client.Id,
            Email = client.Email,
            Uuid = client.Uuid,
            Password = client.Password,
            TotalGB = client.TotalGB,
            ExpiryTime = client.ExpiryTime,
            TgId = client.TgId,
            LimitIp = client.LimitIp,
            Enable = client.Enable,
            SubId = client.SubId,
            Flow = client.Flow,
            Comment = client.Comment,
            Group = client.Group,
            Reverse = client.Reverse?.DeepClone(),
            Extra = CloneChangeLinkExtra(client.Extra),
            InboundIds = client.InboundIds?.ToList() ?? new List<int>(),
            Traffic = CloneClientTraffic(client.Traffic)
        };
    }

    /// <summary>
    /// Clones nullable traffic counters used by snapshot and verification results.
    /// </summary>
    /// <param name="traffic">Live XUI traffic object, or null during an incomplete repair read.</param>
    /// <returns>A detached traffic object, or null when <paramref name="traffic"/> is null.</returns>
    private static XuiV3ClientTraffic CloneClientTraffic(XuiV3ClientTraffic traffic)
    {
        if (traffic == null)
            return null;

        return new XuiV3ClientTraffic
        {
            Email = traffic.Email,
            Up = traffic.Up,
            Down = traffic.Down,
            Total = traffic.Total,
            TotalGB = traffic.TotalGB,
            ExpiryTime = traffic.ExpiryTime,
            Enable = traffic.Enable
        };
    }

    /// <summary>
    /// Identifies extension-data keys whose values are verified through dedicated XUI traffic fields instead.
    /// </summary>
    /// <param name="key">Extension-data key returned by the panel.</param>
    /// <returns><c>true</c> for dynamic usage fields that should not participate in static-field equality.</returns>
    private static bool IsDynamicChangeLinkExtraKey(string key)
        => string.Equals(key, "up", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "down", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "total", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "totalGB", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "expiryTime", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "id", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "inboundIds", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "traffic", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "createdAt", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "updatedAt", StringComparison.OrdinalIgnoreCase) ||
           string.Equals(key, "lastOnline", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Converts allowed-IP extension values into a stable ordered sequence for semantic comparison.
    /// </summary>
    /// <param name="token">String, JSON-array string, array, or null value returned by XUI.</param>
    /// <returns>Distinct non-empty entries sorted ordinally.</returns>
    private static IReadOnlyList<string> NormalizeAllowedIpToken(Newtonsoft.Json.Linq.JToken token)
    {
        if (token == null || token.Type == Newtonsoft.Json.Linq.JTokenType.Null)
            return Array.Empty<string>();

        IEnumerable<string> values;
        if (token is Newtonsoft.Json.Linq.JArray array)
        {
            values = array.Select(item => item?.ToString());
        }
        else
        {
            var raw = token.ToString().Trim();
            if (raw.StartsWith("[", StringComparison.Ordinal))
            {
                try
                {
                    values = Newtonsoft.Json.Linq.JArray.Parse(raw).Select(item => item?.ToString());
                }
                catch (JsonReaderException)
                {
                    values = raw.Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                }
            }
            else
            {
                values = raw.Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            }
        }

        return values
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Select(value => value.Trim())
            .Distinct(StringComparer.Ordinal)
            .OrderBy(value => value, StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>
    /// Immutable pre-change state used to preserve one XUI client across an identity replacement.
    /// </summary>
    private sealed class XuiV3LinkChangeSnapshot
    {
        /// <summary>Numeric XUI client id that must remain stable after the identity change.</summary>
        public int ClientId { get; set; }

        /// <summary>Detached canonical client containing every non-identity field captured from live panel responses.</summary>
        public XuiV3Client Client { get; set; }

        /// <summary>Sorted, distinct inbound ids attached to the client before mutation.</summary>
        public List<int> InboundIds { get; set; } = new List<int>();

        /// <summary>Uploaded bytes captured before mutation.</summary>
        public long Up { get; set; }

        /// <summary>Downloaded bytes captured before mutation.</summary>
        public long Down { get; set; }
    }

    /// <summary>
    /// Result of the fail-closed snapshot operation that runs before any XUI identity mutation.
    /// </summary>
    private sealed class XuiV3LinkChangeSnapshotCaptureResult
    {
        /// <summary>Captured immutable snapshot, or null when live state was incomplete.</summary>
        public XuiV3LinkChangeSnapshot Snapshot { get; private set; }

        /// <summary>Non-secret diagnostic reason when <see cref="Snapshot"/> is null.</summary>
        public string ErrorMessage { get; private set; }

        /// <summary>Creates a successful snapshot result.</summary>
        /// <param name="snapshot">Complete snapshot with live inbound and traffic data.</param>
        /// <returns>A result whose <see cref="Snapshot"/> is non-null.</returns>
        public static XuiV3LinkChangeSnapshotCaptureResult Captured(XuiV3LinkChangeSnapshot snapshot)
            => new() { Snapshot = snapshot };

        /// <summary>Creates a failed snapshot result that forbids identity mutation.</summary>
        /// <param name="errorMessage">Non-secret reason live state could not be established.</param>
        /// <returns>A result whose <see cref="Snapshot"/> is null.</returns>
        public static XuiV3LinkChangeSnapshotCaptureResult Failed(string errorMessage)
            => new() { ErrorMessage = errorMessage };
    }

    /// <summary>
    /// Canonical live state returned by XUI reads during snapshot capture and post-change verification.
    /// </summary>
    private sealed class XuiV3LinkChangeLiveState
    {
        /// <summary>Detached canonical client assembled from list and direct-client responses.</summary>
        public XuiV3Client Client { get; set; }

        /// <summary>Sorted, distinct inbound ids returned by live panel endpoints.</summary>
        public List<int> InboundIds { get; set; } = new List<int>();

        /// <summary>Current traffic counters, or null only during repair reads that allow missing traffic.</summary>
        public XuiV3ClientTraffic Traffic { get; set; }

        /// <summary>Whether the current inbound set came from an authoritative live list response.</summary>
        public bool InboundIdsObserved { get; set; }

        /// <summary>Whether traffic counters came from a live traffic or embedded traffic response.</summary>
        public bool TrafficObserved { get; set; }
    }

    /// <summary>
    /// Result wrapper for a live XUI state read.
    /// </summary>
    private sealed class XuiV3LinkChangeLiveStateResult
    {
        /// <summary>Tri-state outcome that keeps transport uncertainty distinct from an authoritative absence.</summary>
        public XuiV3LinkChangeObservationStatus ObservationStatus { get; private set; }

        /// <summary>Canonical live state, or null when required panel data could not be read.</summary>
        public XuiV3LinkChangeLiveState State { get; private set; }

        /// <summary>Non-secret diagnostic reason when <see cref="State"/> is null.</summary>
        public string ErrorMessage { get; private set; }

        /// <summary>Creates a successful live-state result.</summary>
        /// <param name="state">Canonical state loaded from current panel responses.</param>
        /// <returns>A result whose <see cref="State"/> is non-null.</returns>
        public static XuiV3LinkChangeLiveStateResult Loaded(XuiV3LinkChangeLiveState state)
            => new() { State = state, ObservationStatus = XuiV3LinkChangeObservationStatus.Observed };

        /// <summary>Creates an authoritative not-found result.</summary>
        /// <param name="errorMessage">Non-secret reason the requested identity was absent.</param>
        /// <returns>A result whose state is null and observation is <c>NotFound</c>.</returns>
        public static XuiV3LinkChangeLiveStateResult NotFound(string errorMessage)
            => new() { ErrorMessage = errorMessage, ObservationStatus = XuiV3LinkChangeObservationStatus.NotFound };

        /// <summary>Creates an unknown result for timeout, transport failure, or incomplete panel data.</summary>
        /// <param name="errorMessage">Non-secret reason no safe conclusion could be reached.</param>
        /// <returns>A result whose state is null and observation is <c>Unknown</c>.</returns>
        public static XuiV3LinkChangeLiveStateResult Unknown(string errorMessage)
            => new() { ErrorMessage = errorMessage, ObservationStatus = XuiV3LinkChangeObservationStatus.Unknown };
    }

    /// <summary>
    /// One normalized field mismatch found during final link-change verification.
    /// </summary>
    /// <param name="Field">Stable field name used in internal diagnostics.</param>
    /// <param name="Expected">Redacted canonical expected value.</param>
    /// <param name="Actual">Redacted canonical observed value.</param>
    /// <param name="IsCritical">Whether the mismatch blocks success and permits a corrective update.</param>
    private sealed record XuiV3LinkChangeFieldDifference(
        string Field,
        string Expected,
        string Actual,
        bool IsCritical)
    {
        /// <summary>Builds a compact internal diagnostic without panel endpoints or credentials.</summary>
        /// <returns>Field, severity, and truncated canonical values.</returns>
        public string ToDiagnosticText()
            => $"{Field}[{(IsCritical ? "critical" : "informational")}]:{Compact(Expected)}->{Compact(Actual)}";

        /// <summary>Truncates one canonical value so one malformed extension cannot flood the logger channel.</summary>
        /// <param name="value">Canonical field value.</param>
        /// <returns>Value limited to eighty characters.</returns>
        private static string Compact(string value)
            => string.IsNullOrEmpty(value) || value.Length <= 80 ? value ?? string.Empty : value[..80] + "...";
    }

    /// <summary>
    /// Structured semantic comparison result for all stable XUI client fields.
    /// </summary>
    private sealed class XuiV3LinkChangeDifferenceReport
    {
        /// <summary>Field-level differences retained for corrective decisions and diagnostics.</summary>
        public List<XuiV3LinkChangeFieldDifference> Differences { get; } = new();

        /// <summary>Whether at least one access, identity, quota, expiry, owner, or protocol field differs.</summary>
        public bool HasCriticalDifferences => Differences.Any(x => x.IsCritical);

        /// <summary>Adds one explicit field mismatch.</summary>
        /// <param name="field">Stable diagnostic field name.</param>
        /// <param name="expected">Canonical expected value.</param>
        /// <param name="actual">Canonical observed value.</param>
        /// <param name="critical">Whether this mismatch blocks final success.</param>
        public void Add(string field, string expected, string actual, bool critical)
            => Differences.Add(new XuiV3LinkChangeFieldDifference(field, expected, actual, critical));

        /// <summary>Adds a mismatch when two value-type values differ.</summary>
        /// <typeparam name="T">Comparable scalar type.</typeparam>
        /// <param name="field">Stable diagnostic field name.</param>
        /// <param name="expected">Expected typed value.</param>
        /// <param name="actual">Observed typed value.</param>
        /// <param name="critical">Whether this mismatch blocks final success.</param>
        public void AddWhenDifferent<T>(string field, T expected, T actual, bool critical)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                Add(field, Convert.ToString(expected, CultureInfo.InvariantCulture), Convert.ToString(actual, CultureInfo.InvariantCulture), critical);
        }

        /// <summary>Adds a mismatch after null/empty and surrounding whitespace normalization.</summary>
        /// <param name="field">Stable diagnostic field name.</param>
        /// <param name="expected">Expected nullable text.</param>
        /// <param name="actual">Observed nullable text.</param>
        /// <param name="critical">Whether this mismatch blocks final success.</param>
        public void AddTextWhenDifferent(string field, string expected, string actual, bool critical)
        {
            if (!ChangeLinkTextEquals(expected, actual))
                Add(field, (expected ?? string.Empty).Trim(), (actual ?? string.Empty).Trim(), critical);
        }
    }

    /// <summary>
    /// Final result of post-change correction, inbound reconciliation, traffic restoration, and verification.
    /// </summary>
    private sealed class XuiV3LinkChangePreservationResult
    {
        /// <summary>Whether every required field, inbound, and traffic invariant passed final verification.</summary>
        public bool Success { get; private set; }

        /// <summary>Repair or verification stage that failed, or <c>verified</c> after success.</summary>
        public string Stage { get; private set; }

        /// <summary>Non-secret panel or invariant message associated with a failed stage.</summary>
        public string Message { get; private set; }

        /// <summary>Latest canonical client available when the result was created.</summary>
        public XuiV3Client Client { get; private set; }

        /// <summary>Latest live inbound ids available for critical audit logging.</summary>
        public List<int> ActualInboundIds { get; private set; } = new List<int>();

        /// <summary>Latest traffic counters available for critical audit logging.</summary>
        public XuiV3ClientTraffic Traffic { get; private set; }

        /// <summary>Tri-state quality of the latest panel observation.</summary>
        public XuiV3LinkChangeObservationStatus ObservationStatus { get; private set; }

        /// <summary>Exact normalized fields that differed during verification.</summary>
        public List<XuiV3LinkChangeFieldDifference> Differences { get; private set; } = new();

        /// <summary>Creates a fully verified preservation result.</summary>
        /// <param name="state">Final state whose identity, fields, inbounds, and traffic passed verification.</param>
        /// <returns>A successful result safe for normal notification, logging, and website sync.</returns>
        public static XuiV3LinkChangePreservationResult Verified(XuiV3LinkChangeLiveState state)
        {
            return new XuiV3LinkChangePreservationResult
            {
                Success = true,
                Stage = "verified",
                ObservationStatus = XuiV3LinkChangeObservationStatus.Observed,
                Client = state.Client,
                ActualInboundIds = state.InboundIds.ToList(),
                Traffic = CloneClientTraffic(state.Traffic)
            };
        }

        /// <summary>Creates a failed preservation result without rolling the identity back.</summary>
        /// <param name="stage">Stable stage key identifying the failed repair or verification operation.</param>
        /// <param name="message">Non-secret failure message returned by XUI or local invariant validation.</param>
        /// <param name="state">Latest live state, or null when no post-change read succeeded.</param>
        /// <param name="observationStatus">Whether the latest read observed state, proved absence, or remained unknown.</param>
        /// <param name="differences">Normalized field-level differences available for internal diagnostics.</param>
        /// <returns>A failed result containing the latest non-sensitive state for audit.</returns>
        public static XuiV3LinkChangePreservationResult Failed(
            string stage,
            string message,
            XuiV3LinkChangeLiveState state = null,
            XuiV3LinkChangeObservationStatus observationStatus = XuiV3LinkChangeObservationStatus.Observed,
            IEnumerable<XuiV3LinkChangeFieldDifference> differences = null)
        {
            return new XuiV3LinkChangePreservationResult
            {
                Stage = stage,
                Message = message,
                ObservationStatus = observationStatus,
                Client = state?.Client,
                ActualInboundIds = state?.InboundIds?.ToList() ?? new List<int>(),
                Traffic = CloneClientTraffic(state?.Traffic),
                Differences = differences?.ToList() ?? new List<XuiV3LinkChangeFieldDifference>()
            };
        }
    }

    private static XuiV3ClientPayload BuildUpdateCommentPayload(
        XuiV3Client client,
        string newUserComment,
        long actorTelegramUserId)
    {
        var metadata = TryReadMetadata(client.Comment) ?? new XuiV3ClientMetadata
        {
            TelegramUserId = GetClientOwnerTelegramId(client) > 0 ? GetClientOwnerTelegramId(client) : actorTelegramUserId,
            CreatedAtUtc = DateTime.UtcNow
        };

        if (metadata.TelegramUserId <= 0)
            metadata.TelegramUserId = GetClientOwnerTelegramId(client) > 0 ? GetClientOwnerTelegramId(client) : actorTelegramUserId;

        metadata.UserComment = newUserComment?.Trim();
        metadata.LastUpdatedByTelegramUserId = actorTelegramUserId;
        metadata.LastAction = "update-comment";

        return new XuiV3ClientPayload
        {
            Email = client.Email,
            Uuid = client.Uuid,
            Password = client.Password,
            TotalGB = GetTotalBytes(client),
            ExpiryTime = GetExpiryTime(client),
            TgId = metadata.TelegramUserId,
            LimitIp = client.LimitIp,
            Enable = client.Enable,
            SubId = string.IsNullOrWhiteSpace(client.SubId) ? client.Email : client.SubId,
            Flow = client.Flow,
            Comment = JsonConvert.SerializeObject(metadata, Formatting.None),
            Group = client.Group,
            Reverse = client.Reverse,
            Extra = client.Extra
        };
    }

    /// <summary>
    /// Edits the durable operation message with one user-readable processing stage.
    /// </summary>
    /// <param name="botClient">Telegram client of the bot that owns the operation.</param>
    /// <param name="operation">Persisted operation containing chat, message, client, and public operation ids.</param>
    /// <param name="title">Short Persian stage title shown to the customer.</param>
    /// <param name="description">Persian explanation of the current safe operation.</param>
    /// <param name="cancellationToken">Token that cancels Telegram delivery.</param>
    /// <returns>A task that completes after the best-effort edit.</returns>
    /// <remarks>Telegram edit failures do not change panel or database state and are handled by the shared safe editor.</remarks>
    private static async Task UpdateChangeLinkProgressAsync(
        ITelegramBotClient botClient,
        XuiV3LinkChangeOperation operation,
        string title,
        string description,
        CancellationToken cancellationToken)
    {
        var text = "⏳ <b>تغییر لینک در حال انجام است</b>\n\n" +
                   $"مرحله: <b>{Html(title)}</b>\n" +
                   $"{Html(description)}\n\n" +
                   $"شناسه پیگیری: <code>{Html(operation.OperationKey)}</code>";
        try
        {
            await SendOrEditTextAsync(
                botClient,
                new ChatId(operation.ChatId),
                operation.MessageId,
                text,
                ParseMode.Html,
                BuildChangeLinkStatusKeyboard(operation),
                cancellationToken);
        }
        catch (Exception ex)
        {
            // Telegram delivery is observational only. It must never roll back, replay, or reschedule an XUI mutation.
            Console.WriteLine($"[XUIv3] link-change progress delivery failed. operationKey={operation.OperationKey}, error={ex.Message}");
        }
    }

    /// <summary>
    /// Persists an ambiguous panel result for automatic recovery and updates the customer without exposing internals.
    /// </summary>
    /// <param name="botClient">Telegram client of the operation's owned or tenant bot.</param>
    /// <param name="operation">Current operation whose client remains locked.</param>
    /// <param name="stage">Stable internal stage key that could not be verified.</param>
    /// <param name="safeError">Redacted diagnostic detail with no panel URL, token, root path, or response body.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram work.</param>
    /// <returns>A task that completes after recovery state is durable and status delivery is attempted.</returns>
    private async Task ScheduleUnknownLinkChangeAsync(
        ITelegramBotClient botClient,
        XuiV3LinkChangeOperation operation,
        string stage,
        string safeError,
        CancellationToken cancellationToken)
    {
        var pending = await _linkChangeOperationStore.ScheduleRecoveryAsync(
            operation.OperationKey,
            stage,
            safeError,
            cancellationToken);
        try
        {
            await SendOrEditTextAsync(
                botClient,
                new ChatId(pending.ChatId),
                pending.MessageId,
                BuildChangeLinkOperationStatusText(pending),
                ParseMode.Html,
                BuildChangeLinkStatusKeyboard(pending),
                cancellationToken);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] link-change recovery status delivery failed. operationKey={pending.OperationKey}, error={ex.Message}");
        }
    }

    /// <summary>
    /// Builds the explicit warning shown before any XUI identity mutation.
    /// </summary>
    /// <param name="operation">Awaiting-confirmation operation containing the current account identity.</param>
    /// <returns>HTML-safe Persian confirmation text with a public operation id.</returns>
    private static string BuildChangeLinkConfirmationText(XuiV3LinkChangeOperation operation)
    {
        return "⚠️ <b>تأیید نهایی تغییر لینک</b>\n\n" +
               "با تأیید این عملیات، نام اکانت، UUID و subscription id فقط یک‌بار تغییر می‌کند. " +
               "حجم، مصرف، انقضا، کامنت، محدودیت‌ها و inboundهای متصل حفظ و دوباره بررسی می‌شوند.\n\n" +
               $"اکانت فعلی: <code>{Html(operation.OldEmail)}</code>\n" +
               $"شناسه پیگیری: <code>{Html(operation.OperationKey)}</code>\n\n" +
               "تا پایان عملیات دوباره روی دکمه تغییر لینک نزنید.";
    }

    /// <summary>
    /// Builds confirmation and cancellation callbacks for one unmutated operation.
    /// </summary>
    /// <param name="operation">Awaiting-confirmation operation owned by the current bot and user.</param>
    /// <returns>Inline keyboard whose mutation callbacks carry only the random operation key.</returns>
    private static InlineKeyboardMarkup BuildChangeLinkConfirmationKeyboard(XuiV3LinkChangeOperation operation)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("✅ تأیید نهایی تغییر لینک", XuiV3PurchaseCallbacks.AccountChangeLinkConfirm(operation.OperationKey)) },
            new[] { InlineKeyboardButton.WithCallbackData("انصراف", XuiV3PurchaseCallbacks.AccountChangeLinkCancel(operation.OperationKey)) },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    IsChangeLinkSearchSource(operation) ? "بازگشت به نتایج جستجو" : "بازگشت به لیست",
                    IsChangeLinkSearchSource(operation)
                        ? XuiV3PurchaseCallbacks.AccountSearchList(operation.Page)
                        : XuiV3PurchaseCallbacks.AccountList(operation.Page))
            }
        });
    }

    /// <summary>
    /// Builds a safe customer-facing status for processing, recovery, manual review, or completion.
    /// </summary>
    /// <param name="operation">Persisted operation whose status should be rendered.</param>
    /// <returns>HTML-safe Persian status without raw panel errors or infrastructure addresses.</returns>
    private static string BuildChangeLinkOperationStatusText(XuiV3LinkChangeOperation operation)
    {
        if (operation == null)
            return "عملیات تغییر لینک پیدا نشد.";

        var statusText = operation.Status switch
        {
            XuiV3LinkChangeStatuses.AwaitingConfirmation => "در انتظار تأیید نهایی شما",
            XuiV3LinkChangeStatuses.Processing => "در حال پردازش و بررسی پنل",
            XuiV3LinkChangeStatuses.RecoveryPending => "در حال بازیابی خودکار و بررسی مجدد پنل",
            XuiV3LinkChangeStatuses.ManualReview => "نیازمند بررسی پشتیبانی؛ عملیات جدید برای این اکانت قفل است",
            XuiV3LinkChangeStatuses.Succeeded => "با موفقیت تکمیل شد",
            XuiV3LinkChangeStatuses.Cancelled => "پیش از تغییر لغو شد",
            XuiV3LinkChangeStatuses.Expired => "مهلت تأیید تمام شد و تغییری انجام نشد",
            XuiV3LinkChangeStatuses.FailedBeforeMutation => "پیش از تغییر متوقف شد و شناسه‌ها تغییر نکردند",
            _ => "در حال بررسی"
        };
        var identityText = operation.IdentityCommitted && !string.IsNullOrWhiteSpace(operation.NewEmail)
            ? $"\nشناسه ثبت‌شده روی پنل: <code>{Html(operation.NewEmail)}</code>"
            : string.Empty;
        var guidance = operation.Status switch
        {
            XuiV3LinkChangeStatuses.ManualReview =>
                "بازیابی خودکار به پایان رسیده است. قفل اکانت حفظ شده و پشتیبانی باید همین شناسه پیگیری را بررسی کند.",
            XuiV3LinkChangeStatuses.Succeeded =>
                "عملیات تکمیل شده است و کلیک دوباره هیچ شناسه جدیدی ایجاد نمی‌کند.",
            XuiV3LinkChangeStatuses.Cancelled or
            XuiV3LinkChangeStatuses.Expired or
            XuiV3LinkChangeStatuses.FailedBeforeMutation =>
                "هیچ تغییر تأییدنشده‌ای از این عملیات روی اکانت باقی نمانده است.",
            _ => "اگر پاسخ پنل دیر برسد، همین عملیات به‌صورت خودکار ادامه پیدا می‌کند و شناسه دیگری ساخته نمی‌شود."
        };
        return "🔄 <b>وضعیت تغییر لینک</b>\n\n" +
               $"وضعیت: <b>{Html(statusText)}</b>\n" +
               $"مرحله: <b>{Html(GetChangeLinkStageText(operation.Stage))}</b>\n" +
               $"تعداد بررسی: <code>{operation.AttemptCount}</code>" +
               identityText + "\n" +
               $"شناسه پیگیری: <code>{Html(operation.OperationKey)}</code>\n\n" +
               guidance;
    }

    /// <summary>
    /// Converts an internal link-change stage key into a stable Persian customer-facing label.
    /// </summary>
    /// <param name="stage">Persisted non-secret stage key written by foreground or recovery processing.</param>
    /// <returns>A short Persian label; unknown future stages fall back to a generic review label.</returns>
    private static string GetChangeLinkStageText(string stage)
    {
        return stage switch
        {
            "awaiting-confirmation" => "در انتظار تأیید نهایی",
            "confirmed" => "تأیید دریافت شد",
            "snapshot-saved" => "وضعیت اکانت ذخیره شد",
            "identity-update-sent" => "ثبت شناسه‌های جدید",
            "identity-committed" => "شناسه‌های جدید ثبت شد",
            "reconciling-account-state" => "تطبیق اطلاعات اکانت",
            "verified" => "بررسی نهایی موفق",
            "confirmation-expired" => "مهلت تأیید پایان یافت",
            "cancelled" => "عملیات لغو شد",
            "manual-recheck-requested" => "درخواست بررسی مجدد",
            "recovery-claimed" => "بازیابی خودکار",
            "panel-configuration-changed" => "انتظار برای تنظیم صحیح پنل",
            _ => "بررسی وضعیت پنل"
        };
    }

    /// <summary>
    /// Builds status refresh and source-aware navigation without exposing a second mutation action.
    /// </summary>
    /// <param name="operation">Persisted operation whose public key and navigation source are used.</param>
    /// <returns>Inline keyboard for status refresh, list/search return, and main menu.</returns>
    private static InlineKeyboardMarkup BuildChangeLinkStatusKeyboard(XuiV3LinkChangeOperation operation)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (operation != null && XuiV3LinkChangeStatuses.Active.Contains(operation.Status))
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData("🔄 بررسی مجدد وضعیت", XuiV3PurchaseCallbacks.AccountChangeLinkStatus(operation.OperationKey))
            });
        }

        if (operation != null)
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    IsChangeLinkSearchSource(operation) ? "بازگشت به نتایج جستجو" : "بازگشت به لیست",
                    IsChangeLinkSearchSource(operation)
                        ? XuiV3PurchaseCallbacks.AccountSearchList(operation.Page)
                        : XuiV3PurchaseCallbacks.AccountList(operation.Page))
            });
        }
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Determines whether the operation originated from account-search results.
    /// </summary>
    /// <param name="operation">Persisted operation with a list or search source value.</param>
    /// <returns><c>true</c> only for the search source.</returns>
    private static bool IsChangeLinkSearchSource(XuiV3LinkChangeOperation operation)
        => string.Equals(operation?.Source, AccountCommentSourceSearch, StringComparison.Ordinal);

    /// <summary>
    /// Builds navigation after a completed or safely aborted link change.
    /// </summary>
    /// <param name="clientId">Stable numeric XUI client id.</param>
    /// <param name="page">Zero-based source page.</param>
    /// <param name="fromSearch">Whether navigation returns to search results.</param>
    /// <returns>Inline account-detail, source-list, and main-menu navigation.</returns>
    private static InlineKeyboardMarkup BuildChangeLinkResultKeyboard(int clientId, int page, bool fromSearch)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "مشاهده مشخصات",
                    fromSearch
                        ? XuiV3PurchaseCallbacks.AccountSearchView(clientId, page)
                        : XuiV3PurchaseCallbacks.AccountView(clientId, page))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    fromSearch ? "بازگشت به نتایج جستجو" : "بازگشت به لیست",
                    fromSearch
                        ? XuiV3PurchaseCallbacks.AccountSearchList(page)
                        : XuiV3PurchaseCallbacks.AccountList(page))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home())
            }
        });
    }

    private static string BuildChangeLinkSuccessText(
        string oldEmail,
        string oldUuid,
        string oldSubId,
        string newEmail,
        string newUuid,
        string newSubId,
        string newSubLink)
    {
        var builder = new StringBuilder();
        builder.AppendLine("✅ لینک اکانت با موفقیت تغییر کرد.");
        builder.AppendLine();
        builder.AppendLine("📌 اطلاعات قبلی");
        builder.AppendLine("👤 نام قبلی:");
        builder.AppendLine($"<code>{Html(oldEmail)}</code>");
        builder.AppendLine("🆔 UUID قبلی:");
        builder.AppendLine($"<code>{Html(oldUuid)}</code>");
        builder.AppendLine("🔖 Subscription ID قبلی:");
        builder.AppendLine($"<code>{Html(oldSubId)}</code>");
        builder.AppendLine();
        builder.AppendLine("✅ اطلاعات جدید");
        builder.AppendLine("👤 نام جدید:");
        builder.AppendLine($"<code>{Html(newEmail)}</code>");
        builder.AppendLine("🆔 UUID جدید:");
        builder.AppendLine($"<code>{Html(newUuid)}</code>");
        builder.AppendLine("🔖 Subscription ID جدید:");
        builder.AppendLine($"<code>{Html(newSubId)}</code>");
        builder.AppendLine();
        builder.AppendLine("🔗 سابلینک جدید:");
        builder.AppendLine($"<code>{Html(newSubLink)}</code>");
        builder.AppendLine();
        builder.AppendLine("از این لحظه لینک قبلی را استفاده نکنید.");
        return builder.ToString();
    }

    /// <summary>
    /// Combines the current link-change processor's panel time with the durable end-to-end confirmation duration.
    /// </summary>
    /// <param name="operation">
    /// Persisted link-change saga. <see cref="XuiV3LinkChangeOperation.ConfirmedAtUtc"/> is the start of actual
    /// execution and survives process restarts.
    /// </param>
    /// <param name="timing">Monotonic timer for the current foreground or recovery execution attempt.</param>
    /// <returns>
    /// A snapshot whose API duration covers the current execution attempt and whose total duration covers the whole
    /// confirmed saga when a durable confirmation time is available.
    /// </returns>
    /// <remarks>
    /// API time from a process that crashed cannot be reconstructed without persisting telemetry, so recovery logs
    /// intentionally report the successful/final attempt's panel time while total time remains restart-safe.
    /// </remarks>
    private static XuiOperationTimingSnapshot BuildLinkChangeTimingSnapshot(
        XuiV3LinkChangeOperation operation,
        XuiOperationTiming timing)
    {
        var snapshot = timing?.Snapshot() ?? default;
        if (operation?.ConfirmedAtUtc is not DateTime confirmedAtUtc)
            return snapshot;

        var totalElapsed = DateTime.UtcNow - confirmedAtUtc;
        if (totalElapsed < TimeSpan.Zero)
            totalElapsed = snapshot.TotalElapsed;

        return new XuiOperationTimingSnapshot(snapshot.PanelApiElapsed, totalElapsed);
    }

    /// <summary>
    /// Logs a safe failed or ambiguous link-change attempt with restart-aware total duration.
    /// </summary>
    /// <param name="operation">Durable link-change operation that supplies route, target name, and confirmation time.</param>
    /// <param name="actor">Authenticated Telegram user who initiated the mutation.</param>
    /// <param name="timing">Monotonic timer for panel calls made during the current execution attempt.</param>
    /// <param name="result">Fixed Persian outcome with no raw panel response, exception detail, or secret identifier.</param>
    /// <remarks>
    /// Recovery may execute the same operation more than once. Each completed attempt is logged separately so API
    /// health remains visible; total duration is calculated from the durable confirmation time when available.
    /// </remarks>
    private void LogLinkChangeOutcome(
        XuiV3LinkChangeOperation operation,
        CredUser actor,
        XuiOperationTiming timing,
        string result)
    {
        LogXuiOperationOutcomeSnapshot(
            "تغییر لینک اکانت نسخه ۳",
            result,
            actor,
            BuildLinkChangeTimingSnapshot(operation, timing),
            accountEmail: operation?.OldEmail ?? operation?.NewEmail,
            source: string.IsNullOrWhiteSpace(operation?.Source) ? "link-change" : operation.Source);
    }

    /// <summary>
    /// Builds the private HTML audit for a completed XUI v3 identity/link rotation and appends measured durations.
    /// </summary>
    /// <param name="actor">Authenticated Telegram user who confirmed the link change.</param>
    /// <param name="client">Pre-change panel client used to preserve service and ownership metadata.</param>
    /// <param name="oldEmail">Panel email/name before rotation.</param>
    /// <param name="oldUuid">Protocol UUID before rotation; included only in the private administrator audit.</param>
    /// <param name="oldSubId">Subscription identifier before rotation.</param>
    /// <param name="oldSubLink">Complete subscription link before rotation.</param>
    /// <param name="newEmail">Panel email/name committed by the rotation saga.</param>
    /// <param name="newUuid">Protocol UUID committed by the rotation saga.</param>
    /// <param name="newSubId">Subscription identifier committed by the rotation saga.</param>
    /// <param name="newSubLink">Complete replacement subscription link delivered to the account owner.</param>
    /// <param name="serverInfo">Panel descriptor used for non-secret server attribution.</param>
    /// <param name="timing">API and durable end-to-end timing snapshot for the completed saga.</param>
    /// <returns>HTML-safe private-channel audit text including old/new identity data and elapsed durations.</returns>
    /// <remarks>
    /// This formatter has no panel, database, wallet, order, or Telegram side effects. Because the result contains
    /// credentials and subscription links, it must only be sent to the configured private logger channel.
    /// </remarks>
    private static string BuildChangeLinkLogMessage(
        CredUser actor,
        XuiV3Client client,
        string oldEmail,
        string oldUuid,
        string oldSubId,
        string oldSubLink,
        string newEmail,
        string newUuid,
        string newSubId,
        string newSubLink,
        ServerInfo serverInfo,
        XuiOperationTimingSnapshot timing)
    {
        var metadata = TryReadMetadata(client.Comment);
        var actorRole = actor?.IsColleague == true ? "همکار" : "کاربر عادی";
        var ownerTelegramUserId = GetClientOwnerTelegramId(client);
        var totalBytes = GetTotalBytes(client);
        var usedBytes = GetUsedBytes(client);
        var trafficText = totalBytes > 0
            ? $"{usedBytes.ConvertBytesToGB():0.##} از {totalBytes.ConvertBytesToGB():0.##} GB"
            : $"{usedBytes.ConvertBytesToGB():0.##} از نامحدود";
        var userComment = CompactLogText(metadata?.UserComment, 120);
        var now = DateTime.UtcNow.AddMinutes(210).ConvertToHijriShamsi();

        var builder = new StringBuilder();
        builder.AppendLine("🔁 <b>گزارش تغییر لینک اکانت نسخه ۳</b>");
        builder.AppendLine();
        builder.AppendLine($"👤 انجام‌دهنده: {TelegramUserLinkFormatter.HtmlUserLink(actor)}");
        builder.AppendLine($"🔹 یوزرنیم: {TelegramUserLinkFormatter.HtmlUsername(actor)}");
        builder.AppendLine($"🆔 آیدی عددی انجام‌دهنده: <code>{actor?.TelegramUserId ?? 0}</code>");
        builder.AppendLine($"👥 نوع کاربر: <code>{Html(actorRole)}</code>");
        builder.AppendLine($"📌 مالک اکانت روی پنل: <code>{ownerTelegramUserId}</code>");
        builder.AppendLine($"🕒 زمان تغییر: <code>{Html(now)}</code>");
        builder.AppendLine();
        builder.AppendLine("قبل از تغییر:");
        builder.AppendLine($"• Email: <code>{Html(oldEmail)}</code>");
        builder.AppendLine($"• UUID: <code>{Html(oldUuid)}</code>");
        builder.AppendLine($"• Subscription ID: <code>{Html(oldSubId)}</code>");
        builder.AppendLine($"• Sub Link: <code>{Html(oldSubLink)}</code>");
        builder.AppendLine();
        builder.AppendLine("بعد از تغییر:");
        builder.AppendLine($"• Email: <code>{Html(newEmail)}</code>");
        builder.AppendLine($"• UUID: <code>{Html(newUuid)}</code>");
        builder.AppendLine($"• Subscription ID: <code>{Html(newSubId)}</code>");
        builder.AppendLine($"• Sub Link: <code>{Html(newSubLink)}</code>");
        builder.AppendLine();
        builder.AppendLine("مشخصات اکانت در لحظه تغییر:");
        builder.AppendLine($"• سرویس: <code>{Html(metadata?.ServiceName ?? "نامشخص")}</code>");
        builder.AppendLine($"• مصرف: <code>{Html(trafficText)}</code>");
        builder.AppendLine($"• انقضا: <code>{Html(FormatExpiry(GetExpiryTime(client)))}</code>");
        builder.AppendLine($"• وضعیت: <code>{(client.Enable ? "فعال" : "غیرفعال")}</code>");
        if (!string.IsNullOrWhiteSpace(userComment))
            builder.AppendLine($"• کامنت کاربر: <code>{Html(userComment)}</code>");
        builder.AppendLine($"• پنل: <code>{Html(serverInfo.Url)}</code>");
        builder.AppendLine($"• Root Path: <code>{Html(serverInfo.RootPath)}</code>");
        builder.AppendLine();
        builder.Append(XuiOperationTiming.BuildHtmlLines(timing));
        return builder.ToString();
    }

    /// <summary>
    /// Sends an operational Telegram log after a user-owned XUI v3 account is deleted.
    /// </summary>
    /// <param name="client">Deleted XUI client as it existed before the panel delete call.</param>
    /// <param name="credUser">Telegram user who requested the delete action.</param>
    /// <param name="source">Delete surface, such as account list or search results.</param>
    /// <param name="timing">Monotonic duration snapshot captured after the panel accepted the delete.</param>
    /// <remarks>
    /// The delete operation has already succeeded before this method is called. The log is best-effort and
    /// does not participate in the panel transaction, but it gives admins the same visibility as link changes.
    /// It is committed to the durable Telegram outbox as HTML (EventId 1001/TelegramHtml) and never requests a
    /// database backup, because deleting an account does not itself mutate wallet or payment state.
    /// </remarks>
    private void LogAccountDelete(
        XuiV3Client client,
        CredUser credUser,
        string source,
        XuiOperationTimingSnapshot timing)
    {
        var metadata = TryReadMetadata(client.Comment);
        var builder = new StringBuilder();
        builder.AppendLine("🗑 <b>گزارش حذف اکانت نسخه ۳</b>");
        builder.AppendLine();
        builder.AppendLine(TelegramUserLinkFormatter.HtmlSummary(credUser));
        builder.AppendLine($"مسیر حذف: <code>{Html(source)}</code>");
        builder.AppendLine($"اکانت: <code>{Html(client.Email)}</code>");
        builder.AppendLine($"UUID: <code>{Html(client.Uuid)}</code>");
        builder.AppendLine($"ساب‌لینک: <code>{Html(client.SubId)}</code>");
        builder.AppendLine($"مالک متادیتا: <code>{Html((metadata?.TelegramUserId ?? 0).ToString(CultureInfo.InvariantCulture))}</code>");
        builder.AppendLine($"BotId: <code>{Html(BotContextAccessor.CurrentBotId)}</code>");
        builder.AppendLine($"BotType: <code>{Html(BotContextAccessor.CurrentBotType)}</code>");
        builder.AppendLine($"زمان: <code>{Html(DateTime.UtcNow.AddMinutes(210).ConvertToHijriShamsi())}</code>");
        builder.AppendLine();
        builder.Append(XuiOperationTiming.BuildHtmlLines(timing));
        _logger.LogTelegramHtml(builder.ToString());
    }

    private static long GetClientOwnerTelegramId(XuiV3Client client)
    {
        if (client != null && client.TgId > 0)
            return client.TgId;

        return TryReadMetadata(client?.Comment)?.TelegramUserId ?? 0;
    }

    private static string CompactLogText(string value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var normalized = value.Replace("\r", " ").Replace("\n", " ").Trim();
        return normalized.Length <= maxLength
            ? normalized
            : normalized.Substring(0, maxLength) + "...";
    }

    private static string NormalizeUserComment(string text)
    {
        return XuiV3PurchaseService.NormalizeOptionalUserComment(text, 200) ?? string.Empty;
    }

    /// <summary>
    /// Builds the customer-facing account details text for owned and tenant account lists/search results.
    /// </summary>
    /// <param name="client">XUI client whose current panel fields should be displayed.</param>
    /// <param name="serverInfo">Panel descriptor used to rebuild the subscription link.</param>
    /// <param name="isColleague">Whether colleague-only warning rules should be applied.</param>
    /// <param name="showRenewCommand">Whether the slash-command renewal hint should be appended.</param>
    /// <returns>
    /// HTML-formatted Persian account details text, including the resolved service/account type when available.
    /// </returns>
    /// <remarks>
    /// Tenant search reuses this method. The account type is resolved from metadata first and from active plan
    /// inbounds second so customers can see whether a found account is normal, national, or unlimited even after
    /// a link-change operation.
    /// </remarks>
    private string BuildV3ClientInfo(XuiV3Client client, ServerInfo serverInfo, bool isColleague, bool showRenewCommand = true)
    {
        var email = Html(client.Email);
        var usedBytes = GetUsedBytes(client);
        var totalBytes = GetTotalBytes(client);
        var expiryTime = GetExpiryTime(client);
        var subId = string.IsNullOrWhiteSpace(client.SubId) ? client.Email : client.SubId;
        var subLink = ApiServicev3.BuildSubscriptionLink(serverInfo, subId);
        var metadata = TryReadMetadata(client.Comment);
        var service = ResolveServiceForClient(client);
        var serviceText = service?.DisplayName ?? metadata?.ServiceName ?? "نامشخص";

        var text = new System.Text.StringBuilder();
        text.AppendLine($"👤 نام: <code>{email}</code>");
        text.AppendLine($"🧩 نوع اکانت: <code>{Html(serviceText)}</code>");
        text.AppendLine(FormatV3Expiry(expiryTime));
        text.AppendLine(FormatV3Traffic(usedBytes, totalBytes));
        if (!string.IsNullOrWhiteSpace(metadata?.UserComment))
            text.AppendLine($"📝 کامنت: <code>{Html(metadata.UserComment)}</code>");

        if (client.Enable)
        {
            text.AppendLine("✔️ فعال");
        }
        else
        {
            text.AppendLine("🚫 غیرفعال");
        }

        if (!isColleague && totalBytes > 0 && usedBytes >= totalBytes && !IsExpired(expiryTime))
        {
            text.AppendLine("❗️مولتی آیپی");
        }

        if (showRenewCommand)
            text.AppendLine($"🔄 تمدید ⬅️ /renew_{email}");
        text.AppendLine("🔗 سابلینک:");
        text.AppendLine($"<code>{Html(subLink)}</code>");
        text.AppendLine("___________________________");
        return text.ToString();
    }

    /// <summary>
    /// Enables or disables an owned XUI client and rebuilds its complete account card on the originating list page.
    /// </summary>
    /// <param name="botClient">Telegram client for the owned or tenant bot that received the callback.</param>
    /// <param name="chatId">Telegram chat containing the account card to update.</param>
    /// <param name="messageId">Message id of the account card, or zero when a new card must be sent.</param>
    /// <param name="credUser">
    /// Bot-scoped credential record for the Telegram user. Its Telegram id is used to revalidate account ownership.
    /// </param>
    /// <param name="clientId">Numeric panel client id from the callback; a missing or non-positive value is rejected.</param>
    /// <param name="page">
    /// Zero-based owned-account list page restored after the panel mutation. Legacy callbacks use page zero.
    /// </param>
    /// <param name="enable"><c>true</c> to enable the client; <c>false</c> to disable it.</param>
    /// <param name="cancellationToken">Token that cancels panel, activity-log, and Telegram operations.</param>
    /// <returns>A task that completes after rejection or after the updated account card has been delivered.</returns>
    /// <remarks>
    /// The method reloads the panel client list and checks Telegram ownership before mutation. A successful update
    /// keeps the account card on its previous page and restores the same full action menu, including read-only
    /// configuration retrieval. It does not change wallet, order, renewal, or conversation-state records. Every
    /// terminal panel outcome includes API and total elapsed durations in the private central audit.
    /// </remarks>
    private async Task HandleAccountStateCallbackAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        CredUser credUser,
        int? clientId,
        int page,
        bool enable,
        CancellationToken cancellationToken)
    {
        if (clientId == null || clientId <= 0)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "شناسه اکانت معتبر نیست.",
                cancellationToken: cancellationToken);
            return;
        }

        using var operationTiming = XuiOperationTiming.Start();
        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            Console.WriteLine($"[XUIv3] account state callback user={credUser.TelegramUserId}, clientId={clientId}, enable={enable}, panel={serverInfo.Url}, rootPath={serverInfo.RootPath}");

            var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
            if (!clientsResponse.Success)
            {
                LogXuiOperationOutcome(
                    enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                    "دریافت لیست از پنل ناموفق بود",
                    credUser,
                    operationTiming,
                    source: "list");
                await botClient.SendMessage(
                    chatId: chatId,
                    text: $"دریافت اطلاعات اکانت ناموفق بود.\n{clientsResponse.Msg}",
                    cancellationToken: cancellationToken);
                return;
            }

            var client = clientsResponse.Obj?.FirstOrDefault(c => c.Id == clientId.Value);
            if (client == null || !ClientBelongsToUser(client, credUser.TelegramUserId))
            {
                LogXuiOperationOutcome(
                    enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                    "اکانت پیدا نشد یا مجاز نبود",
                    credUser,
                    operationTiming,
                    source: "list");
                await botClient.SendMessage(
                    chatId: chatId,
                    text: "اکانت مورد نظر پیدا نشد یا متعلق به حساب شما نیست.",
                    cancellationToken: cancellationToken);
                return;
            }

            var updateResponse = await ApiServicev3.SetClientEnabledAsync(
                serverInfo,
                _configuration,
                client.Email,
                enable,
                credUser.TelegramUserId,
                cancellationToken);
            if (!updateResponse.Success)
            {
                await _activityLog.LogWarningAsync(
                    "xui_v3_account_state_callback_failed",
                    credUser,
                    false,
                    new Dictionary<string, object>
                    {
                        ["clientId"] = clientId,
                        ["accountEmail"] = client.Email,
                        ["requestedAction"] = enable ? "enable" : "disable",
                        ["message"] = updateResponse.Msg ?? string.Empty
                    },
                    cancellationToken);

                LogXuiOperationOutcome(
                    enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                    "پنل تغییر را رد کرد",
                    credUser,
                    operationTiming,
                    accountEmail: client.Email,
                    source: "list");

                await botClient.SendMessage(
                    chatId: chatId,
                    text: $"متاسفانه عملیات مورد نظر انجام نشد.\n{updateResponse.Msg}",
                    cancellationToken: cancellationToken);
                return;
            }

            await _activityLog.LogBotActionAsync(
                enable ? "xui_v3_account_enabled" : "xui_v3_account_disabled",
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["clientId"] = clientId,
                    ["accountEmail"] = client.Email,
                    ["panelUrl"] = serverInfo.Url,
                    ["rootPath"] = serverInfo.RootPath,
                    ["source"] = "account_callback",
                    ["panelApiElapsedMs"] = (long)operationTiming.PanelApiElapsed.TotalMilliseconds,
                    ["totalElapsedMs"] = (long)operationTiming.TotalElapsed.TotalMilliseconds
                },
                cancellationToken);

            client.Enable = enable;
            var updatedText = BuildV3ClientInfo(client, serverInfo, credUser.IsColleague, IsClientRenewable(client));
            var updatedKeyboard = BuildAccountDetailsKeyboard(
                client,
                page,
                IsClientRenewable(client));

            if (messageId != 0)
            {
                await SafeEditMessageTextAsync(
                    botClient,
                    chatId: chatId,
                    messageId: messageId,
                    text: updatedText,
                    parseMode: ParseMode.Html,
                    replyMarkup: updatedKeyboard,
                    cancellationToken: cancellationToken);
            }
            else
            {
                await botClient.SendMessage(
                    chatId: chatId,
                    text: updatedText,
                    parseMode: ParseMode.Html,
                    replyMarkup: updatedKeyboard,
                    cancellationToken: cancellationToken);
            }

            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                "موفق",
                credUser,
                operationTiming,
                accountEmail: client.Email,
                source: "list");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[XUIv3] account state callback exception user={credUser.TelegramUserId}, clientId={clientId}, enable={enable}: {ex}");
            await _activityLog.LogErrorAsync(
                "xui_v3_account_state_callback_exception",
                ex,
                credUser,
                false,
                new Dictionary<string, object>
                {
                    ["clientId"] = clientId,
                    ["requestedAction"] = enable ? "enable" : "disable"
                },
                cancellationToken);
            LogXuiOperationOutcome(
                enable ? "فعال‌سازی اکانت نسخه ۳" : "غیرفعال‌سازی اکانت نسخه ۳",
                $"خطا ({ex.GetType().Name})",
                credUser,
                operationTiming,
                source: "list");
            await botClient.SendMessage(
                chatId: chatId,
                text: "در انجام عملیات خطا رخ داد. جزئیات در ترمینال ثبت شد.",
                cancellationToken: cancellationToken);
        }
    }

    private static string FormatV3Expiry(long expiryTime)
    {
        if (expiryTime < 0)
            return $"📅 انقضا: {FormatFirstUseDurationDays(expiryTime)} روز بعد از اولین اتصال";

        if (expiryTime == 0)
            return "📅 انقضا: نامحدود";

        var expiryUtc = DateTimeOffset.FromUnixTimeMilliseconds(expiryTime).UtcDateTime;
        var expiryText = expiryUtc.AddMinutes(210).ConvertToHijriShamsi();

        if (expiryUtc < DateTime.UtcNow)
            return $"📅 انقضا: {Html(expiryText)}\n🚫 منقضی شده است.";

        var remainingDays = (expiryUtc - DateTime.UtcNow).Days;
        var icon = remainingDays <= 5 ? "❕⌛️" : "⏳";
        return $"📅 انقضا: {Html(expiryText)}\n{icon} روزهای باقی‌مانده: {remainingDays} روز";
    }

    private static string FormatV3Traffic(long usedBytes, long totalBytes)
    {
        var usedGb = usedBytes.ConvertBytesToGB();
        if (totalBytes <= 0)
            return $"🔋 میزان مصرف: {usedGb:F2} گیگابایت از نامحدود";

        var totalGb = totalBytes.ConvertBytesToGB();
        var icon = usedBytes < totalBytes * 0.9 ? "🔋" : "🪫";
        return $"{icon} میزان مصرف: {usedGb:F2} از {totalGb:F2} گیگابایت";
    }

    private static string FormatGb(long bytes, bool zeroAsUnknown = true)
    {
        if (bytes < 0 || bytes == 0 && zeroAsUnknown)
            return "نامحدود / نامشخص";

        return $"{bytes.ConvertBytesToGB():0.##} GB";
    }

    private static bool IsExpired(long expiryTime)
    {
        return expiryTime > 0 &&
               DateTimeOffset.FromUnixTimeMilliseconds(expiryTime).UtcDateTime < DateTime.UtcNow;
    }

    private static bool IsExpiredOrDepleted(XuiV3Client client)
    {
        if (client == null)
            return false;

        if (IsExpired(GetExpiryTime(client)))
            return true;

        var totalBytes = GetTotalBytes(client);
        var usedBytes = GetUsedBytes(client);
        return totalBytes > 0 && usedBytes >= totalBytes;
    }

    private static string GetExpiryOrTrafficReason(XuiV3Client client)
    {
        var reasons = new List<string>();
        if (IsExpired(GetExpiryTime(client)))
            reasons.Add("اتمام زمان");

        var totalBytes = GetTotalBytes(client);
        var usedBytes = GetUsedBytes(client);
        if (totalBytes > 0 && usedBytes >= totalBytes)
            reasons.Add("اتمام حجم");

        return reasons.Count == 0 ? "نامشخص" : string.Join(" + ", reasons);
    }

    private static ReplyKeyboardMarkup BuildDeleteExpiredConfirmKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("تایید حذف اکانت های منقضی") },
            new[] { new KeyboardButton("انصراف") }
        })
        {
            ResizeKeyboard = true,
            OneTimeKeyboard = true
        };
    }

    private static string BuildDeleteExpiredConfirmationText(IReadOnlyCollection<XuiV3Client> clients, bool isAdmin, long telegramUserId)
    {
        var builder = new StringBuilder();
        builder.AppendLine(isAdmin
            ? "🗑 لیست اکانت‌های منقضی کاربر مورد نظر"
            : "🗑 لیست اکانت‌های منقضی شما");
        builder.AppendLine();
        builder.AppendLine($"👤 تلگرام آیدی: <code>{telegramUserId}</code>");
        builder.AppendLine($"📦 تعداد: <code>{clients.Count}</code>");
        builder.AppendLine();

        foreach (var client in clients)
        {
            builder.AppendLine($"• <code>{Html(client.Email)}</code>");
            builder.AppendLine($"  علت: <code>{Html(GetExpiryOrTrafficReason(client))}</code>");
            builder.AppendLine($"  انقضا: <code>{Html(FormatDeleteExpiry(client))}</code>");
            builder.AppendLine($"  مصرف: <code>{Html(FormatDeleteTraffic(client))}</code>");
        }

        builder.AppendLine();
        builder.AppendLine("در صورت تایید، این اکانت‌ها از پنل نسخه ۳ حذف می‌شوند.");
        return builder.ToString();
    }

    private static string BuildDeleteExpiredResultText(
        IReadOnlyCollection<string> deleted,
        IReadOnlyCollection<string> failed,
        bool isAdmin,
        long telegramUserId)
    {
        var builder = new StringBuilder();
        builder.AppendLine(isAdmin
            ? "✅ نتیجه حذف اکانت‌های منقضی کاربر"
            : "✅ نتیجه حذف اکانت‌های منقضی شما");
        builder.AppendLine();
        builder.AppendLine($"👤 تلگرام آیدی: <code>{telegramUserId}</code>");
        builder.AppendLine($"🗑 حذف‌شده: <code>{deleted.Count}</code>");
        builder.AppendLine($"⚠️ ناموفق: <code>{failed.Count}</code>");

        if (deleted.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("اکانت‌های حذف‌شده:");
            foreach (var email in deleted)
                builder.AppendLine($"• <code>{Html(email)}</code>");
        }

        if (failed.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("اکانت‌های حذف‌نشده:");
            foreach (var email in failed)
                builder.AppendLine($"• <code>{Html(email)}</code>");
        }

        return builder.ToString();
    }

    private static List<string> DeserializeEmailList(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return new List<string>();

        try
        {
            return JsonConvert.DeserializeObject<List<string>>(raw) ?? new List<string>();
        }
        catch
        {
            return new List<string>();
        }
    }

    private static string FormatDeleteExpiry(XuiV3Client client)
    {
        var expiryTime = GetExpiryTime(client);
        if (expiryTime < 0)
            return $"{FormatFirstUseDurationDays(expiryTime)} روز بعد از اولین اتصال";

        if (expiryTime == 0)
            return "نامحدود";

        var expiryUtc = DateTimeOffset.FromUnixTimeMilliseconds(expiryTime).UtcDateTime;
        return expiryUtc.AddMinutes(210).ConvertToHijriShamsi();
    }

    private static int FormatFirstUseDurationDays(long expiryTime)
    {
        return Math.Max(1, (int)Math.Ceiling(Math.Abs(expiryTime) / (double)TimeSpan.FromDays(1).TotalMilliseconds));
    }

    private static string FormatDeleteTraffic(XuiV3Client client)
    {
        var usedBytes = GetUsedBytes(client);
        var totalBytes = GetTotalBytes(client);
        var usedText = $"{usedBytes.ConvertBytesToGB():0.##} GB";
        if (totalBytes <= 0)
            return $"{usedText} از نامحدود";

        return $"{usedText} از {totalBytes.ConvertBytesToGB():0.##} GB";
    }

    /// <summary>
    /// Reads consumed upload and download bytes for a user-facing XUI v3 client card.
    /// </summary>
    /// <param name="client">
    /// XUI v3 client returned by the panel. The value may be null, and the nested <c>Traffic</c> object may be
    /// omitted by recent v3 responses.
    /// </param>
    /// <returns>
    /// Total used bytes. Missing upload/download counters are treated as zero after checking the raw
    /// <c>Extra["up"]</c> and <c>Extra["down"]</c> fallback fields.
    /// </returns>
    /// <remarks>
    /// This helper is used by "my accounts", account search, renewal previews, and delete confirmations.
    /// It must never throw for <c>traffic == null</c> because those paths run inside Telegram update handlers.
    /// </remarks>
    private static long GetUsedBytes(XuiV3Client client)
    {
        if (client == null)
            return 0;

        var traffic = client.Traffic;
        return (traffic?.Up ?? ReadLongExtra(client, "up")) +
               (traffic?.Down ?? ReadLongExtra(client, "down"));
    }

    /// <summary>
    /// Reads the configured traffic limit for a user-facing XUI v3 client card.
    /// </summary>
    /// <param name="client">
    /// XUI v3 client returned by the panel. The nested <c>Traffic</c> object may be null.
    /// </param>
    /// <returns>
    /// Traffic limit in bytes, or <c>0</c> when no limit was supplied by top-level fields, nested traffic fields,
    /// or the raw <c>Extra["totalGB"]</c> fallback.
    /// </returns>
    /// <remarks>
    /// Lookup order is top-level <c>TotalGB</c>, <c>Traffic.TotalGB</c>, <c>Traffic.Total</c>, then
    /// <c>Extra["totalGB"]</c>. This preserves compatibility with different 3x-ui v3 response shapes.
    /// </remarks>
    private static long GetTotalBytes(XuiV3Client client)
    {
        if (client == null)
            return 0;

        if (client.TotalGB > 0)
            return client.TotalGB;

        var trafficTotalGb = client.Traffic?.TotalGB ?? 0;
        if (trafficTotalGb > 0)
            return trafficTotalGb;

        var trafficTotal = client.Traffic?.Total ?? 0;
        if (trafficTotal > 0)
            return trafficTotal;

        return ReadLongExtra(client, "totalGB");
    }

    /// <summary>
    /// Reads the expiry value for a user-facing XUI v3 client card.
    /// </summary>
    /// <param name="client">
    /// XUI v3 client returned by the panel. The value may be null, and <c>Traffic</c> may be absent.
    /// </param>
    /// <returns>
    /// Expiry timestamp in Unix milliseconds, <c>0</c> for unlimited/no expiry, or a negative first-use duration
    /// used by 3x-ui to start validity from the first connection.
    /// </returns>
    /// <remarks>
    /// Lookup order is top-level <c>ExpiryTime</c>, <c>Traffic.ExpiryTime</c>, then <c>Extra["expiryTime"]</c>.
    /// Keeping this null-safe prevents "my accounts" and account-search messages from crashing when the panel
    /// omits the traffic object.
    /// </remarks>
    private static long GetExpiryTime(XuiV3Client client)
    {
        if (client == null)
            return 0;

        if (client.ExpiryTime != 0)
            return client.ExpiryTime;

        var trafficExpiryTime = client.Traffic?.ExpiryTime ?? 0;
        if (trafficExpiryTime != 0)
            return trafficExpiryTime;

        return ReadLongExtra(client, "expiryTime");
    }

    private static long ReadLongExtra(XuiV3Client client, string key)
    {
        if (client?.Extra == null || !client.Extra.TryGetValue(key, out var token) || token == null)
            return 0;

        return token.Type == Newtonsoft.Json.Linq.JTokenType.Integer ||
               token.Type == Newtonsoft.Json.Linq.JTokenType.Float ||
               token.Type == Newtonsoft.Json.Linq.JTokenType.String
            ? token.ToObject<long>()
            : 0;
    }

    private static string Html(string value)
    {
        return System.Net.WebUtility.HtmlEncode(value ?? string.Empty);
    }

    private ServerInfo BuildConfiguredPanelServerInfo()
    {
        var baseUrl = _appConfig.XuiV3ApiBaseUrl;
        if (string.IsNullOrWhiteSpace(baseUrl))
            throw new InvalidOperationException("XuiV3ApiBaseUrl is not configured.");

        return new ServerInfo
        {
            ApiVersion = "v3",
            ApiToken = _appConfig.XuiV3ApiToken,
            Url = baseUrl.TrimEnd('/'),
            RootPath = (_appConfig.XuiV3ApiRootPath ?? string.Empty).Trim('/'),
            SubLinkUrl = string.IsNullOrWhiteSpace(_appConfig.XuiV3SubLinkBaseUrl)
                ? null
                : _appConfig.XuiV3SubLinkBaseUrl.TrimEnd('/'),
            Name = "Configured V3 Panel"
        };
    }
}
