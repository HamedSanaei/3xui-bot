using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;
using Adminbot.Domain;
using Adminbot.Domain.Logging;
using Adminbot.Services;
using Adminbot.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

/// <summary>
/// owns all colleague tenant Bot behavior.
/// it has two RESPONSIBILITIES:
/// 1) owner-side setup from the Main brand Bot, and
/// 2) customer-side storefront purchase, payment, fulfillment, and ledger accounting inside tenant bots.
/// </summary>
/// <remarks>One execution scope owns one explicitly selected management store. Settings and customer state are per store;
/// all sibling stores retain the same owner's global wallet and website account. Never reuse this scoped service concurrently.</remarks>
public partial class TenantBotService
{
    /// <summary>Explicit owner-authorized selection for this execution scope, never inferred from the first owned store.</summary>
    private BotInstance _selectedOwnerStore;
    /// <summary>Coordinates funding-source selection and settlement across all storefronts of one owner; never held during provisioning.</summary>
    private static readonly AsyncKeyedGate OwnerSettlementGate = new();
    /// <summary>
    /// Serializes tenant fulfillment across provider callbacks, customer checks, and manual admin retries.
    /// </summary>
    /// <remarks>
    /// The order is reloaded after this gate is acquired so a stale tracked <c>IsFulfilled=false</c> value cannot
    /// create another XUI account or owner wallet mutation while a concurrent path completes the same order.
    /// </remarks>
    private static readonly AsyncKeyedGate TenantFulfillmentGate = new();
    /// <summary>
    /// Serializes the local claim that precedes a Tetraminator tenant invoice creation request.
    /// </summary>
    /// <remarks>
    /// The gate is held only while users.db is checked and the pending payment row is inserted. It prevents two
    /// callbacks for the same tenant order from issuing two non-idempotent provider create requests.
    /// </remarks>
    private static readonly AsyncKeyedGate TenantTetraminatorInvoiceCreationGate = new();
    /// <summary>
    /// Serializes the local claim before UniquePay's non-retried invoice creation request.
    /// </summary>
    private static readonly AsyncKeyedGate TenantUniquePayInvoiceCreationGate = new();
    private static readonly AsyncKeyedGate TenantAtlasPayInvoiceCreationGate = new();
    public const string OwnerMenuButton = "🛒 فعالسازی ربات فروشگاهی";

    private const string OWNERCALLBACKPREFIX = "TBM:";
    private const string CUSTOMERCALLBACKPREFIX = "TN:";
    private const string OWNERFLOW = "TENANTBOT-owner";
    private const string TENANTPURCHASEFLOW = "TENANTBOT-purchase";
    private const string TENANTPURCHASESTEPTRAFFIC = "purchase-traffic";
    private const string TENANTPURCHASESTEPDURATION = "purchase-duration";
    private const string STEPTOKEN = "Token";
    private const string STEPMARKUP = "markup";
    private const string STEPSUPPORT = "support";
    private const string STEPWELCOME = "WELCOME";
    private const string STEPCARDNUMBER = "card-number";
    private const string STEPCARDHOLDER = "card-HOLDER";
    private const string STEPMANDATORYCHANNEL = "mandatory-channel";
    private const string STEPMANUALCARDORDERID = "manual-card-order-id";
    private const string STEPTUTORIALTITLE = "tutorial-title";
    private const string STEPTUTORIALURL = "tutorial-url";
    /// <summary>
    /// Safe response shown when a tenant owner triggers the now-disabled owner-configurable tutorial manager.
    /// </summary>
    /// <remarks>
    /// Used both for stale <c>TBM:tutorial*</c> callbacks from old Telegram messages and for obsolete owner input steps,
    /// so an owner always learns that tutorials are provided by the system instead of silently getting no reaction.
    /// </remarks>
    private const string TENANTTUTORIALMANAGERDISABLEDMESSAGE =
        "این بخش فعلاً غیرفعال است و آموزش‌ها به‌صورت پیش‌فرض توسط سیستم ارائه می‌شوند.";
    /// <summary>Customer-facing menu text shown before the three built-in installation tutorials.</summary>
    private const string TENANTTUTORIALMENUTEXT =
        "📚 آموزش نصب\n\nسیستم‌عامل یا نرم‌افزار موردنظر خود را انتخاب کنید:";
    /// <summary>Customer-facing text used when the built-in tutorial images cannot be read from the deployed assets.</summary>
    private const string TENANTTUTORIALASSETSUNAVAILABLEMESSAGE =
        "در حال حاضر فایل‌های آموزش در دسترس نیستند. لطفاً کمی بعد دوباره تلاش کنید.";
    private const string STEPBROADCASTINPUT = "broadcast-input";
    private const string TENANTRENEWFLOW = "TENANTBOT-renew";
    private const string TENANTRENEWSTEPACCOUNT = "renew-account";
    private const string TENANTRENEWSTEPEXTERNALTARGETCONFIRMATION = "renew-confirm-external-target";
    /// <summary>Tenant-scoped step that awaits an explicit category for a metadata-free ambiguous legacy account.</summary>
    private const string TENANTRENEWSTEPSERVICECATEGORY = "renew-service-category";
    private const string TENANTRENEWSTEPTRAFFIC = "renew-traffic";
    private const string TENANTRENEWSTEPDURATION = "renew-duration";
    private const string TENANTRENEWSTEPUNLIMITEDPLAN = "renew-unlimited-plan";
    private const string TENANTRENEWSTEPCONFIRM = "renew-confirm";

    private readonly UserWorkflowStore _workflow;
    /// <summary>Independent bot/user state operations; no EF context is retained by the store.</summary>
    private readonly UserStateStore _state;
    private readonly CredentialsStore _credentialsDbContext;
    private readonly IConfiguration _configuration;
    private readonly AppConfig _appConfig;
    private readonly XuiV3PurchaseService _purchaseService;
    private readonly HooshPay _hooshPay;
    private readonly NowPayments _nowPayments;
    private readonly Tetraminator _tetraminator;
    private readonly UniquePay _uniquePay;
    private readonly AtlasPay _atlasPay;
    private readonly AtlasPayReconciliationHostedService _atlasPayReconciliation;
    private readonly IPaymentGatewayAvailability _gatewayAvailability;
    private readonly BotRegistry _botRegistry;
    private readonly BotClientProvider _botClientProvider;
    private readonly BotContextAccessor _botContextAccessor;
    private readonly XuiV3BotFlowService _xuiV3BotFlowService;
    private readonly WalletLedgerService _walletLedgerService;
    private readonly SalesAssistantService _salesAssistantService;
    private readonly GozargahSiteSyncService _gozargahSiteSyncService;
    private readonly BroadcastManager _broadcastManager;
    private readonly UsageAnalyticsService _usageAnalyticsService;
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<TenantBotService> _logger;
    private readonly IClientDownloadAvailability _clientDownloadAvailability;
    private readonly IClientReleaseService _clientReleaseService;
    private readonly XuiV3VolumeReminderStateStore _volumeReminderStateStore;
    private readonly XuiV3RenewalOperationStore _renewalOperationStore;
    private readonly TenantProvisioningAttemptCoordinator _tenantProvisioningCoordinator;
    /// <summary>
    /// Creates the single 1 GiB / 1 day courtesy client granted to a tenant card-to-card purchase customer while the
    /// receipt is still under owner review. Only reached when <see cref="AppConfig.TenantCardProvisionalDeliveryEnabled" />
    /// is enabled and the order is a card-funded purchase.
    /// </summary>
    private readonly TenantCardProvisionalProvisioningService _tenantCardProvisionalProvisioning;
    /// <summary>
    /// Upgrades that SAME courtesy client to the exact purchased entitlement once the owner approves the receipt. This
    /// service must be the only path that fulfills a provisional card order, so approval can never create a second client.
    /// </summary>
    private readonly TenantCardProvisionalFinalizationService _tenantCardProvisionalFinalization;
    /// <summary>
    /// Disables the courtesy client after the owner rejects the receipt, so a refused payment does not leave the customer
    /// with working access. Never settles money.
    /// </summary>
    private readonly TenantCardProvisionalRevocationService _tenantCardProvisionalRevocation;

    /// <summary>
    /// Immutable budget for UX-only callback acknowledgement on the tenant bot. Production uses the shared
    /// two-second default; tests inject a millisecond budget so bounded-acknowledgement behaviour is proven
    /// without waiting the real production timeout.
    /// </summary>
    private readonly TelegramInteractionTimeouts _interactionTimeouts;
    private readonly Dictionary<string, TenantJoinCapabilityCacheEntry> _tenantJoinCapabilityCache = new(StringComparer.Ordinal);
    private readonly object _tenantJoinCapabilitySync = new();

    /// <summary>
    /// creates the tenant Bot service with all dependencies needed for owner setup, customer storefronts, payments, and xui account creation.
    /// </summary>
    /// <param name="stateStore">Factory-backed state reader/writer isolated by runtime bot id and Telegram user id.</param>
    /// <param name="UserDbContext">users.db context for Bot instances, orders, payments, and ledger rows.</param>
    /// <param name="CredentialsDbContext">credentials.db context for Shared User profiles and owner wallet balances.</param>
    /// <param name="Configuration">Application Configuration.</param>
    /// <param name="purchaseService">xui v3 purchase and account creation service.</param>
    /// <param name="HooshPay">HooshPay API client used to Create and Verify invoices.</param>
    /// <param name="NowPayments">NOWPayments API client used to create and verify tenant crypto invoices.</param>
    /// <param name="Tetraminator">
    /// Tetraminator API client used to create rial tenant invoices and authoritatively verify their saved pay ids.
    /// The provider key is read from global configuration and must never be logged or stored on tenant rows.
    /// </param>
    /// <param name="UniquePay">
    /// UniquePay API client used to create tenant purchase and renewal invoices with the saved merchant hash.
    /// </param>
    /// <param name="GatewayAvailability">
    /// Live global gateway switches combined with each tenant's local preference.
    /// </param>
    /// <param name="BotRegistry">runtime Bot registry.</param>
    /// <param name="BotClientProvider">Telegram client Provider for owned and tenant bots.</param>
    /// <param name="BotContextAccessor">current Bot context accessor.</param>
    /// <param name="xuiV3BotFlowService">
    /// Shared XUI v3 customer-flow service reused for tenant account search, account list, renewal, and
    /// account-management callbacks so the tenant bot does not duplicate owned-bot account logic.
    /// </param>
    /// <param name="WalletLedgerService">
    /// Append-only wallet ledger writer used for tenant sales, owner profit, card-payment debits, and audit views.
    /// </param>
    /// <param name="SalesAssistantService">
    /// Sales Assistant notifier that sends tenant sale and receipt-review events to the colleague owner.
    /// </param>
    /// <param name="GozargahSiteSyncService">
    /// Site sync service used after successful tenant XUI operations. Tenant records are owned by the
    /// colleague owner on the website while preserving the buyer Telegram id for audit and customer support.
    /// </param>
    /// <param name="BroadcastManager">
    /// Shared broadcast queue used for tenant public messages. Tenant broadcasts use the tenant bot as the
    /// sender, but keep progress/status updates in the owned bot chat that started the job.
    /// </param>
    /// <param name="UsageAnalyticsService">
    /// Shared completed-day activity aggregator used for tenant-scoped owner statistics.
    /// </param>
    /// <param name="ServiceProvider">service Provider used to REACH MultiBotHostedService for runtime TOGGLE.</param>
    /// <param name="Logger">Logger used for tenant payment/audit channel logs.</param>
    /// <param name="VolumeReminderStateStore">
    /// Durable users.db volume-cycle store notified after a tenant renewal succeeds on the panel. Its best-effort state
    /// update never credits or debits the tenant owner and cannot change order fulfillment.
    /// </param>
    /// <param name="RenewalOperationStore">
    /// Durable users.db store that makes each tenant renewal mutation exactly-once: unique-key creation keyed by the
    /// tenant order, lease-bound claims, atomic applied transition, and read-only timeout recovery.
    /// </param>
    /// <param name="TenantProvisioningCoordinator">
    /// Central attempt-resolution engine that maps one paid tenant purchase order to its current immutable
    /// <c>tenant-create:</c> operation, allocating a new <c>:retry:N</c> generation only under a new explicit durable
    /// retry authorization after a definitive rejection.
    /// </param>
    /// <param name="InteractionTimeouts">
    /// Optional immutable budgets for UX-only Telegram interactions. When null the production budgets are used, so
    /// callback acknowledgement is bounded at two seconds. Tests pass millisecond values. This value never affects
    /// tenant pricing, wallet debit, order fulfillment, or XUI exactly-once semantics.
    /// </param>
    /// <remarks>The order is scoped to its tenant and reloaded under an order-specific gate. Wallet receipt keys are derived from that durable order identity.</remarks>
    public TenantBotService(
        UserWorkflowStore UserDbContext,
        UserStateStore stateStore,
        CredentialsStore CredentialsDbContext,
        IConfiguration Configuration,
        XuiV3PurchaseService purchaseService,
        HooshPay HooshPay,
        NowPayments NowPayments,
        Tetraminator Tetraminator,
        UniquePay UniquePay,
        AtlasPay AtlasPay,
        AtlasPayReconciliationHostedService AtlasPayReconciliation,
        IPaymentGatewayAvailability GatewayAvailability,
        IClientDownloadAvailability ClientDownloadAvailability,
        IClientReleaseService ClientReleaseService,
        BotRegistry BotRegistry,
        BotClientProvider BotClientProvider,
        BotContextAccessor BotContextAccessor,
        XuiV3BotFlowService xuiV3BotFlowService,
        WalletLedgerService WalletLedgerService,
        SalesAssistantService SalesAssistantService,
        GozargahSiteSyncService GozargahSiteSyncService,
        BroadcastManager BroadcastManager,
        UsageAnalyticsService UsageAnalyticsService,
        IServiceProvider ServiceProvider,
        ILogger<TenantBotService> Logger,
        XuiV3VolumeReminderStateStore VolumeReminderStateStore,
        XuiV3RenewalOperationStore RenewalOperationStore,
        TenantProvisioningAttemptCoordinator TenantProvisioningCoordinator,
        TenantCardProvisionalProvisioningService TenantCardProvisionalProvisioning,
        TenantCardProvisionalFinalizationService TenantCardProvisionalFinalization,
        TenantCardProvisionalRevocationService TenantCardProvisionalRevocation,
        TelegramInteractionTimeouts InteractionTimeouts = null)
    {
        _workflow = UserDbContext;
        _state = stateStore;
        _credentialsDbContext = CredentialsDbContext;
        _configuration = Configuration;
        _appConfig = Configuration.Get<AppConfig>() ?? new AppConfig();
        _purchaseService = purchaseService;
        _hooshPay = HooshPay;
        _nowPayments = NowPayments;
        _tetraminator = Tetraminator;
        _uniquePay = UniquePay;
        _atlasPay = AtlasPay;
        _atlasPayReconciliation = AtlasPayReconciliation;
        _gatewayAvailability = GatewayAvailability;
        _botRegistry = BotRegistry;
        _botClientProvider = BotClientProvider;
        _botContextAccessor = BotContextAccessor;
        _xuiV3BotFlowService = xuiV3BotFlowService;
        _walletLedgerService = WalletLedgerService;
        _salesAssistantService = SalesAssistantService;
        _gozargahSiteSyncService = GozargahSiteSyncService;
        _broadcastManager = BroadcastManager;
        _usageAnalyticsService = UsageAnalyticsService;
        _serviceProvider = ServiceProvider;
        _logger = Logger;
        _clientDownloadAvailability = ClientDownloadAvailability;
        _clientReleaseService = ClientReleaseService;
        _volumeReminderStateStore = VolumeReminderStateStore;
        _renewalOperationStore = RenewalOperationStore;
        _tenantProvisioningCoordinator = TenantProvisioningCoordinator;
        _tenantCardProvisionalProvisioning = TenantCardProvisionalProvisioning ?? throw new ArgumentNullException(nameof(TenantCardProvisionalProvisioning));
        _tenantCardProvisionalFinalization = TenantCardProvisionalFinalization ?? throw new ArgumentNullException(nameof(TenantCardProvisionalFinalization));
        _tenantCardProvisionalRevocation = TenantCardProvisionalRevocation ?? throw new ArgumentNullException(nameof(TenantCardProvisionalRevocation));
        _interactionTimeouts = InteractionTimeouts ?? TelegramInteractionTimeouts.Production;
    }

    /// <summary>
    /// checks whether callback Data belongs to the owner-side tenant management panel.
    /// </summary>
    /// <param name="Data">Raw Telegram callback Data.</param>
    /// <returns>true when the callback starts with the owner management prefix.</returns>
    public bool IsOwnerCallback(string Data)
    {
        return Data?.StartsWith(OWNERCALLBACKPREFIX, StringComparison.Ordinal) == true;
    }

    /// <summary>
    /// checks whether callback Data belongs to the tenant customer storefront.
    /// </summary>
    /// <param name="Data">Raw Telegram callback Data.</param>
    /// <returns>true when the callback starts with the customer storefront prefix.</returns>
    public bool IsCustomerCallback(string Data)
    {
        return Data?.StartsWith(CUSTOMERCALLBACKPREFIX, StringComparison.Ordinal) == true;
    }

    /// <summary>
    /// Handles Text messages from A colleague inside the Main brand Bot while CONFIGURING A tenant storefront.
    /// </summary>
    /// <param name="botClient">Telegram client of the Main brand Bot that received the Message.</param>
    /// <param name="Message">Incoming owner Message.</param>
    /// <param name="CredUser">Shared credentials profile of the sender.</param>
    /// <param name="User">Bot-scoped conversation state for the sender.</param>
    /// <param name="mainReplyMarkup">Main Menu keyboard to Use when the Flow ENDS or is Rejected.</param>
    /// <param name="CancellationToken">Cancellation Token for async Telegram/database calls.</param>
    /// <returns>true when this Message was handled by tenant setup; false when caller should continue normal routing.</returns>
    /// <remarks>
    /// Owner setup state is scoped to the current owned bot and user. OwnerStoreId persists the exact target across restart;
    /// ownership is rechecked before input is consumed. Opening the store list or selecting another store cancels pending input.
    /// The text button <c>بازگشت به پنل</c> is treated as a cancellation for any pending owner setting input,
    /// clears the temporary state, and returns the colleague to the tenant storefront panel without changing
    /// token, support, payment, card, or tutorial settings.
    /// </remarks>
    public async Task<bool> TryHandleOwnerMessageAsync(
        ITelegramBotClient botClient,
        Message Message,
        CredUser CredUser,
        User User,
        ReplyMarkup mainReplyMarkup,
        CancellationToken CancellationToken)
    {
        if (Message?.From == null || string.IsNullOrWhiteSpace(Message.Text))
            return false;
        if (CredUser != null && Message.From.Id != CredUser.TelegramUserId) return true;

        // The current owned-bot/user conversation selects a store explicitly; wallets remain keyed by owner.
        if (Message.Text == OwnerMenuButton)
        {
            if (CredUser?.IsColleague != true)
            {
                await botClient.SendMessage(
                    chatId: Message.Chat.Id,
                    text: "این بخش فقط برای همکاران فعال است.",
                    replyMarkup: mainReplyMarkup,
                    cancellationToken: CancellationToken);
                return true;
            }

            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await ShowOwnerStoreListAsync(botClient, Message.Chat.Id, CredUser, CancellationToken);
            return true;
        }

        if (!string.Equals(User?.Flow, OWNERFLOW, StringComparison.Ordinal))
            return false;

        if (CredUser?.IsColleague != true)
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await botClient.SendMessage(
                chatId: Message.Chat.Id,
                text: "این بخش فقط برای همکاران فعال است.",
                replyMarkup: mainReplyMarkup,
                cancellationToken: CancellationToken);
            return true;
        }

        _selectedOwnerStore = await _workflow.ReadAsync(db => db.BotInstances.FirstOrDefaultAsync(
            x => x.Id == User.OwnerStoreId && x.Type == BotInstanceTypes.Tenant && x.OwnerTelegramUserId == CredUser.TelegramUserId, CancellationToken));
        if (_selectedOwnerStore == null)
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await ShowOwnerStoreListAsync(botClient, Message.Chat.Id, CredUser, CancellationToken);
            return true;
        }
        botClient = new TenantOwnerPanelClient(botClient, () => _selectedOwnerStore, Message.Chat.Id);
        var step = User.LastStep ?? string.Empty;
        if (string.Equals(Message.Text.Trim(), "بازگشت به پنل", StringComparison.Ordinal))
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await botClient.SendMessage(
                Message.Chat.Id,
                "به پنل ربات فروشگاهی برگشتید.",
                replyMarkup: new ReplyKeyboardRemove(),
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, CredUser, null, CancellationToken);
            return true;
        }

        if (step == STEPTOKEN)
        {
            await SAVETENANTBOTTOKENASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPMARKUP)
        {
            await SAVETENANTMARKUPASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPSUPPORT)
        {
            await SAVETENANTSUPPORTASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPWELCOME)
        {
            await SAVETENANTWELCOMEASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPCARDNUMBER)
        {
            await SAVETENANTCARDNUMBERASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPCARDHOLDER)
        {
            await SAVETENANTCARDHOLDERASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPMANDATORYCHANNEL)
        {
            await SAVETENANTMANDATORYCHANNELASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPMANUALCARDORDERID)
        {
            await CONFIRMMANUALCARDORDERBYORDERIDASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        // Owner-configurable tutorials are disabled. A stale prompt from an old message must cancel the obsolete step
        // without writing anything into TenantTutorialsJson, then return the owner to the tenant panel.
        if (step == STEPTUTORIALTITLE || step == STEPTUTORIALURL)
        {
            await HANDLEOBSOLETETUTORIALSTEPASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        if (step == STEPBROADCASTINPUT)
        {
            await PREPARETENANTBROADCASTASYNC(botClient, Message, CredUser, CancellationToken);
            return true;
        }

        return false;
    }

    /// <summary>
    /// Handles inline callbacks from the colleague tenant management panel.
    /// </summary>
    /// <param name="botClient">Telegram client of the Main brand Bot.</param>
    /// <param name="CallbackQuery">Incoming callback Query.</param>
    /// <param name="CredUser">credentials profile of the colleague owner.</param>
    /// <param name="User">current Bot-scoped conversation state.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <returns>true when the callback belongs to tenant owner management; otherwise false.</returns>
    /// <remarks>Every store action requires its stable number, fresh revision and expiry, then an owner-scoped database lookup.
    /// Legacy unaddressed buttons only display a new list. The response decorator labels the selected store and addresses every owner keyboard.
    /// Selection clears pending input; the add button allocates a disabled independent row in a short transaction.</remarks>
    public async Task<bool> TryHandleOwnerCallbackAsync(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser CredUser,
        User User,
        CancellationToken CancellationToken)
    {
        if (!IsOwnerCallback(CallbackQuery?.Data))
            return false;

        if (CredUser?.IsColleague != true)
        {
            await SafeAnswerCallbackQueryAsync(botClient, 
                CallbackQuery.Id,
                text: "این بخش فقط برای همکاران فعال است.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return true;
        }

        var ChatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var MessageId = CallbackQuery.Message?.MessageId;

        if (CallbackQuery.From.Id != CredUser.TelegramUserId) return true;
        var stores = _serviceProvider.GetRequiredService<TenantStoreStore>();
        var addParts = CallbackQuery.Data.Split(':');
        if (addParts.Length == 4 && addParts[0] == "TBM" && addParts[1] == "add"
            && long.TryParse(addParts[2], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var addIssued)
            && addIssued >= DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 600 && addIssued <= DateTimeOffset.UtcNow.ToUnixTimeSeconds() + 60
            && Guid.TryParseExact(addParts[3], "N", out _))
        {
            var created = await stores.CreateAsync(CredUser.TelegramUserId, addParts[3], CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id,
                created == null ? "سقف تعداد فروشگاه‌ها تکمیل است؛ فروشگاه قبلی را دوباره تنظیم کنید." : "فروشگاه جدید ساخته شد.", cancellationToken: CancellationToken);
            await _state.ClearUserStatus(new User { Id = CredUser.TelegramUserId });
            await ShowOwnerStoreListAsync(botClient, ChatId, CredUser, CancellationToken);
            return true;
        }
        if (!TenantOwnerCallback.TryDecode(CallbackQuery.Data, out var storeNumber, out var storeRevision, out var action))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "فروشگاه را از فهرست تازه انتخاب کنید.", cancellationToken: CancellationToken);
            await _state.ClearUserStatus(new User { Id = CredUser.TelegramUserId });
            await ShowOwnerStoreListAsync(botClient, ChatId, CredUser, CancellationToken);
            return true;
        }
        _selectedOwnerStore = await _workflow.ReadAsync(db => db.BotInstances.FirstOrDefaultAsync(
            x => x.Type == BotInstanceTypes.Tenant && x.OwnerTelegramUserId == CredUser.TelegramUserId && x.TenantStoreNumber == storeNumber, CancellationToken));
        if (_selectedOwnerStore == null || (_selectedOwnerStore.UpdatedAtUtc ?? _selectedOwnerStore.CreatedAtUtc).Ticks != storeRevision
            || (action != "panel" && User?.OwnerStoreId != _selectedOwnerStore.Id))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "این پنل قدیمی است؛ فروشگاه را دوباره انتخاب کنید.", cancellationToken: CancellationToken);
            await _state.ClearUserStatus(new User { Id = CredUser.TelegramUserId });
            await ShowOwnerStoreListAsync(botClient, ChatId, CredUser, CancellationToken);
            return true;
        }
        if (string.IsNullOrWhiteSpace(_selectedOwnerStore.TenantOwnerNotificationBotId) &&
            await stores.EstablishOwnerNotificationRouteFromCurrentOwnedBotAsync(
                _selectedOwnerStore.Id, CredUser.TelegramUserId, CancellationToken))
            _selectedOwnerStore.TenantOwnerNotificationBotId = BotContextAccessor.CurrentBotId;

        if (action == "panel" || User?.OwnerStoreId != _selectedOwnerStore.Id)
            await _state.ClearUserStatus(new User { Id = CredUser.TelegramUserId });
        await _state.SaveUserStatus(new User { Id = CredUser.TelegramUserId, OwnerStoreId = _selectedOwnerStore.Id });
        botClient = new TenantOwnerPanelClient(botClient, () => _selectedOwnerStore, ChatId);

        if (action == "panel")
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                ChatId,
                CredUser,
                MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return true;
        }

        if (action == "reset")
        {
            await SHOWTENANTRESETCONFIRMATIONASYNC(botClient, CallbackQuery, CancellationToken);
            return true;
        }

        if (action == "reset-confirm")
        {
            await RESETTENANTSETTINGSASYNC(botClient, CallbackQuery, CredUser, CancellationToken);
            return true;
        }

        if (action.StartsWith("set-enabled:", StringComparison.Ordinal))
        {
            var parts = action.Split(':');
            if (parts.Length == 4 && TryParseTenantBoolean(parts[1], out var enabled))
            {
                await SETTENANTBOTENABLEDASYNC(
                    botClient,
                    CallbackQuery,
                    CredUser,
                    enabled,
                    parts[2],
                    parts[3],
                    CancellationToken);
                return true;
            }

            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "دکمه معتبر نیست؛ پنل را به‌روزرسانی کنید.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return true;
        }

        if (action.StartsWith("set-setting:", StringComparison.Ordinal))
        {
            var parts = action.Split(':');
            if (parts.Length == 5 && TryParseTenantBoolean(parts[2], out var enabled))
            {
                await SETTENANTSETTINGASYNC(
                    botClient,
                    CallbackQuery,
                    CredUser,
                    parts[1],
                    enabled,
                    parts[3],
                    parts[4],
                    CancellationToken);
                return true;
            }

            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "دکمه معتبر نیست؛ پنل را به‌روزرسانی کنید.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return true;
        }

        if (action == "TOGGLE" || action.StartsWith("TOGGLE:", StringComparison.Ordinal))
        {
            // Old panels used invert-state callbacks. They are intentionally read-only after deployment because a
            // delayed duplicate could otherwise undo a successful enable/disable operation.
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این دکمه قدیمی است؛ پنل جدید نمایش داده شد.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                ChatId,
                CredUser,
                MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return true;
        }

        if (action == "settlement")
        {
            await SafeAnswerCallbackQueryAsync(botClient, 
                CallbackQuery.Id,
                "برداشت در نسخه بعدی فعال می‌شود.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return true;
        }

        if (action == "orders")
        {
            await SHOWOWNERORDERSASYNC(botClient, CallbackQuery, CredUser, 0, CancellationToken);
            return true;
        }

        if (action.StartsWith("orders:", StringComparison.Ordinal))
        {
            var pageText = action["orders:".Length..];
            var page = int.TryParse(pageText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsedPage)
                ? Math.Max(0, parsedPage)
                : 0;
            await SHOWOWNERORDERSASYNC(botClient, CallbackQuery, CredUser, page, CancellationToken);
            return true;
        }

        if (action.StartsWith("order:", StringComparison.Ordinal))
        {
            await SHOWOWNERORDERDETAILASYNC(botClient, CallbackQuery, CredUser, action["order:".Length..], CancellationToken);
            return true;
        }

        if (action == "ledger")
        {
            await ShowOwnerLedgerHintAsync(botClient, CallbackQuery, CredUser, CancellationToken);
            return true;
        }

        if (action == "guide")
        {
            await SHOWOWNERGUIDEASYNC(botClient, CallbackQuery, CredUser, CancellationToken);
            return true;
        }

        if (action == "assistant-test")
        {
            await TESTSALESASSISTANTASYNC(botClient, CallbackQuery, CredUser, CancellationToken);
            return true;
        }

        if (action == "manual-card-confirm")
        {
            await STARTMANUALCARDORDERCONFIRMASYNC(botClient, CallbackQuery, CancellationToken);
            return true;
        }

        // Owner-configured tutorial links are disabled. Historical messages still carry these buttons, so every legacy
        // tutorial callback answers safely and returns without touching users.db. TenantTutorialsJson is never read or
        // rewritten here, which keeps a later rollback to owner-configurable tutorials possible.
        if (action == "tutorials" || action == "tutorial-add" || action.StartsWith("tutorial-del:", StringComparison.Ordinal))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                TENANTTUTORIALMANAGERDISABLEDMESSAGE,
                showAlert: true,
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(botClient, CallbackQuery.Message.Chat.Id, CredUser, null, CancellationToken);
            return true;
        }

        if (action == "broadcast")
        {
            await STARTTENANTBROADCASTASYNC(botClient, CallbackQuery, CancellationToken);
            return true;
        }

        if (action.StartsWith("broadcast-send:", StringComparison.Ordinal))
        {
            await SENDTENANTBROADCASTASYNC(botClient, CallbackQuery, CredUser, action["broadcast-send:".Length..], CancellationToken);
            return true;
        }

        if (action == "stats")
        {
            await SHOWTENANTDAILYSTATSASYNC(botClient, CallbackQuery, CredUser, CancellationToken);
            return true;
        }

        if (action.StartsWith("set:", StringComparison.Ordinal))
        {
            var field = action.Replace("set:", "", StringComparison.Ordinal);
            await STARTOWNERINPUTASYNC(botClient, CallbackQuery, field, CancellationToken);
            return true;
        }

        return true;
    }

    /// <summary>
    /// Handles an update received by A tenant storefront Bot.
    /// tenant bots do not expose the Main Bot menus; this method CONSUMES their messages and callbacks.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant Bot that received the update.</param>
    /// <param name="update">Raw Telegram update.</param>
    /// <param name="CredUser">Shared credentials profile of the customer.</param>
    /// <param name="User">Bot-scoped conversation state for the customer.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <returns>true when current Bot is A tenant Bot and update has been handled; otherwise false.</returns>
    /// <remarks>
    /// Fresh shared-owner suspension and funding are checked before all message/callback actions. Receivers remain
    /// active to report restrictions; existing paid webhook fulfillment does not enter this customer access gate.
    /// Account renewal callbacks are intercepted before the shared XUI dispatcher so tenant customers always create a
    /// tenant-priced order and never enter the owned-wallet flow. State cleanup and UUID target lock remain scoped to the
    /// current tenant bot plus Telegram user; no other bot's state is read or changed.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (await tenantBotService.TryHandleTenantUpdateAsync(
    ///         botClient, update, credentialUser, botScopedUser, cancellationToken))
    ///     return;
    /// </code>
    /// </example>
    public async Task<bool> TryHandleTenantUpdateAsync(
        ITelegramBotClient botClient,
        Update update,
        CredUser CredUser,
        User User,
        CancellationToken CancellationToken)
    {
        if (!string.Equals(BotContextAccessor.CurrentBotType, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase))
            return false;

        // tenant bots expose A SMALL storefront only; they should not FALL through to the Main Bot Menu.
        if (update.Message != null || update.CallbackQuery != null)
        {
            var storefront = await GetCurrentTenantBotAsync(CancellationToken);
            TenantAccessEvaluation accessEvaluation = null;
            if (storefront?.OwnerTelegramUserId is long ownerId)
                accessEvaluation = await _serviceProvider.GetRequiredService<TenantAccessService>()
                    .EvaluateDecisionAsync(ownerId, CancellationToken);
            var restriction = accessEvaluation?.RestrictionMessage ??
                              (storefront?.OwnerTelegramUserId is null ? "فروشگاه در حال حاضر غیرفعال است." : null);
            if (restriction == null && storefront?.Enabled != true)
                restriction = "فروشگاه در حال حاضر غیرفعال است.";
            if (storefront != null && accessEvaluation != null)
                await OBSERVETENANTSTOREFRONTACCESSBESTEFFORTASYNC(storefront, accessEvaluation, CancellationToken);
            if (restriction != null)
            {
                if (update.CallbackQuery is { } blockedCallback)
                    await SafeAnswerCallbackQueryAsync(botClient, blockedCallback.Id, restriction,
                        showAlert: true, cancellationToken: CancellationToken);
                else
                    await botClient.SendMessage(update.Message.Chat.Id, restriction,
                        replyMarkup: new ReplyKeyboardRemove(), cancellationToken: CancellationToken);
                return true;
            }
        }
        if (update.CallbackQuery is { } CallbackQuery)
        {
            var tenant = await GetCurrentTenantBotAsync(CancellationToken);
            if (tenant != null)
                await TouchTenantCustomerStateAsync(tenant, CallbackQuery.From.Id, CancellationToken);

            // Latest-client-software downloads share one callback namespace with the owned bot so both storefront
            // families behave identically. Only the three compile-time platforms can be selected, and the handler
            // re-checks the live global switch so a stale inline button fails closed without contacting GitHub.
            if (ClientDownloadCallbacks.TryParse(CallbackQuery.Data, out var downloadPlatform))
            {
                await HandleClientDownloadPlatformCallbackAsync(botClient, CallbackQuery, downloadPlatform, CancellationToken);
                return true;
            }

            if (IsCustomerCallback(CallbackQuery.Data))
            {
                await HANDLECUSTOMERCALLBACKASYNC(botClient, CallbackQuery, CredUser, User, CancellationToken);
                return true;
            }

            if (XuiV3PurchaseCallbacks.TryParse(CallbackQuery.Data, out var xuiCallback) &&
                IsTenantRenewCallbackAction(xuiCallback.Action))
            {
                await HANDLETENANTRENEWFROMCALLBACKASYNC(
                    botClient,
                    CallbackQuery,
                    xuiCallback,
                    tenant,
                    CredUser,
                    User,
                    CancellationToken);
                return true;
            }

            // Account-management keyboards are produced by XuiV3BotFlowService and do not use the tenant
            // callback prefix. Route them to the shared flow under the current tenant bot context instead of
            // falling through to owned-bot menus.
            await _xuiV3BotFlowService.TryHandleCallbackAsync(
                botClient,
                CallbackQuery,
                CredUser,
                User,
                BuildTenantReplyKeyboard(),
                CancellationToken);
            return true;
        }

        if (update.Message is not { } Message || Message.From == null)
            return true;

        var messageTenant = await GetCurrentTenantBotAsync(CancellationToken);
        if (messageTenant != null)
            await TouchTenantCustomerStateAsync(messageTenant, Message.From.Id, CancellationToken);

        // The download menu is high-level navigation for tenant customers too. It is answered before the storefront
        // conversation state can consume the label as purchase, duration, account, or receipt input, and it
        // deliberately mutates no order, payment, wallet, tenant, or XUI state.
        if (await TryHandleClientDownloadMenuRequestAsync(botClient, Message, CancellationToken))
            return true;

        await HANDLECUSTOMERMESSAGEASYNC(botClient, Message, CredUser, User, CancellationToken);
        return true;
    }

    /// <summary>
    /// Checks whether a shared XUI callback starts an account renewal that must remain inside the tenant order flow.
    /// </summary>
    /// <param name="action">Compact XUI callback action parsed from Telegram callback data.</param>
    /// <returns>
    /// <c>true</c> for owned-list, owned-search, state-bound warning confirmation, or exact-identifier renewal callbacks; otherwise
    /// <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Tenant callbacks are intercepted before <see cref="XuiV3BotFlowService.TryHandleCallbackAsync"/> so they can
    /// never fall into the owned-bot wallet flow. The callback action is routing data only and grants no account access.
    /// </remarks>
    private static bool IsTenantRenewCallbackAction(string action)
    {
        return string.Equals(action, "aren", StringComparison.Ordinal) ||
               string.Equals(action, "asren", StringComparison.Ordinal) ||
               string.Equals(action, "auren", StringComparison.Ordinal) ||
               string.Equals(action, "rgo", StringComparison.Ordinal);
    }

    /// <summary>
    /// Starts a tenant renewal from an account card after reloading and authorizing the selected panel client.
    /// </summary>
    /// <param name="botClient">Telegram client of the tenant storefront that received the callback.</param>
    /// <param name="callbackQuery">Callback containing only the numeric panel client id and source-list page.</param>
    /// <param name="callback">Parsed XUI routing values; UUID and SubId values are never carried here.</param>
    /// <param name="tenant">Current tenant bot row, or <c>null</c> when the bot is no longer configured.</param>
    /// <param name="customer">Credential profile of the customer who pressed the renewal button.</param>
    /// <param name="user">Bot-scoped state used to validate direct UUID/SubId search callbacks.</param>
    /// <param name="cancellationToken">Token that cancels Telegram, users.db, and panel operations.</param>
    /// <returns>A task that completes after safe rejection or delivery of the tenant renewal selection keyboard.</returns>
    /// <remarks>
    /// Normal list/search callbacks remain owner-checked because a numeric id is not an identifier proof. The
    /// <c>auren</c> callback requires saved exact-identifier search state, while <c>rgo</c> requires the persisted
    /// third-party warning state. Every selected target stores a fresh UUID separately from payment choice. These
    /// callbacks grant renewal only and never configuration, mutation, or ownership access. Before a selector is shown,
    /// the per-email detail comment is read and identity-checked so a positive-expiry unlimited account sharing normal
    /// inbounds cannot be misclassified from an incomplete list row.
    /// </remarks>
    private async Task HANDLETENANTRENEWFROMCALLBACKASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        XuiV3PurchaseCallback callback,
        BotInstance tenant,
        CredUser customer,
        User user,
        CancellationToken cancellationToken)
    {
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);

        var chatId = callbackQuery.Message?.Chat.Id ?? customer.ChatID;
        if (tenant == null || !tenant.Enabled)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "فروشگاه در حال حاضر غیرفعال است.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (string.Equals(callback.Action, "rgo", StringComparison.Ordinal))
        {
            await HANDLETENANTEXTERNALRENEWTARGETCONFIRMATIONASYNC(
                botClient,
                chatId,
                callbackQuery.Message?.MessageId ?? 0,
                tenant,
                customer,
                user,
                cancellationToken);
            return;
        }

        var allowExternalRenew = string.Equals(callback.Action, "auren", StringComparison.Ordinal);
        var client = await _xuiV3BotFlowService.ResolveRenewCallbackTargetAsync(
            user,
            customer.TelegramUserId,
            callback.ClientId,
            allowExternalRenew,
            cancellationToken);

        if (client == null ||
            (!allowExternalRenew && !ClientBelongsToTenantCustomer(client, customer.TelegramUserId, tenant.Id)))
        {
            _logger.LogWarning(
                "Tenant renewal callback authorization failed. tenantBotId={TenantBotId}, userId={UserId}, clientId={ClientId}, action={Action}",
                tenant.Id,
                customer.TelegramUserId,
                callback.ClientId,
                callback.Action);
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                allowExternalRenew
                    ? "درخواست تمدید معتبر نیست. UUID یا لینک دارای UUID را دوباره از بخش جستجو ارسال کنید."
                    : "اکانت مورد نظر برای تمدید پیدا نشد یا متعلق به حساب شما در این فروشگاه نیست.",
                allowSearchRestart: allowExternalRenew,
                cancellationToken);
            return;
        }

        var serviceResolution = await ResolveTenantRenewalServiceAsync(
            BuildConfiguredPanelServerInfo(),
            client,
            cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            selectedServiceKey: null,
            storedResolutionMode: null,
            out var service,
            out var resolutionMode,
            out var candidateServices);
        if (!serviceAuthorized && !serviceResolution.RequiresCustomerSelection)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: allowExternalRenew,
                cancellationToken);
            return;
        }

        var belongsToCustomer = ClientBelongsToTenantCustomer(client, customer.TelegramUserId, tenant.Id);
        if (!TryNormalizeTenantClientUuid(client.Uuid, out var targetUuid) && !belongsToCustomer)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "UUID اکانت در پاسخ پنل معتبر نیست و تمدید امن آن ممکن نشد.",
                allowSearchRestart: true,
                cancellationToken);
            return;
        }


        if (!belongsToCustomer)
        {
            await SAVETENANTEXTERNALRENEWWARNINGASYNC(
                botClient,
                chatId,
                customer.TelegramUserId,
                client,
                service,
                resolutionMode,
                targetUuid,
                callbackQuery.Message?.MessageId ?? 0,
                cancellationToken);
            return;
        }

        if (!serviceAuthorized)
        {
            await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                botClient,
                chatId,
                customer.TelegramUserId,
                client,
                candidateServices,
                targetUuid,
                callbackQuery.Message?.MessageId ?? 0,
                cancellationToken);
            return;
        }

        await _state.ClearUserStatus(new User { Id = customer.TelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = customer.TelegramUserId,
            Flow = TENANTRENEWFLOW,
            LastStep = service.IsUnlimited ? TENANTRENEWSTEPUNLIMITEDPLAN : TENANTRENEWSTEPTRAFFIC,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = targetUuid,
            RenewalServiceResolutionMode = resolutionMode,
            PaymentMethod = "credit"
        });

        var navigationKeyboard = allowExternalRenew
            ? new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart()) },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            })
            : new InlineKeyboardMarkup(new[]
            {
                new[]
                {
                    InlineKeyboardButton.WithCallbackData(
                        string.Equals(callback.Action, "asren", StringComparison.Ordinal)
                            ? "بازگشت به نتایج جستجو"
                            : "بازگشت به لیست اکانت‌ها",
                        string.Equals(callback.Action, "asren", StringComparison.Ordinal)
                            ? XuiV3PurchaseCallbacks.AccountSearchList(callback.Page ?? 0)
                            : XuiV3PurchaseCallbacks.AccountList(callback.Page ?? 0))
                },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
            });

        var selectedText =
            $"اکانت انتخاب شد: <code>{Html(client.Email)}</code>\n" +
            (service.IsUnlimited
                ? "پلن تمدید نامحدود را انتخاب کنید."
                : "حجم تمدید را انتخاب کنید یا حجم دلخواه را به GB وارد کنید.");

        if (callbackQuery.Message != null)
        {
            await SafeEditMessageTextAsync(
                botClient,
                callbackQuery.Message.Chat.Id,
                callbackQuery.Message.MessageId,
                selectedText,
                ParseMode.Html,
                navigationKeyboard,
                cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId,
                selectedText,
                parseMode: ParseMode.Html,
                replyMarkup: navigationKeyboard,
                cancellationToken: cancellationToken);
        }

        await botClient.SendMessage(
            chatId,
            service.IsUnlimited
                ? "یکی از پلن‌های زیر را انتخاب کنید:"
                : $"یکی از حجم‌های زیر را انتخاب کنید یا عدد دلخواه بفرستید.\nحداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(service)} GB است.",
            replyMarkup: service.IsUnlimited
                ? BuildTenantRenewUnlimitedKeyboard(service, tenant)
                : BuildTenantRenewTrafficKeyboard(service),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Clears tenant-scoped renewal state before sending a terminal result with safe callback navigation.
    /// </summary>
    /// <param name="botClient">Tenant Telegram client used to send the terminal result.</param>
    /// <param name="chatId">Telegram chat id of the customer whose renewal ended.</param>
    /// <param name="telegramUserId">Numeric customer Telegram id whose state belongs to the current tenant bot.</param>
    /// <param name="text">Persian customer-facing result text; it must not contain panel secrets or raw exceptions.</param>
    /// <param name="allowSearchRestart">Whether a direct-search restart button should be shown above Home.</param>
    /// <param name="cancellationToken">Token that cancels users.db cleanup and Telegram delivery.</param>
    /// <returns>A task that completes after state cleanup and message delivery.</returns>
    /// <remarks>
    /// Cleanup is bot-scoped through the active tenant context. It removes only temporary conversation state and does
    /// not change wallets, orders, account ownership, or panel data.
    /// </remarks>
    private async Task SendTenantRenewTerminalAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        long telegramUserId,
        string text,
        bool allowSearchRestart,
        CancellationToken cancellationToken)
    {
        await _state.ClearUserStatus(new User { Id = telegramUserId });
        var rows = new List<InlineKeyboardButton[]>();
        if (allowSearchRestart)
        {
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData("جستجوی جدید", XuiV3PurchaseCallbacks.AccountSearchStart())
            });
        }

        rows.Add(new[]
        {
            InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home())
        });

        await botClient.SendMessage(
            chatId,
            text,
            replyMarkup: new InlineKeyboardMarkup(rows),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Ensures a tenant customer has a bot-scoped state row so tenant broadcasts can target everyone who started the storefront.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot that received the Telegram update. The tenant id is the local runtime id, not the Telegram bot id.
    /// </param>
    /// <param name="telegramUserId">
    /// Numeric Telegram user id from the incoming message or callback sender. This value is tenant-scoped with
    /// <paramref name="tenant"/> and is used as the broadcast audience key.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the users.db lookup and write when the update receiver is shutting down.
    /// </param>
    /// <returns>A task that completes after the state row has been inserted or touched.</returns>
    /// <remarks>
    /// This method deliberately does not call <see cref="UserDbContext.SaveUserStatus(User)"/> because that
    /// method applies partial legacy flow updates. Broadcast audience tracking must not overwrite purchase,
    /// renewal, receipt-upload, or comment-change state; it only creates a missing row or updates the timestamp.
    /// </remarks>
    private async Task TouchTenantCustomerStateAsync(BotInstance tenant, long telegramUserId, CancellationToken cancellationToken)
    {
        if (tenant == null || string.IsNullOrWhiteSpace(tenant.Id) || telegramUserId <= 0)
            return;

        var existing = await _workflow.ReadAsync(async db => await db.BotUserStates.FirstOrDefaultAsync(
            x => x.BotId == tenant.Id && x.TelegramUserId == telegramUserId,
            cancellationToken));

        if (existing == null)
        {
            _workflow.Add(BotUserState.FromUser(tenant.Id, new User { Id = telegramUserId }));
        }
        else
        {
            existing.UpdatedAtUtc = DateTime.UtcNow;
        }

        await _workflow.SaveAsync(cancellationToken);
    }

    /// <summary>
    /// sends or edits the owner management panel that SHOWS Token, Username, support, WELCOME Text, markup, and enabled state.
    /// </summary>
    /// <param name="botClient">Telegram client used to Send/edit the panel.</param>
    /// <param name="ChatId">owner chat Id.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="MessageId">Message Id to edit; null sends A new Message.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <param name="CurrentMessage">
    /// Optional callback message currently visible in Telegram. When its rendered text and inline keyboard already
    /// equal the new panel, the edit request is skipped to avoid Telegram's <c>message is not modified</c> response.
    /// </param>
    /// <remarks>
    /// Opening or refreshing the panel probes an existing tenant bot token with Telegram <c>getMe</c>. If Telegram
    /// proves the token is revoked or unauthorized, the method clears only the token identity fields and disables
    /// the tenant bot before rendering, while preserving card, support, tutorial, and historical order settings.
    /// Transient Telegram failures are shown as a warning and never clear the owner configuration.
    /// </remarks>
    private async Task SHOWOWNERPANELASYNC(
        ITelegramBotClient botClient,
        ChatId ChatId,
        CredUser owner,
        int? MessageId,
        CancellationToken CancellationToken,
        Message CurrentMessage = null)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, CancellationToken);
        var tokenNotice = await VALIDATETENANTTOKENFORPANELASYNC(tenant, CancellationToken);
        await _state.SaveUserStatus(new User { Id = owner.TelegramUserId, OwnerStoreId = tenant.Id });
        var Text = BUILDOWNERPANELTEXT(tenant, owner, tokenNotice);
        var keyboard = BUILDOWNERPANELKEYBOARD(tenant);

        if (MessageId.HasValue)
        {
            if (IsSameTenantPanel(CurrentMessage, Text, keyboard))
                return;

            await SafeEditMessageTextAsync(
                botClient,
                chatId: ChatId,
                messageId: MessageId.Value,
                text: Text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: CancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId: ChatId,
            text: Text,
            parseMode: ParseMode.Html,
            replyMarkup: keyboard,
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Builds the owner management panel Text from the persisted tenant Bot row.
    /// </summary>
    /// <param name="tenant">current tenant Bot row, or null if the owner has not created one yet.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="tokenNotice">Optional HTML-safe status line produced by token validation before panel rendering.</param>
    /// <returns>Html-formatted panel Text.</returns>
    /// <remarks>
    /// Gateway status combines tenant preferences with live global switches. When a gateway is disabled globally, the
    /// panel reports <c>سراسری خاموش</c> without changing the tenant's persisted preference.
    /// </remarks>
    private string BUILDOWNERPANELTEXT(BotInstance tenant, CredUser owner, string tokenNotice = null)
    {
        var hasToken = !string.IsNullOrWhiteSpace(tenant?.Token);
        var IsEnabled = tenant?.Enabled == true;
        var Username = string.IsNullOrWhiteSpace(tenant?.Username) ? "ثبت نشده" : "@" + tenant.Username.TrimStart('@');
        var support = string.IsNullOrWhiteSpace(tenant?.SupportAccount) ? "ثبت نشده" : tenant.SupportAccount;
        var markup = tenant?.TenantPriceMarkupPercent ?? 0;
        var card = tenant?.TenantCardPaymentEnabled == true && !string.IsNullOrWhiteSpace(tenant.TenantCardNumber)
            ? $"{tenant.TenantCardNumber} - {tenant.TenantCardHolderName}"
            : "ثبت نشده/خاموش";
        var TENANTJOIN = tenant?.TenantMandatoryJoinEnabled == true
            ? $"روشن ({string.Join(", ", GETTENANTCHANNELIDS(tenant))})"
            : "خاموش";
        var WELCOME = string.IsNullOrWhiteSpace(tenant?.TenantWelcomeText) ? "ثبت نشده" : "ثبت شده";

        var text = "🛒 <b>ربات فروشگاهی همکار</b>\n\n" +
                   "کیف پول ربات و حساب گذرگاه شما بین تمام فروشگاه‌ها مشترک است. تنظیمات این پنل فقط برای همین فروشگاه است.\n\n" +
                   "با این بخش می‌توانید ربات فروشگاهی خودتان را با توکن BotFather فعال کنید. مشتری‌ها داخل همان ربات خرید می‌کنند، بعد از پرداخت موفق اکانت ساخته می‌شود و سود سفارش به موجودی شما اضافه می‌شود.\n\n";

        if (!string.IsNullOrWhiteSpace(tokenNotice))
            text += tokenNotice + "\n\n";

        return text +
               $"{STATUSICON(hasToken)} توکن ربات: <code>{Html(hasToken ? "ثبت شده" : "ثبت نشده")}</code>\n" +
               $"{STATUSICON(hasToken)} یوزرنیم ربات: <code>{Html(Username)}</code>\n" +
               $"{STATUSICON(true)} درصد سود روی قیمت همکار: <code>{markup}%</code>\n" +
               $"{STATUSICON(!string.IsNullOrWhiteSpace(tenant?.SupportAccount))} پشتیبانی فروشگاه: <code>{Html(support)}</code>\n" +
               $"{STATUSICON(!string.IsNullOrWhiteSpace(tenant?.TenantWelcomeText))} متن خوشامد: <code>{Html(WELCOME)}</code>\n" +
               $"{STATUSICON(_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) && tenant?.TenantHooshPayEnabled == true)} درگاه هوش‌پی: <b>{Html(!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) ? "سراسری خاموش" : tenant?.TenantHooshPayEnabled == true ? "روشن" : "خاموش")}</b>\n" +
               $"{STATUSICON(_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator) && tenant?.TenantTetraminatorEnabled == true)} درگاه تترامیناتور: <b>{Html(!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator) ? "سراسری خاموش" : tenant?.TenantTetraminatorEnabled == true ? "روشن" : "خاموش")}</b>\n" +
               $"{STATUSICON(_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) && tenant?.TenantUniquePayEnabled == true)} درگاه یونیک‌پی (۱۲٪): <b>{Html(!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) ? "سراسری خاموش" : tenant?.TenantUniquePayEnabled == true ? "روشن" : "خاموش")}</b>\n" +
               $"{STATUSICON(_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay) && tenant?.TenantAtlasPayEnabled == true)} درگاه اطلس‌پی: <b>{Html(!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay) ? "سراسری خاموش" : tenant?.TenantAtlasPayEnabled == true ? "روشن" : "خاموش")}</b>\n" +
               $"{STATUSICON(_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) && tenant?.TenantNowPaymentsEnabled == true)} درگاه ارز دیجیتال: <b>{Html(!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) ? "سراسری خاموش" : tenant?.TenantNowPaymentsEnabled == true ? "روشن" : "خاموش")}</b>\n" +
               $"{STATUSICON(tenant?.TenantCardPaymentEnabled == true)} کارت به کارت همکار: <code>{Html(card)}</code>\n" +
               $"{STATUSICON(tenant?.TenantMandatoryJoinEnabled == true)} جوین اجباری فروشگاه: <code>{Html(TENANTJOIN)}</code>\n" +
               $"{STATUSICON(IsEnabled)} وضعیت: <b>{Html(IsEnabled ? "روشن" : "خاموش")}</b>\n\n" +
               "اگر درصد سود را صفر بگذارید، قیمت فروش با تعرفه کاربر عادی محاسبه می‌شود و سود شما اختلاف قیمت کاربر عادی و قیمت همکار خواهد بود.";
    }

    /// <summary>
    /// Builds inline buttons for EDITING tenant settings and TOGGLING storefront status.
    /// </summary>
    /// <param name="tenant">current tenant Bot row.</param>
    /// <returns>inline keyboard for the owner panel.</returns>
    private static InlineKeyboardMarkup BUILDOWNERPANELKEYBOARD(BotInstance tenant)
    {
        var IsEnabled = tenant?.Enabled == true;
        var HOOSHPAYENABLED = tenant?.TenantHooshPayEnabled == true;
        var TETRAMINATORENABLED = tenant?.TenantTetraminatorEnabled == true;
        var NOWPAYMENTSENABLED = tenant?.TenantNowPaymentsEnabled == true;
        var UNIQUEPAYENABLED = tenant?.TenantUniquePayEnabled == true;
        var ATLASPAYENABLED = tenant?.TenantAtlasPayEnabled == true;
        var CARDENABLED = tenant?.TenantCardPaymentEnabled == true;
        var JOINENABLED = tenant?.TenantMandatoryJoinEnabled == true;
        var revision = BuildTenantPanelRevision(tenant);
        var currentUnixSeconds = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var issuedAt = (currentUnixSeconds - currentUnixSeconds % 300).ToString("X", CultureInfo.InvariantCulture);

        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🤖 ثبت/تغییر توکن", OWNERCALLBACKPREFIX + "set:Token"),
                InlineKeyboardButton.WithCallbackData("📈 درصد سود", OWNERCALLBACKPREFIX + "set:markup")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("💬 پشتیبانی", OWNERCALLBACKPREFIX + "set:support"),
                InlineKeyboardButton.WithCallbackData("👋 متن خوشامد", OWNERCALLBACKPREFIX + "set:WELCOME")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("💳 شماره کارت", OWNERCALLBACKPREFIX + "set:card-number"),
                InlineKeyboardButton.WithCallbackData("👤 صاحب کارت", OWNERCALLBACKPREFIX + "set:card-HOLDER")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(CARDENABLED ? "✅ کارت‌به‌کارت" : "❌ کارت‌به‌کارت", BuildTenantSettingCallback("card", !CARDENABLED, revision, issuedAt)),
                InlineKeyboardButton.WithCallbackData(HOOSHPAYENABLED ? "✅ هوش‌پی" : "❌ هوش‌پی", BuildTenantSettingCallback("HooshPay", !HOOSHPAYENABLED, revision, issuedAt))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(TETRAMINATORENABLED ? "✅ تترامیناتور" : "❌ تترامیناتور", BuildTenantSettingCallback("Tetraminator", !TETRAMINATORENABLED, revision, issuedAt)),
                InlineKeyboardButton.WithCallbackData(NOWPAYMENTSENABLED ? "✅ ارز دیجیتال" : "❌ ارز دیجیتال", BuildTenantSettingCallback("NowPayments", !NOWPAYMENTSENABLED, revision, issuedAt))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(UNIQUEPAYENABLED ? "✅ یونیک‌پی ۱۲٪" : "❌ یونیک‌پی ۱۲٪", BuildTenantSettingCallback("UniquePay", !UNIQUEPAYENABLED, revision, issuedAt)),
                InlineKeyboardButton.WithCallbackData(ATLASPAYENABLED ? "✅ اطلس‌پی" : "❌ اطلس‌پی", BuildTenantSettingCallback("AtlasPay", !ATLASPAYENABLED, revision, issuedAt))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(JOINENABLED ? "✅ جوین اجباری" : "❌ جوین اجباری", BuildTenantSettingCallback("join", !JOINENABLED, revision, issuedAt))
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("📣 کانال جوین", OWNERCALLBACKPREFIX + "set:mandatory-channel"),
                InlineKeyboardButton.WithCallbackData("🧾 سفارش‌ها", OWNERCALLBACKPREFIX + "orders")
            },
            new[]
            {
                // The owner-configurable tutorial manager is intentionally not offered anymore: customer tutorials are
                // now the built-in, system-provided albums. The legacy callback handlers stay reachable as safe no-ops so
                // a stale button in an old Telegram message cannot mutate tenant tutorial data.
                InlineKeyboardButton.WithCallbackData("📢 پیام عمومی", OWNERCALLBACKPREFIX + "broadcast")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("📊 آمار روزانه", OWNERCALLBACKPREFIX + "stats"),
                InlineKeyboardButton.WithCallbackData("📒 تراکنش‌ها", OWNERCALLBACKPREFIX + "ledger"),
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("💸 تسویه حساب", OWNERCALLBACKPREFIX + "settlement"),
                InlineKeyboardButton.WithCallbackData("📘 راهنمای پنل همکاری", OWNERCALLBACKPREFIX + "guide")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🧪 تست دستیار فروش", OWNERCALLBACKPREFIX + "assistant-test"),
                InlineKeyboardButton.WithCallbackData("✅ تایید دستی کارت‌به‌کارت", OWNERCALLBACKPREFIX + "manual-card-confirm")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("🔄 بروزرسانی", OWNERCALLBACKPREFIX + "panel")
            },
            new[] { InlineKeyboardButton.WithCallbackData("🏪 فهرست فروشگاه‌ها", "TBM:list") },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("♻️ بازنشانی تنظیمات ربات", OWNERCALLBACKPREFIX + "reset")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    IsEnabled ? "⛔ خاموش کردن فروشگاه" : "✅ روشن کردن فروشگاه",
                    $"{OWNERCALLBACKPREFIX}set-enabled:{(IsEnabled ? 0 : 1)}:{revision}:{issuedAt}")
            }
        });
    }

    /// <summary>
    /// Builds the optimistic-concurrency revision embedded in tenant owner mutation callbacks.
    /// </summary>
    /// <param name="tenant">Persisted tenant row whose current settings are represented by the keyboard.</param>
    /// <returns>
    /// Uppercase hexadecimal UTC tick value derived from the row's latest update, or <c>0</c> for a not-yet-created row.
    /// </returns>
    /// <remarks>
    /// The revision is non-secret and remains well below Telegram's callback-data limit. Mutating callbacks must
    /// compare it with a freshly loaded row before writing, preventing delayed buttons from an older panel from
    /// undoing newer owner settings.
    /// </remarks>
    private static string BuildTenantPanelRevision(BotInstance tenant)
    {
        if (tenant == null)
            return "0";

        return (tenant.UpdatedAtUtc ?? tenant.CreatedAtUtc).Ticks.ToString("X", CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Builds an idempotent target-state callback for one tenant storefront setting.
    /// </summary>
    /// <param name="setting">Stable setting key: card, HooshPay, Tetraminator, NowPayments, or join.</param>
    /// <param name="enabled">Desired final state rather than an instruction to invert the current value.</param>
    /// <param name="revision">Panel revision returned by <see cref="BuildTenantPanelRevision" />.</param>
    /// <param name="issuedAt">Hexadecimal Unix timestamp rounded to the keyboard's five-minute render bucket.</param>
    /// <returns>Tenant owner callback data containing the setting, target state, revision, and issue timestamp.</returns>
    private static string BuildTenantSettingCallback(string setting, bool enabled, string revision, string issuedAt)
        => $"{OWNERCALLBACKPREFIX}set-setting:{setting}:{(enabled ? 1 : 0)}:{revision}:{issuedAt}";

    /// <summary>
    /// Parses a compact target-state value from Telegram callback data.
    /// </summary>
    /// <param name="value">Callback token; only <c>1</c> and <c>0</c> are accepted.</param>
    /// <param name="enabled">Receives the desired boolean state when parsing succeeds.</param>
    /// <returns><c>true</c> for an exact supported value; otherwise <c>false</c>.</returns>
    private static bool TryParseTenantBoolean(string value, out bool enabled)
    {
        enabled = string.Equals(value, "1", StringComparison.Ordinal);
        return enabled || string.Equals(value, "0", StringComparison.Ordinal);
    }

    /// <summary>
    /// Checks whether a tenant mutation callback was rendered recently enough to change persisted settings.
    /// </summary>
    /// <param name="issuedAt">Hexadecimal Unix timestamp embedded in the callback data.</param>
    /// <returns>
    /// <c>true</c> when the timestamp is valid, is not materially in the future, and is at most ten minutes old;
    /// otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Telegram may deliver callbacks queued while a bot was offline after their answer TTL has expired. This
    /// timestamp prevents those delayed buttons from changing financial, gateway, join, or runtime settings.
    /// </remarks>
    private static bool IsTenantMutationCallbackFresh(string issuedAt)
    {
        if (!long.TryParse(issuedAt, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var unixSeconds))
            return false;

        var age = DateTimeOffset.UtcNow - DateTimeOffset.FromUnixTimeSeconds(unixSeconds);
        return age >= TimeSpan.FromMinutes(-1) && age <= TimeSpan.FromMinutes(10);
    }

    /// <summary>
    /// Determines whether an owner panel callback message already contains the requested text and inline keyboard.
    /// </summary>
    /// <param name="currentMessage">Current Telegram callback message, or null for send-only flows.</param>
    /// <param name="htmlText">New HTML panel text before Telegram entity rendering.</param>
    /// <param name="keyboard">New inline keyboard that would be attached to the panel.</param>
    /// <returns>
    /// <c>true</c> when rendered plain text and serialized reply markup are equal, allowing the edit API call to be skipped.
    /// </returns>
    /// <remarks>
    /// Telegram returns HTTP 400 for no-op edits. Comparing the callback message before calling Telegram removes the
    /// avoidable request; the existing safe exception guard remains for edits whose remote state changed concurrently.
    /// </remarks>
    private static bool IsSameTenantPanel(
        Message currentMessage,
        string htmlText,
        InlineKeyboardMarkup keyboard)
    {
        if (currentMessage == null)
            return false;

        var renderedText = System.Text.RegularExpressions.Regex.Replace(
            htmlText ?? string.Empty,
            "<[^>]+>",
            string.Empty,
            System.Text.RegularExpressions.RegexOptions.CultureInvariant);
        renderedText = WebUtility.HtmlDecode(renderedText);

        return string.Equals(currentMessage.Text ?? string.Empty, renderedText, StringComparison.Ordinal) &&
               string.Equals(
                   JsonConvert.SerializeObject(currentMessage.ReplyMarkup),
                   JsonConvert.SerializeObject(keyboard),
                   StringComparison.Ordinal);
    }

    /// <summary>
    /// Shows the destructive reset confirmation for the tenant owner panel.
    /// </summary>
    /// <param name="botClient">
    /// Owned-brand Telegram client that received the owner callback and can edit the panel message.
    /// </param>
    /// <param name="CallbackQuery">
    /// Callback query from the colleague owner. The callback message is edited in-place when possible.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel Telegram edit and callback-answer operations when the update pipeline stops.
    /// </param>
    /// <remarks>
    /// Reset removes every owner-configured tenant storefront setting and disables the tenant bot, so this
    /// method always asks for a second confirmation before <see cref="RESETTENANTSETTINGSASYNC" /> can run.
    /// </remarks>
    private async Task SHOWTENANTRESETCONFIRMATIONASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CancellationToken CancellationToken)
    {
        var chatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var messageId = CallbackQuery.Message?.MessageId;
        var keyboard = new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("✅ تایید بازنشانی", OWNERCALLBACKPREFIX + "reset-confirm")
            },
            new[]
            {
                InlineKeyboardButton.WithCallbackData("↩️ برگشت به پنل", OWNERCALLBACKPREFIX + "panel")
            }
        });

        const string text =
            "♻️ <b>بازنشانی تنظیمات ربات فروشگاهی</b>\n\n" +
            "با تایید این گزینه، توکن ربات، یوزرنیم ربات، پشتیبانی، متن خوشامد، کارت‌به‌کارت، جوین اجباری، آموزش‌ها و تنظیمات درگاه‌های فروشگاه پاک می‌شود و ربات فروشگاهی خاموش خواهد شد.\n\n" +
            "سوابق سفارش‌ها، رسیدها، پرداخت‌ها، تراکنش‌ها و کاربران قبلی حذف نمی‌شوند.";

        if (messageId.HasValue)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId,
                messageId.Value,
                text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: CancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId,
                text,
                parseMode: ParseMode.Html,
                replyMarkup: keyboard,
                cancellationToken: CancellationToken);
        }

        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Resets all owner-configured storefront settings and disables the colleague tenant bot.
    /// </summary>
    /// <param name="botClient">
    /// Owned-brand Telegram client used to edit the owner panel after the reset has been persisted.
    /// </param>
    /// <param name="CallbackQuery">
    /// Confirmation callback from the tenant owner. The sender must be the colleague who owns the tenant row.
    /// </param>
    /// <param name="owner">
    /// Shared credentials profile of the colleague owner whose tenant settings must be reset.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel users.db writes, runtime stop, cache invalidation, and Telegram replies.
    /// </param>
    /// <remarks>
    /// This method intentionally resets only the mutable storefront configuration stored on <see cref="BotInstance" />.
    /// It preserves the tenant internal id, owner Telegram id, orders, receipts, ledger entries, payments, and
    /// customer state so financial and delivery history remains auditable after the owner starts over.
    /// </remarks>
    private async Task RESETTENANTSETTINGSASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        await StopTenantRuntimeBestEffortAsync(tenant.Id, CancellationToken);

        ResetTenantStorefrontSettings(tenant, clearAllStorefrontSettings: true);
        await _workflow.SaveAsync(CancellationToken);
        _botRegistry.Upsert(tenant);
        _botClientProvider.Invalidate(tenant.Id);

        await SafeAnswerCallbackQueryAsync(
            botClient,
            CallbackQuery.Id,
            "تنظیمات ربات فروشگاهی بازنشانی شد.",
            showAlert: true,
            cancellationToken: CancellationToken);

        await SHOWOWNERPANELASYNC(
            botClient,
            CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
            owner,
            CallbackQuery.Message?.MessageId,
            CancellationToken);
    }

    /// <summary>
    /// Validates the persisted tenant bot token before the owner panel is rendered.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot row owned by the colleague whose panel is being opened. A null value or a row without a token
    /// is treated as an unconfigured storefront and does not call Telegram.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel the Telegram <c>getMe</c> probe and any users.db cleanup if the update stops.
    /// </param>
    /// <returns>
    /// An HTML-safe Persian notice to prepend to the owner panel, or null when no user-visible warning is needed.
    /// The returned text is safe to include in a message sent with <see cref="ParseMode.Html" />.
    /// </returns>
    /// <remarks>
    /// A clearly revoked or unauthorized token is cleaned immediately because keeping it in the panel causes the
    /// owner to believe a dead storefront is still configured. Transient Telegram errors such as timeouts or 5xx
    /// responses do not clear the token; the owner sees a temporary warning and can retry refresh later.
    /// </remarks>
    private async Task<string> VALIDATETENANTTOKENFORPANELASYNC(BotInstance tenant, CancellationToken CancellationToken)
    {
        if (tenant == null || string.IsNullOrWhiteSpace(tenant.Token))
            return null;

        try
        {
            var client = new TelegramBotClient(new TelegramBotClientOptions(tenant.Token) { RetryCount = 0 });
            using var probeCts = CreateTenantTelegramProbeCancellation(CancellationToken);
            var me = await client.GetMe(probeCts.Token);
            var username = me.Username?.Trim().TrimStart('@');
            var changed = false;

            if (!string.IsNullOrWhiteSpace(username) &&
                !string.Equals(tenant.Username, username, StringComparison.OrdinalIgnoreCase))
            {
                tenant.Username = username;
                changed = true;
            }

            if (string.IsNullOrWhiteSpace(tenant.BrandName) && !string.IsNullOrWhiteSpace(me.FirstName))
            {
                tenant.BrandName = me.FirstName;
                changed = true;
            }

            if (changed)
            {
                tenant.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
                _botRegistry.Upsert(tenant);
                _botClientProvider.Invalidate(tenant.Id);
            }

            return null;
        }
        catch (Exception ex) when (ISTELEGRAMTOKENINVALIDERROR(ex))
        {
            await StopTenantRuntimeBestEffortAsync(tenant.Id, CancellationToken);

            ResetTenantStorefrontSettings(tenant, clearAllStorefrontSettings: false);
            await _workflow.SaveAsync(CancellationToken);
            _botRegistry.Upsert(tenant);
            _botClientProvider.Invalidate(tenant.Id);

            _logger.LogWarning(
                "Tenant bot token was invalid during owner panel refresh and was cleared. tenantBotId={TenantBotId}, owner={OwnerTelegramUserId}, reason={Reason}",
                tenant.Id,
                tenant.OwnerTelegramUserId,
                ex.Message);

            return "⚠️ توکن ربات فروشگاهی معتبر نبود و از تنظیمات پاک شد. لطفاً توکن جدید ثبت کنید.";
        }
        catch (Exception ex) when (ISTELEGRAMTRANSIENTTOKENCHECKERROR(ex))
        {
            _logger.LogDebug(
                ex,
                "Tenant bot token validation skipped because Telegram returned a transient error. tenantBotId={TenantBotId}",
                tenant.Id);

            return "⚠️ فعلاً امکان بررسی توکن ربات فروشگاهی نیست. اگر تلگرام مشکل موقت داشته باشد، دوباره بروزرسانی را بزنید.";
        }
        catch (Exception ex)
        {
            _logger.LogDebug(
                ex,
                "Tenant bot token validation skipped because Telegram returned an unknown non-authoritative error. tenantBotId={TenantBotId}",
                tenant.Id);

            return "⚠️ فعلاً امکان بررسی توکن ربات فروشگاهی نیست. تنظیمات شما پاک نشد؛ کمی بعد دوباره بروزرسانی را بزنید.";
        }
    }

    /// <summary>
    /// Stops a tenant receiver without failing the owner-panel cleanup flow.
    /// </summary>
    /// <param name="tenantBotId">
    /// Internal tenant bot id, for example <c>tenant-123456</c>. This is not a Telegram bot id or chat id.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel the runtime stop request if the application is shutting down.
    /// </param>
    /// <returns>A task that completes after the runtime stop attempt has finished or been logged as failed.</returns>
    /// <remarks>
    /// Reset and invalid-token cleanup must update users.db even when the receiver is already stopped or the hosted
    /// service is unavailable. For that reason this helper logs runtime stop failures and lets the caller continue.
    /// </remarks>
    private async Task StopTenantRuntimeBestEffortAsync(string tenantBotId, CancellationToken CancellationToken)
    {
        var runtime = _serviceProvider.GetService<MultiBotHostedService>();
        if (runtime == null || string.IsNullOrWhiteSpace(tenantBotId))
            return;

        try
        {
            await runtime.StopBotAsync(tenantBotId);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Tenant bot receiver stop failed during settings cleanup. tenantBotId={TenantBotId}",
                tenantBotId);
        }
    }

    /// <summary>
    /// Applies either a full storefront reset or an invalid-token cleanup to a tenant bot row.
    /// </summary>
    /// <param name="tenant">
    /// Persisted tenant bot row tracked by <see cref="UserDbContext" />. The caller must save changes after this
    /// method returns.
    /// </param>
    /// <param name="clearAllStorefrontSettings">
    /// When true, all owner-configured storefront settings are cleared. When false, only token identity and
    /// enabled state are cleared so unrelated settings like card payment and support remain intact.
    /// </param>
    /// <remarks>
    /// This method deliberately does not delete tenant orders, receipts, ledger entries, customer states, or payment
    /// rows. Those records are separate audit history and must survive both owner-requested resets and revoked-token
    /// cleanup.
    /// </remarks>
    private static void ResetTenantStorefrontSettings(BotInstance tenant, bool clearAllStorefrontSettings)
    {
        tenant.Enabled = false;
        tenant.Token = null;
        tenant.TelegramBotId = null;
        tenant.Username = null;
        tenant.UpdatedAtUtc = DateTime.UtcNow;

        if (!clearAllStorefrontSettings)
            return;

        tenant.BrandName = null;
        tenant.SupportAccount = null;
        tenant.TenantWelcomeText = null;
        tenant.TenantPriceMarkupPercent = 0;
        tenant.TenantMandatoryJoinEnabled = false;
        tenant.TenantChannelIdsJson = null;
        tenant.TenantCardPaymentEnabled = false;
        tenant.TenantCardNumber = null;
        tenant.TenantCardHolderName = null;
        tenant.TenantHooshPayEnabled = true;
        tenant.TenantTetraminatorEnabled = true;
        tenant.TenantNowPaymentsEnabled = true;
        tenant.TenantUniquePayEnabled = true;
        tenant.TenantAtlasPayEnabled = true;
        tenant.TenantTutorialsJson = JsonConvert.SerializeObject(Array.Empty<TenantTutorialLink>());
    }

    /// <summary>
    /// Determines whether a Telegram exception proves that a bot token is revoked, invalid, or unauthorized.
    /// </summary>
    /// <param name="exception">
    /// Exception thrown by Telegram <c>getMe</c> or another bot-token validation call. The exception message is
    /// inspected without logging or exposing the raw token.
    /// </param>
    /// <returns>
    /// <c>true</c> when the token should be cleared from the tenant row; otherwise <c>false</c>.
    /// </returns>
    private static bool ISTELEGRAMTOKENINVALIDERROR(Exception exception)
    {
        if (exception is ApiRequestException apiException &&
            (apiException.ErrorCode == 401 || CONTAINSTOKENINVALIDTEXT(apiException.Message)))
            return true;

        return CONTAINSTOKENINVALIDTEXT(exception?.Message);
    }

    /// <summary>
    /// Determines whether a token validation failure is likely a temporary Telegram/network issue.
    /// </summary>
    /// <param name="exception">
    /// Exception thrown while probing the tenant token. The raw token is never included in this value by callers.
    /// </param>
    /// <returns>
    /// <c>true</c> for timeout, cancellation, rate-limit, and Telegram 5xx errors that should not clear settings.
    /// </returns>
    private static bool ISTELEGRAMTRANSIENTTOKENCHECKERROR(Exception exception)
    {
        if (exception is TimeoutException || exception is TaskCanceledException)
            return true;

        if (exception is ApiRequestException apiException)
            return apiException.ErrorCode == 429 || apiException.ErrorCode >= 500;

        var message = exception?.Message;
        return !string.IsNullOrWhiteSpace(message) &&
               (message.Contains("timed out", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("timeout", StringComparison.OrdinalIgnoreCase) ||
                message.Contains("temporarily", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Checks Telegram error text for invalid-token keywords without exposing the token value.
    /// </summary>
    /// <param name="message">Telegram or client-library error message to inspect.</param>
    /// <returns><c>true</c> when the message describes an invalid, revoked, or unauthorized bot token.</returns>
    private static bool CONTAINSTOKENINVALIDTEXT(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("unauthorized", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("invalid token", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("bot token", StringComparison.OrdinalIgnoreCase) &&
               message.Contains("invalid", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Starts a one-message owner input flow for a specific tenant setting.
    /// </summary>
    /// <param name="botClient">
    /// Main owned-brand bot client that is currently serving the colleague owner panel.
    /// This is not the tenant storefront bot client.
    /// </param>
    /// <param name="CallbackQuery">
    /// Callback from the owner panel that selected which tenant setting should be edited.
    /// The sender id is used to persist the next expected input step.
    /// </param>
    /// <param name="field">
    /// Requested setting key such as <c>Token</c>, <c>markup</c>, <c>support</c>, or <c>WELCOME</c>.
    /// Unknown values are ignored and only answer the callback.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel database state writes and Telegram prompt sending if the update pipeline stops.
    /// </param>
    /// <remarks>
    /// The method writes a temporary owner-flow state row so the next text message is routed to the matching
    /// save method. Prompts are sent as HTML because the BotFather token prompt contains a clickable
    /// <c>@BotFather</c> link. The support prompt includes a reply-keyboard back button because owners often
    /// need to inspect the current support id before deciding whether to change it.
    /// </remarks>
    /// <returns>A task completing after the owner input step is saved and its prompt is sent.</returns>
    private async Task STARTOWNERINPUTASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        string field,
        CancellationToken CancellationToken)
    {
        var step = field switch
        {
            STEPTOKEN => STEPTOKEN,
            STEPMARKUP => STEPMARKUP,
            STEPSUPPORT => STEPSUPPORT,
            STEPWELCOME => STEPWELCOME,
            STEPCARDNUMBER => STEPCARDNUMBER,
            STEPCARDHOLDER => STEPCARDHOLDER,
            STEPMANDATORYCHANNEL => STEPMANDATORYCHANNEL,
            _ => string.Empty
        };

        if (string.IsNullOrWhiteSpace(step))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        await _state.SaveUserStatus(new User
        {
            Id = CallbackQuery.From.Id,
            Flow = OWNERFLOW,
            LastStep = step
        });

        var tenant = await GetSelectedOwnerStoreAsync(CallbackQuery.From.Id, CancellationToken);
        var currentSupport = string.IsNullOrWhiteSpace(tenant?.SupportAccount)
            ? "ثبت نشده"
            : NormalizeTenantSupportAccount(tenant.SupportAccount) ?? tenant.SupportAccount;

        var PROMPT = step switch
        {
            STEPTOKEN => "توکن رباتی که از <a href=\"https://t.me/BotFather\">@BotFather</a> گرفته‌اید را ارسال کنید.",
            STEPMARKUP => "درصد سود روی قیمت همکار را فقط به عدد ارسال کنید. مثال: 20",
            STEPSUPPORT => $"آیدی پشتیبان فعلی: <code>{Html(currentSupport)}</code>\n\nیوزرنیم پشتیبانی فروشگاه را ارسال کنید. مثال: <code>@SUPPORT_USERNAME</code>",
            STEPWELCOME => "متن خوشامد فروشگاه را ارسال کنید.",
            STEPCARDNUMBER => "شماره کارت درگاه کارت‌به‌کارت فروشگاه را بدون فاصله یا با فاصله خوانا ارسال کنید.",
            STEPCARDHOLDER => "نام صاحب کارت را دقیق ارسال کنید تا برای مشتری نمایش داده شود.",
            STEPMANDATORYCHANNEL => "آیدی یا لینک کانال جوین اجباری را ارسال کنید. مثال: @YOURCHANNEL",
            _ => "مقدار جدید را ارسال کنید."
        };

        await botClient.SendMessage(
            chatId: CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
            text: PROMPT,
            parseMode: ParseMode.Html,
            replyMarkup: step == STEPSUPPORT
                ? new ReplyKeyboardMarkup(new[]
                {
                    new[] { new KeyboardButton("بازگشت به پنل") }
                })
                {
                    ResizeKeyboard = true
                }
                : new ReplyKeyboardRemove(),
            cancellationToken: CancellationToken);

        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Validates a BotFather token with getMe and saves it only on the explicitly selected owner storefront.
    /// </summary>
    /// <param name="botClient">Main brand Bot client used to Reply to the owner.</param>
    /// <param name="Message">owner Message containing the Token.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <returns>A task completing after token validation, tenant persistence, runtime refresh and the owner response.</returns>
    /// <remarks>The returned numeric identity must match the token and be unique across tenant, owned and assistant bots.
    /// Stops only the selected receiver before replacement. The unique database identity closes concurrent registration races.
    /// Raw tokens and probe exception text are never sent to logs or replies. All financial history is preserved.</remarks>
    private async Task SAVETENANTBOTTOKENASYNC(
        ITelegramBotClient botClient,
        Message Message,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        var Token = Message.Text?.Trim();
        if (string.IsNullOrWhiteSpace(Token) || !Token.Contains(':'))
        {
            await botClient.SendMessage(
                Message.Chat.Id,
                "توکن معتبر نیست. توکن BOTFATHER را کامل ارسال کنید.",
                cancellationToken: CancellationToken);
            return;
        }

        Telegram.Bot.Types.User me;
        try
        {
            var TENANTCLIENT = new TelegramBotClient(new TelegramBotClientOptions(Token) { RetryCount = 0 });
            using var probeCts = CreateTenantTelegramProbeCancellation(CancellationToken);
            me = await TENANTCLIENT.GetMe(probeCts.Token);
        }
        catch (Exception)
        {
            await botClient.SendMessage(
                Message.Chat.Id,
                "اعتبارسنجی توکن ناموفق بود. توکن و اتصال تلگرام را بررسی کنید.",
                parseMode: ParseMode.Html,
                cancellationToken: CancellationToken);
            return;
        }

        var Username = me.Username?.Trim().TrimStart('@');
        if (string.IsNullOrWhiteSpace(Username))
        {
            await botClient.SendMessage(
                Message.Chat.Id,
                "این توکن یوزرنیم معتبر برنگرداند. لطفاً BOTFATHER را بررسی کنید.",
                cancellationToken: CancellationToken);
            return;
        }

        if (TelegramBotTokenIdentity.ExtractBotId(Token) != me.Id)
        {
            await botClient.SendMessage(Message.Chat.Id, "هویت ربات با توکن مطابقت ندارد.", cancellationToken: CancellationToken);
            return;
        }
        var duplicate = await FindTenantTokenConflictAsync(Token, Username, owner.TelegramUserId, CancellationToken);
        if (duplicate.HasConflict)
        {
            await botClient.SendMessage(
                Message.Chat.Id,
                "این توکن/ربات در حال حاضر برای اکانت یا ربات دیگری استفاده می‌شود. لطفاً توکن دیگری وارد کنید.",
                cancellationToken: CancellationToken);
            _logger.LogWarning(
                "Rejected duplicate tenant bot token. owner={OwnerTelegramUserId}, conflict={ConflictType}, botId={TokenBotId}, username=@{Username}",
                owner.TelegramUserId,
                duplicate.ConflictType,
                TelegramBotTokenIdentity.ExtractBotId(Token),
                Username);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        await StopTenantRuntimeBestEffortAsync(tenant.Id, CancellationToken);
        tenant.Token = Token;
        tenant.TelegramBotId = me.Id;
        tenant.Username = Username;
        tenant.BrandName = string.IsNullOrWhiteSpace(me.FirstName) ? Username : me.FirstName;
        tenant.Type = BotInstanceTypes.Tenant;
        tenant.OwnerTelegramUserId = owner.TelegramUserId;
        tenant.Enabled = false;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        if (tenant.TenantPriceMarkupPercent < 0)
            tenant.TenantPriceMarkupPercent = 0;
        if (string.IsNullOrWhiteSpace(tenant.SupportAccount) && !string.IsNullOrWhiteSpace(owner.Username))
            tenant.SupportAccount = "@" + owner.Username.TrimStart('@');

        try
        {
            await _workflow.SaveAsync(CancellationToken);
        }
        catch (DbUpdateException ex) when (ex.InnerException is Microsoft.Data.Sqlite.SqliteException { SqliteErrorCode: 19 })
        {
            // A concurrent registration in another owned bot may win after getMe. The unique numeric identity is authoritative.
            await botClient.SendMessage(Message.Chat.Id, "این ربات هم‌زمان در فروشگاه دیگری ثبت شده است. توکن دیگری وارد کنید.", cancellationToken: CancellationToken);
            return;
        }
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);
        _botClientProvider.Invalidate(tenant.Id);

        await botClient.SendMessage(
            Message.Chat.Id,
            $"✅ توکن ربات <b>@{Html(Username)}</b> ثبت شد.\nبرای شروع دریافت پیام، فروشگاه را از پنل روشن کنید.",
            parseMode: ParseMode.Html,
            cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// Checks whether a validated tenant bot token or username is already owned by another runtime bot.
    /// </summary>
    /// <param name="token">
    /// Trimmed BotFather token entered by the colleague. The token is compared in memory only and must never be
    /// written to Telegram messages or operational logs.
    /// </param>
    /// <param name="username">
    /// Username returned by Telegram <c>GetMe</c> for the entered token, without a required leading <c>@</c>.
    /// </param>
    /// <param name="ownerTelegramUserId">
    /// Numeric Telegram user id of the authenticated colleague. Only the selected store is excluded;
    /// other stores belonging to this same owner must also be rejected.
    /// </param>
    /// <param name="cancellationToken">
    /// Token used to cancel the users.db query when the update handler stops.
    /// </param>
    /// <returns>
    /// A conflict descriptor. <see cref="TenantTokenConflictResult.HasConflict" /> is <c>true</c> when the token,
    /// token bot id, or username belongs to another tenant owner or to a configured non-tenant bot.
    /// </returns>
    /// <remarks>
    /// This guard runs after Telegram has accepted the token with <c>GetMe</c>. It prevents two tenant owners from
    /// receiving updates through the same bot and prevents a tenant storefront from reusing an owned bot token.
    /// </remarks>
    private async Task<TenantTokenConflictResult> FindTenantTokenConflictAsync(
        string token,
        string username,
        long ownerTelegramUserId,
        CancellationToken cancellationToken)
    {
        if (_selectedOwnerStore?.OwnerTelegramUserId != ownerTelegramUserId)
            throw new InvalidOperationException("Token registration requires an owner-authorized store.");
        var normalizedUsername = TelegramBotTokenIdentity.NormalizeUsername(username);
        var tenants = await _workflow.ReadAsync(async db => await db.BotInstances
            .Where(x => x.Id != _selectedOwnerStore.Id)
            .ToListAsync(cancellationToken));

        foreach (var tenant in tenants)
        {
            if (tenant.TelegramBotId == TelegramBotTokenIdentity.ExtractBotId(token) || TelegramBotTokenIdentity.IsSameBotToken(token, tenant.Token))
                return TenantTokenConflictResult.Conflict("tenant-token");

            if (!string.IsNullOrWhiteSpace(normalizedUsername) &&
                string.Equals(
                    normalizedUsername,
                    TelegramBotTokenIdentity.NormalizeUsername(tenant.Username),
                    StringComparison.OrdinalIgnoreCase))
            {
                return TenantTokenConflictResult.Conflict("tenant-username");
            }
        }

        foreach (var bot in _botRegistry.Bots.Where(x => x.Id != _selectedOwnerStore.Id)
            .Concat(_appConfig.Bots ?? new List<BotInstanceConfig>())
            .Concat(new[] { _appConfig.SalesAssistantBot, new BotInstanceConfig { Token = _appConfig.BotToken } }).Where(x => x != null))
        {
            if (TelegramBotTokenIdentity.IsSameBotToken(token, bot.Token))
                return TenantTokenConflictResult.Conflict("owned-token");

            if (!string.IsNullOrWhiteSpace(normalizedUsername) &&
                string.Equals(
                    normalizedUsername,
                    TelegramBotTokenIdentity.NormalizeUsername(bot.Username),
                    StringComparison.OrdinalIgnoreCase))
            {
                return TenantTokenConflictResult.Conflict("owned-username");
            }
        }

        return TenantTokenConflictResult.None;
    }

    /// <summary>
    /// Stores the markup percent for the explicitly selected storefront's prices.
    /// </summary>
    /// <param name="botClient">Main brand Bot client.</param>
    /// <param name="Message">owner Message containing A numeric percent.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <returns>A task completing after the validated 0 through 500 percent markup is saved and confirmed.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task SAVETENANTMARKUPASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        if (!int.TryParse(Message.Text?.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var markup) || markup < 0 || markup > 500)
        {
            await botClient.SendMessage(Message.Chat.Id, "درصد سود باید عددی بین 0 تا 500 باشد.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.TenantPriceMarkupPercent = markup;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(Message.Chat.Id, "✅ درصد سود ذخیره شد.", cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// Stores the support account displayed inside the tenant storefront.
    /// </summary>
    /// <param name="botClient">
    /// Main owned-brand bot client used to confirm the saved value and reopen the owner panel.
    /// </param>
    /// <param name="Message">
    /// Owner message containing a Telegram support username. It may include the leading <c>@</c>;
    /// empty values are rejected and do not change the current support account.
    /// </param>
    /// <param name="owner">
    /// Colleague profile from <c>credentials.db</c>. The owner's numeric Telegram id identifies the tenant bot row.
    /// </param>
    /// <param name="CancellationToken">
    /// Token used to cancel database persistence and Telegram replies.
    /// </param>
    /// <remarks>
    /// The value is normalized to a public Telegram username with one leading <c>@</c> and is stored on
    /// <see cref="BotInstance.SupportAccount"/>. The setting is tenant-scoped and is shown only in that
    /// colleague's storefront support flow. Public <c>t.me</c> links are converted to their username segment
    /// so customers never see values like <c>@https://t.me/name</c>.
    /// </remarks>
    /// <returns>A task completing after a valid support account is saved, or an invalid-input reply is sent.</returns>
    private async Task SAVETENANTSUPPORTASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        var support = NormalizeTenantSupportAccount(Message.Text);
        if (string.IsNullOrWhiteSpace(support))
        {
            await botClient.SendMessage(Message.Chat.Id, "آیدی پشتیبانی معتبر نیست. لطفاً یوزرنیم عمومی تلگرام مثل @SUPPORT_USERNAME یا لینک t.me را ارسال کنید.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.SupportAccount = support;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(
            Message.Chat.Id,
            "✅ پشتیبانی فروشگاه ذخیره شد.",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// stores the WELCOME Text displayed on tenant Bot /start.
    /// </summary>
    /// <param name="botClient">Main brand Bot client.</param>
    /// <param name="Message">owner Message containing WELCOME Text.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <returns>A task completing after the tenant welcome message is saved and the owner panel is restored.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task SAVETENANTWELCOMEASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        var WELCOME = Message.Text?.Trim();
        if (string.IsNullOrWhiteSpace(WELCOME))
        {
            await botClient.SendMessage(Message.Chat.Id, "متن خوشامد نمی‌تواند خالی باشد.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.TenantWelcomeText = WELCOME;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(Message.Chat.Id, "✅ متن خوشامد ذخیره شد.", cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// stores the tenant owner's card number for the optional card-to-card payment gateway.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to Reply to the tenant owner.</param>
    /// <param name="Message">owner Message containing the card number Text.</param>
    /// <param name="owner">colleague User who owns the tenant storefront; the value COMES from credentials.db.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db Writes and Telegram REPLIES.</param>
    /// <remarks>
    /// the card number is tenant-scoped and is shown only to customers of this tenant Bot when the owner
    /// Enables card-to-card payment. the value is stored in users.db because credentials.db schema must STAY UNCHANGED.
    /// </remarks>
    /// <returns>A task completing after the validated tenant card number is saved or a validation reply is sent.</returns>
    private async Task SAVETENANTCARDNUMBERASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        var cardNumber = Message.Text?.Trim();
        if (string.IsNullOrWhiteSpace(cardNumber))
        {
            await botClient.SendMessage(Message.Chat.Id, "شماره کارت نمی‌تواند خالی باشد.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.TenantCardNumber = cardNumber;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(Message.Chat.Id, "✅ شماره کارت فروشگاه ذخیره شد.", cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// stores the display name of the card HOLDER for the tenant owner's card-to-card gateway.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to answer the owner.</param>
    /// <param name="Message">owner Message containing the card HOLDER name.</param>
    /// <param name="owner">colleague User who owns the tenant storefront.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db Writes and Telegram REPLIES.</param>
    /// <remarks>
    /// this method does not VALIDATE the name AGAINST A BANK; it only stores the exact owner-provided
    /// Text after TRIMMING so the customer can match the card TRANSFER DESTINATION.
    /// </remarks>
    /// <returns>A task completing after the tenant card-holder label is saved and confirmed.</returns>
    private async Task SAVETENANTCARDHOLDERASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        var CARDHOLDER = Message.Text?.Trim();
        if (string.IsNullOrWhiteSpace(CARDHOLDER))
        {
            await botClient.SendMessage(Message.Chat.Id, "نام صاحب کارت نمی‌تواند خالی باشد.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.TenantCardHolderName = CARDHOLDER;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(Message.Chat.Id, "✅ نام صاحب کارت ذخیره شد.", cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// stores the tenant storefront channel used for optional forced-join checks.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to answer the tenant owner.</param>
    /// <param name="Message">owner Message containing one Telegram channel Username, Id, or INVITE-STYLE link.</param>
    /// <param name="owner">colleague User who owns the tenant storefront.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db Writes and Telegram REPLIES.</param>
    /// <remarks>
    /// the value is normalized to A single channel Id/Username List in <see cref="BotInstance.TenantChannelIdsJson" />.
    /// the Bot Access ITSELF is checked when forced join is enabled or when the storefront is TURNED on.
    /// </remarks>
    /// <returns>A task completing after channel validation and tenant settings persistence or its failure response.</returns>
    private async Task SAVETENANTMANDATORYCHANNELASYNC(ITelegramBotClient botClient, Message Message, CredUser owner, CancellationToken CancellationToken)
    {
        var channel = NORMALIZETELEGRAMCHANNEL(Message.Text);
        if (string.IsNullOrWhiteSpace(channel))
        {
            await botClient.SendMessage(Message.Chat.Id, "کانال معتبر نیست. آیدی کانال مثل @YOURCHANNEL را ارسال کنید.", cancellationToken: CancellationToken);
            return;
        }

        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        tenant.TenantChannelIdsJson = JsonConvert.SerializeObject(new[] { channel });
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        _botRegistry.Upsert(tenant);

        await botClient.SendMessage(Message.Chat.Id, "✅ کانال جوین اجباری ذخیره شد.", cancellationToken: CancellationToken);
        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// Applies an idempotent enabled target state to a tenant bot and starts or stops its serialized runtime receiver.
    /// </summary>
    /// <param name="botClient">Main brand Bot client.</param>
    /// <param name="CallbackQuery">Owner callback carrying the panel message and callback id.</param>
    /// <param name="owner">colleague owner profile.</param>
    /// <param name="desiredEnabled">Desired persisted and runtime state; repeated calls with the same value are no-ops.</param>
    /// <param name="expectedRevision">
    /// Revision embedded in the keyboard that produced the callback. It must match the freshly loaded tenant row.
    /// </param>
    /// <param name="issuedAt">Hexadecimal Unix timestamp used to reject mutation buttons older than ten minutes.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <remarks>
    /// The callback is acknowledged before channel validation or Telegram startup. This prevents callback expiry
    /// during network delays. Enabling is persisted only when <see cref="MultiBotHostedService.StartBotAsync" />
    /// registers a receiver; duplicate enable callbacks never invert the state or create a second receiver.
    /// A fresh blocked owner cannot enable a store. Runtime access independently checks owner suspension on every update.
    /// </remarks>
    private async Task SETTENANTBOTENABLEDASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        bool desiredEnabled,
        string expectedRevision,
        string issuedAt,
        CancellationToken CancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, CancellationToken);
        if (desiredEnabled && (await _credentialsDbContext.GetUserStatusWithId(owner.TelegramUserId))?.IsBlocked == true)
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, TenantAccessService.BlockedMessage,
                showAlert: true, cancellationToken: CancellationToken);
            return;
        }
        if (tenant == null || string.IsNullOrWhiteSpace(tenant.Token) || string.IsNullOrWhiteSpace(tenant.Username))
        {
            await SafeAnswerCallbackQueryAsync(botClient, 
                CallbackQuery.Id,
                "اول توکن ربات فروشگاهی را ثبت کنید.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return;
        }

        if (!IsTenantMutationCallbackFresh(issuedAt))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این دکمه منقضی شده است؛ پنل جدید نمایش داده شد.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                owner,
                CallbackQuery.Message?.MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return;
        }

        if (!string.Equals(BuildTenantPanelRevision(tenant), expectedRevision, StringComparison.Ordinal))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این پنل قدیمی شده است؛ وضعیت جدید نمایش داده شد.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                owner,
                CallbackQuery.Message?.MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return;
        }

        if (tenant.Enabled == desiredEnabled)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                desiredEnabled ? "فروشگاه از قبل روشن است." : "فروشگاه از قبل خاموش است.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                owner,
                CallbackQuery.Message?.MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return;
        }

        await SafeAnswerCallbackQueryAsync(
            botClient,
            CallbackQuery.Id,
            desiredEnabled ? "در حال روشن‌کردن فروشگاه..." : "در حال خاموش‌کردن فروشگاه...",
            cancellationToken: CancellationToken);

        if (CallbackQuery.Message != null)
        {
            await SafeEditMessageTextAsync(
                botClient,
                CallbackQuery.Message.Chat.Id,
                CallbackQuery.Message.MessageId,
                desiredEnabled
                    ? "⏳ <b>در حال روشن‌کردن ربات فروشگاهی...</b>\n\nاتصال تلگرام و تنظیمات فروشگاه در حال بررسی است."
                    : "⏳ <b>در حال خاموش‌کردن ربات فروشگاهی...</b>",
                ParseMode.Html,
                new InlineKeyboardMarkup(new[]
                {
                    InlineKeyboardButton.WithCallbackData("🔄 بروزرسانی", OWNERCALLBACKPREFIX + "panel")
                }),
                CancellationToken);
        }

        if (desiredEnabled && tenant.TenantMandatoryJoinEnabled)
        {
            var validation = await VALIDATETENANTMANDATORYJOINASYNC(tenant, CancellationToken);
            if (!validation.ISVALID)
            {
                tenant.Enabled = false;
                tenant.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
                _botRegistry.Upsert(tenant);

                await botClient.SendMessage(
                    CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                    $"⚠️ {validation.ErrorMessage}",
                    cancellationToken: CancellationToken);
                await SHOWOWNERPANELASYNC(
                    botClient,
                    CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                    owner,
                    CallbackQuery.Message?.MessageId,
                    CancellationToken);
                return;
            }
        }

        tenant.Enabled = desiredEnabled;
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        _botRegistry.Upsert(tenant);
        _botClientProvider.Invalidate(tenant.Id);

        var runtime = _serviceProvider.GetService<MultiBotHostedService>();
        if (runtime != null)
        {
            if (tenant.Enabled)
            {
                var started = await runtime.StartBotAsync(tenant.Id, CancellationToken);
                if (!started)
                {
                    tenant.Enabled = false;
                    tenant.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(CancellationToken);
                    _botRegistry.Upsert(tenant);
                    _botClientProvider.Invalidate(tenant.Id);

                    await botClient.SendMessage(
                        CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                        "⚠️ راه‌اندازی ربات فروشگاهی کامل نشد. چند لحظه بعد پنل را به‌روزرسانی و دوباره تلاش کنید.",
                        cancellationToken: CancellationToken);
                    await SHOWOWNERPANELASYNC(
                        botClient,
                        CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                        owner,
                        CallbackQuery.Message?.MessageId,
                        CancellationToken);
                    return;
                }
            }
            else
            {
                await runtime.StopBotAsync(tenant.Id);
            }
        }

        await SHOWOWNERPANELASYNC(
            botClient,
            CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
            owner,
            CallbackQuery.Message?.MessageId,
            CancellationToken);
    }

    /// <summary>
    /// Applies an idempotent target state to a configurable tenant storefront feature.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to answer the owner callback.</param>
    /// <param name="CallbackQuery">Callback carrying the owner panel revision and Telegram callback id.</param>
    /// <param name="owner">colleague User who owns the tenant storefront.</param>
    /// <param name="setting">Short setting key from callback data: card, HooshPay, Tetraminator, UniquePay, NowPayments, or join.</param>
    /// <param name="desiredEnabled">Desired final value. Repeating the same callback does not invert the setting.</param>
    /// <param name="expectedRevision">Revision embedded in the panel keyboard that must match the current tenant row.</param>
    /// <param name="issuedAt">Hexadecimal Unix timestamp used to reject mutation buttons older than ten minutes.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db Writes, Telegram calls, and optional join validation.</param>
    /// <remarks>
    /// Forced join is validated immediately before it is enabled. The callback is acknowledged before any Telegram
    /// network probe, and validation failures are delivered as normal owner messages because callback answers can
    /// only be sent once. HooshPay, Tetraminator, UniquePay, and NOWPayments tenant preferences cannot be enabled
    /// while their corresponding live global application switches are disabled.
    /// </remarks>
    private async Task SETTENANTSETTINGASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        string setting,
        bool desiredEnabled,
        string expectedRevision,
        string issuedAt,
        CancellationToken CancellationToken)
    {
        var tenant = await RequireSelectedOwnerStoreAsync(owner, CancellationToken);
        if (!IsTenantMutationCallbackFresh(issuedAt))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این دکمه منقضی شده است؛ پنل جدید نمایش داده شد.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                owner,
                CallbackQuery.Message?.MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return;
        }

        if (!string.Equals(BuildTenantPanelRevision(tenant), expectedRevision, StringComparison.Ordinal))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این پنل قدیمی شده است؛ وضعیت جدید نمایش داده شد.",
                cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(
                botClient,
                CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                owner,
                CallbackQuery.Message?.MessageId,
                CancellationToken,
                CallbackQuery.Message);
            return;
        }

        bool currentEnabled;
        switch (setting)
        {
            case "card":
                currentEnabled = tenant.TenantCardPaymentEnabled;
                if (desiredEnabled &&
                    (string.IsNullOrWhiteSpace(tenant.TenantCardNumber) || string.IsNullOrWhiteSpace(tenant.TenantCardHolderName)))
                {
                    await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "اول شماره کارت و نام صاحب کارت را ثبت کنید.", showAlert: true, cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "HooshPay":
                currentEnabled = tenant.TenantHooshPayEnabled;
                if (desiredEnabled && !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay))
                {
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "درگاه هوش‌پی در تنظیمات سراسری غیرفعال است.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "Tetraminator":
                currentEnabled = tenant.TenantTetraminatorEnabled;
                if (desiredEnabled && !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator))
                {
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "درگاه تترامیناتور در تنظیمات سراسری غیرفعال است.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "UniquePay":
                currentEnabled = tenant.TenantUniquePayEnabled;
                if (desiredEnabled && !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay))
                {
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "درگاه یونیک‌پی در تنظیمات سراسری خاموش است.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "AtlasPay":
                currentEnabled = tenant.TenantAtlasPayEnabled;
                if (desiredEnabled && !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay))
                {
                    await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id,
                        "درگاه اطلس‌پی در تنظیمات سراسری خاموش یا ناقص است.", showAlert: true, cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "NowPayments":
                currentEnabled = tenant.TenantNowPaymentsEnabled;
                if (desiredEnabled && !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments))
                {
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "درگاه ارز دیجیتال در تنظیمات سراسری خاموش است.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }
                break;
            case "join":
                currentEnabled = tenant.TenantMandatoryJoinEnabled;
                break;
            default:
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
                return;
        }

        if (currentEnabled == desiredEnabled)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "این تنظیم از قبل در همین وضعیت است.",
                cancellationToken: CancellationToken);
            return;
        }

        await SafeAnswerCallbackQueryAsync(
            botClient,
            CallbackQuery.Id,
            "در حال به‌روزرسانی تنظیمات...",
            cancellationToken: CancellationToken);

        if (setting == "join" && desiredEnabled)
        {
            var validation = await VALIDATETENANTMANDATORYJOINASYNC(tenant, CancellationToken);
            if (!validation.ISVALID)
            {
                tenant.TenantMandatoryJoinEnabled = false;
                await _workflow.SaveAsync(CancellationToken);
                await botClient.SendMessage(
                    CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
                    $"⚠️ {validation.ErrorMessage}",
                    cancellationToken: CancellationToken);
                return;
            }
        }

        switch (setting)
        {
            case "card":
                tenant.TenantCardPaymentEnabled = desiredEnabled;
                break;
            case "HooshPay":
                tenant.TenantHooshPayEnabled = desiredEnabled;
                break;
            case "Tetraminator":
                tenant.TenantTetraminatorEnabled = desiredEnabled;
                break;
            case "UniquePay":
                tenant.TenantUniquePayEnabled = desiredEnabled;
                break;
            case "AtlasPay":
                tenant.TenantAtlasPayEnabled = desiredEnabled;
                break;
            case "NowPayments":
                tenant.TenantNowPaymentsEnabled = desiredEnabled;
                break;
            case "join":
                tenant.TenantMandatoryJoinEnabled = desiredEnabled;
                break;
        }

        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);
        _botRegistry.Upsert(tenant);

        await SHOWOWNERPANELASYNC(
            botClient,
            CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
            owner,
            CallbackQuery.Message?.MessageId,
            CancellationToken);
    }

    /// <summary>
    /// SHOWS the tenant owner A compact newest-first summary of recent storefront orders.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to edit or Send the owner-FACING REPORT.</param>
    /// <param name="CallbackQuery">owner callback REQUESTING the orders REPORT.</param>
    /// <param name="owner">colleague User whose tenant orders should be LISTED.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db and Telegram calls.</param>
    /// <remarks>
    /// this is intentionally Lightweight in the first tenant ROLLOUT: it gives owners IMMEDIATE VISIBILITY
    /// into recent orders while the full PAGINATED REPORT can REUSE the same order Query LATER.
    /// </remarks>
    private async Task SHOWOWNERORDERSASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        int page,
        CancellationToken CancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, CancellationToken);
        const int pageSize = 10;
        var orders = tenant == null
            ? new List<TenantBotOrder>()
            : await _workflow.ReadAsync(async db => await db.TenantBotOrders
                .Where(x => x.TenantBotId == tenant.Id)
                .OrderByDescending(x => x.CreatedAtUtc)
                .Skip(page * pageSize)
                .Take(pageSize)
                .ToListAsync(CancellationToken));
        var totalCount = tenant == null
            ? 0
            : await _workflow.ReadAsync(async db => await db.TenantBotOrders.CountAsync(x => x.TenantBotId == tenant.Id, CancellationToken));
        var totalPages = Math.Max(1, (int)Math.Ceiling(totalCount / (double)pageSize));

        var Builder = new System.Text.StringBuilder();
        Builder.AppendLine("🧾 <b>سفارش‌های فروشگاه</b>");
        Builder.AppendLine($"صفحه <code>{page + 1}</code> از <code>{totalPages}</code>");
        Builder.AppendLine();
        if (orders.Count == 0)
        {
            Builder.AppendLine("هنوز سفارشی ثبت نشده است.");
        }
        else
        {
            Builder.AppendLine("برای دیدن جزئیات، روی سفارش بزنید.");
        }

        var rows = new List<InlineKeyboardButton[]>();
        foreach (var order in orders)
            rows.Add(new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    BuildOwnerOrderButtonText(order),
                    OWNERCALLBACKPREFIX + $"order:{order.Id}:{page}")
            });

        var navigation = new List<InlineKeyboardButton>();
        if (page > 0)
            navigation.Add(InlineKeyboardButton.WithCallbackData("⬅️ قبلی", OWNERCALLBACKPREFIX + $"orders:{page - 1}"));
        if (page + 1 < totalPages)
            navigation.Add(InlineKeyboardButton.WithCallbackData("بعدی ➡️", OWNERCALLBACKPREFIX + $"orders:{page + 1}"));
        if (navigation.Count > 0)
            rows.Add(navigation.ToArray());
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") });

        await SafeEditMessageTextAsync(botClient, 
            CallbackQuery.Message.Chat.Id,
            CallbackQuery.Message.MessageId,
            Builder.ToString(),
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(rows),
            cancellationToken: CancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Shows full details for one tenant order selected from the owner order list.
    /// </summary>
    /// <param name="botClient">Owned bot client used to edit the owner-panel message.</param>
    /// <param name="callbackQuery">Owner callback containing order id and source page.</param>
    /// <param name="owner">Colleague owner requesting the order details.</param>
    /// <param name="payload">Callback payload in the form <c>{orderId}:{page}</c>.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    private async Task SHOWOWNERORDERDETAILASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser owner,
        string payload,
        CancellationToken cancellationToken)
    {
        var parts = payload.Split(':');
        if (parts.Length == 0 || !int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out var orderId))
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش نامعتبر است.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var page = parts.Length > 1 && int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsedPage)
            ? Math.Max(0, parsedPage)
            : 0;
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == orderId && x.OwnerTelegramUserId == owner.TelegramUserId && x.TenantBotId == _selectedOwnerStore.Id,
            cancellationToken));
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var text =
            "🔎 <b>جزئیات سفارش فروشگاه</b>\n\n" +
            $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n" +
            $"نوع سفارش: <b>{Html(GetOrderKindDisplay(order))}</b>\n" +
            $"تاریخ ثبت: <code>{Html(FormatTenantOrderDate(order.CreatedAtUtc))}</code>\n" +
            $"خریدار: {BuildTelegramUserLink(order.CustomerTelegramUserId, BuildCustomerDisplayName(order))}\n" +
            $"درگاه: <code>{Html(order.PaymentProvider)}</code>\n" +
            $"وضعیت پرداخت: <code>{Html(order.PaymentStatus)}</code>\n" +
            $"وضعیت تحویل: <code>{Html(order.IsFulfilled ? "تحویل شده" : "تحویل نشده")}</code>\n\n" +
            $"سرویس: <code>{Html(order.ServiceKey)}</code>\n" +
            $"حجم: <code>{Html(order.TrafficGb?.ToString(CultureInfo.InvariantCulture) ?? "-")} GB</code>\n" +
            $"مدت/پلن: <code>{Html(
                !string.IsNullOrWhiteSpace(order.DurationKey)
                    ? XuiV3PurchaseService.FormatDurationSelectionKey(order.DurationKey)
                    : order.UnlimitedPlanKey ?? "-")}</code>\n" +
            $"اکانت هدف/ساخته‌شده: <code>{Html(order.TargetAccountEmail ?? order.CreatedAccountEmail ?? "-")}</code>\n" +
            $"ساب‌لینک: <code>{Html(order.CreatedSubLink ?? "-")}</code>\n\n" +
            $"مبلغ فروش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
            $"هزینه پایه: <code>{Html(order.BaseCostToman.FormatCurrency())}</code>\n" +
            $"سود/کسر همکار: <code>{Html(order.OwnerWalletDelta.FormatCurrency())}</code>\n" +
            $"موجودی بعد: <code>{Html(order.OwnerBalanceAfter?.FormatCurrency() ?? "-")}</code>" +
            BuildTenantOrderErrorLine(order);

        await SafeEditMessageTextAsync(
            botClient,
            callbackQuery.Message.Chat.Id,
            callbackQuery.Message.MessageId,
            text,
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به سفارش‌ها", OWNERCALLBACKPREFIX + $"orders:{page}") },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به پنل", OWNERCALLBACKPREFIX + "panel") }
            }),
            cancellationToken: cancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Shows the tenant tutorial manager for the colleague owner.
    /// </summary>
    /// <param name="botClient">Owned bot client used to edit the panel message.</param>
    /// <param name="callbackQuery">Owner callback requesting tutorial management.</param>
    /// <param name="owner">Colleague owner whose tenant tutorials are displayed.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <param name="answerCallback">
    /// Whether this method owns the one allowed Telegram callback answer. Pass <c>false</c> when the caller already
    /// acknowledged the callback before a database mutation, such as tutorial deletion.
    /// </param>
    /// <remarks>
    /// Callback acknowledgement occurs before database and edit operations so a slow users.db or Telegram edit
    /// cannot turn the callback answer into <c>query is too old</c>.
    /// </remarks>
    private async Task SHOWTENANTTUTORIALMANAGERASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser owner,
        CancellationToken cancellationToken,
        bool answerCallback = true)
    {
        if (answerCallback)
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        var tutorials = ReadTenantTutorials(tenant).ToList();
        var text = new System.Text.StringBuilder();
        text.AppendLine("🎓 <b>آموزش‌های ربات فروشگاهی</b>");
        text.AppendLine();
        text.AppendLine("هر آموزش شامل یک عنوان و یک لینک از کانال یا سایت شماست.");
        text.AppendLine();
        if (tutorials.Count == 0)
            text.AppendLine("هنوز آموزشی ثبت نشده است.");
        else
            for (var i = 0; i < tutorials.Count; i++)
                text.AppendLine($"{i + 1}. <a href=\"{Html(tutorials[i].Url)}\">{Html(tutorials[i].Title)}</a>");

        var rows = new List<InlineKeyboardButton[]>
        {
            new[] { InlineKeyboardButton.WithCallbackData("➕ افزودن آموزش", OWNERCALLBACKPREFIX + "tutorial-add") }
        };
        for (var i = 0; i < tutorials.Count; i++)
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData($"🗑 حذف {i + 1}", OWNERCALLBACKPREFIX + $"tutorial-del:{i}") });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") });

        await SafeEditMessageTextAsync(
            botClient,
            callbackQuery.Message.Chat.Id,
            callbackQuery.Message.MessageId,
            text.ToString(),
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(rows),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Starts owner input for adding a tenant tutorial title.
    /// </summary>
    /// <param name="botClient">Owned bot client used to prompt the owner.</param>
    /// <param name="callbackQuery">Owner callback that requested tutorial creation.</param>
    /// <param name="cancellationToken">Cancellation token for state and Telegram operations.</param>
    /// <returns>A task completing after the bot-scoped tutorial input step and prompt are saved and sent.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task STARTTENANTTUTORIALADDASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
        await _state.SaveUserStatus(new User
        {
            Id = callbackQuery.From.Id,
            Flow = OWNERFLOW,
            LastStep = STEPTUTORIALTITLE
        });
        await botClient.SendMessage(
            callbackQuery.Message.Chat.Id,
            "عنوان آموزش را ارسال کنید؛ مثلا: آموزش نصب روی اندروید",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Saves the two-step tenant tutorial input collected from the owner.
    /// </summary>
    /// <param name="botClient">Owned bot client used to ask for the next field or show success.</param>
    /// <param name="message">Owner message containing title or URL.</param>
    /// <param name="owner">Colleague owner whose tenant tutorial list is updated.</param>
    /// <param name="state">Current owner state row.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <returns>A task completing after the tutorial draft advances or the completed tutorial is saved.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task SAVETENANTTUTORIALSTEPASYNC(
        ITelegramBotClient botClient,
        Message message,
        CredUser owner,
        User state,
        CancellationToken cancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        if (tenant == null)
            return;

        var text = message.Text?.Trim();
        if (state.LastStep == STEPTUTORIALTITLE)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                await botClient.SendMessage(message.Chat.Id, "عنوان نمی‌تواند خالی باشد.", cancellationToken: cancellationToken);
                return;
            }

            state.Flow = OWNERFLOW;
            state.LastStep = STEPTUTORIALURL;
            state.SubLink = text;
            await _state.SaveUserStatus(state);
            await botClient.SendMessage(message.Chat.Id, "حالا لینک آموزش را ارسال کنید.", cancellationToken: cancellationToken);
            return;
        }

        if (!Uri.TryCreate(text, UriKind.Absolute, out _))
        {
            await botClient.SendMessage(message.Chat.Id, "لینک معتبر نیست. یک لینک کامل مثل https://t.me/... ارسال کنید.", cancellationToken: cancellationToken);
            return;
        }

        var tutorials = ReadTenantTutorials(tenant).ToList();
        tutorials.Add(new TenantTutorialLink { Title = state.SubLink, Url = text });
        tenant.TenantTutorialsJson = JsonConvert.SerializeObject(tutorials);
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);
        await _state.ClearUserStatus(state);
        await _state.SaveUserStatus(new User { Id = owner.TelegramUserId, OwnerStoreId = tenant.Id });
        await botClient.SendMessage(message.Chat.Id, "✅ آموزش ثبت شد.", replyMarkup: BUILDOWNERPANELKEYBOARD(tenant), cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Deletes one tenant tutorial by list index.
    /// </summary>
    /// <param name="botClient">Owned bot client used to edit the tutorial manager.</param>
    /// <param name="callbackQuery">Owner callback containing the tutorial index.</param>
    /// <param name="owner">Colleague owner whose tutorial is deleted.</param>
    /// <param name="indexText">Zero-based tutorial index from callback data.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    private async Task DELETETENANTTUTORIALASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser owner,
        string indexText,
        CancellationToken cancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        var tutorials = ReadTenantTutorials(tenant).ToList();
        if (!int.TryParse(indexText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var index) || index < 0 || index >= tutorials.Count)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "آموزش پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
        tutorials.RemoveAt(index);
        tenant.TenantTutorialsJson = JsonConvert.SerializeObject(tutorials);
        tenant.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);
        await SHOWTENANTTUTORIALMANAGERASYNC(
            botClient,
            callbackQuery,
            owner,
            cancellationToken,
            answerCallback: false);
    }

    /// <summary>
    /// Starts the tenant broadcast input flow for a colleague owner.
    /// </summary>
    /// <param name="botClient">Owned bot client used to prompt the owner.</param>
    /// <param name="callbackQuery">Owner callback that opened broadcast.</param>
    /// <param name="cancellationToken">Cancellation token for state and Telegram operations.</param>
    /// <returns>A task completing after the owner broadcast input step and prompt are prepared.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task STARTTENANTBROADCASTASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CancellationToken cancellationToken)
    {
        await _state.SaveUserStatus(new User
        {
            Id = callbackQuery.From.Id,
            Flow = OWNERFLOW,
            LastStep = STEPBROADCASTINPUT
        });
        await botClient.SendMessage(
            callbackQuery.Message.Chat.Id,
            "پیام عمومی فروشگاه را ارسال کنید.\nمی‌توانید متن بفرستید یا لینک پست کانال خودتان را ارسال کنید تا همان پست forward شود.",
            cancellationToken: cancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Stores a tenant broadcast draft and asks the owner for final confirmation.
    /// </summary>
    /// <param name="botClient">Owned bot client used to show the preview.</param>
    /// <param name="message">Owner message containing text or a Telegram post URL.</param>
    /// <param name="owner">Colleague owner who owns the tenant broadcast audience.</param>
    /// <param name="cancellationToken">Cancellation token for state and Telegram operations.</param>
    /// <returns>A task completing after the broadcast draft is stored and its confirmation preview is sent.</returns>
    /// <remarks>The caller must establish the active bot context and authorize the actor before entry. Conversation writes use BotId plus TelegramUserId, preserving independent state for the same person in other bots. Network work is outside state-store transactions.</remarks>
    private async Task PREPARETENANTBROADCASTASYNC(
        ITelegramBotClient botClient,
        Message message,
        CredUser owner,
        CancellationToken cancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        if (tenant == null)
            return;

        var recipients = await GetTenantBroadcastRecipientsAsync(tenant, cancellationToken);
        var audienceCount = recipients.Count;
        var draft = message.Text?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(draft))
        {
            await botClient.SendMessage(message.Chat.Id, "متن یا لینک پست نمی‌تواند خالی باشد.", cancellationToken: cancellationToken);
            return;
        }

        var token = Guid.NewGuid().ToString("N")[..10];
        await _state.SaveUserStatus(new User
        {
            Id = message.From.Id,
            Flow = OWNERFLOW,
            LastStep = string.Empty,
            ConfigLink = token,
            SubLink = draft
        });

        await botClient.SendMessage(
            message.Chat.Id,
            "📢 <b>پیش‌نمایش پیام عمومی</b>\n\n" +
            $"مخاطب‌های این فروشگاه: <code>{audienceCount}</code>\n" +
            $"محتوا:\n<code>{Html(draft)}</code>\n\n" +
            "ارسال فقط برای کاربرانی انجام می‌شود که همین tenant bot را start کرده‌اند.",
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("✅ ارسال نهایی", OWNERCALLBACKPREFIX + $"broadcast-send:{token}") },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") }
            }),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Queues a confirmed tenant broadcast to users who have interacted with that exact tenant bot.
    /// </summary>
    /// <param name="botClient">Owned bot client used to edit progress for the owner.</param>
    /// <param name="callbackQuery">Owner confirmation callback containing the draft token.</param>
    /// <param name="owner">Colleague owner whose tenant audience receives the broadcast.</param>
    /// <param name="token">Draft token stored in the owner bot state.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <remarks>
    /// The tenant audience is tenant-scoped through <see cref="GetTenantBroadcastRecipientsAsync" />.
    /// Delivery itself is delegated to <see cref="BroadcastManager"/> so tenant owners get the same retry,
    /// refresh, live progress, and final summary behavior as super-admin broadcasts. The status message is
    /// edited by the owned bot that received the owner callback, while each recipient receives the message
    /// from the tenant bot configured by the colleague.
    /// </remarks>
    /// <returns>A task completing after broadcast submission to the tracked sender and its owner response.</returns>
    private async Task SENDTENANTBROADCASTASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser owner,
        string token,
        CancellationToken cancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        var state = await _state.GetUserStatus(owner.TelegramUserId);
        if (tenant == null || state?.ConfigLink != token || string.IsNullOrWhiteSpace(state.SubLink))
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "پیش‌نویس پیام عمومی پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var content = state.SubLink;
        var recipients = await GetTenantBroadcastRecipientsAsync(tenant, cancellationToken);
        var template = BuildTenantBroadcastTemplate(content);

        await SafeEditMessageTextAsync(
            botClient,
            callbackQuery.Message.Chat.Id,
            callbackQuery.Message.MessageId,
            $"در حال آماده‌سازی ارسال عمومی فروشگاه برای <code>{recipients.Count}</code> کاربر...",
            parseMode: ParseMode.Html,
            cancellationToken: cancellationToken);

        var job = await _broadcastManager.EnqueueAsync(
            recipients,
            template,
            callbackQuery.Message.Chat.Id,
            callbackQuery.Message.MessageId,
            owner.TelegramUserId,
            cancellationToken,
            senderBotId: tenant.Id);

        await _state.ClearUserStatus(state);
        await _state.SaveUserStatus(new User { Id = owner.TelegramUserId, OwnerStoreId = tenant.Id });
        await _broadcastManager.RefreshStatusMessageAsync(job.Id, cancellationToken);
        await botClient.SendMessage(
            callbackQuery.Message.Chat.Id,
            "ارسال عمومی فروشگاه شروع شد. وضعیت را از پیام بالا پیگیری کنید.",
            replyMarkup: BUILDOWNERPANELKEYBOARD(tenant),
            cancellationToken: cancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Converts an owner tenant-broadcast draft into the shared broadcast template model.
    /// </summary>
    /// <param name="content">
    /// Owner-provided broadcast content. A public Telegram post URL is converted to a forward template;
    /// every other value is sent as plain text by the tenant bot.
    /// </param>
    /// <returns>
    /// A <see cref="BroadcastManager.BroadcastItem"/> without a recipient chat id. The caller supplies the
    /// tenant-scoped audience when enqueueing the job.
    /// </returns>
    /// <remarks>
    /// This helper deliberately does not read global users. It only decides how the already-approved tenant
    /// broadcast content should be delivered by <see cref="BroadcastManager"/>.
    /// </remarks>
    private static BroadcastManager.BroadcastItem BuildTenantBroadcastTemplate(string content)
    {
        if (TryParseTelegramPostLink(content, out var fromChat, out var messageId))
        {
            return new BroadcastManager.BroadcastItem
            {
                FromChatId = fromChat,
                MessageId = messageId,
                IsForward = true
            };
        }

        return new BroadcastManager.BroadcastItem
        {
            Text = content,
            IsForward = false
        };
    }

    /// <summary>
    /// Gets the exact Telegram audience for a tenant storefront broadcast.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot whose private-chat users should receive the broadcast. The method uses
    /// <see cref="BotInstance.Id"/> as the tenant-scoped key and never reads users from another bot.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the users.db query.</param>
    /// <returns>
    /// A distinct list of numeric Telegram user ids that have a <see cref="BotUserState"/> row for this exact
    /// tenant bot. The list can be empty when nobody has started or interacted with the storefront yet.
    /// </returns>
    /// <remarks>
    /// This is the only audience source for tenant broadcasts. A colleague owner must not send tenant broadcast
    /// messages to global owned-bot users, users of another tenant, or users known only from <c>credentials.db</c>.
    /// Telegram private chats use the numeric user id as the chat id, so the returned ids are safe to pass to
    /// the tenant bot client for text or forwarded-message delivery.
    /// </remarks>
    private async Task<List<long>> GetTenantBroadcastRecipientsAsync(BotInstance tenant, CancellationToken cancellationToken)
    {
        if (tenant == null || string.IsNullOrWhiteSpace(tenant.Id))
            return new List<long>();

        return await _workflow.ReadAsync(async db => await db.BotUserStates
            .Where(x => x.BotId == tenant.Id && x.TelegramUserId > 0)
            .Select(x => x.TelegramUserId)
            .Distinct()
            .OrderBy(x => x)
            .ToListAsync(cancellationToken));
    }

    /// <summary>
    /// Shows seven completed Tehran days of tenant-scoped usage from the shared activity aggregator.
    /// </summary>
    /// <param name="botClient">Owned bot client used to edit the owner-panel message.</param>
    /// <param name="callbackQuery">Owner callback that requested daily statistics.</param>
    /// <param name="owner">Colleague owner whose tenant bot stats are displayed.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <returns>A task that completes after the existing owner-panel message is edited or an error is answered.</returns>
    /// <remarks>
    /// The report is isolated by the owner's internal tenant bot id, excludes global super-admin ids, counts messages
    /// and callbacks, and uses only the seven completed Tehran days ending yesterday. It does not read sales values.
    /// </remarks>
    private async Task SHOWTENANTDAILYSTATSASYNC(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        CredUser owner,
        CancellationToken cancellationToken)
    {
        var tenant = await GetSelectedOwnerStoreAsync(owner.TelegramUserId, cancellationToken);
        if (tenant == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "ربات فروشگاهی پیدا نشد.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var startIran = _usageAnalyticsService.GetIranNow().Date.AddDays(-7);
        var report = await _usageAnalyticsService.GetReportAsync(
            startIran,
            7,
            botIdFilter: tenant.Id,
            includeSales: false,
            cancellationToken);
        var builder = new System.Text.StringBuilder();
        builder.AppendLine("📊 <b>آمار روزانه فروشگاه</b>");
        builder.AppendLine("۷ روز کامل تا دیروز؛ شامل پیام‌ها و دکمه‌های callback:");
        builder.AppendLine();
        foreach (var item in report.Days)
        {
            builder.AppendLine(
                $"📅 <code>{UsageAnalyticsService.FormatPersianDate(item.DateIran)}</code> | " +
                $"👤 <code>{item.UniqueUsers:N0}</code> کاربر | 💬 <code>{item.Interactions:N0}</code> تعامل");
        }

        if (report.MissingActivityLogDays > 0 || report.MalformedLines > 0)
        {
            builder.AppendLine();
            builder.AppendLine(
                $"⚠️ <code>{report.MissingActivityLogDays}</code> روز بدون فایل و " +
                $"<code>{report.MalformedLines}</code> خط خراب نادیده گرفته شد.");
        }

        await SafeEditMessageTextAsync(
            botClient,
            callbackQuery.Message.Chat.Id,
            callbackQuery.Message.MessageId,
            builder.ToString(),
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("🔄 بروزرسانی", OWNERCALLBACKPREFIX + "stats") },
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") }
            }),
            cancellationToken: cancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, cancellationToken: cancellationToken);
    }

    /// <summary>
    /// sends A short owner hint for the Shared wallet ledger UNTIL the full owner-panel ledger VIEW is expanded.
    /// </summary>
    /// <param name="botClient">Main owned Bot client used to answer the callback.</param>
    /// <param name="CallbackQuery">owner callback that requested ledger Information.</param>
    /// <param name="owner">colleague User whose wallet ledger is stored UNDER the Shared credentials IDENTITY.</param>
    /// <param name="CancellationToken">Cancellation Token for Telegram calls.</param>
    /// <remarks>
    /// the general User Menu already EXPOSES the PAGINATED ledger by Telegram User Id. this method POINTS
    /// the tenant owner to the same ledger Source without creating A second INCONSISTENT financial VIEW.
    /// </remarks>
    private async Task ShowOwnerLedgerHintAsync(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
        await SafeEditMessageTextAsync(botClient, 
            CallbackQuery.Message.Chat.Id,
            CallbackQuery.Message.MessageId,
            "📌 تراکنش‌های کیف پول شما در بخش «تراکنش‌های من» منوی اصلی قابل مشاهده است.\nهمه فروش‌های tenant و کسر/افزایش موجودی هم در همان ledger ثبت می‌شود.",
            replyMarkup: new InlineKeyboardMarkup(new[] { new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") } }),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Shows the colleague-facing setup guide for BotFather, tenant storefront branding, forced join, and Sales Assistant usage.
    /// </summary>
    /// <param name="botClient">Main owned bot client used to edit the owner-panel message.</param>
    /// <param name="CallbackQuery">Owner callback that requested the guide.</param>
    /// <param name="owner">Colleague profile that owns the tenant storefront.</param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <remarks>
    /// The guide is informational only. It does not mutate tenant settings and it does not validate tokens or channels.
    /// </remarks>
    private async Task SHOWOWNERGUIDEASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        var assistant = _botRegistry.Bots.FirstOrDefault(x => string.Equals(x.Type, BotInstanceTypes.SalesAssistant, StringComparison.OrdinalIgnoreCase));
        var assistantUsername = string.IsNullOrWhiteSpace(assistant?.Username) ? "ربات دستیار فروش" : "@" + assistant.Username.TrimStart('@');
        var text =
            "📘 <b>راهنمای پنل همکاری و ربات فروشگاهی</b>\n\n" +
            "1. داخل <b>@BotFather</b> دستور <code>/newbot</code> را بزنید و برای فروشگاه خودتان یک نام و username بسازید.\n" +
            "2. بعد از ساخت ربات، توکن را از BotFather بگیرید و در همین پنل با دکمه «ثبت/تغییر توکن» ذخیره کنید.\n" +
            "3. برای حرفه‌ای‌تر شدن فروشگاه، در BotFather از بخش‌های <code>/setuserpic</code>، <code>/setdescription</code> و <code>/setabouttext</code> عکس، توضیحات و متن معرفی ربات را تنظیم کنید.\n" +
            "4. اگر می‌خواهید جوین اجباری داشته باشید، ربات فروشگاهی را داخل کانال خودتان اضافه و admin کنید، سپس آیدی کانال را در بخش «کانال جوین» ثبت کنید.\n" +
            "5. ربات فروشگاهی و کانال بعد از ساخت دست خودتان می‌ماند و مشتری‌ها با برند شما خرید می‌کنند.\n\n" +
            $"🤖 <b>ربات دستیار فروش:</b> {Html(assistantUsername)}\n" +
            "این ربات برای نمایش فروش‌ها، رسیدهای کارت‌به‌کارت و تایید نهایی رسیدهاست. حتماً آن را start کنید. وقتی مشتری رسید کارت‌به‌کارت می‌فرستد، عکس رسید در دستیار فروش می‌آید؛ شما اول «تایید» و بعد «تایید نهایی» را می‌زنید.\n\n" +
            "اگر رسیدی به هر دلیل تایید نشد، از دکمه «تایید دستی کارت‌به‌کارت» در همین پنل استفاده کنید و OrderId سفارش را دقیق وارد کنید.";

        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
        await SafeEditMessageTextAsync(
            botClient,
            CallbackQuery.Message.Chat.Id,
            CallbackQuery.Message.MessageId,
            text,
            parseMode: ParseMode.Html,
            replyMarkup: new InlineKeyboardMarkup(new[] { new[] { InlineKeyboardButton.WithCallbackData("بازگشت", OWNERCALLBACKPREFIX + "panel") } }),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Sends a test message from the configured Sales Assistant bot to the colleague owner.
    /// </summary>
    /// <param name="botClient">Main owned bot client used to answer the callback in the owner panel.</param>
    /// <param name="CallbackQuery">Owner callback that requested the assistant test.</param>
    /// <param name="owner">Colleague profile whose Telegram id should receive the assistant test message.</param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <remarks>
    /// Telegram only lets a bot message users who have started it. A <c>chat not found</c> or block error is
    /// reported to the owner as setup guidance instead of failing the tenant panel flow.
    /// </remarks>
    private async Task TESTSALESASSISTANTASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        var assistant = _botRegistry.Bots.FirstOrDefault(x => string.Equals(x.Type, BotInstanceTypes.SalesAssistant, StringComparison.OrdinalIgnoreCase));
        if (assistant == null || string.IsNullOrWhiteSpace(assistant.Token))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "ربات دستیار فروش در کانفیگ فعال نشده است.", showAlert: true, cancellationToken: CancellationToken);
            return;
        }

        var assistantUsername = string.IsNullOrWhiteSpace(assistant.Username) ? "ربات دستیار فروش" : "@" + assistant.Username.TrimStart('@');
        try
        {
            await _botClientProvider.GetClient(assistant.Id).SendMessage(
                owner.TelegramUserId,
                "✅ تست ربات دستیار فروش موفق بود.\nاز این به بعد فروش‌ها و رسیدهای کارت‌به‌کارت اینجا برای شما ارسال می‌شود.",
                cancellationToken: CancellationToken);

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "پیام تست در ربات دستیار فروش ارسال شد.", showAlert: true, cancellationToken: CancellationToken);
        }
        catch (ApiRequestException ex) when (ex.Message.Contains("chat not found", StringComparison.OrdinalIgnoreCase) ||
                                            ex.Message.Contains("bot was blocked", StringComparison.OrdinalIgnoreCase) ||
                                            ex.Message.Contains("forbidden", StringComparison.OrdinalIgnoreCase))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, $"اول {assistantUsername} را start کنید، بعد دوباره تست بگیرید.", showAlert: true, cancellationToken: CancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Sales assistant test failed. owner={OwnerTelegramUserId}", owner.TelegramUserId);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "ارسال پیام تست ناموفق بود. لاگ را بررسی کنید.", showAlert: true, cancellationToken: CancellationToken);
        }
    }

    /// <summary>
    /// Starts the owner-side flow that asks for a tenant card-to-card order id and manually approves it.
    /// </summary>
    /// <param name="botClient">Main owned bot client used to prompt the colleague owner.</param>
    /// <param name="CallbackQuery">Owner callback that requested manual card-order confirmation.</param>
    /// <param name="CancellationToken">Cancellation token for state persistence and Telegram delivery.</param>
    /// <remarks>
    /// The next owner text message is interpreted as an exact tenant <c>OrderId</c>. The final approval still
    /// runs through the shared idempotent fulfillment path so duplicate approvals cannot create duplicate accounts.
    /// </remarks>
    /// <returns>A task completing after the bot-scoped order-id prompt is saved and sent.</returns>
    private async Task STARTMANUALCARDORDERCONFIRMASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CancellationToken CancellationToken)
    {
        await _state.SaveUserStatus(new User
        {
            Id = CallbackQuery.From.Id,
            Flow = OWNERFLOW,
            LastStep = STEPMANUALCARDORDERID
        });

        await botClient.SendMessage(
            CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id,
            "OrderId سفارش کارت‌به‌کارت را دقیق ارسال کنید.\nمثال: <code>TENANTBOT-...</code>",
            parseMode: ParseMode.Html,
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: CancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Handles tenant customer text messages such as <c>/start</c>, purchases, tariffs, support, and payment returns.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client belonging to the active tenant storefront. It must not be the default owned-bot client.
    /// </param>
    /// <param name="Message">
    /// Incoming tenant-customer message. Its sender id is the Telegram user id scoped to the active tenant bot, and its
    /// chat id receives storefront, membership, payment, or flow responses.
    /// </param>
    /// <param name="customer">
    /// Shared credentials profile for the sender. Wallet/profile identity is global, while the conversation state and
    /// tenant order routing remain scoped to the active storefront.
    /// </param>
    /// <param name="User">
    /// Bot-scoped conversation state for this Telegram user. The state belongs to the active tenant bot and
    /// is passed through to shared XUI handlers so account search, comment changes, and renewal steps do not
    /// leak into another bot instance.
    /// </param>
    /// <param name="CancellationToken">Token for users.db, Telegram, payment, tenant-order, and XUI operations.</param>
    /// <returns>A task that completes after the tenant message is consumed.</returns>
    /// <remarks>
    /// This method handles tenant-only purchase and payment messages locally, but delegates account-management
    /// commands and the unchanged bot/user-scoped free-trial policy to <see cref="XuiV3BotFlowService" />.
    /// Contacts use the owned-bot verifier and save only the shared phone profile, without financial effects.
    /// The outer dispatcher clears persisted conversation state and the
    /// in-memory XUI selection before every valid tenant <c>/start</c>, then this method preserves the storefront-enabled
    /// and mandatory-join gates before displaying home. Payment success/cancel payloads retain their existing order
    /// behavior after that reset. Tenant bots deliberately do not accept <c>/refresh</c>.
    /// </remarks>
    /// <example>
    /// <code>
    /// await HANDLECUSTOMERMESSAGEASYNC(botClient, message, customer, botScopedState, cancellationToken);
    /// </code>
    /// </example>
    private async Task HANDLECUSTOMERMESSAGEASYNC(
        ITelegramBotClient botClient,
        Message Message,
        CredUser customer,
        User User,
        CancellationToken CancellationToken)
    {
        var tenant = await GetCurrentTenantBotAsync(CancellationToken);
        if (tenant == null || !tenant.Enabled)
        {
            await botClient.SendMessage(Message.Chat.Id, "فروشگاه در حال حاضر غیرفعال است.", cancellationToken: CancellationToken);
            return;
        }

        if (!await EnsureTenantCustomerJoinAsync(botClient, Message, tenant, CancellationToken))
            return;

        // A card-to-card receipt may arrive either as a compressed Telegram photo or as an uncompressed image
        // document, which is what the production incident exposed. Both resolve to a plain file id through one helper so
        // the two message shapes cannot drift into different ingestion behavior.
        if (TenantReceiptMediaResolver.TryResolve(Message, out var receiptMedia))
        {
            await CREATETENANTMANUALRECEIPTASYNC(botClient, Message, tenant, customer, receiptMedia, CancellationToken);
            return;
        }

        // Only answer an unsupported document when the customer is actually mid receipt-upload, so an unrelated file in
        // the storefront is not lectured about receipt formats. The durable target is deliberately kept so the customer
        // can immediately send a correct image without pressing the receipt button again.
        if (Message.Document != null &&
            await _state.GetPendingReceiptTargetAsync(customer.TelegramUserId, CancellationToken) is not null)
        {
            await botClient.SendMessage(
                Message.Chat.Id,
                "❌ فایل رسید باید تصویر باشد. لطفاً رسید را به صورت عکس (JPG، PNG یا WebP) ارسال کنید.",
                replyMarkup: BuildTenantReplyKeyboard(),
                cancellationToken: CancellationToken);
            return;
        }

        var Text = Message.Text?.Trim() ?? string.Empty;
        var tenantReplyKeyboard = BuildTenantReplyKeyboard();

        if (Message.Contact != null)
        {
            var phone = await TelegramPhoneVerification.ValidateAsync(botClient, Message,
                BuildTenantSupportContactHtml(tenant.SupportAccount), tenantReplyKeyboard, CancellationToken);
            if (phone != null)
            {
                await _credentialsDbContext.SavePhoneNumber(Message.From.Id, phone);
                await botClient.SendMessage(Message.Chat.Id,
                    "شماره شما با موفقیت تایید شد. حالا دوباره گزینه مورد نظرتان را انتخاب کنید.",
                    replyMarkup: tenantReplyKeyboard, cancellationToken: CancellationToken);
            }
            return;
        }

        var hasStartCommand = TelegramNavigationCommandParser.TryParse(
                                  Text,
                                  BotContextAccessor.CurrentBotUsername,
                                  allowRefresh: false,
                                  out var navigationCommand) &&
                              navigationCommand.Kind == TelegramNavigationCommandKind.Start;

        if (hasStartCommand)
        {
            if (navigationCommand.HasPayloadToken("payment_success"))
            {
                await botClient.SendMessage(Message.Chat.Id, "پرداخت از سمت درگاه پرداخت تایید شد. در حال بررسی وضعیت سفارش...", cancellationToken: CancellationToken);
                await CHECKLATESTCUSTOMERORDERASYNC(botClient, Message.Chat.Id, customer.TelegramUserId, CancellationToken);
                return;
            }

            if (navigationCommand.HasPayloadToken("payment_cancel"))
            {
                await MARKLATESTCUSTOMERORDERCANCELLEDASYNC(botClient, Message.Chat.Id, customer.TelegramUserId, CancellationToken);
                return;
            }

            await SendTenantHomeAsync(botClient, Message.Chat.Id, tenant, CancellationToken);
            return;
        }

        // Reuse owned trial eligibility, per-type cooldown and durable creation under the current storefront context.
        if (await _xuiV3BotFlowService.TryHandleFreeTrialAsync(
                botClient, Message, customer, User, tenantReplyKeyboard, CancellationToken))
            return;

        if (Text == "خرید اکانت" || Text == "💳 خرید اکانت")
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await SendServiceSelectionAsync(botClient, Message.Chat.Id, tenant, CancellationToken);
            return;
        }

        if (Text == "تعرفه‌ها" || Text == "📋 تعرفه‌ها")
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await botClient.SendMessage(
                Message.Chat.Id,
                BUILDTENANTTARIFFSTEXT(tenant),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantReplyKeyboard(),
                cancellationToken: CancellationToken);
            return;
        }

        if (Text == "پشتیبانی" || Text == "💬 پشتیبانی")
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            var support = BuildTenantSupportContactHtml(tenant.SupportAccount);
            await botClient.SendMessage(
                Message.Chat.Id,
                $"برای پشتیبانی فروشگاه به این آیدی پیام بدهید:\n{support}",
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantReplyKeyboard(),
                cancellationToken: CancellationToken);
            return;
        }

        if (IsTenantTutorialCommand(Text))
        {
            await _state.ClearUserStatus(new User { Id = Message.From.Id });
            await SendTenantTutorialsAsync(botClient, Message.Chat.Id, tenant, CancellationToken);
            return;
        }

        if (await TRYHANDLETENANTPURCHASETEXTASYNC(
                botClient,
                Message,
                tenant,
                User,
                CancellationToken))
            return;

        if (await _xuiV3BotFlowService.TryHandleAccountCommentTextAsync(
                botClient,
                Message,
                customer,
                User,
                tenantReplyKeyboard,
                CancellationToken))
            return;

        if (IsTenantMyAccountsCommand(Text))
        {
            if (await _xuiV3BotFlowService.TryHandleMyAccountsAsync(
                    botClient,
                    Message,
                    customer,
                    tenantReplyKeyboard,
                    CancellationToken))
                return;
        }

        if (await _xuiV3BotFlowService.TryHandleAccountSearchAsync(
                botClient,
                Message,
                customer,
                User,
                tenantReplyKeyboard,
                CancellationToken))
            return;

        if (await TRYHANDLETENANTRENEWASYNC(
                botClient,
                Message,
                tenant,
                customer,
                User,
                tenantReplyKeyboard,
                CancellationToken))
            return;

        await SendTenantHomeAsync(botClient, Message.Chat.Id, tenant, CancellationToken);
    }

    /// <summary>
    /// Handles typed metered traffic and custom duration days in a tenant customer's purchase flow.
    /// </summary>
    /// <param name="botClient">Tenant bot client that received the customer's typed traffic value.</param>
    /// <param name="message">
    /// Incoming customer text message containing either a GB amount in the traffic step or a digit-only custom day
    /// count in the duration step.
    /// </param>
    /// <param name="tenant">Tenant storefront whose prices will be used after a valid traffic amount is selected.</param>
    /// <param name="user">
    /// Bot-scoped customer state. The state belongs to the active tenant bot and carries the selected metered service key.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for users.db state updates and Telegram replies.</param>
    /// <returns>
    /// <c>true</c> when the message belonged to tenant purchase traffic or duration state and was handled; otherwise
    /// <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Tenant purchase preserves its inline preset callbacks while accepting typed traffic and <c>days-N</c> duration
    /// selections. Both values are validated by the same global policy used by owned bots before an order, gateway
    /// invoice, tenant balance movement, or XUI request can be created. A stale duration is cleared with an explicit
    /// empty value because null is intentionally treated as "preserve" by legacy partial state updates.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during users.db or Telegram work.
    /// </exception>
    private async Task<bool> TRYHANDLETENANTPURCHASETEXTASYNC(
        ITelegramBotClient botClient,
        Message message,
        BotInstance tenant,
        User user,
        CancellationToken cancellationToken)
    {
        if (!string.Equals(user?.Flow, TENANTPURCHASEFLOW, StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(user.SelectedCountry))
        {
            return false;
        }

        var text = message.Text?.Trim() ?? string.Empty;
        if (IsCancelText(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                message.Chat.Id,
                "فرایند خرید لغو شد.",
                replyMarkup: BuildTenantReplyKeyboard(),
                cancellationToken: cancellationToken);
            return true;
        }

        var service = _purchaseService.GetEnabledServices()
            .FirstOrDefault(x => string.Equals(x.Key, user.SelectedCountry, StringComparison.OrdinalIgnoreCase));
        if (service == null || service.IsUnlimited)
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(
                message.Chat.Id,
                "سرویس انتخاب‌شده قبلی دیگر فعال نیست. لطفاً سرویس جدید را انتخاب کنید.",
                cancellationToken: cancellationToken);
            await SendServiceSelectionAsync(botClient, message.Chat.Id, tenant, cancellationToken);
            return true;
        }

        if (user.LastStep == TENANTPURCHASESTEPTRAFFIC)
        {
            if (!TryParseTenantTrafficSelection(text, service, out var trafficGb))
            {
                await botClient.SendMessage(
                    message.Chat.Id,
                    BuildTenantMinimumTrafficMessage(service),
                    replyMarkup: BuildTenantTrafficInlineKeyboard(service),
                    cancellationToken: cancellationToken);
                return true;
            }

            await _state.ResetUserStatus(new User
            {
                Id = message.From.Id,
                Flow = TENANTPURCHASEFLOW,
                LastStep = TENANTPURCHASESTEPDURATION,
                SelectedCountry = service.Key,
                TotoalGB = trafficGb.ToString(CultureInfo.InvariantCulture),
                SelectedPeriod = string.Empty,
                Type = string.Empty,
                PendingUserComment = string.Empty
            });

            await SHOWDURATIONOPTIONSASYNC(
                botClient,
                message.Chat.Id,
                null,
                tenant,
                service.Key,
                trafficGb,
                cancellationToken);
            return true;
        }

        if (user.LastStep == TENANTPURCHASESTEPDURATION)
        {
            if (!int.TryParse(
                    user.TotoalGB,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out var trafficGb) ||
                !XuiV3PurchaseService.MeetsMinimumTraffic(service, trafficGb))
            {
                await _state.ResetUserStatus(new User
                {
                    Id = message.From.Id,
                    Flow = TENANTPURCHASEFLOW,
                    LastStep = TENANTPURCHASESTEPTRAFFIC,
                    SelectedCountry = service.Key,
                    SelectedPeriod = string.Empty,
                    Type = string.Empty,
                    TotoalGB = string.Empty,
                    PendingUserComment = string.Empty
                });
                await botClient.SendMessage(
                    message.Chat.Id,
                    BuildTenantMinimumTrafficMessage(service),
                    replyMarkup: BuildTenantTrafficInlineKeyboard(service),
                    cancellationToken: cancellationToken);
                return true;
            }

            if (!XuiV3PurchaseService.TryResolveDurationInput(service, text, out var duration))
            {
                await SHOWDURATIONOPTIONSASYNC(
                    botClient,
                    message.Chat.Id,
                    null,
                    tenant,
                    service.Key,
                    trafficGb,
                    cancellationToken,
                    "مدت معتبر نیست. یکی از گزینه‌های فعال را انتخاب کنید.");
                return true;
            }

            var selection = new XuiV3PurchaseSelection
            {
                ServiceKey = service.Key,
                TrafficGb = trafficGb,
                DurationKey = duration.Key
            };
            await _state.ClearUserStatus(user);
            await SHOWCUSTOMERCONFIRMASYNC(
                botClient,
                message.Chat.Id,
                null,
                tenant,
                selection,
                cancellationToken);
            return true;
        }

        await botClient.SendMessage(
            message.Chat.Id,
            "برای ادامه، مدت سرویس را از دکمه‌های پیام قبلی انتخاب کنید یا انصراف دهید.",
            replyMarkup: new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("بازگشت به انتخاب سرویس", CUSTOMERCALLBACKPREFIX + "services") }
            }),
            cancellationToken: cancellationToken);
        return true;
    }

    /// <summary>
    /// Checks whether a tenant customer asked to see the XUI accounts already linked to their Telegram id.
    /// </summary>
    /// <param name="text">
    /// The raw reply-keyboard text received from the tenant bot customer. The value is tenant-scoped only by
    /// the active <see cref="BotContextAccessor" /> context; it is not a Telegram command or payment provider id.
    /// </param>
    /// <returns>
    /// <c>true</c> when the text is one of the tenant-facing aliases for the existing "my accounts" flow.
    /// </returns>
    /// <remarks>
    /// The shared XUI flow historically starts from "وضعیت اکانت های من"; tenant storefronts display the
    /// shorter "اکانت‌های من" label, so the tenant layer normalizes that label before delegating to the shared service.
    /// </remarks>
    private static bool IsTenantMyAccountsCommand(string text)
    {
        return string.Equals(text, "اکانت‌های من", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "اکانت های من", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "وضعیت اکانت های من", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Checks whether a tenant customer opened the installation tutorial menu.
    /// </summary>
    /// <param name="text">The tenant customer reply-keyboard text. Empty values are treated as non-matches.</param>
    /// <returns><c>true</c> when the customer selected the tenant tutorial command.</returns>
    private static bool IsTenantTutorialCommand(string text)
    {
        return string.Equals(text, "راهنما نصب", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "💡راهنما نصب", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Handles the tenant-specific renewal flow without debiting the customer's shared wallet.
    /// </summary>
    /// <param name="botClient">Tenant bot client that is serving the storefront customer.</param>
    /// <param name="message">Incoming tenant customer message.</param>
    /// <param name="tenant">Tenant bot whose pricing and payment settings apply to the renewal.</param>
    /// <param name="customer">Credentials profile of the customer requesting renewal.</param>
    /// <param name="user">Bot-scoped state row for this customer and tenant bot.</param>
    /// <param name="mainReplyMarkup">Tenant reply keyboard restored when the flow ends or fails.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram, database, and panel calls.</param>
    /// <returns>
    /// <c>true</c> when the message belonged to the tenant renewal state machine; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Tenant renewals intentionally do not call the owned-bot renewal completion path because that path debits
    /// the customer's wallet. This flow only collects the same plan choices, calculates the same tenant sale
    /// price used by purchases, and creates a tenant order that is fulfilled after payment settlement. For the normal
    /// metered service, digit-only Latin, Persian, and Arabic-Indic duration input is persisted as <c>days-N</c> and
    /// revalidated before order creation and again before fulfillment. Email, SubId/subscription link, UUID, and
    /// supported proxy configurations resolve without ownership filtering. Non-owner targets pause at an explicit
    /// warning callback and every new target is locked by its panel email plus UUID without transferring ownership.
    /// </remarks>
    private async Task<bool> TRYHANDLETENANTRENEWASYNC(
        ITelegramBotClient botClient,
        Message message,
        BotInstance tenant,
        CredUser customer,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        var text = message.Text?.Trim() ?? string.Empty;
        if (string.Equals(user?.Flow, TENANTRENEWFLOW, StringComparison.Ordinal))
        {
            await HANDLETENANTRENEWSTEPASYNC(botClient, message, tenant, customer, user, mainReplyMarkup, cancellationToken);
            return true;
        }

        if (!IsTenantRenewCommand(text))
            return false;

        await _state.ClearUserStatus(new User { Id = message.From.Id });
        await _state.SaveUserStatus(new User
        {
            Id = message.From.Id,
            Flow = TENANTRENEWFLOW,
            LastStep = TENANTRENEWSTEPACCOUNT
        });

        await botClient.SendMessage(
            message.Chat.Id,
            "یکی از شناسه‌های اکانتی که می‌خواهید تمدید کنید را ارسال کنید:\n" +
            "• نام اکانت (Email)\n" +
            "• SubId یا لینک اشتراک\n" +
            "• UUID\n" +
            "• یکی از کانفیگ‌های VLESS، VMess، Trojan، Shadowsocks یا Hysteria\n\n" +
            "تمدید اکانت شخص دیگر ممکن است، اما مالکیت یا دسترسی مدیریتی آن را تغییر نمی‌دهد.",
            replyMarkup: new ReplyKeyboardRemove(),
            cancellationToken: cancellationToken);
        await botClient.SendMessage(
            message.Chat.Id,
            "برای خروج از فرایند تمدید، دکمه زیر را بزنید.",
            replyMarkup: BuildTenantRenewHomeKeyboard(),
            cancellationToken: cancellationToken);
        return true;
    }

    /// <summary>
    /// Advances one step of the tenant renewal state machine.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to answer the customer.</param>
    /// <param name="message">Customer message containing the current renewal input.</param>
    /// <param name="tenant">Tenant bot whose pricing settings apply.</param>
    /// <param name="customer">
    /// Customer profile that pays for renewal. Ownership determines whether the explicit warning is required; it does
    /// not block renewal after an exact email-plus-UUID target lock has been established.
    /// </param>
    /// <param name="user">Current bot-scoped renewal state.</param>
    /// <param name="mainReplyMarkup">Tenant reply keyboard used after completion.</param>
    /// <param name="cancellationToken">Cancellation token for async operations.</param>
    /// <remarks>
    /// The method stores only temporary selection state in users.db. Preset duration keys honor their current enabled
    /// flag, while a numeric custom duration is independent of presets and must satisfy the current normal-service
    /// custom range. The actual renewal is not applied until a tenant payment order is settled, which keeps duplicate
    /// callbacks idempotent. If a preset becomes disabled at confirmation, the duration is explicitly emptied while
    /// preserving the tenant-scoped target-account identity lock and the rest of the renewal state. Before any traffic,
    /// duration, plan, or confirmation text is consumed, the target is reloaded and its identity-checked detail comment
    /// is compared with the saved service key. A stale service selection is reset to the current category without
    /// creating an order or calling a payment provider. Metadata-free accounts that still match both normal and unlimited
    /// services enter an explicit category step; only a choice from the freshly recomputed compatible set is persisted.
    /// A disabled unlimited sub-plan returns to the active tenant-priced plan keyboard before any order is created.
    /// </remarks>
    /// <returns>A task that completes after the current state transition and its Telegram response.</returns>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during users.db, Telegram, panel, or order work.
    /// </exception>
    private async Task HANDLETENANTRENEWSTEPASYNC(
        ITelegramBotClient botClient,
        Message message,
        BotInstance tenant,
        CredUser customer,
        User user,
        ReplyMarkup mainReplyMarkup,
        CancellationToken cancellationToken)
    {
        var text = message.Text?.Trim() ?? string.Empty;
        if (IsCancelText(text))
        {
            await _state.ClearUserStatus(user);
            await botClient.SendMessage(message.Chat.Id, "فرایند تمدید لغو شد.", replyMarkup: mainReplyMarkup, cancellationToken: cancellationToken);
            return;
        }

        if (user.LastStep == TENANTRENEWSTEPACCOUNT)
        {
            await STARTTENANTRENEWSELECTIONASYNC(botClient, message, tenant, customer, text, cancellationToken);
            return;
        }

        if (user.LastStep == TENANTRENEWSTEPEXTERNALTARGETCONFIRMATION)
        {
            await botClient.SendMessage(
                message.Chat.Id,
                "برای ادامه تمدید اکانت شخص دیگر، هشدار قبلی را با دکمه «ادامه تمدید همین اکانت» تأیید کنید یا به منوی اصلی برگردید.",
                replyMarkup: BuildTenantExternalRenewTargetConfirmationKeyboard(),
                cancellationToken: cancellationToken);
            return;
        }

        var serverInfo = BuildConfiguredPanelServerInfo();
        var renewalClient = await GetAuthorizedTenantRenewClientAsync(
            serverInfo,
            user,
            customer.TelegramUserId,
            tenant.Id,
            cancellationToken);
        var serviceResolution = await ResolveTenantRenewalServiceAsync(
            serverInfo,
            renewalClient,
            cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            user.SelectedCountry,
            user.RenewalServiceResolutionMode,
            out var service,
            out var effectiveResolutionMode,
            out var candidateServices);

        if (user.LastStep == TENANTRENEWSTEPSERVICECATEGORY)
        {
            if (serviceResolution.RequiresCustomerSelection)
            {
                var selectedService = FindTenantRenewServiceCategory(text, candidateServices);
                if (selectedService == null)
                {
                    await botClient.SendMessage(
                        message.Chat.Id,
                        "نوع سرویس معتبر نیست. فقط یکی از گزینه‌های سازگار زیر را انتخاب کنید.",
                        replyMarkup: BuildTenantRenewServiceCategoryKeyboard(candidateServices),
                        cancellationToken: cancellationToken);
                    return;
                }

                user.Flow = TENANTRENEWFLOW;
                user.LastStep = selectedService.IsUnlimited
                    ? TENANTRENEWSTEPUNLIMITEDPLAN
                    : TENANTRENEWSTEPTRAFFIC;
                user.SelectedCountry = selectedService.Key;
                user.RenewalServiceResolutionMode =
                    TenantRenewalServiceResolutionModes.CustomerSelectedLegacy;
                user.TotoalGB = string.Empty;
                user.SelectedPeriod = string.Empty;
                user.Type = string.Empty;
                await _state.SaveUserStatus(user);
                await botClient.SendMessage(
                    message.Chat.Id,
                    selectedService.IsUnlimited
                        ? "پلن تمدید نامحدود را انتخاب کنید:"
                        : $"حجم تمدید را انتخاب کنید یا حجم دلخواه را به GB وارد کنید.\nحداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(selectedService)} GB است.",
                    replyMarkup: selectedService.IsUnlimited
                        ? BuildTenantRenewUnlimitedKeyboard(selectedService, tenant)
                        : BuildTenantRenewTrafficKeyboard(selectedService),
                    cancellationToken: cancellationToken);
                return;
            }

            if (serviceAuthorized)
            {
                await RecoverTenantRenewServiceSelectionAsync(
                    botClient,
                    message.Chat.Id,
                    tenant,
                    user,
                    service,
                    effectiveResolutionMode,
                    cancellationToken);
                return;
            }
        }

        if (!serviceAuthorized)
        {
            if (serviceResolution.RequiresCustomerSelection && candidateServices.Count > 0)
            {
                await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                    botClient,
                    message.Chat.Id,
                    message.From.Id,
                    renewalClient,
                    candidateServices,
                    user.RenewTargetUuid,
                    messageId: 0,
                    cancellationToken);
                return;
            }

            await SendTenantRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!string.Equals(service.Key, user.SelectedCountry, StringComparison.OrdinalIgnoreCase))
        {
            await RecoverTenantRenewServiceSelectionAsync(
                botClient,
                message.Chat.Id,
                tenant,
                user,
                service,
                effectiveResolutionMode,
                cancellationToken);
            return;
        }

        if (!string.Equals(
                user.RenewalServiceResolutionMode,
                effectiveResolutionMode,
                StringComparison.Ordinal))
        {
            user.RenewalServiceResolutionMode = effectiveResolutionMode;
            await _state.SaveUserStatus(user);
        }

        if (user.LastStep == TENANTRENEWSTEPTRAFFIC)
        {
            if (!TryParseTenantTrafficSelection(text, service, out var trafficGb))
            {
                await botClient.SendMessage(message.Chat.Id, BuildTenantMinimumTrafficMessage(service), replyMarkup: BuildTenantRenewTrafficKeyboard(service), cancellationToken: cancellationToken);
                return;
            }

            user.Flow = TENANTRENEWFLOW;
            user.LastStep = TENANTRENEWSTEPDURATION;
            user.TotoalGB = trafficGb.ToString(CultureInfo.InvariantCulture);
            await _state.SaveUserStatus(user);
            await botClient.SendMessage(
                message.Chat.Id,
                XuiV3PurchaseService.BuildDurationSelectionText(service, "مدت تمدید را انتخاب کنید:"),
                replyMarkup: BuildTenantRenewDurationKeyboard(service),
                cancellationToken: cancellationToken);
            return;
        }

        if (user.LastStep == TENANTRENEWSTEPDURATION)
        {
            var duration = FindTenantDurationOption(service, text);
            if (duration == null)
            {
                await botClient.SendMessage(
                    message.Chat.Id,
                    XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        "مدت تمدید معتبر نیست. یکی از گزینه‌های زیر را انتخاب کنید."),
                    replyMarkup: BuildTenantRenewDurationKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            user.Flow = TENANTRENEWFLOW;
            user.LastStep = TENANTRENEWSTEPCONFIRM;
            user.SelectedPeriod = duration.Key;
            await _state.SaveUserStatus(user);
            await SendTenantRenewSummaryAsync(botClient, message.Chat.Id, tenant, customer, user, cancellationToken);
            return;
        }

        if (user.LastStep == TENANTRENEWSTEPUNLIMITEDPLAN)
        {
            var plan = FindTenantUnlimitedPlan(service, text);
            if (plan == null)
            {
                await botClient.SendMessage(message.Chat.Id, "پلن تمدید معتبر نیست. یکی از گزینه‌های زیر را انتخاب کنید.", replyMarkup: BuildTenantRenewUnlimitedKeyboard(service, tenant), cancellationToken: cancellationToken);
                return;
            }

            user.Flow = TENANTRENEWFLOW;
            user.LastStep = TENANTRENEWSTEPCONFIRM;
            user.Type = plan.Key;
            await _state.SaveUserStatus(user);
            await SendTenantRenewSummaryAsync(botClient, message.Chat.Id, tenant, customer, user, cancellationToken);
            return;
        }

        if (user.LastStep == TENANTRENEWSTEPCONFIRM)
        {
            if (!IsConfirmText(text))
            {
                await botClient.SendMessage(message.Chat.Id, "برای ساخت فاکتور تمدید، گزینه تایید را بزنید یا انصراف دهید.", replyMarkup: BuildTenantRenewConfirmKeyboard(), cancellationToken: cancellationToken);
                return;
            }

            if (!service.IsUnlimited &&
                !XuiV3PurchaseService.TryResolveDurationKey(service, user.SelectedPeriod, out _))
            {
                user.LastStep = TENANTRENEWSTEPDURATION;
                user.SelectedPeriod = string.Empty;
                await _state.SaveUserStatus(user);
                await botClient.SendMessage(
                    message.Chat.Id,
                    XuiV3PurchaseService.BuildDurationSelectionText(
                        service,
                        "مدت انتخاب‌شده دیگر معتبر نیست. مدت جدید را انتخاب کنید."),
                    replyMarkup: BuildTenantRenewDurationKeyboard(service),
                    cancellationToken: cancellationToken);
                return;
            }

            var selectedUnlimitedPlan = service.IsUnlimited
                ? service.UnlimitedPlans?.FirstOrDefault(plan =>
                    string.Equals(plan.Key, user.Type, StringComparison.OrdinalIgnoreCase))
                : null;
            if (service.IsUnlimited &&
                !XuiV3PurchaseService.IsUnlimitedPlanAvailableForTenant(selectedUnlimitedPlan))
            {
                user.LastStep = TENANTRENEWSTEPUNLIMITEDPLAN;
                user.Type = string.Empty;
                await _state.SaveUserStatus(user);
                await botClient.SendMessage(
                    message.Chat.Id,
                    "پلن نامحدود انتخاب‌شده دیگر فعال نیست. پلن جدید را انتخاب کنید.",
                    replyMarkup: BuildTenantRenewUnlimitedKeyboard(service, tenant),
                    cancellationToken: cancellationToken);
                return;
            }

            await CreateTenantRenewOrderFromStateAsync(botClient, message.Chat.Id, tenant, customer, user, cancellationToken);
        }
    }

    /// <summary>
    /// Finds the target XUI account and starts selecting a renewal plan for it.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send the next selection keyboard.</param>
    /// <param name="message">Customer message containing the account identifier.</param>
    /// <param name="tenant">Tenant bot that owns the storefront.</param>
    /// <param name="customer">
    /// Customer requesting renewal. Ownership controls whether the explicit warning is shown, but does not prevent
    /// renewal after one of the four exact identifiers has resolved a unique safely lockable account.
    /// </param>
    /// <param name="input">Account email, SubId/subscription URL, raw UUID, or a supported proxy configuration.</param>
    /// <param name="cancellationToken">Cancellation token for panel and Telegram operations.</param>
    /// <returns>A task that completes after terminal cleanup or delivery of the next tenant selection keyboard.</returns>
    /// <remarks>
    /// The panel-derived UUID is persisted separately in <see cref="User.RenewTargetUuid"/> for every safely lockable
    /// renewal and is checked again before summary, order creation, and fulfillment. An owned UUID-less legacy client
    /// retains owner checks. After target resolution, the identity-checked per-email comment is the authoritative service
    /// category; transient detail failure without readable list metadata stops safely. No identifier grants
    /// account-management access or changes XUI ownership metadata.
    /// </remarks>
    private async Task STARTTENANTRENEWSELECTIONASYNC(
        ITelegramBotClient botClient,
        Message message,
        BotInstance tenant,
        CredUser customer,
        string input,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        XuiV3ApiResponse<List<XuiV3Client>> response;
        try
        {
            response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "Tenant renewal target list lookup failed. tenantBotId={TenantBotId}, userId={UserId}, errorType={ErrorType}",
                tenant.Id,
                customer.TelegramUserId,
                ex.GetType().Name);
            await SendTenantRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                "دریافت اطلاعات اکانت‌ها از پنل ناموفق بود. دوباره تلاش کنید.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!response.Success)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                "دریافت اطلاعات اکانت‌ها از پنل ناموفق بود. دوباره تلاش کنید.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        var resolution = XuiV3RenewalTargetResolver.Resolve(response.Obj, input);
        var legacyOwnedWithoutUuid =
            resolution.Status == XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid &&
            ClientBelongsToTenantCustomer(resolution.Client, customer.TelegramUserId, tenant.Id);
        if (!resolution.Success && !legacyOwnedWithoutUuid)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                BuildTenantRenewTargetResolutionFailureText(resolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        var client = resolution.Client;

        var serviceResolution = await ResolveTenantRenewalServiceAsync(serverInfo, client, cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            selectedServiceKey: null,
            storedResolutionMode: null,
            out var service,
            out var resolutionMode,
            out var candidateServices);
        if (!serviceAuthorized && !serviceResolution.RequiresCustomerSelection)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                message.Chat.Id,
                message.From.Id,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!ClientBelongsToTenantCustomer(client, customer.TelegramUserId, tenant.Id))
        {
            await SAVETENANTEXTERNALRENEWWARNINGASYNC(
                botClient,
                message.Chat.Id,
                message.From.Id,
                client,
                service,
                resolutionMode,
                resolution.CanonicalUuid,
                messageId: 0,
                cancellationToken);
            return;
        }

        if (!serviceAuthorized)
        {
            await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                botClient,
                message.Chat.Id,
                message.From.Id,
                client,
                candidateServices,
                resolution.CanonicalUuid,
                messageId: 0,
                cancellationToken);
            return;
        }

        await STARTTENANTRENEWPLANSELECTIONASYNC(
            botClient,
            message.Chat.Id,
            message.From.Id,
            tenant,
            client,
            service,
            resolutionMode,
            resolution.CanonicalUuid,
            messageId: 0,
            cancellationToken);
    }

    /// <summary>
    /// Maps a shared renewal resolver failure to fixed tenant-safe Persian text without echoing sensitive input.
    /// </summary>
    /// <param name="status">Safe resolver status for the submitted renewal identifier.</param>
    /// <returns>User-facing retry guidance containing no email, UUID, SubId, password, configuration, or panel body.</returns>
    private static string BuildTenantRenewTargetResolutionFailureText(XuiV3RenewalTargetResolutionStatus status)
    {
        return status switch
        {
            XuiV3RenewalTargetResolutionStatus.InvalidInput =>
                "شناسه ارسالی معتبر نیست. نام اکانت، SubId یا ساب‌لینک، UUID یا یکی از کانفیگ‌های پشتیبانی‌شده را ارسال کنید.",
            XuiV3RenewalTargetResolutionStatus.Ambiguous =>
                "این شناسه با بیش از یک اکانت تطبیق دارد و انتخاب خودکار آن امن نیست. UUID یا یک کانفیگ دقیق همان اکانت را ارسال کنید.",
            XuiV3RenewalTargetResolutionStatus.MissingCanonicalUuid =>
                "هویت دقیق این اکانت از پاسخ پنل قابل قفل‌کردن نیست و تمدید امن آن از فروشگاه ممکن نشد.",
            _ => "اکانتی با شناسه ارسال‌شده پیدا نشد."
        };
    }

    /// <summary>
    /// Persists a non-owned tenant renewal target and displays the explicit third-party warning.
    /// </summary>
    /// <param name="botClient">Telegram client of the active tenant storefront.</param>
    /// <param name="chatId">Tenant customer chat receiving the warning.</param>
    /// <param name="customerTelegramUserId">Telegram id whose tenant-scoped state is replaced.</param>
    /// <param name="client">Unique current panel client selected by the shared resolver.</param>
    /// <param name="service">
    /// Enabled catalog service resolved for the client, or <c>null</c> for a metadata-free legacy target that requires
    /// category selection after the ownership warning is accepted.
    /// </param>
    /// <param name="resolutionMode">
    /// Metadata/deterministic evidence mode for <paramref name="service" />, or an empty value while legacy category
    /// selection is still pending.
    /// </param>
    /// <param name="canonicalUuid">Panel-derived UUID paired with the email as the exact renewal target lock.</param>
    /// <param name="messageId">Search-result message to replace with the warning, or zero to send a new message.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram work.</param>
    /// <returns>A task that completes after state persistence and warning delivery.</returns>
    /// <remarks>
    /// No tenant order, payment, wallet movement, or panel mutation occurs. The fixed callback contains no client
    /// identity and can continue only this tenant bot plus Telegram user's matching warning state.
    /// </remarks>
    private async Task SAVETENANTEXTERNALRENEWWARNINGASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        long customerTelegramUserId,
        XuiV3Client client,
        XuiV3ServiceDefinition service,
        string resolutionMode,
        string canonicalUuid,
        int messageId,
        CancellationToken cancellationToken)
    {
        // Persist the sensitive target only in this tenant bot's conversation row; the confirmation callback is fixed.
        await _state.ClearUserStatus(new User { Id = customerTelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = customerTelegramUserId,
            Flow = TENANTRENEWFLOW,
            LastStep = TENANTRENEWSTEPEXTERNALTARGETCONFIRMATION,
            ConfigLink = client.Email,
            SelectedCountry = service?.Key ?? string.Empty,
            RenewTargetUuid = canonicalUuid,
            RenewalServiceResolutionMode = resolutionMode ?? string.Empty,
            PaymentMethod = "credit"
        });

        var warningText =
            "⚠️ <b>هشدار تمدید اکانت شخص دیگر</b>\n\n" +
            $"اکانت پیدا شد: <code>{Html(client.Email)}</code>\n" +
            "این اکانت در این فروشگاه متعلق به حساب شما نیست. پرداخت شما فقط همین اکانت را تمدید می‌کند و " +
            "مالکیت، کانفیگ‌ها یا دسترسی مدیریت آن را به شما منتقل نمی‌کند.\n\n" +
            "اگر شناسه را درست وارد کرده‌اید، ادامه تمدید همین اکانت را تأیید کنید.";
        if (messageId > 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId,
                messageId,
                warningText,
                ParseMode.Html,
                BuildTenantExternalRenewTargetConfirmationKeyboard(),
                cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId,
                warningText,
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantExternalRenewTargetConfirmationKeyboard(),
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Persists an exact legacy renewal target and asks the tenant customer to choose its compatible service category.
    /// </summary>
    /// <param name="botClient">Telegram client of the active tenant storefront.</param>
    /// <param name="chatId">Customer chat that receives the category selector.</param>
    /// <param name="customerTelegramUserId">Telegram user id whose state is isolated under the current tenant bot.</param>
    /// <param name="client">
    /// Identity-verified panel client. Its email is persisted with <paramref name="canonicalUuid" /> and must never be
    /// placed in callback data or operational logs.
    /// </param>
    /// <param name="candidateServices">
    /// Enabled tenant-compatible service categories derived from a fresh metadata-free client observation.
    /// </param>
    /// <param name="canonicalUuid">Normalized panel UUID paired with the email as the exact renewal target lock.</param>
    /// <param name="messageId">Existing warning/search message to edit, or zero to send a new target message.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram operations.</param>
    /// <returns>A task that completes after state replacement and category-keyboard delivery.</returns>
    /// <remarks>
    /// No service is authorized at this stage: <c>SelectedCountry</c> and the resolution mode are deliberately empty.
    /// The next text handler accepts only one service still present in a fresh compatible candidate set. This method
    /// creates no order, provider request, wallet entry, payment, or XUI mutation.
    /// </remarks>
    private async Task STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        long customerTelegramUserId,
        XuiV3Client client,
        IReadOnlyList<XuiV3ServiceDefinition> candidateServices,
        string canonicalUuid,
        int messageId,
        CancellationToken cancellationToken)
    {
        var candidates = candidateServices?
            .Where(IsTenantRenewalServiceVisible)
            .DistinctBy(service => service.Key, StringComparer.OrdinalIgnoreCase)
            .ToList() ?? new List<XuiV3ServiceDefinition>();
        if (client == null ||
            !TryNormalizeTenantClientUuid(canonicalUuid, out canonicalUuid) ||
            candidates.Count == 0)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customerTelegramUserId,
                "نوع سرویس این اکانت قدیمی از اطلاعات فعلی پنل قابل تشخیص نیست و گزینه سازگاری برای تمدید وجود ندارد.",
                allowSearchRestart: true,
                cancellationToken);
            return;
        }

        await _state.ClearUserStatus(new User { Id = customerTelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = customerTelegramUserId,
            Flow = TENANTRENEWFLOW,
            LastStep = TENANTRENEWSTEPSERVICECATEGORY,
            ConfigLink = client.Email,
            SelectedCountry = string.Empty,
            RenewTargetUuid = canonicalUuid,
            RenewalServiceResolutionMode = string.Empty,
            PaymentMethod = "credit"
        });

        const string targetText =
            "ℹ️ این اکانت قدیمی metadata قابل‌اعتماد برای تشخیص نوع سرویس ندارد.\n" +
            "هدف تمدید با ایمیل و UUID پنل قفل شده است؛ نوع سرویس صحیح را از گزینه‌های سازگار انتخاب کنید.";
        if (messageId > 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId,
                messageId,
                targetText,
                ParseMode.Html,
                BuildTenantRenewHomeKeyboard(),
                cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId,
                targetText,
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantRenewHomeKeyboard(),
                cancellationToken: cancellationToken);
        }

        await botClient.SendMessage(
            chatId,
            "نوع فعلی اکانت را برای ادامه تمدید انتخاب کنید:",
            replyMarkup: BuildTenantRenewServiceCategoryKeyboard(candidates),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Persists one exact tenant renewal target and opens its tenant-priced traffic or unlimited-plan selector.
    /// </summary>
    /// <param name="botClient">Telegram client of the tenant storefront.</param>
    /// <param name="chatId">Customer chat receiving the target and plan selector.</param>
    /// <param name="customerTelegramUserId">Telegram id whose state is replaced inside the current tenant bot scope.</param>
    /// <param name="tenant">Active storefront whose pricing and plan visibility apply.</param>
    /// <param name="client">Fresh unique panel client selected for renewal.</param>
    /// <param name="service">Current enabled service resolved for the client.</param>
    /// <param name="resolutionMode">
    /// Current metadata, deterministic-legacy, or explicitly selected legacy evidence mode. It is persisted with the
    /// bot-scoped state and must be revalidated before order or provider creation.
    /// </param>
    /// <param name="canonicalUuid">Panel-derived UUID stored independently from later payment choice.</param>
    /// <param name="messageId">Warning message to edit after confirmation, or zero to send a new target message.</param>
    /// <param name="cancellationToken">Token that cancels users.db and Telegram operations.</param>
    /// <returns>A task that completes after state replacement and plan-keyboard delivery.</returns>
    /// <remarks>
    /// The target lock is stored whenever the panel supplies a valid UUID, including accounts already belonging to the
    /// customer. Owned legacy clients without UUID retain owner checks. No payable order or XUI side effect occurs here.
    /// </remarks>
    private async Task STARTTENANTRENEWPLANSELECTIONASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        long customerTelegramUserId,
        BotInstance tenant,
        XuiV3Client client,
        XuiV3ServiceDefinition service,
        string resolutionMode,
        string canonicalUuid,
        int messageId,
        CancellationToken cancellationToken)
    {
        // Replace the warning/search state before showing prices so a stale tenant callback cannot swap the target.
        await _state.ClearUserStatus(new User { Id = customerTelegramUserId });
        await _state.SaveUserStatus(new User
        {
            Id = customerTelegramUserId,
            Flow = TENANTRENEWFLOW,
            LastStep = service.IsUnlimited ? TENANTRENEWSTEPUNLIMITEDPLAN : TENANTRENEWSTEPTRAFFIC,
            ConfigLink = client.Email,
            SelectedCountry = service.Key,
            RenewTargetUuid = canonicalUuid,
            RenewalServiceResolutionMode = resolutionMode,
            PaymentMethod = "credit"
        });

        var targetText = $"اکانت برای تمدید انتخاب شد: <code>{Html(client.Email)}</code>";
        if (messageId > 0)
        {
            await SafeEditMessageTextAsync(
                botClient,
                chatId,
                messageId,
                targetText,
                ParseMode.Html,
                BuildTenantRenewHomeKeyboard(),
                cancellationToken);
        }
        else
        {
            await botClient.SendMessage(
                chatId,
                targetText,
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantRenewHomeKeyboard(),
                cancellationToken: cancellationToken);
        }

        await botClient.SendMessage(
            chatId,
            service.IsUnlimited
                ? "پلن تمدید نامحدود را انتخاب کنید:"
                : $"حجم تمدید را انتخاب کنید یا حجم دلخواه را به GB وارد کنید.\nحداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(service)} GB است.",
            replyMarkup: service.IsUnlimited
                ? BuildTenantRenewUnlimitedKeyboard(service, tenant)
                : BuildTenantRenewTrafficKeyboard(service),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Repairs a tenant renewal state whose saved service category no longer matches the target's authoritative comment.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client for the active tenant storefront. It is used only to show the corrected selector.
    /// </param>
    /// <param name="chatId">Tenant customer chat receiving the recovery message and replacement keyboard.</param>
    /// <param name="tenant">
    /// Active tenant bot whose markup and tenant-visible unlimited plans determine displayed renewal prices.
    /// </param>
    /// <param name="user">
    /// Bot-scoped conversation row for the current tenant plus Telegram user. Its exact email and UUID target lock are
    /// preserved, while traffic, duration, and unlimited-plan selections are explicitly cleared.
    /// </param>
    /// <param name="service">
    /// Enabled service resolved from identity-checked live client metadata or the configured legacy fallback.
    /// </param>
    /// <param name="resolutionMode">
    /// Fresh metadata or deterministic-legacy evidence mode that authorized <paramref name="service" />.
    /// </param>
    /// <param name="cancellationToken">Token that cancels users.db persistence and Telegram delivery.</param>
    /// <returns>A task that completes after the corrected tenant state and selector are delivered.</returns>
    /// <remarks>
    /// This recovery has no payment, wallet, order, provider, or XUI mutation side effects. Empty strings are assigned
    /// deliberately because partial user-state persistence treats <c>null</c> as "preserve the previous value".
    /// </remarks>
    /// <example>
    /// <code>
    /// await RecoverTenantRenewServiceSelectionAsync(
    ///     botClient, chatId, tenant, state, resolvedService,
    ///     TenantRenewalServiceResolutionModes.Metadata, cancellationToken);
    /// </code>
    /// </example>
    private async Task RecoverTenantRenewServiceSelectionAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        BotInstance tenant,
        User user,
        XuiV3ServiceDefinition service,
        string resolutionMode,
        CancellationToken cancellationToken)
    {
        user.Flow = TENANTRENEWFLOW;
        user.LastStep = service.IsUnlimited ? TENANTRENEWSTEPUNLIMITEDPLAN : TENANTRENEWSTEPTRAFFIC;
        user.SelectedCountry = service.Key;
        user.RenewalServiceResolutionMode = resolutionMode;
        user.TotoalGB = string.Empty;
        user.SelectedPeriod = string.Empty;
        user.Type = string.Empty;
        user.PendingUserComment = string.Empty;
        await _state.SaveUserStatus(user);

        await botClient.SendMessage(
            chatId,
            $"نوع سرویس اکانت از اطلاعات فعلی پنل دوباره تشخیص داده شد: <b>{Html(service.DisplayName)}</b>\n" +
            "انتخاب قبلی کنار گذاشته شد. لطفاً گزینه تمدید مناسب این سرویس را انتخاب کنید.",
            parseMode: ParseMode.Html,
            replyMarkup: service.IsUnlimited
                ? BuildTenantRenewUnlimitedKeyboard(service, tenant)
                : BuildTenantRenewTrafficKeyboard(service),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Revalidates and confirms a tenant third-party renewal warning before any plan or payable order is created.
    /// </summary>
    /// <param name="botClient">Tenant Telegram client that received the fixed callback.</param>
    /// <param name="chatId">Customer chat containing the warning.</param>
    /// <param name="messageId">Warning message id edited after successful confirmation.</param>
    /// <param name="tenant">Current active tenant storefront.</param>
    /// <param name="customer">Customer who will later pay the tenant sale price.</param>
    /// <param name="user">Current tenant-scoped state that must be at the external-target confirmation step.</param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, and Telegram work.</param>
    /// <returns>A task that completes after safe rejection or delivery of the tenant plan selector.</returns>
    /// <remarks>
    /// Callback data contains no account identity. Email, UUID, eligibility, and bot-scoped state are checked again;
    /// stale or cross-bot callbacks cannot create an order or expose any account-management action. The current detail
    /// comment is read again before the selector is shown, so a warning saved with a stale or incomplete list category
    /// cannot continue under the wrong tenant service.
    /// </remarks>
    private async Task HANDLETENANTEXTERNALRENEWTARGETCONFIRMATIONASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        BotInstance tenant,
        CredUser customer,
        User user,
        CancellationToken cancellationToken)
    {
        if (user == null ||
            !string.Equals(user.Flow, TENANTRENEWFLOW, StringComparison.Ordinal) ||
            !string.Equals(user.LastStep, TENANTRENEWSTEPEXTERNALTARGETCONFIRMATION, StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(user.ConfigLink) ||
            string.IsNullOrWhiteSpace(user.RenewTargetUuid))
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "این تایید قدیمی یا نامعتبر است. فرایند تمدید را دوباره شروع کنید.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        var client = await GetAuthorizedTenantRenewClientAsync(
            BuildConfiguredPanelServerInfo(),
            user,
            customer.TelegramUserId,
            tenant.Id,
            cancellationToken);
        var serviceResolution = await ResolveTenantRenewalServiceAsync(
            BuildConfiguredPanelServerInfo(),
            client,
            cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            user.SelectedCountry,
            user.RenewalServiceResolutionMode,
            out var service,
            out var resolutionMode,
            out var candidateServices);
        if (!serviceAuthorized && !serviceResolution.RequiresCustomerSelection)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!serviceAuthorized)
        {
            await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                botClient,
                chatId,
                customer.TelegramUserId,
                client,
                candidateServices,
                user.RenewTargetUuid,
                messageId,
                cancellationToken);
            return;
        }

        await STARTTENANTRENEWPLANSELECTIONASYNC(
            botClient,
            chatId,
            customer.TelegramUserId,
            tenant,
            client,
            service,
            resolutionMode,
            user.RenewTargetUuid,
            messageId,
            cancellationToken);
    }

    /// <summary>
    /// Builds tenant actions for confirming a non-owner renewal warning or returning safely to Home.
    /// </summary>
    /// <returns>An inline keyboard with one fixed state-bound confirmation and one Home callback.</returns>
    private static InlineKeyboardMarkup BuildTenantExternalRenewTargetConfirmationKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData(
                    "ادامه تمدید همین اکانت",
                    XuiV3PurchaseCallbacks.ConfirmExternalRenewTarget())
            },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home()) }
        });
    }

    /// <summary>
    /// Builds the inline callback used to abandon tenant renewal and return through the shared bot-scoped Home route.
    /// </summary>
    /// <returns>An inline keyboard containing only the safe <c>x3:home</c> navigation callback.</returns>
    /// <remarks>
    /// The Home handler clears the current tenant bot's persisted state and in-memory XUI session without touching
    /// state for the same Telegram user in other owned or tenant bots.
    /// </remarks>
    private static InlineKeyboardMarkup BuildTenantRenewHomeKeyboard()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("بازگشت به منوی اصلی", XuiV3PurchaseCallbacks.Home())
            }
        });
    }

    /// <summary>
    /// Sends the tenant renewal summary before creating a payable tenant order.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client of the tenant storefront that owns this customer conversation. It must match
    /// <paramref name="tenant"/> so the summary is never sent through another tenant or an owned bot.
    /// </param>
    /// <param name="chatId">Telegram chat id of the tenant customer receiving the renewal summary.</param>
    /// <param name="tenant">
    /// Tenant bot database row whose owner-defined sale pricing and storefront settings apply. The global XUI plan
    /// catalog still provides traffic and duration values.
    /// </param>
    /// <param name="customer">
    /// Shared credential profile of the Telegram customer requesting renewal. Its numeric Telegram id is used for
    /// legacy owner-only targets and renewal audit history; exact-lock targets may belong to someone else. This method
    /// does not debit its wallet.
    /// </param>
    /// <param name="user">
    /// Tenant-scoped conversation state containing the target email and selected renewal plan. The state must belong
    /// to the composite tenant bot id and customer Telegram id currently being handled.
    /// </param>
    /// <param name="cancellationToken">Token that cancels Telegram and read-only XUI operations for this update.</param>
    /// <returns>A task that completes after the HTML summary and confirmation keyboard are sent to the customer.</returns>
    /// <remarks>
    /// The preview is tenant-isolated and uses tenant sale pricing, but traffic and expiry arithmetic come from the
    /// shared renewal policy. Active unlimited accounts show direct quota addition; expired unlimited accounts show
    /// replacement quota and a first-connection duration after reset. Metered renewals show the effective storefront
    /// per-GB and per-day calculation without exposing the tenant owner's colleague base rates. Fresh account data is
    /// authorized again before rendering; an email/UUID mismatch clears state and prevents confirmation. An unresolved
    /// account-level renewal lock stops the preview before the customer can create or fund another order. The current
    /// detail comment is resolved before price resolution, and a service mismatch returns the same exact target to the
    /// correct category selector instead of rendering a payable summary. Unlimited state is also checked against the
    /// current tenant-visible catalog before the summary can expose a payable action.
    /// </remarks>
    private async Task SendTenantRenewSummaryAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        BotInstance tenant,
        CredUser customer,
        User user,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        var client = await GetAuthorizedTenantRenewClientAsync(
            serverInfo,
            user,
            customer.TelegramUserId,
            tenant.Id,
            cancellationToken);
        if (client == null)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "اکانت هدف حذف شده یا UUID آن تغییر کرده است. بدون پرداخت دوباره از منوی تمدید اقدام کنید.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        var serviceResolution = await ResolveTenantRenewalServiceAsync(serverInfo, client, cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            user.SelectedCountry,
            user.RenewalServiceResolutionMode,
            out var service,
            out var resolutionMode,
            out var candidateServices);
        if (!serviceAuthorized)
        {
            if (serviceResolution.RequiresCustomerSelection && candidateServices.Count > 0)
            {
                await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                    botClient,
                    chatId,
                    customer.TelegramUserId,
                    client,
                    candidateServices,
                    user.RenewTargetUuid,
                    messageId: 0,
                    cancellationToken);
                return;
            }

            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!string.Equals(service.Key, user.SelectedCountry, StringComparison.OrdinalIgnoreCase))
        {
            await RecoverTenantRenewServiceSelectionAsync(
                botClient,
                chatId,
                tenant,
                user,
                service,
                resolutionMode,
                cancellationToken);
            return;
        }

        if (!string.Equals(user.RenewalServiceResolutionMode, resolutionMode, StringComparison.Ordinal))
        {
            user.RenewalServiceResolutionMode = resolutionMode;
            await _state.SaveUserStatus(user);
        }

        var selection = BuildTenantRenewSelectionFromState(user);
        var resolved = _purchaseService.ResolveTenantPurchase(selection, false);
        var price = CalculateTenantPrice(tenant, selection);
        var priceBreakdownText = BuildTenantMeteredPriceBreakdownText(tenant, resolved, price.SalePriceToman);

        if (await _renewalOperationStore.FindBlockingOperationAsync(
                client.Uuid,
                client.Email,
                cancellationToken: cancellationToken) != null)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "یک تمدید قبلی برای این اکانت در حال بررسی خودکار است. تمدید جدید تا مشخص‌شدن نتیجه موقتاً قفل است.",
                allowSearchRestart: true,
                cancellationToken);
            return;
        }

        var hasExactTargetLock = !string.IsNullOrWhiteSpace(user.RenewTargetUuid);
        var renewal = XuiV3RenewalPolicy.Calculate(
            client,
            resolved,
            "tenant-renew-summary",
            customer.TelegramUserId,
            allowActorAsOwnerFallback: !hasExactTargetLock);

        var trafficLine = resolved.IsUnlimited
            ? renewal?.ShouldResetTraffic == true
                ? $"حجم جدید بعد از ریست مصرف: <code>{Html(resolved.TrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n"
                : $"حجم اضافه: <code>{Html(resolved.TrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n" +
                  (renewal == null
                      ? string.Empty
                      : $"حجم کل بعد از تمدید: <code>{Html(XuiV3PurchaseService.FormatTrafficSize(renewal.TotalBytesAfterRenew))}</code>\n")
            : $"حجم تمدید: <code>{Html(resolved.TrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n";

        var text =
            "✅ <b>خلاصه تمدید اکانت</b>\n\n" +
            $"اکانت: <code>{Html(user.ConfigLink)}</code>\n" +
            $"سرویس: <b>{Html(resolved.Service.DisplayName)}</b>\n" +
            trafficLine +
            $"مدت افزوده: <code>{Html(resolved.DurationDays <= 0 ? "نامحدود" : resolved.DurationDays + " روز")}</code>\n" +
            (renewal == null ? string.Empty : $"مدت نهایی بعد از تمدید: <code>{Html(renewal.FinalDurationDays <= 0 ? "نامحدود" : renewal.FinalDurationDays + " روز")}</code>\n") +
            (string.IsNullOrWhiteSpace(priceBreakdownText) ? string.Empty : $"\n{priceBreakdownText}\n") +
            $"مبلغ قابل پرداخت: <b>{Html(price.SalePriceToman.FormatCurrency())}</b>\n\n" +
            "بعد از تایید، روش پرداخت را انتخاب می‌کنید و پس از پرداخت موفق اکانت تمدید می‌شود.";

        await botClient.SendMessage(
            chatId,
            text,
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantRenewConfirmKeyboard(),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Creates a pending tenant renewal order from the customer's saved renewal state.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send payment buttons.</param>
    /// <param name="chatId">Customer chat id that receives payment choices.</param>
    /// <param name="tenant">Tenant bot that owns the renewal order.</param>
    /// <param name="customer">Customer who will pay for the renewal.</param>
    /// <param name="user">Bot-scoped state containing target account and selected plan.</param>
    /// <param name="cancellationToken">Cancellation token for database and Telegram operations.</param>
    /// <returns>A task that completes after safe target validation and order/payment-choice delivery.</returns>
    /// <remarks>
    /// The order is not fulfilled here. Payment callbacks and IPNs later call the shared tenant fulfillment
    /// routine, which applies the renewal exactly once. Every safely lockable renewal stores the normalized target UUID
    /// on the order; old state or an owned legacy client without UUID leaves it null and remains owner-checked. A live
    /// unresolved-operation lookup runs before insertion so no new payable order is offered for a locked account.
    /// Authoritative tenant pricing rejects a hidden unlimited plan before the order row is created. The target's live
    /// detail metadata is also compared with the saved service category; a mismatch resets the state selector and creates
    /// no order, payment row, provider request, wallet entry, or XUI mutation. The service-resolution evidence mode is
    /// copied to the order so payment activation and paid fulfillment can distinguish a verified customer choice from a
    /// historical null value without storing account metadata or exposing identity in callback data.
    /// </remarks>
    private async Task CreateTenantRenewOrderFromStateAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        BotInstance tenant,
        CredUser customer,
        User user,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        var client = await GetAuthorizedTenantRenewClientAsync(
            serverInfo,
            user,
            customer.TelegramUserId,
            tenant.Id,
            cancellationToken);
        if (client == null)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "اکانت هدف حذف شده یا UUID آن تغییر کرده است. هیچ سفارشی ساخته نشد.",
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        var serviceResolution = await ResolveTenantRenewalServiceAsync(serverInfo, client, cancellationToken);
        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            user.SelectedCountry,
            user.RenewalServiceResolutionMode,
            out var service,
            out var resolutionMode,
            out var candidateServices);
        if (!serviceAuthorized)
        {
            if (serviceResolution.RequiresCustomerSelection && candidateServices.Count > 0)
            {
                await STARTTENANTRENEWSERVICECATEGORYSELECTIONASYNC(
                    botClient,
                    chatId,
                    customer.TelegramUserId,
                    client,
                    candidateServices,
                    user.RenewTargetUuid,
                    messageId: 0,
                    cancellationToken);
                return;
            }

            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                BuildTenantRenewServiceResolutionFailureText(serviceResolution.Status),
                allowSearchRestart: false,
                cancellationToken);
            return;
        }

        if (!string.Equals(service.Key, user.SelectedCountry, StringComparison.OrdinalIgnoreCase))
        {
            await RecoverTenantRenewServiceSelectionAsync(
                botClient,
                chatId,
                tenant,
                user,
                service,
                resolutionMode,
                cancellationToken);
            return;
        }

        if (!string.Equals(user.RenewalServiceResolutionMode, resolutionMode, StringComparison.Ordinal))
        {
            user.RenewalServiceResolutionMode = resolutionMode;
            await _state.SaveUserStatus(user);
        }

        if (await _renewalOperationStore.FindBlockingOperationAsync(
                client.Uuid,
                client.Email,
                cancellationToken: cancellationToken) != null)
        {
            await SendTenantRenewTerminalAsync(
                botClient,
                chatId,
                customer.TelegramUserId,
                "یک تمدید قبلی برای این اکانت در حال بررسی خودکار است. هیچ سفارش پرداخت جدیدی ساخته نشد و تمدید این اکانت موقتاً قفل است.",
                allowSearchRestart: true,
                cancellationToken);
            return;
        }

        var selection = BuildTenantRenewSelectionFromState(user);
        var price = CalculateTenantPrice(tenant, selection);
        var order = CreateTenantOrder(tenant, customer, chatId, selection, price, "pending");
        order.OrderKind = TenantBotOrderKinds.Renew;
        order.TargetAccountEmail = client.Email;
        order.TargetAccountUuid = TryNormalizeTenantClientUuid(user.RenewTargetUuid, out var targetUuid)
            ? targetUuid
            : null;
        order.RenewalServiceResolutionMode = resolutionMode;
        order.PaymentStatus = TenantBotOrderStatuses.Pending;
        order.UpdatedAtUtc = DateTime.UtcNow;

        _workflow.Add(order);
        await _workflow.SaveAsync(cancellationToken);
        await _state.ClearUserStatus(user);

        await botClient.SendMessage(
            chatId,
            BuildTenantRenewOrderPaymentChoiceText(order),
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantRenewPaymentProviderKeyboard(order, tenant),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Builds the selected renewal plan from temporary bot state.
    /// </summary>
    /// <param name="user">Bot-scoped state row created by the tenant renewal flow.</param>
    /// <returns>
    /// The selected XUI v3 purchase selection reused for renewal pricing. Metered duration is preserved as either an
    /// enabled preset key or canonical <c>days-N</c> value for central revalidation.
    /// </returns>
    private static XuiV3PurchaseSelection BuildTenantRenewSelectionFromState(User user)
    {
        return string.IsNullOrWhiteSpace(user.Type)
            ? new XuiV3PurchaseSelection
            {
                ServiceKey = user.SelectedCountry,
                TrafficGb = int.TryParse(user.TotoalGB, NumberStyles.Integer, CultureInfo.InvariantCulture, out var trafficGb) ? trafficGb : 0,
                DurationKey = user.SelectedPeriod
            }
            : new XuiV3PurchaseSelection
            {
                ServiceKey = user.SelectedCountry,
                UnlimitedPlanKey = user.Type
            };
    }

    /// <summary>
    /// Checks whether a tenant customer selected the renewal command.
    /// </summary>
    /// <param name="text">Raw reply-keyboard text from the tenant bot.</param>
    /// <returns><c>true</c> when the text starts the tenant renewal flow.</returns>
    private static bool IsTenantRenewCommand(string text)
    {
        return string.Equals(text, "تمدید اکانت", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "🔄 تمدید اکانت", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Checks whether a tenant customer confirmed a state-machine step.
    /// </summary>
    /// <param name="text">Raw customer text.</param>
    /// <returns><c>true</c> when the text is the tenant confirmation label.</returns>
    private static bool IsConfirmText(string text)
    {
        return string.Equals(text, "تایید", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "✅ تایید", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Checks whether a tenant customer cancelled a state-machine step.
    /// </summary>
    /// <param name="text">Raw customer text.</param>
    /// <returns><c>true</c> when the text is a recognized cancel label.</returns>
    private static bool IsCancelText(string text)
    {
        return string.Equals(text, "انصراف", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(text, "❌ انصراف", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Builds the reply keyboard for explicitly classifying a metadata-free legacy tenant renewal target.
    /// </summary>
    /// <param name="candidateServices">
    /// Fresh enabled tenant-compatible services whose inbounds match the identity-verified client. Account identifiers
    /// must not be included in this collection or in button labels.
    /// </param>
    /// <returns>A resizeable keyboard with one service per row and an explicit cancel action.</returns>
    /// <remarks>
    /// Buttons are presentation only. Typed labels and stale keyboards are accepted only after a new panel read proves
    /// the selected key is still in the compatible candidate set.
    /// </remarks>
    private static ReplyKeyboardMarkup BuildTenantRenewServiceCategoryKeyboard(
        IEnumerable<XuiV3ServiceDefinition> candidateServices)
    {
        var rows = (candidateServices ?? Array.Empty<XuiV3ServiceDefinition>())
            .Where(IsTenantRenewalServiceVisible)
            .DistinctBy(service => service.Key, StringComparer.OrdinalIgnoreCase)
            .OrderBy(service => service.DisplayName, StringComparer.Ordinal)
            .Select(service => new[] { new KeyboardButton($"{service.DisplayName} [{service.Key}]") })
            .Append(new[] { new KeyboardButton("❌ انصراف") })
            .ToArray();
        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Finds an explicitly selected service only inside a freshly computed legacy candidate set.
    /// </summary>
    /// <param name="text">Reply-keyboard label or manually typed exact service key/display name.</param>
    /// <param name="candidateServices">Fresh tenant-visible services compatible with the exact panel client.</param>
    /// <returns>The matching service, or <c>null</c> when the input is stale, crafted, or ambiguous.</returns>
    /// <remarks>
    /// The formatted keyboard label must match exactly; a prefix match cannot authorize a crafted key. This parser has
    /// no state, payment, wallet, provider, Telegram-send, or XUI side effects.
    /// </remarks>
    private static XuiV3ServiceDefinition FindTenantRenewServiceCategory(
        string text,
        IEnumerable<XuiV3ServiceDefinition> candidateServices)
    {
        var normalized = text?.Trim();
        if (string.IsNullOrWhiteSpace(normalized))
            return null;

        return (candidateServices ?? Array.Empty<XuiV3ServiceDefinition>())
            .Where(IsTenantRenewalServiceVisible)
            .FirstOrDefault(service =>
                string.Equals(normalized, service.Key, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(normalized, service.DisplayName, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(
                    normalized,
                    $"{service.DisplayName} [{service.Key}]",
                    StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Builds the reply keyboard used to choose metered renewal traffic.
    /// </summary>
    /// <param name="service">Metered XUI service definition.</param>
    /// <returns>Reply keyboard containing traffic options and cancel.</returns>
    private static ReplyKeyboardMarkup BuildTenantRenewTrafficKeyboard(XuiV3ServiceDefinition service)
    {
        var rows = XuiV3PurchaseService.GetVisibleTrafficOptions(service)
            .Chunk(3)
            .Select(chunk => chunk.Select(x => new KeyboardButton($"{x} GB")).ToArray())
            .Append(new[] { new KeyboardButton("❌ انصراف") })
            .ToArray();
        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the reply keyboard used to choose metered renewal duration.
    /// </summary>
    /// <param name="service">Metered XUI service definition.</param>
    /// <returns>Reply keyboard containing enabled duration options and cancel.</returns>
    /// <remarks>
    /// The global catalog controls duration availability for every tenant. Text parsing and final order pricing repeat
    /// this check because an old Telegram reply keyboard can outlive a configuration change.
    /// </remarks>
    private static ReplyKeyboardMarkup BuildTenantRenewDurationKeyboard(XuiV3ServiceDefinition service)
    {
        var rows = XuiV3PurchaseService.GetEnabledDurationOptions(service)
            .OrderBy(x => x.Days)
            .Select(x => new[] { new KeyboardButton($"{x.DisplayName} [{x.Key}]") })
            .Append(new[] { new KeyboardButton("❌ انصراف") })
            .ToArray();
        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the reply keyboard used to choose an unlimited renewal plan with tenant prices.
    /// </summary>
    /// <param name="service">Unlimited XUI service definition loaded from the current global catalog.</param>
    /// <param name="tenant">
    /// Tenant bot whose authoritative pricing policy controls the displayed customer price.
    /// </param>
    /// <returns>Reply keyboard containing only tenant-visible unlimited plans and an explicit cancel row.</returns>
    /// <remarks>
    /// Each label uses <see cref="CalculateTenantPrice" /> so fixed-public-price plans and ordinary markup plans cannot
    /// drift from order pricing. Typed selections and final state are revalidated separately before any side effect.
    /// </remarks>
    /// <example>
    /// <code>
    /// var keyboard = BuildTenantRenewUnlimitedKeyboard(service, tenant);
    /// </code>
    /// </example>
    private ReplyKeyboardMarkup BuildTenantRenewUnlimitedKeyboard(XuiV3ServiceDefinition service, BotInstance tenant)
    {
        var rows = XuiV3PurchaseService.GetUnlimitedPlansForTenant(service)
            .OrderBy(x => x.Days)
            .Select(plan =>
            {
                var selection = new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = plan.Key };
                var price = CalculateTenantPrice(tenant, selection).SalePriceToman;
                return new[] { new KeyboardButton($"{plan.DisplayName} [{plan.Key}] - {price.FormatCurrency()}") };
            })
            .Append(new[] { new KeyboardButton("❌ انصراف") })
            .ToArray();
        return new ReplyKeyboardMarkup(rows) { ResizeKeyboard = true };
    }

    /// <summary>
    /// Builds the final confirmation keyboard for tenant renewal order creation.
    /// </summary>
    /// <returns>Reply keyboard with confirm and cancel labels.</returns>
    private static ReplyKeyboardMarkup BuildTenantRenewConfirmKeyboard()
    {
        return new ReplyKeyboardMarkup(new[]
        {
            new[] { new KeyboardButton("✅ تایید"), new KeyboardButton("❌ انصراف") }
        })
        {
            ResizeKeyboard = true
        };
    }

    /// <summary>
    /// Parses and validates tenant metered traffic entered by button or typed text.
    /// </summary>
    /// <param name="text">Customer text such as <c>20 GB</c>, <c>20</c>, or Persian-digit equivalents.</param>
    /// <param name="service">Metered service whose minimum traffic rule is enforced.</param>
    /// <param name="trafficGb">Selected traffic in GB when parsing and minimum validation succeed.</param>
    /// <returns>
    /// <c>true</c> when the text contains a positive integer GB amount that is at least the service minimum;
    /// otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Tenant storefront purchases can use custom typed traffic, so this parser must not require the amount to
    /// exist in <c>trafficOptionsGb</c>. Preset buttons are only suggestions.
    /// </remarks>
    private static bool TryParseTenantTrafficSelection(string text, XuiV3ServiceDefinition service, out int trafficGb)
    {
        var digits = new string(NormalizeTenantDigits(text ?? string.Empty).Where(char.IsDigit).ToArray());
        return int.TryParse(digits, NumberStyles.Integer, CultureInfo.InvariantCulture, out trafficGb) &&
               trafficGb > 0 &&
               XuiV3PurchaseService.MeetsMinimumTraffic(service, trafficGb);
    }

    /// <summary>
    /// Builds tenant purchase inline buttons for visible metered traffic presets.
    /// </summary>
    /// <param name="service">Metered service whose visible preset values should be shown.</param>
    /// <returns>Inline keyboard with traffic buttons that satisfy the service minimum, plus a back button.</returns>
    /// <remarks>
    /// The keyboard is intentionally not the full policy surface: customers may type any larger custom traffic
    /// amount, and <see cref="TryParseTenantTrafficSelection"/> validates it.
    /// </remarks>
    private static InlineKeyboardMarkup BuildTenantTrafficInlineKeyboard(XuiV3ServiceDefinition service)
    {
        var rows = XuiV3PurchaseService.GetVisibleTrafficOptions(service)
            .Chunk(2)
            .Select(chunk => chunk
                .Select(gb => InlineKeyboardButton.WithCallbackData($"{gb} GB", CUSTOMERCALLBACKPREFIX + $"GB:{service.Key}:{gb}"))
                .ToArray())
            .Append(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", CUSTOMERCALLBACKPREFIX + "services") })
            .ToArray();

        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the Persian validation message shown when tenant traffic input is invalid or below the service minimum.
    /// </summary>
    /// <param name="service">Metered service whose minimum traffic should be displayed.</param>
    /// <returns>Customer-facing text explaining that a larger integer GB amount is required.</returns>
    private static string BuildTenantMinimumTrafficMessage(XuiV3ServiceDefinition service)
    {
        if (service == null)
            return "حجم وارد شده معتبر نیست. لطفاً دوباره تلاش کنید.";

        return $"حجم وارد شده معتبر نیست. حداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(service)} GB است. می‌توانید یکی از دکمه‌ها را بزنید یا عدد دلخواه بزرگ‌تر را وارد کنید.";
    }

    /// <summary>
    /// Converts Persian and Arabic digits in customer input to ASCII digits before numeric parsing.
    /// </summary>
    /// <param name="text">Raw tenant customer text, possibly containing Persian or Arabic digits.</param>
    /// <returns>Text with localized decimal digits converted to ASCII digits; null becomes an empty string.</returns>
    private static string NormalizeTenantDigits(string text)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        var builder = new System.Text.StringBuilder(text.Length);
        foreach (var ch in text)
        {
            var numericValue = char.GetNumericValue(ch);
            builder.Append(numericValue is >= 0 and <= 9 && Math.Abs(numericValue % 1) < double.Epsilon
                ? (char)('0' + (int)numericValue)
                : ch);
        }

        return builder.ToString();
    }

    /// <summary>
    /// Finds an enabled preset or allowed custom-day duration from a tenant renewal reply.
    /// </summary>
    /// <param name="service">Service containing duration options.</param>
    /// <param name="text">
    /// Customer text containing a preset display name/key or a digit-only Latin, Persian, or Arabic-Indic day count.
    /// </param>
    /// <returns>The matched configured or detached custom duration, or <c>null</c> when invalid.</returns>
    /// <remarks>
    /// Preset keys honor <c>isEnabled</c>. Numeric custom input remains independent of preset availability and is
    /// checked against the normal service's current custom-duration policy before tenant renewal state is persisted.
    /// </remarks>
    private static XuiV3DurationOption FindTenantDurationOption(XuiV3ServiceDefinition service, string text)
    {
        return XuiV3PurchaseService.TryResolveDurationInput(service, text, out var duration)
            ? duration
            : null;
    }

    /// <summary>
    /// Finds an unlimited plan from a tenant reply-keyboard label.
    /// </summary>
    /// <param name="service">Unlimited service containing plan options.</param>
    /// <param name="text">Customer text containing display name or key.</param>
    /// <returns>
    /// The matched tenant-visible plan, or <c>null</c> when the text is unknown or the plan is disabled or hidden from
    /// tenant storefronts.
    /// </returns>
    /// <remarks>
    /// Possession of a reply label or plan key is not authorization. This method performs no state, order, payment,
    /// wallet, or XUI mutation.
    /// </remarks>
    /// <example>
    /// <code>
    /// var plan = FindTenantUnlimitedPlan(service, message.Text);
    /// </code>
    /// </example>
    private static XuiV3UnlimitedPlan FindTenantUnlimitedPlan(XuiV3ServiceDefinition service, string text)
    {
        return XuiV3PurchaseService.GetUnlimitedPlansForTenant(service).FirstOrDefault(x =>
            (string.Equals(text, x.Key, StringComparison.OrdinalIgnoreCase) ||
             string.Equals(text, x.DisplayName, StringComparison.OrdinalIgnoreCase) ||
             (text?.Contains($"[{x.Key}]", StringComparison.OrdinalIgnoreCase) == true)));
    }

    /// <summary>
    /// Shows the tenant customer the three built-in installation tutorials as category buttons.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send the tutorial menu.</param>
    /// <param name="chatId">Telegram chat id of the tenant customer requesting help.</param>
    /// <param name="tenant">Tenant bot that owns this storefront conversation; used only for tenant context.</param>
    /// <param name="cancellationToken">Cancellation token for the Telegram send operation.</param>
    /// <returns>A task completing after the category menu has been sent.</returns>
    /// <remarks>
    /// Tutorials are built into the application and are identical for every storefront. This method therefore never
    /// reads <c>TenantTutorialsJson</c> and performs no users.db write: choosing a tutorial is a pure presentation action
    /// and cannot change customer, order, wallet, or tenant state.
    ///
    /// The customer is never left in a tutorial conversation step, so the normal tenant reply keyboard keeps working after
    /// the guide is delivered.
    /// </remarks>
    private async Task SendTenantTutorialsAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        BotInstance tenant,
        CancellationToken cancellationToken)
    {
        // One row per category so the operating system is unambiguous on narrow mobile clients.
        var rows = new List<InlineKeyboardButton[]>
        {
            new[] { InlineKeyboardButton.WithCallbackData("🤖 آموزش نصب Android", CUSTOMERCALLBACKPREFIX + "tutorial:" + TenantTutorialKinds.Android) },
            new[] { InlineKeyboardButton.WithCallbackData("🍎 آموزش نصب iOS", CUSTOMERCALLBACKPREFIX + "tutorial:" + TenantTutorialKinds.Ios) },
            new[] { InlineKeyboardButton.WithCallbackData("🪟 آموزش نصب ویندوز", CUSTOMERCALLBACKPREFIX + "tutorial:" + TenantTutorialKinds.Windows) }
        };

        await botClient.SendMessage(
            chatId,
            TENANTTUTORIALMENUTEXT,
            replyMarkup: new InlineKeyboardMarkup(rows),
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Delivers one built-in installation tutorial to a tenant customer as Telegram photo albums.
    /// </summary>
    /// <param name="botClient">Tenant bot client that serves the requesting customer.</param>
    /// <param name="chatId">Customer chat that requested the tutorial.</param>
    /// <param name="tutorialKind">
    /// Tutorial kind extracted from the callback payload. Only the three closed <see cref="TenantTutorialKinds" />
    /// values resolve to a directory; any other value is treated as unavailable rather than mapped to a folder.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for local file reads and Telegram uploads.</param>
    /// <returns>A task completing after the albums or the unavailable notice have been sent.</returns>
    /// <remarks>
    /// Reads only the fixed built-in tutorial directory for the requested kind and performs no database work, so
    /// requesting a tutorial cannot change customer, order, wallet, XUI, or tenant configuration state.
    ///
    /// A missing, empty, or unreadable asset directory is a local operational condition: it is logged with the tutorial
    /// kind and its repository-relative directory (never an absolute server path) and the customer receives a friendly
    /// temporary-unavailable message instead of a failed callback.
    /// </remarks>
    private async Task SENDTENANTTUTORIALALBUMASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        string tutorialKind,
        CancellationToken cancellationToken)
    {
        var assets = TenantTutorialAssetService.Resolve(tutorialKind);
        if (!assets.IsAvailable)
        {
            _logger.LogWarning(
                "Tenant tutorial assets unavailable. kind={TutorialKind}, dir={RelativeDirectory}, status={AssetStatus}",
                assets.Kind ?? "unsupported",
                assets.RelativeDirectory,
                assets.Status);
            await botClient.SendMessage(
                chatId,
                TENANTTUTORIALASSETSUNAVAILABLEMESSAGE,
                cancellationToken: cancellationToken);
            return;
        }

        await TenantTutorialAlbumSender.SendAsync(botClient, chatId, assets, _logger, cancellationToken);
    }

    /// <summary>
    /// Cancels an obsolete owner tutorial input step without persisting anything.
    /// </summary>
    /// <param name="botClient">Owned bot client used to answer the owner and restore the tenant panel.</param>
    /// <param name="message">Owner text message that arrived while an obsolete tutorial step was still stored.</param>
    /// <param name="owner">Authenticated colleague profile that owns the current storefront selection.</param>
    /// <param name="cancellationToken">Cancellation token for state and Telegram operations.</param>
    /// <returns>A task completing after the stale step is cleared and the owner is returned to the panel.</returns>
    /// <remarks>
    /// This path exists only for owners whose conversation state still holds <c>tutorial-title</c> or <c>tutorial-url</c>
    /// from before owner-configurable tutorials were disabled. It clears the bot-scoped step and never writes
    /// <c>TenantTutorialsJson</c>, so historical tutorial data stays intact for a possible future rollback.
    /// </remarks>
    private async Task HANDLEOBSOLETETUTORIALSTEPASYNC(
        ITelegramBotClient botClient,
        Message message,
        CredUser owner,
        CancellationToken cancellationToken)
    {
        await _state.ClearUserStatus(new User { Id = message.From.Id });
        await botClient.SendMessage(
            message.Chat.Id,
            TENANTTUTORIALMANAGERDISABLEDMESSAGE,
            cancellationToken: cancellationToken);
        await SHOWOWNERPANELASYNC(botClient, message.Chat.Id, owner, null, cancellationToken);
    }

    /// <summary>
    /// Adds URL buttons for one tutorial platform to a tenant tutorial keyboard.
    /// </summary>
    /// <remarks>
    /// Dormant: owner-configurable tutorial links are disabled, so this helper currently has no production caller. It is
    /// intentionally retained so re-enabling owner tutorials later does not require reconstructing the keyboard logic.
    /// </remarks>
    /// <param name="rows">Mutable inline-keyboard rows that will be sent to the tenant customer.</param>
    /// <param name="label">Human-readable platform label, such as Android or Windows.</param>
    /// <param name="json">JSON array of URLs stored on the tenant bot row; null or invalid JSON is ignored.</param>
    /// <remarks>
    /// Invalid or non-HTTP URLs are skipped so tenant owners cannot accidentally create Telegram buttons that fail
    /// at send time.
    /// </remarks>
    private static void AddTenantTutorialButtons(List<InlineKeyboardButton[]> rows, string label, string json)
    {
        var urls = DeserializeTenantStringArray(json);
        for (var i = 0; i < urls.Length; i++)
        {
            var url = urls[i];
            if (string.IsNullOrWhiteSpace(url) ||
                (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                 !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            var suffix = urls.Length == 1 ? string.Empty : $" {i + 1}";
            rows.Add(new[] { InlineKeyboardButton.WithUrl($"{label}{suffix}", url) });
        }
    }

    /// <summary>
    /// Deserializes a tenant-owned JSON string array without throwing into the update pipeline.
    /// </summary>
    /// <param name="json">JSON array stored in users.db for one tenant tutorial platform.</param>
    /// <returns>An array of configured strings; empty when the value is null, empty, or invalid.</returns>
    private static string[] DeserializeTenantStringArray(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return Array.Empty<string>();

        try
        {
            return JsonConvert.DeserializeObject<string[]>(json) ?? Array.Empty<string>();
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    /// <summary>
    /// Routes tenant customer inline callbacks through current service selection, plan selection, payment creation, and manual checks.
    /// </summary>
    /// <param name="botClient">tenant Bot client.</param>
    /// <param name="CallbackQuery">Incoming customer callback.</param>
    /// <param name="customer">Shared customer profile.</param>
    /// <param name="User">
    /// Bot-scoped state for the customer that clicked the inline button. Tenant-specific callbacks use it only
    /// for isolation; non-tenant XUI callbacks are delegated before this method is called.
    /// </param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <remarks>
    /// Only callbacks with the tenant customer prefix are processed here. Shared account-management callbacks
    /// are routed to <see cref="XuiV3BotFlowService" /> by the update dispatcher so tenant storefront buttons can
    /// reuse the existing account details, search, renewal, and comment logic. Duration callbacks are checked against
    /// the freshly loaded catalog before tenant state advances or a payable order can be created. Removed services,
    /// below-minimum traffic, disabled durations, and disabled unlimited plans reset only this tenant bot/customer
    /// conversation to the earliest valid menu. Stale callback data never creates an order or payment invoice.
    /// </remarks>
    /// <returns>A task that completes after the callback is rejected, recovered, or routed to its tenant operation.</returns>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="CancellationToken"/> is cancelled during users.db, Telegram, pricing, or payment work.
    /// </exception>
    private async Task HANDLECUSTOMERCALLBACKASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        CredUser customer,
        User User,
        CancellationToken CancellationToken)
    {
        var tenant = await GetCurrentTenantBotAsync(CancellationToken);
        if (tenant == null || !tenant.Enabled)
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "فروشگاه غیرفعال است.", showAlert: true, cancellationToken: CancellationToken);
            return;
        }

        var action = CallbackQuery.Data[CUSTOMERCALLBACKPREFIX.Length..];
        var ChatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var MessageId = CallbackQuery.Message?.MessageId;

        if (action == "joincheck")
        {
            var joined = await EnsureTenantCustomerJoinAsync(
                botClient,
                ChatId,
                CallbackQuery.From.Id,
                tenant,
                CancellationToken,
                isJoinRetry: true);
            if (joined)
            {
                await SendTenantHomeAsync(botClient, ChatId, tenant, CancellationToken);
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "عضویت شما تایید شد.", cancellationToken: CancellationToken);
            }
            else
            {
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "هنوز عضو کانال نشده‌اید.", showAlert: true, cancellationToken: CancellationToken);
            }

            return;
        }

        if (!await EnsureTenantCustomerJoinAsync(botClient, ChatId, CallbackQuery.From.Id, tenant, CancellationToken))
        {
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "ابتدا در کانال عضو شوید.", showAlert: true, cancellationToken: CancellationToken);
            return;
        }

        if (action == "home")
        {
            await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
            await SendTenantHomeAsync(botClient, ChatId, tenant, CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        // Built-in installation tutorials. The payload selects one of three compile-time kinds only: it can never
        // choose a filesystem path, another tenant bot, or an arbitrary folder, so no customer input reaches the
        // filesystem resolver. The callback is acknowledged before any file I/O so the client spinner is not held open
        // while several photos are uploaded.
        if (action.StartsWith("tutorial:", StringComparison.Ordinal))
        {
            // No conversation state is written or cleared: the tutorial menu is a standalone inline message, and
            // interrupting an in-progress purchase just to view a guide must not discard that flow. Requesting a
            // tutorial is therefore a pure presentation action with no users.db effect.
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            await SENDTENANTTUTORIALALBUMASYNC(
                botClient,
                ChatId,
                action["tutorial:".Length..],
                CancellationToken);
            return;
        }

        if (action == "services")
        {
            await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
            await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("svc:", StringComparison.Ordinal))
        {
            await SHOWSERVICEOPTIONSASYNC(botClient, ChatId, MessageId, tenant, action["svc:".Length..], CallbackQuery.From.Id, CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("GB:", StringComparison.Ordinal))
        {
            var parts = action.Split(':');
            if (parts.Length == 3 && int.TryParse(parts[2], out var GB))
            {
                var service = _purchaseService.GetEnabledServices().FirstOrDefault(x => string.Equals(x.Key, parts[1], StringComparison.OrdinalIgnoreCase));
                if (service == null || service.IsUnlimited)
                {
                    await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                    await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
                }
                else if (!XuiV3PurchaseService.MeetsMinimumTraffic(service, GB))
                {
                    await _state.ResetUserStatus(new User
                    {
                        Id = CallbackQuery.From.Id,
                        Flow = TENANTPURCHASEFLOW,
                        LastStep = TENANTPURCHASESTEPTRAFFIC,
                        SelectedCountry = service.Key,
                        SelectedPeriod = string.Empty,
                        Type = string.Empty,
                        TotoalGB = string.Empty,
                        PendingUserComment = string.Empty
                    });
                    await EDITORSENDASYNC(
                        botClient,
                        ChatId,
                        MessageId,
                        BuildTenantMinimumTrafficMessage(service),
                        BuildTenantTrafficInlineKeyboard(service),
                        CancellationToken);
                }
                else
                {
                    await _state.ResetUserStatus(new User
                    {
                        Id = CallbackQuery.From.Id,
                        Flow = TENANTPURCHASEFLOW,
                        LastStep = TENANTPURCHASESTEPDURATION,
                        SelectedCountry = service.Key,
                        TotoalGB = GB.ToString(CultureInfo.InvariantCulture),
                        SelectedPeriod = string.Empty,
                        Type = string.Empty,
                        PendingUserComment = string.Empty
                    });
                    await SHOWDURATIONOPTIONSASYNC(botClient, ChatId, MessageId, tenant, parts[1], GB, CancellationToken);
                }
            }

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("dur:", StringComparison.Ordinal))
        {
            var parts = action.Split(':');
            if (parts.Length == 4 && int.TryParse(parts[2], out var GB))
            {
                var service = _purchaseService.GetEnabledServices().FirstOrDefault(x => string.Equals(x.Key, parts[1], StringComparison.OrdinalIgnoreCase));
                if (service == null || service.IsUnlimited)
                {
                    await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                    await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
                    await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
                    return;
                }

                if (!XuiV3PurchaseService.MeetsMinimumTraffic(service, GB))
                {
                    await _state.ResetUserStatus(new User
                    {
                        Id = CallbackQuery.From.Id,
                        Flow = TENANTPURCHASEFLOW,
                        LastStep = TENANTPURCHASESTEPTRAFFIC,
                        SelectedCountry = service.Key,
                        SelectedPeriod = string.Empty,
                        Type = string.Empty,
                        TotoalGB = string.Empty,
                        PendingUserComment = string.Empty
                    });
                    await EDITORSENDASYNC(
                        botClient,
                        ChatId,
                        MessageId,
                        BuildTenantMinimumTrafficMessage(service),
                        BuildTenantTrafficInlineKeyboard(service),
                        CancellationToken);
                    await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
                    return;
                }

                if (!XuiV3PurchaseService.TryResolveDurationKey(service, parts[3], out _))
                {
                    // Tenant callback messages can remain clickable after an operator disables a duration. Refresh
                    // the current choices before order creation so no tenant balance or gateway flow can be reached.
                    await _state.ResetUserStatus(new User
                    {
                        Id = CallbackQuery.From.Id,
                        Flow = TENANTPURCHASEFLOW,
                        LastStep = TENANTPURCHASESTEPDURATION,
                        SelectedCountry = service.Key,
                        TotoalGB = GB.ToString(CultureInfo.InvariantCulture),
                        SelectedPeriod = string.Empty,
                        Type = string.Empty,
                        PendingUserComment = string.Empty
                    });
                    await SHOWDURATIONOPTIONSASYNC(botClient, ChatId, MessageId, tenant, service.Key, GB, CancellationToken);
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "این مدت غیرفعال شده است. یک گزینه فعال را انتخاب کنید.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }

                var selection = new XuiV3PurchaseSelection { ServiceKey = parts[1], TrafficGb = GB, DurationKey = parts[3] };
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await SHOWCUSTOMERCONFIRMASYNC(botClient, ChatId, MessageId, tenant, selection, CancellationToken);
            }

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("upl:", StringComparison.Ordinal))
        {
            var parts = action.Split(':');
            if (parts.Length == 3)
            {
                var service = _purchaseService.GetEnabledServices().FirstOrDefault(candidate =>
                    candidate.IsUnlimited &&
                    string.Equals(candidate.Key, parts[1], StringComparison.OrdinalIgnoreCase));
                var plan = XuiV3PurchaseService.GetUnlimitedPlansForTenant(service).FirstOrDefault(candidate =>
                    string.Equals(candidate.Key, parts[2], StringComparison.OrdinalIgnoreCase));
                if (service == null)
                {
                    await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                    await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
                }
                else if (plan == null)
                {
                    await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                    await SHOWSERVICEOPTIONSASYNC(
                        botClient,
                        ChatId,
                        MessageId,
                        tenant,
                        service.Key,
                        CallbackQuery.From.Id,
                        CancellationToken);
                    await SafeAnswerCallbackQueryAsync(
                        botClient,
                        CallbackQuery.Id,
                        "این پلن غیرفعال شده است. یک پلن فعال را انتخاب کنید.",
                        showAlert: true,
                        cancellationToken: CancellationToken);
                    return;
                }
                else
                {
                    var selection = new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = plan.Key };
                    await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                    await SHOWCUSTOMERCONFIRMASYNC(botClient, ChatId, MessageId, tenant, selection, CancellationToken);
                }
            }

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("Pay:", StringComparison.Ordinal))
        {
            var selection = PARSESELECTIONFROMPAYACTION(action);
            if (selection == null)
            {
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "سفارش نامعتبر است.", showAlert: true, cancellationToken: CancellationToken);
                return;
            }

            if (!await EnsureTenantPurchaseSelectionIsCurrentAsync(
                    botClient,
                    CallbackQuery,
                    tenant,
                    selection,
                    CancellationToken))
            {
                return;
            }

            await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
            await CreateTenantOrderINVOICEASYNC(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            return;
        }

        if (action.StartsWith("PAYHP:", StringComparison.Ordinal) ||
            action.StartsWith("PAYTM:", StringComparison.Ordinal) ||
            action.StartsWith("PAYUP:", StringComparison.Ordinal) ||
            action.StartsWith("PAYAP:", StringComparison.Ordinal) ||
            action.StartsWith("PAYNP:", StringComparison.Ordinal) ||
            action.StartsWith("PAYCARD:", StringComparison.Ordinal))
        {
            var Provider = action.Split(':', 2)[0];
            var PAYACTION = action[(Provider.Length + 1)..];
            var selection = PARSESELECTIONFROMPAYACTION(PAYACTION);
            if (selection == null)
            {
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "سفارش نامعتبر است.", showAlert: true, cancellationToken: CancellationToken);
                return;
            }

            if (!await EnsureTenantPurchaseSelectionIsCurrentAsync(
                    botClient,
                    CallbackQuery,
                    tenant,
                    selection,
                    CancellationToken))
            {
                return;
            }

            if (Provider == "PAYHP")
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantOrderINVOICEASYNC(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            else if (Provider == "PAYTM")
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantTetraminatorInvoiceAsync(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            else if (Provider == "PAYUP")
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantUniquePayInvoiceAsync(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            else if (Provider == "PAYAP")
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantAtlasPayInvoiceAsync(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            else if (Provider == "PAYNP")
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantNowPaymentsInvoiceAsync(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            else
            {
                await _state.ClearUserStatus(new User { Id = CallbackQuery.From.Id });
                await CreateTenantCardOrderAsync(botClient, CallbackQuery, tenant, customer, selection, CancellationToken);
            }
            return;
        }

        if (action.StartsWith("RNHP:", StringComparison.Ordinal) ||
            action.StartsWith("RNTM:", StringComparison.Ordinal) ||
            action.StartsWith("RNUP:", StringComparison.Ordinal) ||
            action.StartsWith("RNAP:", StringComparison.Ordinal) ||
            action.StartsWith("RNNP:", StringComparison.Ordinal) ||
            action.StartsWith("RNCARD:", StringComparison.Ordinal))
        {
            var provider = action.Split(':', 2)[0];
            var idText = action[(provider.Length + 1)..];
            if (!int.TryParse(idText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var orderDbId))
            {
                await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "سفارش تمدید نامعتبر است.", showAlert: true, cancellationToken: CancellationToken);
                return;
            }

            if (provider == "RNHP")
                await CreateTenantHooshPayInvoiceForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            else if (provider == "RNTM")
                await CreateTenantTetraminatorInvoiceForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            else if (provider == "RNUP")
                await CreateTenantUniquePayInvoiceForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            else if (provider == "RNAP")
                await CreateTenantAtlasPayInvoiceForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            else if (provider == "RNNP")
                await CreateTenantNowPaymentsInvoiceForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            else
                await ActivateTenantCardPaymentForExistingOrderAsync(botClient, CallbackQuery, tenant, customer, orderDbId, CancellationToken);
            return;
        }

        if (action.StartsWith("CHK:", StringComparison.OrdinalIgnoreCase))
        {
            var idText = action["CHK:".Length..];
            if (int.TryParse(idText, out var OrderId))
                await CheckTenantOrderAsync(botClient, ChatId, OrderId, customer.TelegramUserId, CancellationToken);

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "وضعیت بررسی شد.", cancellationToken: CancellationToken);
            return;
        }

        if (action.StartsWith("receipt:", StringComparison.Ordinal))
        {
            var idText = action["receipt:".Length..];
            if (int.TryParse(idText, out var OrderId))
                await PromptTenantReceiptUploadAsync(botClient, ChatId, OrderId, customer.TelegramUserId, CancellationToken);

            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "رسید را به صورت عکس ارسال کنید.", cancellationToken: CancellationToken);
            return;
        }
    }

    /// <summary>
    /// sends the tenant storefront home Message and Reply keyboard.
    /// </summary>
    /// <param name="botClient">tenant Bot client.</param>
    /// <param name="ChatId">customer chat Id.</param>
    /// <param name="tenant">current tenant Bot row.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    private async Task SendTenantHomeAsync(ITelegramBotClient botClient, ChatId ChatId, BotInstance tenant, CancellationToken CancellationToken)
    {
        var WELCOME = string.IsNullOrWhiteSpace(tenant.TenantWelcomeText)
            ? $"به فروشگاه {tenant.BrandName ?? tenant.Username} خوش آمدید."
            : tenant.TenantWelcomeText;

        await botClient.SendMessage(
            chatId: ChatId,
            text: $"{Html(WELCOME)}\n\nبرای خرید اکانت یا دیدن تعرفه‌ها از دکمه‌های پایین استفاده کنید.",
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantReplyKeyboard(),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Builds the SMALL Reply keyboard shown to tenant customers.
    /// </summary>
    /// <returns>Storefront menu displaying «اکانت تست» for the shared owned-policy trial entry.</returns>
    /// <remarks>All actions execute under the current store; trial history remains bot/user scoped.</remarks>
    private ReplyKeyboardMarkup BuildTenantReplyKeyboard()
    {
        // The latest-client-download button is global and read from the live switch on every render, so a super-admin
        // toggle affects newly drawn tenant keyboards immediately and no tenant can override it. Tenant owners have no
        // per-tenant flag for this feature and none is persisted on BotInstance.
        var rows = new List<KeyboardButton[]>
        {
            new KeyboardButton[] { "💳 خرید اکانت", "📋 تعرفه‌ها" },
            new KeyboardButton[] { "اکانت‌های من", "🔄 تمدید اکانت" },
            new KeyboardButton[] { "جستجوی اکانت", "راهنما نصب" },
            new KeyboardButton[] { "🌟اکانت تست", "💬 پشتیبانی" }
        };

        if (_clientDownloadAvailability.Snapshot.Enabled)
            rows.Add(new KeyboardButton[] { ClientDownloadCallbacks.OpenCommand });

        return new ReplyKeyboardMarkup(rows)
        {
            ResizeKeyboard = true
        };
    }

    /// <summary>
    /// Builds a clickable Telegram support contact for tenant storefront customers.
    /// </summary>
    /// <param name="supportAccount">
    /// Tenant-scoped support account configured by the colleague owner. The value may be a raw username,
    /// an <c>@username</c>, a public <c>https://t.me/username</c> link, or a <c>t.me/username</c> value without
    /// a scheme. Empty values mean no support account has been configured.
    /// </param>
    /// <returns>
    /// HTML-safe text for a Telegram message. Valid Telegram usernames are returned as clickable
    /// <c>https://t.me/...</c> links with visible <c>@username</c> text; unsupported values are escaped and
    /// displayed as plain text.
    /// </returns>
    /// <remarks>
    /// The tenant support message is sent with <see cref="ParseMode.Html"/>. This helper keeps owner-provided
    /// text out of raw HTML while making normal Telegram usernames clickable even when the client does not
    /// auto-link plain <c>@username</c> text.
    /// </remarks>
    private static string BuildTenantSupportContactHtml(string supportAccount)
    {
        if (string.IsNullOrWhiteSpace(supportAccount))
            return "ثبت نشده";

        var normalized = NormalizeTenantSupportAccount(supportAccount);
        if (string.IsNullOrWhiteSpace(normalized))
            return Html(supportAccount.Trim());

        var username = normalized.TrimStart('@');
        var safeUsername = Html(username);
        return $"<a href=\"https://t.me/{safeUsername}\">@{safeUsername}</a>";
    }

    /// <summary>
    /// Normalizes a tenant support contact into a Telegram username with one leading <c>@</c>.
    /// </summary>
    /// <param name="supportAccount">
    /// Owner-provided support contact. The value may be <c>@username</c>, <c>username</c>,
    /// <c>https://t.me/username</c>, <c>t.me/username</c>, or <c>telegram.me/username</c>.
    /// </param>
    /// <returns>
    /// A normalized <c>@username</c> when the input contains a valid public Telegram username; otherwise <c>null</c>.
    /// </returns>
    /// <remarks>
    /// Tenant support is customer-facing. Storing the canonical username avoids rendering broken values such as
    /// <c>@https://t.me/name</c> later in support messages, owner panels, and logs.
    /// </remarks>
    private static string NormalizeTenantSupportAccount(string supportAccount)
    {
        if (string.IsNullOrWhiteSpace(supportAccount))
            return null;

        var normalized = supportAccount.Trim();
        if (normalized.StartsWith("@http://", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@https://", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@t.me/", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("@telegram.me/", StringComparison.OrdinalIgnoreCase))
        {
            normalized = normalized[1..];
        }

        if (normalized.StartsWith("t.me/", StringComparison.OrdinalIgnoreCase) ||
            normalized.StartsWith("telegram.me/", StringComparison.OrdinalIgnoreCase))
        {
            normalized = "https://" + normalized;
        }

        if (Uri.TryCreate(normalized, UriKind.Absolute, out var uri) &&
            (string.Equals(uri.Host, "t.me", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(uri.Host, "telegram.me", StringComparison.OrdinalIgnoreCase)))
        {
            normalized = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? string.Empty;
        }

        var username = normalized.Trim().TrimStart('@');
        return IsTelegramUsername(username) ? "@" + username : null;
    }

    /// <summary>
    /// Checks whether a value can be used as a public Telegram username link.
    /// </summary>
    /// <param name="username">
    /// Username without the leading <c>@</c>. It must contain only ASCII letters, digits, or underscores.
    /// </param>
    /// <returns>
    /// <c>true</c> when the value satisfies Telegram's public username shape closely enough to build a
    /// clickable <c>t.me</c> link; otherwise <c>false</c>.
    /// </returns>
    private static bool IsTelegramUsername(string username)
    {
        return !string.IsNullOrWhiteSpace(username) &&
               username.Length is >= 5 and <= 32 &&
               username.All(ch => char.IsAsciiLetterOrDigit(ch) || ch == '_');
    }

    /// <summary>
    /// sends or edits the first storefront purchase step where the customer CHOOSES A service.
    /// </summary>
    /// <param name="botClient">tenant Bot client.</param>
    /// <param name="ChatId">customer chat Id.</param>
    /// <param name="tenant">current tenant Bot row.</param>
    /// <param name="CancellationToken">Cancellation Token.</param>
    /// <param name="MessageId">optional Message Id to edit.</param>
    private async Task SendServiceSelectionAsync(
        ITelegramBotClient botClient,
        ChatId ChatId,
        BotInstance tenant,
        CancellationToken CancellationToken,
        int? MessageId = null)
    {
        var keyboard = BUILDTENANTSERVICEKEYBOARD();
        var Text = "نوع سرویس مورد نظر را انتخاب کنید:";
        if (MessageId.HasValue)
        {
            await SafeEditMessageTextAsync(botClient, ChatId, MessageId.Value, Text, replyMarkup: keyboard, cancellationToken: CancellationToken);
            return;
        }

        await botClient.SendMessage(ChatId, Text, replyMarkup: keyboard, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Builds inline buttons for all enabled xui v3 service definitions.
    /// </summary>
    /// <returns>inline keyboard where each button POINTS to A tenant service callback.</returns>
    private InlineKeyboardMarkup BUILDTENANTSERVICEKEYBOARD()
    {
        var rows = _purchaseService.GetEnabledServices()
            .Select(service => new[]
            {
                InlineKeyboardButton.WithCallbackData(service.DisplayName, CUSTOMERCALLBACKPREFIX + "svc:" + service.Key)
            })
            .Append(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", CUSTOMERCALLBACKPREFIX + "home") })
            .ToArray();

        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Shows current traffic options for a metered service or enabled sub-plans for an unlimited service.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant storefront handling the customer callback.</param>
    /// <param name="ChatId">Telegram chat id of the tenant customer receiving the live service choices.</param>
    /// <param name="MessageId">Optional Telegram message id to edit; null sends a new selection message.</param>
    /// <param name="tenant">
    /// Tenant bot row whose markup or fixed-public-price policy determines each displayed sale amount.
    /// </param>
    /// <param name="ServiceKey">Global enabled XUI service key selected by the tenant customer callback.</param>
    /// <param name="CustomerTelegramUserId">
    /// Numeric Telegram user id of the tenant customer. This is stored in users.db state so a typed traffic
    /// message can continue the same purchase flow after the service callback.
    /// </param>
    /// <param name="CancellationToken">Token that cancels users.db state changes and Telegram delivery.</param>
    /// <returns>A task that completes after tenant-scoped state and the current selection message are synchronized.</returns>
    /// <remarks>
    /// Selecting a metered service atomically clears duration, plan, traffic, count, and comment values from any older
    /// purchase before installing the traffic step. A removed or disabled service clears this tenant conversation and
    /// returns to the live service menu. Unlimited selection clears prior state before showing only tenant-visible
    /// plans priced by <see cref="CalculateTenantPrice" />. No order, wallet, payment, or XUI operation is performed.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="CancellationToken"/> is cancelled during users.db or Telegram work.
    /// </exception>
    /// <example>
    /// <code>
    /// await SHOWSERVICEOPTIONSASYNC(
    ///     botClient, chatId, messageId, tenant, "unlimited", customerTelegramUserId, cancellationToken);
    /// </code>
    /// </example>
    private async Task SHOWSERVICEOPTIONSASYNC(
        ITelegramBotClient botClient,
        ChatId ChatId,
        int? MessageId,
        BotInstance tenant,
        string ServiceKey,
        long CustomerTelegramUserId,
        CancellationToken CancellationToken)
    {
        var service = _purchaseService.GetEnabledServices().FirstOrDefault(x => x.Key == ServiceKey);
        if (service == null)
        {
            await _state.ClearUserStatus(new User { Id = CustomerTelegramUserId });
            await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
            return;
        }

        if (service.IsUnlimited)
        {
            await _state.ClearUserStatus(new User { Id = CustomerTelegramUserId });
            var rows = XuiV3PurchaseService.GetUnlimitedPlansForTenant(service)
                .Select(plan =>
                {
                    var selection = new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = plan.Key };
                    var Price = CalculateTenantPrice(tenant, selection).SalePriceToman;
                    return new[]
                    {
                        InlineKeyboardButton.WithCallbackData(
                            $"{plan.DisplayName} - {Price.FormatCurrency()}",
                            CUSTOMERCALLBACKPREFIX + $"upl:{service.Key}:{plan.Key}")
                    };
                })
                .Append(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", CUSTOMERCALLBACKPREFIX + "services") })
                .ToArray();

            await EDITORSENDASYNC(botClient, ChatId, MessageId, "پلن مورد نظر را انتخاب کنید:", new InlineKeyboardMarkup(rows), CancellationToken);
            return;
        }

        await _state.ResetUserStatus(new User
        {
            Id = CustomerTelegramUserId,
            Flow = TENANTPURCHASEFLOW,
            LastStep = TENANTPURCHASESTEPTRAFFIC,
            SelectedCountry = service.Key,
            SelectedPeriod = string.Empty,
            Type = string.Empty,
            TotoalGB = string.Empty,
            PendingUserComment = string.Empty
        });

        await EDITORSENDASYNC(
            botClient,
            ChatId,
            MessageId,
            $"حجم مورد نظر را انتخاب کنید یا حجم دلخواه را به GB وارد کنید.\nحداقل حجم این سرویس {XuiV3PurchaseService.GetMinimumTrafficGb(service)} GB است.",
            BuildTenantTrafficInlineKeyboard(service),
            CancellationToken);
    }

    /// <summary>
    /// Shows the duration choices for a tenant customer's metered purchase after traffic has been selected.
    /// </summary>
    /// <param name="botClient">
    /// Telegram client for the tenant storefront that is serving the customer.
    /// </param>
    /// <param name="ChatId">
    /// Telegram chat id where the customer is choosing the plan duration.
    /// </param>
    /// <param name="MessageId">
    /// Optional Telegram message id to edit. When <c>null</c>, a new message is sent instead.
    /// </param>
    /// <param name="tenant">
    /// Tenant bot instance that owns the storefront, pricing markup, and payment settings for this purchase.
    /// </param>
    /// <param name="ServiceKey">
    /// Service key from <c>xui-v3-service-plans.json</c>, such as <c>normal</c> or <c>national</c>.
    /// </param>
    /// <param name="TrafficGb">
    /// Customer-selected metered traffic in GB. The value must satisfy the selected service's
    /// <c>minimumTrafficGb</c> policy before duration buttons are shown.
    /// </param>
    /// <param name="CancellationToken">
    /// Cancellation token for Telegram and state-validation operations.
    /// </param>
    /// <param name="Heading">
    /// Optional Persian heading shown above the duration instructions. Pass a validation message after rejected typed
    /// input, or leave <c>null</c> to use the normal duration-selection heading.
    /// </param>
    /// <remarks>
    /// This method is shared by callback traffic buttons and manually typed traffic in tenant bots. It rechecks the
    /// minimum traffic and includes only currently enabled preset durations. When the normal service enables typed
    /// custom durations, the prompt also publishes its inclusive day range and explicit numeric example. Every button
    /// price comes from the shared resolver plus current tenant markup, so stale data cannot bypass global pricing or
    /// availability. The method sends or edits Telegram text but does not create an order or mutate a wallet.
    /// </remarks>
    private async Task SHOWDURATIONOPTIONSASYNC(
        ITelegramBotClient botClient,
        ChatId ChatId,
        int? MessageId,
        BotInstance tenant,
        string ServiceKey,
        int TrafficGb,
        CancellationToken CancellationToken,
        string Heading = null)
    {
        var service = _purchaseService.GetEnabledServices().FirstOrDefault(x => x.Key == ServiceKey);
        if (service == null)
        {
            await SendServiceSelectionAsync(botClient, ChatId, tenant, CancellationToken, MessageId);
            return;
        }

        if (!XuiV3PurchaseService.MeetsMinimumTraffic(service, TrafficGb))
        {
            await EDITORSENDASYNC(
                botClient,
                ChatId,
                MessageId,
                BuildTenantMinimumTrafficMessage(service),
                BuildTenantTrafficInlineKeyboard(service),
                CancellationToken);
            return;
        }

        var rows = XuiV3PurchaseService.GetEnabledDurationOptions(service)
            .Select(Duration =>
            {
                var selection = new XuiV3PurchaseSelection { ServiceKey = ServiceKey, TrafficGb = TrafficGb, DurationKey = Duration.Key };
                var Price = CalculateTenantPrice(tenant, selection).SalePriceToman;
                return new[]
                {
                    InlineKeyboardButton.WithCallbackData(
                        $"{Duration.DisplayName} - {Price.FormatCurrency()}",
                        CUSTOMERCALLBACKPREFIX + $"dur:{ServiceKey}:{TrafficGb}:{Duration.Key}")
                };
            })
            .Append(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", CUSTOMERCALLBACKPREFIX + $"svc:{ServiceKey}") })
            .ToArray();

        await EDITORSENDASYNC(
            botClient,
            ChatId,
            MessageId,
            XuiV3PurchaseService.BuildDurationSelectionText(
                service,
                Heading ?? "مدت سرویس را انتخاب کنید:"),
            new InlineKeyboardMarkup(rows),
            CancellationToken);
    }

    /// <summary>
    /// Revalidates a tenant purchase callback against the current global catalog before any payment action.
    /// </summary>
    /// <param name="botClient">Tenant storefront client used to refresh an invalid selection.</param>
    /// <param name="callbackQuery">Customer callback containing the chat, message, and Telegram user identifiers.</param>
    /// <param name="tenant">Tenant bot whose current markup participates in authoritative sale-price validation.</param>
    /// <param name="selection">
    /// Parsed purchase selection from callback data. Metered duration may be a preset key or canonical <c>days-N</c>.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for users.db and Telegram operations.</param>
    /// <returns>
    /// <c>true</c> when the selection and current tenant price resolve successfully; <c>false</c> when no order or
    /// payment invoice may be created and the customer has been notified.
    /// </returns>
    /// <remarks>
    /// A custom-duration policy or preset can change while a Telegram pre-invoice remains visible. Invalid metered
    /// selections are restored to the tenant-scoped duration step and current options are shown. Unlimited selections
    /// hidden by <c>TenantVisible</c> are restored to the current tenant plan selector. Full price validation is also
    /// repeated so malformed configuration cannot reach order, gateway, wallet, ledger, or XUI side effects.
    /// The duration is cleared with an explicit empty string because null preserves legacy partial state.
    /// </remarks>
    /// <exception cref="OperationCanceledException">
    /// Propagated when <paramref name="cancellationToken"/> is cancelled during users.db or Telegram recovery work.
    /// </exception>
    /// <example>
    /// <code>
    /// var current = await EnsureTenantPurchaseSelectionIsCurrentAsync(
    ///     botClient, callbackQuery, tenant, selection, cancellationToken);
    /// </code>
    /// </example>
    private async Task<bool> EnsureTenantPurchaseSelectionIsCurrentAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        XuiV3PurchaseSelection selection,
        CancellationToken cancellationToken)
    {
        var service = _purchaseService.GetEnabledServices().FirstOrDefault(candidate =>
            string.Equals(candidate.Key, selection?.ServiceKey, StringComparison.OrdinalIgnoreCase));
        if (service == null)
        {
            await _state.ClearUserStatus(new User { Id = callbackQuery.From.Id });
            await SendServiceSelectionAsync(
                botClient,
                callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                tenant,
                cancellationToken,
                callbackQuery.Message?.MessageId);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "این سرویس دیگر فعال نیست. خرید را دوباره آغاز کنید.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return false;
        }

        if (!service.IsUnlimited &&
            (!selection.TrafficGb.HasValue ||
             !XuiV3PurchaseService.MeetsMinimumTraffic(service, selection.TrafficGb.Value) ||
             !XuiV3PurchaseService.TryResolveDurationKey(service, selection.DurationKey, out _)))
        {
            if (selection.TrafficGb.HasValue && XuiV3PurchaseService.MeetsMinimumTraffic(service, selection.TrafficGb.Value))
            {
                await _state.ResetUserStatus(new User
                {
                    Id = callbackQuery.From.Id,
                    Flow = TENANTPURCHASEFLOW,
                    LastStep = TENANTPURCHASESTEPDURATION,
                    SelectedCountry = service.Key,
                    TotoalGB = selection.TrafficGb.Value.ToString(CultureInfo.InvariantCulture),
                    SelectedPeriod = string.Empty,
                    Type = string.Empty,
                    PendingUserComment = string.Empty
                });
                await SHOWDURATIONOPTIONSASYNC(
                    botClient,
                    callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                    callbackQuery.Message?.MessageId,
                    tenant,
                    service.Key,
                    selection.TrafficGb.Value,
                    cancellationToken,
                    "مدت انتخاب‌شده دیگر معتبر نیست. مدت جدید را انتخاب کنید.");
            }
            else
            {
                await _state.ResetUserStatus(new User
                {
                    Id = callbackQuery.From.Id,
                    Flow = TENANTPURCHASEFLOW,
                    LastStep = TENANTPURCHASESTEPTRAFFIC,
                    SelectedCountry = service.Key,
                    SelectedPeriod = string.Empty,
                    Type = string.Empty,
                    TotoalGB = string.Empty,
                    PendingUserComment = string.Empty
                });
                await EDITORSENDASYNC(
                    botClient,
                    callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                    callbackQuery.Message?.MessageId,
                    BuildTenantMinimumTrafficMessage(service),
                    BuildTenantTrafficInlineKeyboard(service),
                    cancellationToken);
            }

            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "مدت یا حجم این سفارش دیگر معتبر نیست.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return false;
        }

        if (service.IsUnlimited)
        {
            var selectedPlan = service.UnlimitedPlans?.FirstOrDefault(plan =>
                string.Equals(plan.Key, selection.UnlimitedPlanKey, StringComparison.OrdinalIgnoreCase));
            if (!XuiV3PurchaseService.IsUnlimitedPlanAvailableForTenant(selectedPlan))
            {
                await _state.ClearUserStatus(new User { Id = callbackQuery.From.Id });
                await SHOWSERVICEOPTIONSASYNC(
                    botClient,
                    callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id,
                    callbackQuery.Message?.MessageId,
                    tenant,
                    service.Key,
                    callbackQuery.From.Id,
                    cancellationToken);
                await SafeAnswerCallbackQueryAsync(
                    botClient,
                    callbackQuery.Id,
                    "این پلن دیگر فعال نیست. یک پلن فعال را انتخاب کنید.",
                    showAlert: true,
                    cancellationToken: cancellationToken);
                return false;
            }
        }

        try
        {
            _ = CalculateTenantPrice(tenant, selection);
            return true;
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException or OverflowException)
        {
            _logger.LogWarning(
                ex,
                "Tenant purchase callback was rejected by current pricing. tenantBotId={TenantBotId}, customerTelegramUserId={CustomerTelegramUserId}, serviceKey={ServiceKey}",
                tenant.Id,
                callbackQuery.From.Id,
                selection.ServiceKey);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "تعرفه این سفارش تغییر کرده است. خرید را دوباره آغاز کنید.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return false;
        }
    }

    /// <summary>
    /// Shows the tenant customer pre-invoice with the selected duration, sale-price calculation, and payment choices.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant storefront that owns this customer conversation.</param>
    /// <param name="ChatId">Telegram chat id of the tenant customer receiving or updating the pre-invoice.</param>
    /// <param name="MessageId">Optional Telegram message id to edit; <c>null</c> sends a new message.</param>
    /// <param name="tenant">Tenant bot whose markup and enabled payment methods control the sale.</param>
    /// <param name="selection">
    /// Current global plan selection. A metered duration may be an enabled preset or canonical <c>days-N</c> custom key.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <returns>A task that completes after the tenant-visible pre-invoice and payment choices are delivered.</returns>
    /// <remarks>
    /// The shared resolver revalidates service, traffic, and duration before the summary is built. Metered summaries
    /// show traffic and daily components using customer-visible effective tenant rates; markup pricing never exposes
    /// the owner's raw colleague cost. Unlimited selections are tenant-authorized again, and fixed-public-price policy
    /// changes only the displayed sale amount. This method sends UI only and does not create an order, invoice, wallet
    /// movement, ledger entry, or XUI account.
    ///
    /// Every enabled online gateway is displayed as instant and includes its customer-facing fee percentage:
    /// HooshPay 15%, Tetraminator 12%, UniquePay 12%, AtlasPay card-to-card, and NOWPayments 0%. Rial methods - the four
    /// Iranian toman gateways and the tenant owner's personal card-to-card option - end with a <c>ریالی</c> marker,
    /// while the NOWPayments button deliberately does not, so a customer can separate toman methods from cryptocurrency
    /// at a glance. The marker is display-only and never enters callback data, so previously issued invoices and
    /// idempotent settlement behavior are unaffected by these display labels. A shared notice distinguishes automatic
    /// verified online fulfillment from card-to-card fulfillment that waits for the tenant owner's receipt approval and
    /// may take longer.
    /// </remarks>
    private async Task SHOWCUSTOMERCONFIRMASYNC(ITelegramBotClient botClient, ChatId ChatId, int? MessageId, BotInstance tenant, XuiV3PurchaseSelection selection, CancellationToken CancellationToken)
    {
        var Price = CalculateTenantPrice(tenant, selection);
        var resolved = _purchaseService.ResolveTenantPurchase(selection, false);
        var priceBreakdownText = BuildTenantMeteredPriceBreakdownText(tenant, resolved, Price.SalePriceToman);
        var Text = "📌 <b>پیش‌فاکتور خرید</b>\n\n" +
                   $"سرویس: <b>{Html(resolved.Service.DisplayName)}</b>\n" +
                   (resolved.IsUnlimited
                       ? $"حد مصرف منصفانه: <code>{resolved.TrafficGb} GB</code>\n"
                       : $"حجم: <code>{resolved.TrafficGb} GB</code>\n") +
                   $"مدت: <code>{(resolved.DurationDays <= 0 ? "نامحدود" : resolved.DurationDays + " روز")}</code>\n" +
                   (string.IsNullOrWhiteSpace(priceBreakdownText) ? string.Empty : $"\n{priceBreakdownText}\n") +
                   $"مبلغ قابل پرداخت: <b>{Html(Price.SalePriceToman.FormatCurrency())}</b>\n\n" +
                   BuildTenantPaymentTimingNotice(isRenewal: false);

        var PAYMENTROWS = new List<InlineKeyboardButton[]>();
        if (IsTenantHooshPayAvailable(tenant, Price.SalePriceToman))
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ هوش‌پی آنی | کارمزد ۱۵٪ | ریالی", CUSTOMERCALLBACKPREFIX + "PAYHP:" + BUILDPAYACTION(selection)) });
        if (IsTenantTetraminatorAvailable(tenant, Price.SalePriceToman))
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ تترامیناتور آنی | کارمزد ۱۲٪ | ریالی", CUSTOMERCALLBACKPREFIX + "PAYTM:" + BUILDPAYACTION(selection)) });
        if (IsTenantUniquePayAvailable(tenant, Price.SalePriceToman))
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ یونیک‌پی آنی | کارمزد ۱۲٪ | ریالی", CUSTOMERCALLBACKPREFIX + "PAYUP:" + BUILDPAYACTION(selection)) });
        if (IsTenantAtlasPayAvailable(tenant))
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("💳 اطلس‌پی | کارت‌به‌کارت آنی | ریالی", CUSTOMERCALLBACKPREFIX + "PAYAP:" + BUILDPAYACTION(selection)) });
        if (_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) && tenant.TenantNowPaymentsEnabled)
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ ارز دیجیتال آنی | کارمزد ۰٪", CUSTOMERCALLBACKPREFIX + "PAYNP:" + BUILDPAYACTION(selection)) });
        if (tenant.TenantCardPaymentEnabled && !string.IsNullOrWhiteSpace(tenant.TenantCardNumber))
            PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("🧾 کارت‌به‌کارت به فروشگاه | ریالی", CUSTOMERCALLBACKPREFIX + "PAYCARD:" + BUILDPAYACTION(selection)) });
        PAYMENTROWS.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت", CUSTOMERCALLBACKPREFIX + "services") });

        await EDITORSENDASYNC(
            botClient,
            ChatId,
            MessageId,
            Text,
            new InlineKeyboardMarkup(PAYMENTROWS),
            CancellationToken,
            ParseMode.Html);
    }

    /// <summary>
    /// creates the local tenant order, creates the LINKED HooshPay invoice, stores both records,
    /// and sends the payment CONTROLS to the tenant customer.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant storefront Bot that is SERVING the customer.</param>
    /// <param name="CallbackQuery">callback that Confirmed the tenant customer's selected plan.</param>
    /// <param name="tenant">tenant Bot definition and PRICING settings owned by the colleague.</param>
    /// <param name="customer">Credential User record for the customer BUYING from the tenant storefront.</param>
    /// <param name="selection">resolved XuiV3 service, Traffic, Duration, or Unlimited-plan selection.</param>
    /// <param name="CancellationToken">Cancellation Token PROPAGATED from the Telegram update handler.</param>
    /// <remarks>
    /// The global and tenant-specific HooshPay switches are checked before creating either the tenant order or its
    /// linked payment row. Existing HooshPay orders remain eligible for inquiry and settlement after either switch is
    /// disabled, but stale purchase callbacks cannot create a new invoice.
    /// </remarks>
    private async Task CreateTenantOrderINVOICEASYNC(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        BotInstance tenant,
        CredUser customer,
        XuiV3PurchaseSelection selection,
        CancellationToken CancellationToken)
    {
        var ChatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var Price = CalculateTenantPrice(tenant, selection);
        if (!IsTenantHooshPayAvailable(tenant, Price.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                BuildTenantHooshPayUnavailableMessage(tenant, Price.SalePriceToman),
                showAlert: true,
                cancellationToken: CancellationToken);
            return;
        }

        var OrderId = CreateTenantOrderId(tenant, customer.TelegramUserId);

        // the local order is created before the invoice so ipn can be matched EVEN if the User leaves Telegram.
        var order = new TenantBotOrder
        {
            OrderId = OrderId,
            TenantBotId = tenant.Id,
            TenantBotUsername = tenant.Username,
            OwnerTelegramUserId = tenant.OwnerTelegramUserId ?? 0,
            CustomerTelegramUserId = customer.TelegramUserId,
            CustomerChatId = ChatId,
            CustomerUsername = customer.Username,
            CustomerFirstName = customer.FirstName,
            CustomerLastName = customer.LastName,
            OrderKind = TenantBotOrderKinds.Purchase,
            ServiceKey = selection.ServiceKey,
            TrafficGb = selection.TrafficGb,
            DurationKey = selection.DurationKey,
            UnlimitedPlanKey = selection.UnlimitedPlanKey,
            AccountCount = 1,
            SalePriceToman = Price.SalePriceToman,
            BaseCostToman = Price.BaseCostToman,
            ProfitToman = Price.ProfitToman,
            PaymentStatus = TenantBotOrderStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };

        _workflow.Add(order);
        await _workflow.SaveAsync(CancellationToken);

        var payment = new HooshPayPaymentInfo
        {
            OrderId = order.OrderId,
            AmountToman = order.SalePriceToman,
            FeeMode = HooshPayFeeModes.Buyer,
            IpnCallbackUrl = _appConfig.HooshPayIpnUrl,
            ReturnUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_success"),
            TelegramUserId = customer.TelegramUserId,
            ChatId = ChatId,
            BotId = tenant.Id,
            BotUsername = tenant.Username,
            PaymentPurpose = TenantBotPaymentPurposes.TenantOrder,
            TenantBotOrderId = order.Id,
            TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId,
            PaymentStatus = HooshPayStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };

        // Purpose marks this HooshPay row as A direct sale, not A wallet top-Up.
        _workflow.Add(payment);
        await _workflow.SaveAsync(CancellationToken);

        order.HooshPayPaymentInfoId = payment.Id;
        payment.RawRequestJson = JsonConvert.SerializeObject(new
        {
            amount = payment.AmountToman,
            fee_mode = HooshPayFeeModes.Buyer,
            Description = $"tenant Bot order {order.OrderId}",
            order_id = order.OrderId,
            callback_url = payment.IpnCallbackUrl,
            return_url = payment.ReturnUrl
        });

        try
        {
            var invoice = await _hooshPay.CreateInvoiceAsync(
                payment.AmountToman,
                payment.OrderId,
                $"tenant Bot order {order.OrderId}",
                payment.IpnCallbackUrl,
                payment.ReturnUrl,
                CancellationToken);

            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.Apply(invoice?.data);
            order.HooshPayInvoiceUid = payment.InvoiceUid;
            order.PaymentUrl = payment.PaymentUrl;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);

            await botClient.SendMessage(
                chatId: ChatId,
                text: BuildTenantPaymentText(order, payment),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment),
                cancellationToken: CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "فاکتور پرداخت ساخته شد.", cancellationToken: CancellationToken);
        }
        catch (Exception ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "ساخت فاکتور ناموفق بود.", showAlert: true, cancellationToken: CancellationToken);
            await botClient.SendMessage(ChatId, "ساخت فاکتور پرداخت ناموفق بود. لطفاً بعداً دوباره تلاش کنید.", cancellationToken: CancellationToken);
        }
    }

    /// <summary>
    /// creates A tenant order invoice through NowPayments and stores the crypto invoice metadata in users.db.
    /// </summary>
    /// <param name="botClient">tenant storefront Bot client that will Send the invoice link to the customer.</param>
    /// <param name="CallbackQuery">customer callback that selected crypto payment for A PREPARED plan.</param>
    /// <param name="tenant">tenant Bot that owns the storefront and Receives profit after settlement.</param>
    /// <param name="customer">credentials profile of the tenant customer.</param>
    /// <param name="selection">selected service, Traffic, Duration, or Unlimited plan.</param>
    /// <param name="CancellationToken">Cancellation Token for NowPayments, users.db, and Telegram calls.</param>
    /// <remarks>
    /// the created <see cref="SwapinoPaymentInfo" /> is marked with <see cref="TenantBotPaymentPurposes.TenantOrder" />
    /// so the NowPayments ipn endpoint routes paid invoices to tenant fulfillment instead of wallet top-Up settlement.
    /// </remarks>
    private async Task CreateTenantNowPaymentsInvoiceAsync(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        BotInstance tenant,
        CredUser customer,
        XuiV3PurchaseSelection selection,
        CancellationToken CancellationToken)
    {
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) ||
            tenant?.TenantNowPaymentsEnabled != true)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "درگاه ارز دیجیتال برای این فروشگاه در حال حاضر غیرفعال است.",
                showAlert: true,
                cancellationToken: CancellationToken);
            return;
        }

        var ChatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var Price = CalculateTenantPrice(tenant, selection);
        var order = CreateTenantOrder(tenant, customer, ChatId, selection, Price, "NowPayments");

        _workflow.Add(order);
        await _workflow.SaveAsync(CancellationToken);

        var payment = SwapinoPaymentInfo.CreateCryptoCharge(
            customer.TelegramUserId,
            order.SalePriceToman,
            _appConfig.NowpaymentIpnUrl,
            ChatId,
            _appConfig.NowpaymentPayCurrency);
        payment.OrderId = order.OrderId;
        payment.SuccessUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_success");
        payment.CancelUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_cancel");
        payment.BotId = tenant.Id;
        payment.BotUsername = tenant.Username;
        payment.PaymentPurpose = TenantBotPaymentPurposes.TenantOrder;
        payment.TenantBotOrderId = order.Id;
        payment.TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId;

        _workflow.Add(payment);
        await _workflow.SaveAsync(CancellationToken);

        try
        {
            var invoice = await _nowPayments.CreateInvoiceAsync(
                order.SalePriceToman,
                order.OrderId,
                $"tenant Bot order {order.OrderId}",
                successUrl: payment.SuccessUrl,
                cancelUrl: payment.CancelUrl,
                cancellationToken: CancellationToken);
            var Data = NowPaymentsPaymentRecordData.FromInvoiceResponse(invoice);
            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.SetNowPaymentsData(Data);
            order.NowPaymentsPaymentInfoId = payment.Id;
            order.PaymentUrl = payment.InvoiceUrl;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);

            await botClient.SendMessage(
                ChatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "ارز دیجیتال"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment.InvoiceUrl),
                cancellationToken: CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "فاکتور پرداخت ساخته شد.", cancellationToken: CancellationToken);
        }
        catch (NowPaymentsRateUnavailableException ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                CallbackQuery.Id,
                "??? ??????? ??? ??????? ?????? ???? ????? ???? ? ??? ??????? ????? ???. ????? ??? ????? ???? ?????? ???? ????.",
                showAlert: true,
                cancellationToken: CancellationToken);
        }
        catch (Exception ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "ساخت فاکتور ناموفق بود.", showAlert: true, cancellationToken: CancellationToken);
        }
    }

    /// <summary>
    /// Creates a Tetraminator invoice for a new tenant storefront purchase.
    /// </summary>
    /// <param name="botClient">Tenant bot client that receives the customer callback and sends payment controls.</param>
    /// <param name="callbackQuery">Customer callback containing the selected service payload.</param>
    /// <param name="tenant">Tenant storefront whose local gateway preference and global availability are enforced.</param>
    /// <param name="customer">Credentials profile of the tenant customer who will own the delivered account.</param>
    /// <param name="selection">Validated XUI service selection used to calculate the tenant sale price.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, provider, and Telegram operations.</param>
    /// <remarks>
    /// Invoice creation is not retried because Tetraminator does not provide a merchant idempotency key. The local
    /// order and payment row are persisted first so a later unsigned callback can only locate data and must still
    /// pass authoritative pay-id, paid-status, and amount verification.
    /// </remarks>
    private async Task CreateTenantTetraminatorInvoiceAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        XuiV3PurchaseSelection selection,
        CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var price = CalculateTenantPrice(tenant, selection);
        if (!IsTenantTetraminatorAvailable(tenant, price.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantTetraminatorUnavailableMessage(price.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var order = CreateTenantOrder(tenant, customer, chatId, selection, price, "Tetraminator");
        _workflow.Add(order);
        await _workflow.SaveAsync(cancellationToken);
        await CreateTenantTetraminatorInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    /// <summary>
    /// creates A tenant card-to-card order and asks the customer to Send A payment receipt photo.
    /// </summary>
    /// <param name="botClient">tenant storefront Bot client used to Send card INSTRUCTIONS.</param>
    /// <param name="CallbackQuery">customer callback that selected card-to-card payment.</param>
    /// <param name="tenant">tenant Bot whose owner Receives card-to-card money directly.</param>
    /// <param name="customer">credentials profile of the tenant customer.</param>
    /// <param name="selection">selected service, Traffic, Duration, or Unlimited plan.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db and Telegram calls.</param>
    /// <remarks>
    /// the customer PAYS the owner outside the PLATFORM. after the sales assistant CONFIRMS the receipt,
    /// fulfillment debits the tenant owner's base cost from the Shared wallet and may LEAVE the balance negative.
    /// </remarks>
    private async Task CreateTenantCardOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery CallbackQuery,
        BotInstance tenant,
        CredUser customer,
        XuiV3PurchaseSelection selection,
        CancellationToken CancellationToken)
    {
        var ChatId = CallbackQuery.Message?.Chat.Id ?? CallbackQuery.From.Id;
        var Price = CalculateTenantPrice(tenant, selection);
        var order = CreateTenantOrder(tenant, customer, ChatId, selection, Price, "tenant_card");
        order.PaymentStatus = TenantBotOrderStatuses.AwaitingReceipt;
        order.UpdatedAtUtc = DateTime.UtcNow;

        _workflow.Add(order);
        await _workflow.SaveAsync(CancellationToken);

        await botClient.SendMessage(
            ChatId,
            "💳 <b>پرداخت کارت‌به‌کارت فروشگاه</b>\n\n" +
            $"مبلغ دقیق: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
            $"شماره کارت: <code>{Html(tenant.TenantCardNumber)}</code>\n" +
            $"نام صاحب کارت: <b>{Html(tenant.TenantCardHolderName)}</b>\n" +
            $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n\n" +
            "بعد از پرداخت، عکس رسید را همینجا ارسال کنید تا همکار آن را تایید کند.",
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantCardPaymentKeyboard(order),
            cancellationToken: CancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, CallbackQuery.Id, "سفارش کارت‌به‌کارت ثبت شد.", cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Creates a HooshPay invoice for an existing tenant renewal order.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send the invoice to the customer.</param>
    /// <param name="callbackQuery">Customer callback that selected HooshPay for renewal.</param>
    /// <param name="tenant">Tenant bot that owns the order.</param>
    /// <param name="customer">Customer who owns the order.</param>
    /// <param name="orderDbId">Internal users.db id of the pending renewal order.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, HooshPay, and Telegram operations.</param>
    /// <remarks>
    /// The global and tenant-specific HooshPay switches are rechecked before loading or mutating the pending renewal
    /// order. Previously created invoices remain checkable and settleable through their existing status/IPN paths.
    /// </remarks>
    private async Task CreateTenantHooshPayInvoiceForExistingOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        int orderDbId,
        CancellationToken cancellationToken)
    {
        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش تمدید پیدا نشد، قبلاً پردازش شده یا نوع سرویس اکانت با سفارش سازگار نیست. دوباره از منوی تمدید اقدام کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        if (!IsTenantHooshPayAvailable(tenant, order.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantHooshPayUnavailableMessage(tenant, order.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        order.PaymentProvider = "HooshPay";
        order.UpdatedAtUtc = DateTime.UtcNow;
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var payment = new HooshPayPaymentInfo
        {
            OrderId = order.OrderId,
            AmountToman = order.SalePriceToman,
            FeeMode = HooshPayFeeModes.Buyer,
            IpnCallbackUrl = _appConfig.HooshPayIpnUrl,
            ReturnUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_success"),
            TelegramUserId = customer.TelegramUserId,
            ChatId = chatId,
            BotId = tenant.Id,
            BotUsername = tenant.Username,
            PaymentPurpose = TenantBotPaymentPurposes.TenantOrder,
            TenantBotOrderId = order.Id,
            TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId,
            PaymentStatus = HooshPayStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };

        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);

        order.HooshPayPaymentInfoId = payment.Id;
        payment.RawRequestJson = JsonConvert.SerializeObject(new
        {
            amount = payment.AmountToman,
            fee_mode = HooshPayFeeModes.Buyer,
            description = $"tenant renewal order {order.OrderId}",
            order_id = order.OrderId,
            callback_url = payment.IpnCallbackUrl,
            return_url = payment.ReturnUrl
        });

        try
        {
            var invoice = await _hooshPay.CreateInvoiceAsync(
                payment.AmountToman,
                payment.OrderId,
                $"tenant renewal order {order.OrderId}",
                payment.IpnCallbackUrl,
                payment.ReturnUrl,
                cancellationToken);

            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.Apply(invoice?.data);
            order.HooshPayInvoiceUid = payment.InvoiceUid;
            order.PaymentUrl = payment.PaymentUrl;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await botClient.SendMessage(
                chatId,
                BuildTenantPaymentText(order, payment),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور پرداخت ساخته شد.", cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "ساخت فاکتور ناموفق بود.", showAlert: true, cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Creates a NOWPayments invoice for an existing tenant renewal order.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send the invoice link.</param>
    /// <param name="callbackQuery">Customer callback that selected crypto payment.</param>
    /// <param name="tenant">Tenant bot that owns the order.</param>
    /// <param name="customer">Customer who owns the order.</param>
    /// <param name="orderDbId">Internal users.db id of the pending renewal order.</param>
    /// <param name="cancellationToken">Cancellation token for database, gateway, and Telegram calls.</param>
    private async Task CreateTenantNowPaymentsInvoiceForExistingOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        int orderDbId,
        CancellationToken cancellationToken)
    {
        if (!_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) ||
            tenant?.TenantNowPaymentsEnabled != true)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "درگاه ارز دیجیتال برای این فروشگاه در حال حاضر غیرفعال است.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش تمدید پیدا نشد، قبلاً پردازش شده یا نوع سرویس اکانت با سفارش سازگار نیست. دوباره از منوی تمدید اقدام کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        order.PaymentProvider = "NowPayments";
        order.UpdatedAtUtc = DateTime.UtcNow;
        var payment = SwapinoPaymentInfo.CreateCryptoCharge(
            customer.TelegramUserId,
            order.SalePriceToman,
            _appConfig.NowpaymentIpnUrl,
            chatId,
            _appConfig.NowpaymentPayCurrency);
        payment.OrderId = order.OrderId;
        payment.SuccessUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_success");
        payment.CancelUrl = _botRegistry.GetById(tenant.Id).BuildTelegramStartUrl("payment_cancel");
        payment.BotId = tenant.Id;
        payment.BotUsername = tenant.Username;
        payment.PaymentPurpose = TenantBotPaymentPurposes.TenantOrder;
        payment.TenantBotOrderId = order.Id;
        payment.TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId;
        _workflow.Add(payment);
        await _workflow.SaveAsync(cancellationToken);

        try
        {
            var invoice = await _nowPayments.CreateInvoiceAsync(
                order.SalePriceToman,
                order.OrderId,
                $"tenant renewal order {order.OrderId}",
                successUrl: payment.SuccessUrl,
                cancelUrl: payment.CancelUrl,
                cancellationToken: cancellationToken);
            var data = NowPaymentsPaymentRecordData.FromInvoiceResponse(invoice);
            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.SetNowPaymentsData(data);
            order.NowPaymentsPaymentInfoId = payment.Id;
            order.PaymentUrl = payment.InvoiceUrl;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await botClient.SendMessage(
                chatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "ارز دیجیتال"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment.InvoiceUrl),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور پرداخت ساخته شد.", cancellationToken: cancellationToken);
        }
        catch (NowPaymentsRateUnavailableException ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "??? ??????? ??? ??????? ?????? ???? ????? ???? ? ??? ??????? ????? ???. ????? ??? ????? ???? ?????? ???? ????.",
                showAlert: true,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = ex.Message;
            payment.ErrorMessage = ex.Message;
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "ساخت فاکتور ناموفق بود.", showAlert: true, cancellationToken: cancellationToken);
        }
    }

    private async Task CreateTenantAtlasPayInvoiceAsync(ITelegramBotClient botClient, CallbackQuery callbackQuery,
        BotInstance tenant, CredUser customer, XuiV3PurchaseSelection selection, CancellationToken cancellationToken)
    {
        var price = CalculateTenantPrice(tenant, selection);
        if (!IsTenantAtlasPayAvailable(tenant))
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, BuildTenantAtlasPayUnavailableMessage(tenant),
                showAlert: true, cancellationToken: cancellationToken); return;
        }
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var order = CreateTenantOrder(tenant, customer, chatId, selection, price, "atlaspay");
        _workflow.Add(order); await _workflow.SaveAsync(cancellationToken);
        await CreateTenantAtlasPayInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    private async Task CreateTenantAtlasPayInvoiceForExistingOrderAsync(ITelegramBotClient botClient, CallbackQuery callbackQuery,
        BotInstance tenant, CredUser customer, int orderDbId, CancellationToken cancellationToken)
    {
        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        { await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش تمدید پیدا نشد یا قبلاً پردازش شده است.", showAlert: true, cancellationToken: cancellationToken); return; }
        if (!IsTenantAtlasPayAvailable(tenant))
        { await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, BuildTenantAtlasPayUnavailableMessage(tenant), showAlert: true, cancellationToken: cancellationToken); return; }
        order.PaymentProvider = "atlaspay"; order.UpdatedAtUtc = DateTime.UtcNow; await _workflow.SaveAsync(cancellationToken);
        await CreateTenantAtlasPayInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    private async Task CreateTenantAtlasPayInvoiceCoreAsync(ITelegramBotClient botClient, CallbackQuery callbackQuery,
        BotInstance tenant, CredUser customer, TenantBotOrder order, CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        if (!IsTenantAtlasPayAvailable(tenant))
        { await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, BuildTenantAtlasPayUnavailableMessage(tenant), showAlert: true, cancellationToken: cancellationToken); return; }
        AtlasPayPaymentInfo payment; string existingLink = null; bool mutationBlocked = false;
        using var gate = await TenantAtlasPayInvoiceCreationGate.EnterAsync(order.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            payment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.FirstOrDefaultAsync(x => x.TenantBotOrderId == order.Id, cancellationToken));
            if (payment != null)
            {
                order.AtlasPayPaymentInfoId = payment.Id; order.UpdatedAtUtc = DateTime.UtcNow;
                if (!string.IsNullOrWhiteSpace(payment.CustomerStartLink)) { order.PaymentUrl = payment.CustomerStartLink; existingLink = payment.CustomerStartLink; }
                else mutationBlocked = true;
                await _workflow.SaveAsync(cancellationToken);
            }
            else
            {
                payment = new AtlasPayPaymentInfo
                {
                    MerchantOrderRef = AtlasPayPaymentInfo.CreateMerchantOrderRef(), BaseAmountToman = order.SalePriceToman,
                    TelegramUserId = customer.TelegramUserId, ChatId = chatId, BotId = tenant.Id, BotUsername = tenant.Username,
                    PaymentPurpose = TenantBotPaymentPurposes.TenantOrder, TenantBotOrderId = order.Id,
                    TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId, CreationState = AtlasPayCreationStates.Attempting,
                    SettlementState = AtlasPaySettlementStates.Pending, CreatedAtUtc = DateTime.UtcNow, UpdatedAtUtc = DateTime.UtcNow
                };
                payment.BeginCreationAttempt(payment.CreatedAtUtc); _workflow.Add(payment); await _workflow.SaveAsync(cancellationToken);
                order.AtlasPayPaymentInfoId = payment.Id; order.PaymentProvider = "atlaspay"; order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
            }
        }
        finally { gate.Dispose(); }
        if (!string.IsNullOrWhiteSpace(existingLink))
        {
            await botClient.SendMessage(chatId, BuildTenantAtlasPayPaymentText(order, payment), parseMode: ParseMode.Html,
                replyMarkup: BuildTenantAtlasPayPaymentKeyboard(payment), cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور قبلی اطلس‌پی دوباره نمایش داده شد.", cancellationToken: cancellationToken); return;
        }
        if (mutationBlocked)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id,
                payment.CreationState == AtlasPayCreationStates.Failed ? "ساخت فاکتور قبلی اطلس‌پی ناموفق بود و درخواست تکراری ارسال نشد."
                : "نتیجه ساخت فاکتور قبلی اطلس‌پی نامشخص است؛ درخواست ساخت دوباره ارسال نشد.", showAlert: true, cancellationToken: cancellationToken); return;
        }
        try
        {
            var created = await _atlasPay.CreateOrderAsync(payment.MerchantOrderRef, payment.BaseAmountToman, payment.TelegramUserId, cancellationToken);
            payment.ApplyCreate(created, DateTime.UtcNow, DateTime.UtcNow.AddSeconds(Math.Clamp(_appConfig.AtlasPayReconciliationIntervalSeconds, 10, 3600)));
            order.AtlasPayPaymentInfoId = payment.Id; order.PaymentUrl = payment.CustomerStartLink; order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await botClient.SendMessage(chatId, BuildTenantAtlasPayPaymentText(order, payment), parseMode: ParseMode.Html,
                replyMarkup: BuildTenantAtlasPayPaymentKeyboard(payment), cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور اطلس‌پی ساخته شد.", cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            var definitive = AtlasPay.IsDefinitiveCreateFailure(ex);
            var code = ex is AtlasPayApiException api && api.StatusCode > 0 ? api.StatusCode.ToString(CultureInfo.InvariantCulture) : "ambiguous";
            payment.RecordCreationFailure(definitive, code, DateTime.UtcNow); payment.ErrorCode = code;
            payment.ErrorMessage = definitive ? "AtlasPay rejected order creation." : "AtlasPay create outcome is ambiguous; no automatic retry.";
            order.PaymentStatus = definitive ? TenantBotOrderStatuses.Failed : TenantBotOrderStatuses.Pending;
            order.ErrorMessage = definitive ? "AtlasPay invoice creation failed." : "AtlasPay invoice creation outcome is ambiguous.";
            order.UpdatedAtUtc = DateTime.UtcNow; await _workflow.SaveAsync(cancellationToken);
            _logger.LogWarning("AtlasPay tenant create ended without usable invoice. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}, definitive={Definitive}, errorType={ErrorType}",
                tenant.Id, order.OrderId, payment.Id, definitive, ex.GetType().Name);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id,
                definitive ? "ساخت فاکتور اطلس‌پی ناموفق بود." : "نتیجه ساخت فاکتور اطلس‌پی نامشخص است؛ برای جلوگیری از فاکتور تکراری درخواست دوباره ارسال نمی‌شود.",
                showAlert: true, cancellationToken: cancellationToken);
        }
    }

    internal static string BuildTenantAtlasPayPaymentText(TenantBotOrder order, AtlasPayPaymentInfo payment)
    {
        var deadline = payment.PaymentDeadlineAtUtc?.ToString("yyyy-MM-dd HH:mm 'UTC'", CultureInfo.InvariantCulture) ?? "نامشخص";
        return "⚠️ <b>پیش از پرداخت لطفاً موارد زیر را بررسی کنید:</b>\n\n" +
               $"💰 مبلغ دقیق قابل پرداخت: <code>{Html(payment.TotalAmountToman!.Value.FormatCurrency())}</code>\n" +
               $"⏱ مهلت پرداخت: <code>{Html(deadline)}</code>\n" +
               $"🔖 شماره پیگیری: <code>{Html(payment.TrackingCode)}</code>\n\n" +
               "مبلغ را دقیقاً مطابق عدد بالا پرداخت کنید. پس از پرداخت، وضعیت فقط با استعلام رسمی اطلس‌پی تایید می‌شود.";
    }

    /// <summary>
    /// Creates a UniquePay invoice for a new tenant storefront purchase.
    /// </summary>
    /// <param name="botClient">Tenant storefront client used for customer-facing invoice delivery.</param>
    /// <param name="callbackQuery">Customer callback that selected UniquePay for a prepared plan.</param>
    /// <param name="tenant">Tenant bot owning pricing, local gateway preference, and owner profit.</param>
    /// <param name="customer">Shared credentials profile of the tenant customer.</param>
    /// <param name="selection">Selected XUI service, traffic, duration, or unlimited plan.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, provider, and Telegram operations.</param>
    /// <remarks>
    /// The global/live and tenant switches are checked before order creation. The local order and UniquePay row are
    /// persisted before the one non-retried create call so an ambiguous response is auditable and cannot be duplicated
    /// by a stale callback.
    /// </remarks>
    private async Task CreateTenantUniquePayInvoiceAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        XuiV3PurchaseSelection selection,
        CancellationToken cancellationToken)
    {
        var price = CalculateTenantPrice(tenant, selection);
        if (!IsTenantUniquePayAvailable(tenant, price.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantUniquePayUnavailableMessage(tenant, price.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        var order = CreateTenantOrder(tenant, customer, chatId, selection, price, "UniquePay");
        _workflow.Add(order);
        await _workflow.SaveAsync(cancellationToken);
        await CreateTenantUniquePayInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    /// <summary>
    /// Reuses an existing pending tenant renewal order while creating its UniquePay invoice.
    /// </summary>
    /// <param name="botClient">Tenant storefront client used for invoice delivery.</param>
    /// <param name="callbackQuery">Customer callback that selected UniquePay for renewal.</param>
    /// <param name="tenant">Tenant storefront owning the order.</param>
    /// <param name="customer">Customer whose XUI account is being renewed.</param>
    /// <param name="orderDbId">Internal users.db id of the pending renewal order.</param>
    /// <param name="cancellationToken">Cancellation token for database, provider, and Telegram work.</param>
    /// <remarks>
    /// The existing order is reloaded and the global/local availability guard is evaluated before any payment row or
    /// provider call. A fulfilled order or stale callback cannot create a new invoice.
    /// </remarks>
    private async Task CreateTenantUniquePayInvoiceForExistingOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        int orderDbId,
        CancellationToken cancellationToken)
    {
        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "سفارش تمدید پیدا نشد، قبلاً پردازش شده یا نوع سرویس اکانت با سفارش سازگار نیست. دوباره از منوی تمدید اقدام کنید.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        if (!IsTenantUniquePayAvailable(tenant, order.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantUniquePayUnavailableMessage(tenant, order.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        order.PaymentProvider = "UniquePay";
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);
        await CreateTenantUniquePayInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    /// <summary>
    /// Persists and creates the UniquePay invoice shared by tenant purchases and renewals.
    /// </summary>
    /// <param name="botClient">Tenant bot client used for customer-facing payment text and buttons.</param>
    /// <param name="callbackQuery">Callback acknowledged after invoice creation or safe failure.</param>
    /// <param name="tenant">Tenant bot attribution and local gateway preference.</param>
    /// <param name="customer">Tenant customer receiving the payment link.</param>
    /// <param name="order">Tracked purchase/renewal order whose sale amount is the financial source of truth.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, UniquePay, and Telegram work.</param>
    /// <remarks>
    /// Creation uses the bot-compatible endpoint and is not retried. The local payment row, one-attempt reservation,
    /// and <see cref="TenantBotOrder.UniquePayPaymentInfoId"/> relationship are saved before provider network I/O. A
    /// known prior link is reused; an ambiguous prior attempt is blocked for GET-only review rather than issuing a
    /// second provider invoice. The invoice-specific callback is only an authoritative-inquiry trigger. Bounded
    /// recovery polling verifies either the provider's
    /// <c>user</c>/<c>buyer</c>-paid or owner-paid amount contract when notification delivery is lost.
    /// </remarks>
    /// <returns>A task completing after the invoice is durably reserved and its known link or safe failure is presented.</returns>
    private async Task CreateTenantUniquePayInvoiceCoreAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        if (!IsTenantUniquePayAvailable(tenant, order.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantUniquePayUnavailableMessage(tenant, order.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        UniquePayPaymentInfo payment;
        string existingPaymentLink = null;
        string blockedCreationState = null;
        var existingMutationBlocked = false;

        using var tenantUniquePayInvoiceCreationGateLease = await TenantUniquePayInvoiceCreationGate.EnterAsync(order.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            payment = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.FirstOrDefaultAsync(
                x => x.TenantBotOrderId == order.Id || x.HashId == order.OrderId,
                cancellationToken));
            if (payment != null)
            {
                order.UniquePayPaymentInfoId = payment.Id;
                order.UpdatedAtUtc = DateTime.UtcNow;
                if (!string.IsNullOrWhiteSpace(payment.PaymentLink))
                {
                    order.PaymentUrl = payment.PaymentLink;
                    existingPaymentLink = payment.PaymentLink;
                }
                else
                {
                    // Every existing row represents the one reserved POST. Missing link never authorizes replay,
                    // regardless of whether the durable result is ambiguous, failed, or awaiting manual review.
                    blockedCreationState = payment.CreationState;
                    existingMutationBlocked = true;
                }
                await _workflow.SaveAsync(cancellationToken);
            }
            else
            {
                payment = new UniquePayPaymentInfo
                {
                    HashId = UniquePayPaymentInfo.CreateHashId(customer.TelegramUserId),
                    BaseAmountToman = order.SalePriceToman,
                    FeePercent = _appConfig.UniquePayFeePercent,
                    TelegramUserId = customer.TelegramUserId,
                    ChatId = chatId,
                    BotId = tenant.Id,
                    BotUsername = tenant.Username,
                    PaymentPurpose = TenantBotPaymentPurposes.TenantOrder,
                    TenantBotOrderId = order.Id,
                    TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId,
                    PaymentStatus = UniquePayStatuses.Pending,
                    NextInquiryAtUtc = DateTime.UtcNow,
                    CreatedAtUtc = DateTime.UtcNow
                };
                payment.BeginCreationAttempt(payment.CreatedAtUtc);
                payment.RawRequestJson = JsonConvert.SerializeObject(new
                {
                    hashId = payment.HashId,
                    orderId = payment.HashId,
                    amount = payment.BaseAmountToman,
                    redirectUrl = BuildUniquePayReturnUrl(payment.HashId),
                    callbackUrl = BuildUniquePayCallbackUrl(payment.HashId)
                });
                _workflow.Add(payment);
                await _workflow.SaveAsync(cancellationToken);

                // The tenant-order relationship must survive even when the one create POST times out or returns 5xx.
                order.UniquePayPaymentInfoId = payment.Id;
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
            }
        }
        finally
        {
            tenantUniquePayInvoiceCreationGateLease.Dispose();
        }

        if (!string.IsNullOrWhiteSpace(existingPaymentLink))
        {
            await botClient.SendMessage(
                chatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "یونیک‌پی | کارمزد ۱۲٪"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, existingPaymentLink),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "فاکتور قبلی یونیک‌پی دوباره نمایش داده شد.",
                cancellationToken: cancellationToken);
            return;
        }

        if (existingMutationBlocked)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                string.Equals(blockedCreationState, UniquePayCreationStates.Failed, StringComparison.Ordinal) ||
                string.Equals(blockedCreationState, UniquePayCreationStates.ManualReview, StringComparison.Ordinal)
                    ? "ساخت فاکتور قبلی ناموفق یا نیازمند بررسی دستی است؛ درخواست تکراری ارسال نشد."
                    : "ساخت فاکتور قبلی نامشخص است؛ فقط استعلام امن انجام می‌شود و درخواست تکراری ارسال نشد.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        try
        {
            var invoice = await _uniquePay.CreateInvoiceAsync(
                payment.HashId,
                payment.BaseAmountToman,
                BuildUniquePayReturnUrl(payment.HashId),
                BuildUniquePayCallbackUrl(payment.HashId),
                cancellationToken);
            payment.Apply(invoice);
            payment.NextInquiryAtUtc = DateTime.UtcNow.AddSeconds(Math.Clamp(
                _appConfig.UniquePayReconciliationIntervalSeconds,
                10,
                3600));
            order.UniquePayPaymentInfoId = payment.Id;
            order.PaymentUrl = payment.PaymentLink;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await botClient.SendMessage(
                chatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "یونیک‌پی | کارمزد ۱۲٪"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment.PaymentLink),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور یونیک‌پی ساخته شد.", cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            var definitiveFailure = UniquePay.IsDefinitiveCreateFailure(ex);
            var creationErrorCode = ex is UniquePayApiException apiException
                ? apiException.StatusCode.ToString(CultureInfo.InvariantCulture)
                : "create_failed";
            payment.RecordCreationFailure(
                definitiveFailure,
                creationErrorCode,
                DateTime.UtcNow);
            order.PaymentStatus = definitiveFailure
                ? TenantBotOrderStatuses.Failed
                : TenantBotOrderStatuses.Pending;
            order.ErrorMessage = ex.Message;
            payment.ErrorCode = creationErrorCode;
            payment.ErrorMessage = ex.Message;
            payment.RawResponseJson = ex is UniquePayApiException providerError
                ? providerError.ResponseBody
                : payment.RawResponseJson;
            payment.PaymentStatus = definitiveFailure ? UniquePayStatuses.Failed : UniquePayStatuses.Pending;
            payment.NextInquiryAtUtc = definitiveFailure
                ? null
                : DateTime.UtcNow.AddSeconds(Math.Clamp(
                    _appConfig.UniquePayReconciliationIntervalSeconds,
                    10,
                    3600));
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogError(
                ex,
                "UniquePay tenant invoice creation failed. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}, amountToman={AmountToman}, providerCode={ProviderCode}",
                tenant.Id,
                order.OrderId,
                payment.Id,
                order.SalePriceToman,
                payment.ErrorCode);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                definitiveFailure
                    ? "ساخت فاکتور یونیک‌پی ناموفق بود."
                    : "نتیجه ساخت فاکتور نامشخص است؛ وضعیت به‌صورت خودکار و بدون ارسال درخواست ساخت دوباره بررسی می‌شود.",
                showAlert: true,
                cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Builds the UniquePay return trigger URL while preserving configured query parameters.
    /// </summary>
    /// <param name="hashId">Merchant hash used only to locate the saved row before official inquiry.</param>
    /// <returns>Absolute configured return endpoint with the escaped hash query.</returns>
    private string BuildUniquePayReturnUrl(string hashId)
    {
        var builder = new UriBuilder(_appConfig.UniquePayReturnUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query)
            ? string.Empty
            : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "hashId=" + Uri.EscapeDataString(hashId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Builds the invoice-specific UniquePay provider-notification URL for a tenant purchase or renewal.
    /// </summary>
    /// <param name="hashId">
    /// Persisted merchant hash belonging to the tenant order's UniquePay row. It is a lookup hint and never payment
    /// proof, so it is safe to include in the callback query string but must not authorize fulfillment.
    /// </param>
    /// <returns>Absolute configured callback endpoint with the escaped merchant hash appended.</returns>
    /// <remarks>
    /// All tenant bots share the platform endpoint while the hash resolves the tenant-owned order. The callback is
    /// unsigned; fulfillment still requires an authoritative UniquePay inquiry and the existing tenant idempotency
    /// boundary.
    /// </remarks>
    /// <example>
    /// A configured <c>https://merchant.example/uniquepay-callback</c> becomes
    /// <c>https://merchant.example/uniquepay-callback?hashId=merchant-hash</c>.
    /// </example>
    private string BuildUniquePayCallbackUrl(string hashId)
    {
        var builder = new UriBuilder(_appConfig.UniquePayCallbackUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query)
            ? string.Empty
            : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "hashId=" + Uri.EscapeDataString(hashId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Creates a Tetraminator invoice for an existing, unfulfilled tenant renewal order.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send the renewal invoice.</param>
    /// <param name="callbackQuery">Customer callback selecting Tetraminator for the renewal.</param>
    /// <param name="tenant">Tenant storefront that owns the pending renewal order.</param>
    /// <param name="customer">Customer who owns the target XUI account and order.</param>
    /// <param name="orderDbId">Internal users.db id of the pending renewal order.</param>
    /// <param name="cancellationToken">Cancellation token for database, provider, and Telegram calls.</param>
    /// <remarks>
    /// The existing renewal order is reused. A second invoice is not created after the order has been fulfilled.
    /// </remarks>
    private async Task CreateTenantTetraminatorInvoiceForExistingOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        int orderDbId,
        CancellationToken cancellationToken)
    {
        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش تمدید پیدا نشد، قبلاً پردازش شده یا نوع سرویس اکانت با سفارش سازگار نیست. دوباره از منوی تمدید اقدام کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }
        if (!IsTenantTetraminatorAvailable(tenant, order.SalePriceToman))
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                BuildTenantTetraminatorUnavailableMessage(order.SalePriceToman),
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        order.PaymentProvider = "Tetraminator";
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);
        await CreateTenantTetraminatorInvoiceCoreAsync(botClient, callbackQuery, tenant, customer, order, cancellationToken);
    }

    /// <summary>
    /// Persists and creates the provider invoice shared by tenant purchases and renewals.
    /// </summary>
    /// <param name="botClient">Tenant bot client used for customer-facing invoice messages.</param>
    /// <param name="callbackQuery">Customer callback acknowledged after invoice creation or failure.</param>
    /// <param name="tenant">Tenant storefront recorded for bot and owner attribution.</param>
    /// <param name="customer">Tenant customer recorded on the payment row.</param>
    /// <param name="order">Tracked tenant purchase or renewal order; its sale amount is the settlement source of truth.</param>
    /// <param name="cancellationToken">Cancellation token for users.db, Tetraminator, and Telegram work.</param>
    /// <remarks>
    /// The API key is never persisted. Callback data is untrusted and settlement later re-inquires the saved
    /// <c>PayId</c>. A provider-create timeout is deliberately not retried to avoid duplicate invoices. Repeated
    /// callbacks reuse the persisted invoice when its link is known; an ambiguous prior create remains blocked for
    /// manual review instead of sending another provider mutation.
    /// </remarks>
    /// <returns>A task completing after the order's invoice attempt and customer response; uncertain attempts stay reserved.</returns>
    private async Task CreateTenantTetraminatorInvoiceCoreAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        TetraminatorPaymentInfo payment;
        string existingPaymentLink = null;
        var hasAmbiguousExistingPayment = false;

        using var tenantTetraminatorInvoiceCreationGateLease = await TenantTetraminatorInvoiceCreationGate.EnterAsync(order.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            payment = await _workflow.ReadAsync(async db => await db.TetraminatorPaymentInfos.FirstOrDefaultAsync(
                x => x.OrderId == order.OrderId || x.TenantBotOrderId == order.Id,
                cancellationToken));
            if (payment != null)
            {
                if (!string.IsNullOrWhiteSpace(payment.PayId) && !string.IsNullOrWhiteSpace(payment.PaymentLink))
                {
                    order.TetraminatorPaymentInfoId = payment.Id;
                    order.PaymentUrl = payment.PaymentLink;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(cancellationToken);
                    existingPaymentLink = payment.PaymentLink;
                }
                else
                {
                    // A create timeout may still have produced an invoice at the provider. Retrying the POST here
                    // could charge the customer against two unrelated pay ids, so the order remains blocked.
                    hasAmbiguousExistingPayment = true;
                }
            }
            else
            {
                payment = new TetraminatorPaymentInfo
                {
                    OrderId = order.OrderId,
                    AmountToman = order.SalePriceToman,
                    CallbackUrl = BuildTenantTetraminatorCallbackUrl(order.OrderId),
                    TelegramUserId = customer.TelegramUserId,
                    ChatId = chatId,
                    BotId = tenant.Id,
                    BotUsername = tenant.Username,
                    PaymentPurpose = TenantBotPaymentPurposes.TenantOrder,
                    TenantBotOrderId = order.Id,
                    TenantOwnerTelegramUserId = tenant.OwnerTelegramUserId,
                    PaymentStatus = TetraminatorStatuses.Pending,
                    CreatedAtUtc = DateTime.UtcNow
                };
                payment.RawRequestJson = JsonConvert.SerializeObject(new
                {
                    price = payment.AmountToman,
                    callback_url = payment.CallbackUrl,
                    order_id = payment.OrderId
                });
                _workflow.Add(payment);
                await _workflow.SaveAsync(cancellationToken);
            }
        }
        finally
        {
            tenantTetraminatorInvoiceCreationGateLease.Dispose();
        }

        if (!string.IsNullOrWhiteSpace(existingPaymentLink))
        {
            await botClient.SendMessage(
                chatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "تترامیناتور"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, existingPaymentLink),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "فاکتور قبلی تترامیناتور دوباره نمایش داده شد.",
                cancellationToken: cancellationToken);
            return;
        }
        if (hasAmbiguousExistingPayment)
        {
            await SafeAnswerCallbackQueryAsync(
                botClient,
                callbackQuery.Id,
                "وضعیت ساخت فاکتور قبلی نامشخص است. برای جلوگیری از ساخت فاکتور تکراری با پشتیبانی تماس بگیرید.",
                showAlert: true,
                cancellationToken: cancellationToken);
            return;
        }

        try
        {
            var invoice = await _tetraminator.CreateInvoiceAsync(payment.AmountToman, payment.CallbackUrl, cancellationToken);
            payment.RawResponseJson = JsonConvert.SerializeObject(invoice);
            payment.Apply(invoice);
            order.TetraminatorPaymentInfoId = payment.Id;
            order.PaymentUrl = payment.PaymentLink;
            order.PaymentStatus = TenantBotOrderStatuses.Pending;
            order.ErrorMessage = null;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            await botClient.SendMessage(
                chatId,
                BUILDTENANTGATEWAYPAYMENTTEXT(order, "تترامیناتور"),
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, payment.PaymentLink),
                cancellationToken: cancellationToken);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "فاکتور تترامیناتور ساخته شد.", cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = "Tetraminator invoice creation failed.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            payment.ErrorCode = ex is TetraminatorApiException apiException
                ? apiException.StatusCode.ToString(CultureInfo.InvariantCulture)
                : "create_failed";
            payment.ErrorMessage = ex.Message;
            payment.RawResponseJson = ex is TetraminatorApiException providerError ? providerError.ResponseBody : null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogError(
                ex,
                "Tenant Tetraminator invoice creation failed. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}, amountToman={AmountToman}",
                tenant.Id,
                order.OrderId,
                payment.Id,
                payment.AmountToman);
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "ساخت فاکتور تترامیناتور ناموفق بود. کمی بعد دوباره تلاش کنید.", showAlert: true, cancellationToken: cancellationToken);
        }
    }

    /// <summary>
    /// Activates card-to-card payment for an existing tenant renewal order.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to send card instructions.</param>
    /// <param name="callbackQuery">Customer callback that selected tenant card payment.</param>
    /// <param name="tenant">Tenant bot containing card number and holder name.</param>
    /// <param name="customer">Customer who owns the order.</param>
    /// <param name="orderDbId">Internal users.db id of the pending renewal order.</param>
    /// <param name="cancellationToken">Cancellation token for users.db and Telegram operations.</param>
    private async Task ActivateTenantCardPaymentForExistingOrderAsync(
        ITelegramBotClient botClient,
        CallbackQuery callbackQuery,
        BotInstance tenant,
        CredUser customer,
        int orderDbId,
        CancellationToken cancellationToken)
    {
        var order = await GetPendingTenantRenewOrderAsync(orderDbId, tenant, customer, cancellationToken);
        if (order == null)
        {
            await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش تمدید پیدا نشد، قبلاً پردازش شده یا نوع سرویس اکانت با سفارش سازگار نیست. دوباره از منوی تمدید اقدام کنید.", showAlert: true, cancellationToken: cancellationToken);
            return;
        }

        order.PaymentProvider = "tenant_card";
        order.PaymentStatus = TenantBotOrderStatuses.AwaitingReceipt;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);

        var chatId = callbackQuery.Message?.Chat.Id ?? callbackQuery.From.Id;
        await botClient.SendMessage(
            chatId,
            "💳 <b>پرداخت کارت‌به‌کارت تمدید</b>\n\n" +
            $"مبلغ دقیق: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
            $"شماره کارت: <code>{Html(tenant.TenantCardNumber)}</code>\n" +
            $"نام صاحب کارت: <b>{Html(tenant.TenantCardHolderName)}</b>\n" +
            $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n\n" +
            "بعد از پرداخت، عکس رسید را همینجا ارسال کنید تا همکار آن را تایید کند.",
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantCardPaymentKeyboard(order),
            cancellationToken: cancellationToken);
        await SafeAnswerCallbackQueryAsync(botClient, callbackQuery.Id, "سفارش کارت‌به‌کارت ثبت شد.", cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Loads a pending tenant renewal order and revalidates its plan and price before payment activation.
    /// </summary>
    /// <param name="orderDbId">Internal users.db order id from callback data.</param>
    /// <param name="tenant">Current tenant bot.</param>
    /// <param name="customer">Current tenant customer.</param>
    /// <param name="cancellationToken">Cancellation token for the database lookup.</param>
    /// <returns>
    /// The tracked pending renewal order when ownership, status, exact target identity, metadata-derived service category,
    /// current plan eligibility, and current tenant sale price all match; otherwise <c>null</c>. A null result must not be
    /// used to create a payment record or provider invoice.
    /// </returns>
    /// <remarks>
    /// This guard prevents a stored <c>days-N</c> order from becoming payable after custom durations are disabled or
    /// narrowed, and also rejects price/markup changes between summary and provider selection. It performs read-only
    /// validation and does not mutate the order, wallet, ledger, payment provider, or XUI account. It performs read-only
    /// list/detail XUI calls so a previously misclassified or later-changed account cannot be funded under another service.
    /// A null evidence mode on a historical order is accepted only when live metadata or a deterministic legacy rule
    /// proves the stored service. Ambiguous historical orders cannot create a payment/provider row and must be recreated.
    /// </remarks>
    private async Task<TenantBotOrder> GetPendingTenantRenewOrderAsync(
        int orderDbId,
        BotInstance tenant,
        CredUser customer,
        CancellationToken cancellationToken)
    {
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == orderDbId &&
                 x.TenantBotId == tenant.Id &&
                 x.CustomerTelegramUserId == customer.TelegramUserId &&
                 x.OrderKind == TenantBotOrderKinds.Renew &&
                  !x.IsFulfilled &&
                  (x.PaymentStatus == TenantBotOrderStatuses.Pending || x.PaymentStatus == TenantBotOrderStatuses.Failed),
            cancellationToken));
        if (order == null)
            return null;

        XuiV3Client client;
        try
        {
            var serverInfo = BuildConfiguredPanelServerInfo();
            var hasExactTargetLock = !string.IsNullOrWhiteSpace(order.TargetAccountUuid);
            client = hasExactTargetLock
                ? await FINDTENANTRENEWTARGETBYLOCKASYNC(
                    serverInfo,
                    order.TargetAccountEmail,
                    order.TargetAccountUuid,
                    cancellationToken)
                : await FindTenantClientAsync(serverInfo, order.TargetAccountEmail, cancellationToken);
            if (client == null ||
                (!hasExactTargetLock &&
                 !ClientBelongsToTenantCustomer(client, customer.TelegramUserId, tenant.Id)))
            {
                return null;
            }

            var serviceResolution = await ResolveTenantRenewalServiceAsync(serverInfo, client, cancellationToken);
            var serviceAuthorized = TryAuthorizeTenantRenewalService(
                serviceResolution,
                order.ServiceKey,
                order.RenewalServiceResolutionMode,
                out var liveService,
                out var effectiveResolutionMode,
                out _);
            if (!serviceAuthorized ||
                !string.Equals(liveService.Key, order.ServiceKey, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning(
                    "Tenant renewal payment activation rejected by live account service. orderId={OrderId}, storedServiceKey={StoredServiceKey}, resolutionStatus={ResolutionStatus}, liveServiceKey={LiveServiceKey}",
                    order.OrderId,
                    order.ServiceKey,
                    serviceResolution.Status,
                    liveService?.Key ?? serviceResolution.Service?.Key ?? "none");
                return null;
            }

            // Persist stronger current evidence before any provider row/request. A historical null is accepted only
            // when live metadata or a deterministic legacy rule proves the category; ambiguity never implies consent.
            if (!string.Equals(
                    order.RenewalServiceResolutionMode,
                    effectiveResolutionMode,
                    StringComparison.Ordinal))
            {
                order.RenewalServiceResolutionMode = effectiveResolutionMode;
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "Tenant renewal payment activation target revalidation failed. orderId={OrderId}, errorType={ErrorType}",
                order.OrderId,
                ex.GetType().Name);
            return null;
        }

        try
        {
            var selection = new XuiV3PurchaseSelection
            {
                ServiceKey = order.ServiceKey,
                TrafficGb = order.TrafficGb,
                DurationKey = order.DurationKey,
                UnlimitedPlanKey = order.UnlimitedPlanKey,
                AccountCount = order.AccountCount
            };
            var currentPrice = CalculateTenantPrice(tenant, selection);
            if (currentPrice.SalePriceToman != order.SalePriceToman ||
                currentPrice.BaseCostToman != order.BaseCostToman)
            {
                _logger.LogWarning(
                    "Tenant renewal payment activation rejected after price change. orderId={OrderId}, storedSalePriceToman={StoredSalePriceToman}, currentSalePriceToman={CurrentSalePriceToman}",
                    order.OrderId,
                    order.SalePriceToman,
                    currentPrice.SalePriceToman);
                return null;
            }

            return order;
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException or OverflowException)
        {
            _logger.LogWarning(
                ex,
                "Tenant renewal payment activation rejected by current plan configuration. orderId={OrderId}, durationKey={DurationKey}",
                order.OrderId,
                order.DurationKey);
            return null;
        }
    }

    /// <summary>
    /// Fulfills a paid HooshPay tenant order through the shared idempotent tenant settlement pipeline.
    /// </summary>
    /// <param name="payment">
    /// The HooshPay users.db payment row associated with a tenant order. The row must carry either the internal
    /// tenant-order id or its public order id; a null value is treated as not found.
    /// </param>
    /// <param name="Source">
    /// The non-secret settlement trigger recorded for auditing, such as <c>ipn</c> or <c>manual-check</c>.
    /// </param>
    /// <param name="CancellationToken">
    /// A token that cancels users.db, XUI, wallet-ledger, and Telegram operations for this settlement attempt.
    /// </param>
    /// <returns>
    /// A settlement result indicating that the order was applied, was already fulfilled, was not found, or could
    /// not be completed. Callers must use the result rather than retrying fulfillment blindly.
    /// </returns>
    /// <remarks>
    /// The shared fulfillment routine is the only implementation used here. It protects account creation and the
    /// tenant owner's toman profit credit from duplicate provider callbacks and records the corresponding ledger row.
    /// A missing payment or order produces no XUI, balance, ledger, or notification side effect.
    /// </remarks>
    /// <example>
    /// <code>
    /// var result = await tenantBotService.ApplyPaidTenantOrderAsync(
    ///     verifiedPayment,
    ///     "ipn",
    ///     cancellationToken);
    /// </code>
    /// </example>
    /// <param name="retryAuthorization">
    /// Optional typed authorization passed by an explicit super-admin confirmation. Null marks automatic or
    /// provider-driven settlement, which can never allocate a new retry generation.
    /// </param>
    public async Task<NowPaymentsSettlementResult> ApplyPaidTenantOrderAsync(
        HooshPayPaymentInfo payment,
        string Source,
        CancellationToken CancellationToken = default,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();

        payment = await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.SingleAsync(x => x.Id == payment.Id, CancellationToken));
        await _workflow.ReloadAsync(payment, CancellationToken);

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == payment.TenantBotOrderId || x.OrderId == payment.OrderId,
            CancellationToken));
        if (order == null)
            return NowPaymentsSettlementResult.NotFound();

        return await FULFILLPAIDTENANTORDERASYNC(order, Source, payment, null, false, CancellationToken, retryAuthorization);
    }

    public async Task<NowPaymentsSettlementResult> ApplyPaidTenantOrderAsync(
        AtlasPayPaymentInfo payment, string Source, CancellationToken CancellationToken = default,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        if (payment == null || !string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.TenantOrder, StringComparison.OrdinalIgnoreCase) ||
            !AtlasPayStatuses.IsSuccess(payment.ProviderStatus) || payment.RequiresManualDelivery || !payment.PaidAtUtc.HasValue)
            return NowPaymentsSettlementResult.ProviderNotPaid();
        payment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.FirstOrDefaultAsync(x => x.Id == payment.Id, CancellationToken));
        if (payment == null) return NowPaymentsSettlementResult.NotFound();
        if (payment.IsAddedToBalance || payment.SettlementState == AtlasPaySettlementStates.Settled)
            return NowPaymentsSettlementResult.AlreadyAdded(payment.BalanceAfter ?? 0);
        if (payment.SettlementState == AtlasPaySettlementStates.ManualReview) return NowPaymentsSettlementResult.ProviderNotPaid();
        if (payment.SettlementState == AtlasPaySettlementStates.Processing)
        {
            if (!payment.SettlementStartedAtUtc.HasValue || DateTime.UtcNow - payment.SettlementStartedAtUtc.Value >= TimeSpan.FromMinutes(30))
            {
                payment.SettlementState = AtlasPaySettlementStates.ManualReview; payment.ErrorCode = "tenant_fulfillment_claim_ambiguous";
                payment.ErrorMessage = "A previous AtlasPay tenant fulfillment claim became stale and requires manual review.";
                payment.NextInquiryAtUtc = null; payment.UpdatedAtUtc = DateTime.UtcNow; await _workflow.SaveAsync(CancellationToken);
            }
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(x => x.Id == payment.TenantBotOrderId, CancellationToken));
        if (order == null)
        {
            payment.SettlementState = AtlasPaySettlementStates.ManualReview; payment.ErrorCode = "tenant_order_not_found";
            payment.ErrorMessage = "The paid AtlasPay row is not linked to a tenant order."; payment.NextInquiryAtUtc = null;
            payment.UpdatedAtUtc = DateTime.UtcNow; await _workflow.SaveAsync(CancellationToken); return NowPaymentsSettlementResult.NotFound();
        }
        if (!string.Equals(order.TenantBotId, payment.BotId, StringComparison.Ordinal) || order.CustomerTelegramUserId != payment.TelegramUserId ||
            order.SalePriceToman != payment.BaseAmountToman || order.AtlasPayPaymentInfoId != payment.Id)
        {
            payment.SettlementState = AtlasPaySettlementStates.ManualReview; payment.ErrorCode = "tenant_payment_link_mismatch";
            payment.ErrorMessage = "AtlasPay tenant payment linkage did not match the saved order."; payment.NextInquiryAtUtc = null;
            payment.UpdatedAtUtc = DateTime.UtcNow; await _workflow.SaveAsync(CancellationToken); return NowPaymentsSettlementResult.ProviderNotPaid();
        }
        var attemptId = Guid.NewGuid().ToString("N"); var now = DateTime.UtcNow;
        var claimed = await _workflow.WriteAsync(async db => await db.AtlasPayPaymentInfos
            .Where(x => x.Id == payment.Id && !x.IsAddedToBalance && x.SettlementState == AtlasPaySettlementStates.Pending)
            .ExecuteUpdateAsync(setters => setters.SetProperty(x => x.SettlementState, AtlasPaySettlementStates.Processing)
                .SetProperty(x => x.SettlementAttemptId, attemptId).SetProperty(x => x.SettlementStartedAtUtc, now)
                .SetProperty(x => x.UpdatedAtUtc, now), CancellationToken));
        if (claimed != 1) return NowPaymentsSettlementResult.ProviderNotPaid();
        NowPaymentsSettlementResult settlement;
        try { settlement = await FULFILLPAIDTENANTORDERASYNC(order, Source, null, null, false, CancellationToken, retryAuthorization); }
        catch (Exception ex)
        {
            payment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.FirstAsync(x => x.Id == payment.Id, CancellationToken));
            payment.SettlementState = AtlasPaySettlementStates.ManualReview; payment.ErrorCode = "tenant_fulfillment_ambiguous";
            payment.ErrorMessage = ex.GetType().Name; payment.NextInquiryAtUtc = null; payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken); return NowPaymentsSettlementResult.ProviderNotPaid();
        }
        payment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.FirstAsync(x => x.Id == payment.Id, CancellationToken));
        if (settlement.Status is NowPaymentsSettlementStatus.Applied or NowPaymentsSettlementStatus.AlreadyAdded)
        {
            payment.IsAddedToBalance = true; payment.SettlementState = AtlasPaySettlementStates.Settled;
            payment.SettlementAttemptId = null; payment.SettlementStartedAtUtc = null; payment.SettledAtUtc ??= order.FulfilledAtUtc ?? DateTime.UtcNow;
            payment.BalanceBefore = settlement.BeforeBalance; payment.BalanceAfter = settlement.AfterBalance; payment.NextInquiryAtUtc = null;
            payment.ErrorCode = null; payment.ErrorMessage = null; payment.SuccessLoggedAtUtc ??= DateTime.UtcNow; payment.UpdatedAtUtc = DateTime.UtcNow;
        }
        else if (settlement.Status is NowPaymentsSettlementStatus.UserNotFound or NowPaymentsSettlementStatus.PaymentNotFound)
        {
            payment.SettlementState = AtlasPaySettlementStates.Pending; payment.SettlementAttemptId = null; payment.SettlementStartedAtUtc = null;
            payment.NextInquiryAtUtc = DateTime.UtcNow.AddSeconds(Math.Clamp(_appConfig.AtlasPayReconciliationIntervalSeconds, 10, 3600));
            payment.ErrorCode = "tenant_fulfillment_prerequisite_failed"; payment.UpdatedAtUtc = DateTime.UtcNow;
        }
        else
        {
            payment.SettlementState = AtlasPaySettlementStates.ManualReview; payment.ErrorCode = "tenant_fulfillment_ambiguous";
            payment.NextInquiryAtUtc = null; payment.UpdatedAtUtc = DateTime.UtcNow;
        }
        await _workflow.SaveAsync(CancellationToken); return settlement;
    }

    /// <summary>
    /// Fulfills a UniquePay tenant order exactly once after a verified provider inquiry.
    /// </summary>
    /// <param name="payment">
    /// Tracked users.db payment whose purpose is <see cref="TenantBotPaymentPurposes.TenantOrder" /> and whose
    /// hash, toman amount, fee-payer contract, gateway fee, reference, and exact <c>paid</c> status were verified against UniquePay.
    /// </param>
    /// <param name="Source">Audit source such as callback, customer check, or super-admin check.</param>
    /// <param name="CancellationToken">Cancellation token for users.db, XUI, wallet ledger, and Telegram operations.</param>
    /// <returns>
    /// Settlement result from the shared tenant fulfillment path. Repeated callbacks return an already-applied
    /// result and never create another account, owner-profit credit, or ledger entry.
    /// </returns>
    /// <remarks>
    /// This method never accepts provisional approval. It only consumes an already provider-verified payment row;
    /// callers handling return, customer-check, or worker triggers must perform
    /// <see cref="UniquePayPaymentVerifier.IsVerifiedPaid" /> immediately before invoking it.
    /// Successful fulfillment records the effective currency, fee payer, stored base amount, and provider-reported
    /// fee once in the protected payment channel; repeated fulfillment checks do not emit another provider-success log.
    /// </remarks>
    /// <param name="retryAuthorization">
    /// Optional typed authorization passed by an explicit super-admin confirmation. Null marks automatic or
    /// provider-driven settlement, which can never allocate a new retry generation.
    /// </param>
    public async Task<NowPaymentsSettlementResult> ApplyPaidTenantOrderAsync(
        UniquePayPaymentInfo payment,
        string Source,
        CancellationToken CancellationToken = default,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        if (payment == null ||
            !string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.TenantOrder, StringComparison.OrdinalIgnoreCase) ||
            !UniquePayStatuses.IsPaid(payment.PaymentStatus) ||
            string.IsNullOrWhiteSpace(payment.HashId) ||
            !payment.PaidAtUtc.HasValue)
        {
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        payment = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.FirstOrDefaultAsync(
            x => x.Id == payment.Id,
            CancellationToken));
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();

        payment = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.SingleAsync(x => x.Id == payment.Id, CancellationToken));
        await _workflow.ReloadAsync(payment, CancellationToken);
        if (payment.IsAddedToBalance ||
            string.Equals(payment.SettlementState, UniquePaySettlementStates.Settled, StringComparison.Ordinal))
        {
            return NowPaymentsSettlementResult.AlreadyAdded(payment.BalanceAfter ?? 0);
        }
        if (await RejectActiveOrAmbiguousUniquePayTenantClaimAsync(payment, CancellationToken))
            return NowPaymentsSettlementResult.ProviderNotPaid();

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == payment.TenantBotOrderId || x.OrderId == payment.HashId,
            CancellationToken));
        if (order == null)
        {
            payment.SettlementState = UniquePaySettlementStates.ManualReview;
            payment.ErrorCode = "tenant_order_not_found";
            payment.ErrorMessage = "The paid UniquePay row is not linked to a tenant order.";
            payment.NextInquiryAtUtc = null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            _logger.LogError(
                "Paid UniquePay tenant row has no order and requires manual review. paymentId={PaymentId}, hashId={HashId}, tenantOrderId={TenantOrderId}",
                payment.Id,
                payment.HashId,
                payment.TenantBotOrderId);
            return NowPaymentsSettlementResult.NotFound();
        }

        var attemptId = Guid.NewGuid().ToString("N");
        var claimedAtUtc = DateTime.UtcNow;
        var claimed = await _workflow.WriteAsync(async db => await db.UniquePayPaymentInfos
            .Where(x => x.Id == payment.Id &&
                        !x.IsAddedToBalance &&
                        (x.SettlementState == null || x.SettlementState == UniquePaySettlementStates.Pending))
            .ExecuteUpdateAsync(
                setters => setters
                    .SetProperty(x => x.SettlementState, UniquePaySettlementStates.Processing)
                    .SetProperty(x => x.SettlementAttemptId, attemptId)
                    .SetProperty(x => x.SettlementStartedAtUtc, claimedAtUtc)
                    .SetProperty(x => x.UpdatedAtUtc, claimedAtUtc),
                CancellationToken));
        if (claimed != 1)
            return NowPaymentsSettlementResult.ProviderNotPaid();

        await _workflow.ReloadAsync(payment, CancellationToken);
        NowPaymentsSettlementResult settlement;
        try
        {
            settlement = await FULFILLPAIDTENANTORDERASYNC(order, Source, null, null, false, CancellationToken, retryAuthorization);
        }
        catch (Exception ex)
        {
            payment.SettlementState = UniquePaySettlementStates.ManualReview;
            payment.ErrorCode = "tenant_fulfillment_ambiguous";
            payment.ErrorMessage = ex.Message;
            payment.NextInquiryAtUtc = null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            _logger.LogError(
                ex,
                "UniquePay tenant fulfillment became ambiguous and stopped for manual review. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}, attemptId={AttemptId}",
                order.TenantBotId,
                order.OrderId,
                payment.Id,
                payment.SettlementAttemptId);
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        if (settlement.Status is NowPaymentsSettlementStatus.Applied or NowPaymentsSettlementStatus.AlreadyAdded)
        {
            var shouldLogProviderSuccess = !payment.SuccessLoggedAtUtc.HasValue;
            payment.IsAddedToBalance = true;
            payment.SettlementState = UniquePaySettlementStates.Settled;
            payment.SettlementAttemptId = null;
            payment.SettlementStartedAtUtc = null;
            payment.SettledAtUtc ??= order.FulfilledAtUtc ?? DateTime.UtcNow;
            payment.BalanceBefore = settlement.BeforeBalance;
            payment.BalanceAfter = settlement.AfterBalance;
            payment.ErrorCode = null;
            payment.ErrorMessage = null;
            payment.SuccessLoggedAtUtc ??= DateTime.UtcNow;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);

            if (shouldLogProviderSuccess)
            {
                _logger.LogPayment(
                    "✅ پرداخت رسمی UniquePay فروشگاه تایید شد\n\n" +
                    $"ربات tenant: <code>{Html(order.TenantBotId)}</code> @{Html(order.TenantBotUsername)}\n" +
                    $"Order ID: <code>{Html(order.OrderId)}</code>\n" +
                    $"Payment ID: <code>UP:{payment.Id}</code>\n" +
                    $"Hash ID: <code>{Html(payment.HashId)}</code>\n" +
                    $"Ref ID: <code>{Html(payment.RefId)}</code>\n" +
                    $"مبلغ پایه: <code>{Html(payment.BaseAmountToman.FormatCurrency())}</code>\n" +
                    $"کارمزد واقعی درگاه: <code>{Html((payment.ProviderFeeToman ?? 0).FormatCurrency())}</code>\n" +
                    $"پرداخت‌کننده کارمزد: <code>{Html(payment.FeePayer)}</code>\n" +
                    $"واحد: <code>{Html(payment.Currency)}</code>\n" +
                    $"منبع: <code>{Html(Source)}</code>");
            }
        }
        else if (settlement.Status is NowPaymentsSettlementStatus.UserNotFound or NowPaymentsSettlementStatus.PaymentNotFound)
        {
            // No XUI or wallet mutation occurs before these precondition failures, so a later retry is safe.
            payment.SettlementState = UniquePaySettlementStates.Pending;
            payment.SettlementAttemptId = null;
            payment.SettlementStartedAtUtc = null;
            payment.NextInquiryAtUtc = DateTime.UtcNow.AddSeconds(Math.Clamp(
                _appConfig.UniquePayReconciliationIntervalSeconds,
                10,
                3600));
            payment.ErrorCode = "tenant_fulfillment_prerequisite_failed";
            payment.ErrorMessage = order.ErrorMessage;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
        }
        else
        {
            // InvalidAmount can be returned after an ambiguous XUI or cross-database owner-wallet operation.
            // Automatic replay would risk duplicate account delivery or profit credit, so require operator review.
            payment.SettlementState = UniquePaySettlementStates.ManualReview;
            payment.ErrorCode = "tenant_fulfillment_ambiguous";
            payment.ErrorMessage = order.ErrorMessage;
            payment.NextInquiryAtUtc = null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            _logger.LogError(
                "UniquePay tenant fulfillment stopped for manual review. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}, attemptId={AttemptId}, settlementStatus={SettlementStatus}",
                order.TenantBotId,
                order.OrderId,
                payment.Id,
                payment.SettlementAttemptId,
                settlement.Status);
        }

        return settlement;
    }

    /// <summary>
    /// Rejects a concurrent UniquePay tenant fulfillment claim and terminally quarantines a stale claim.
    /// </summary>
    /// <param name="payment">Tracked, officially paid tenant UniquePay row.</param>
    /// <param name="cancellationToken">Cancellation token for the users.db transition.</param>
    /// <returns><c>true</c> when automatic fulfillment must stop; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// A stale processing claim may have crossed the XUI or credentials.db side-effect boundary. It is therefore
    /// placed in manual review rather than replayed, preserving fail-closed financial and delivery semantics.
    /// </remarks>
    private async Task<bool> RejectActiveOrAmbiguousUniquePayTenantClaimAsync(
        UniquePayPaymentInfo payment,
        CancellationToken cancellationToken)
    {
        if (string.Equals(payment.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal))
            return true;
        if (!string.Equals(payment.SettlementState, UniquePaySettlementStates.Processing, StringComparison.Ordinal))
            return false;
        if (payment.SettlementStartedAtUtc.HasValue &&
            DateTime.UtcNow - payment.SettlementStartedAtUtc.Value < TimeSpan.FromMinutes(30))
        {
            return true;
        }

        payment.SettlementState = UniquePaySettlementStates.ManualReview;
        payment.ErrorCode = "tenant_fulfillment_claim_ambiguous";
        payment.ErrorMessage = "A previous UniquePay tenant fulfillment claim became stale and requires manual review.";
        payment.NextInquiryAtUtc = null;
        payment.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);
        _logger.LogError(
            "UniquePay stale tenant fulfillment claim stopped for manual review. tenantOrderId={TenantOrderId}, paymentId={PaymentId}, attemptId={AttemptId}",
            payment.TenantBotOrderId,
            payment.Id,
            payment.SettlementAttemptId);
        return true;
    }

    /// <summary>
    /// Fulfills a Tetraminator tenant order exactly once after a verified provider inquiry.
    /// </summary>
    /// <param name="payment">
    /// Tracked users.db payment whose purpose is <see cref="TenantBotPaymentPurposes.TenantOrder" /> and whose
    /// pay id, amount, and exact <c>paid</c> status were verified against Tetraminator.
    /// </param>
    /// <param name="Source">Audit source such as callback, customer check, or super-admin check.</param>
    /// <param name="CancellationToken">Cancellation token for users.db, XUI, wallet ledger, and Telegram operations.</param>
    /// <returns>
    /// Settlement result from the shared tenant fulfillment path. Repeated callbacks return an already-applied
    /// result and never create another account, owner-profit credit, or ledger entry.
    /// </returns>
    /// <remarks>
    /// This method never accepts provisional approval. It only consumes an already provider-verified payment row;
    /// callers handling unsigned callbacks must perform <see cref="TetraminatorPaymentVerifier.IsVerifiedPaid" />
    /// immediately before invoking it.
    /// </remarks>
    /// <param name="retryAuthorization">
    /// Optional typed authorization passed by an explicit super-admin confirmation. Null marks automatic or
    /// provider-driven settlement, which can never allocate a new retry generation.
    /// </param>
    public async Task<NowPaymentsSettlementResult> ApplyPaidTenantOrderAsync(
        TetraminatorPaymentInfo payment,
        string Source,
        CancellationToken CancellationToken = default,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        if (payment == null) return NowPaymentsSettlementResult.NotFound();
        payment = await _workflow.ReadAsync(async db => await db.TetraminatorPaymentInfos.SingleAsync(x => x.Id == payment.Id, CancellationToken));
        await _workflow.ReloadAsync(payment, CancellationToken);
        if (payment == null ||
            !string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.TenantOrder, StringComparison.OrdinalIgnoreCase) ||
            !TetraminatorStatuses.IsPaid(payment.PaymentStatus) ||
            string.IsNullOrWhiteSpace(payment.PayId) ||
            !payment.PaidAtUtc.HasValue ||
            !string.IsNullOrWhiteSpace(payment.ErrorCode))
        {
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == payment.TenantBotOrderId || x.OrderId == payment.OrderId,
            CancellationToken));
        if (order == null)
            return NowPaymentsSettlementResult.NotFound();

        var settlement = await FULFILLPAIDTENANTORDERASYNC(order, Source, null, null, false, CancellationToken, retryAuthorization);
        if (settlement.Status is NowPaymentsSettlementStatus.Applied or NowPaymentsSettlementStatus.AlreadyAdded)
        {
            payment.IsAddedToBalance = true;
            payment.SettledAtUtc ??= order.FulfilledAtUtc ?? DateTime.UtcNow;
            payment.ErrorCode = null;
            payment.ErrorMessage = null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
        }

        return settlement;
    }

    /// <summary>
    /// fulfills A NowPayments tenant order exactly once after the crypto gateway reports A paid invoice.
    /// </summary>
    /// <param name="payment">NowPayments payment row marked as A tenant order.</param>
    /// <param name="Source">settlement Source such as ipn, manual-check, or admin-manual.</param>
    /// <param name="CancellationToken">Cancellation Token for database, wallet, panel, and Telegram operations.</param>
    /// <returns>settlement result INDICATING whether the tenant order was applied or HAD already been fulfilled.</returns>
    /// <remarks>
    /// this method intentionally does not credit the customer wallet. it creates the ORDERED account, credits
    /// the tenant owner profit, Writes the general wallet ledger, and NOTIFIES the sales assistant. Manual
    /// super-admin sources force a fresh NOWPayments provider lookup and return
    /// <see cref="NowPaymentsSettlementStatus.ProviderNotPaid"/> unless the provider reports a paid status.
    /// </remarks>
    /// <param name="retryAuthorization">
    /// Optional typed authorization passed by an explicit super-admin confirmation. Null marks automatic or
    /// provider-driven settlement, which can never allocate a new retry generation.
    /// </param>
    public async Task<NowPaymentsSettlementResult> ApplyPaidTenantOrderAsync(
        SwapinoPaymentInfo payment,
        string Source,
        CancellationToken CancellationToken = default,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();

        payment = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.SingleAsync(x => x.Id == payment.Id, CancellationToken));
        await _workflow.ReloadAsync(payment, CancellationToken);



        var data = payment.GetNowPaymentsData();
        var requiresProviderRefresh = Source?.IndexOf("manual", StringComparison.OrdinalIgnoreCase) >= 0;
        if (requiresProviderRefresh || !NowPaymentsStatuses.IsPaid(data.PaymentStatus ?? payment.PaymentStatus))
        {
            NowPaymentsPaymentStatusResult remoteStatus = null;
            try
            {
                remoteStatus = await REFRESHTENANTNOWPAYMENTSSTATUSASYNC(payment, data, CancellationToken);
            }
            catch (Exception ex)
            {
                payment.ErrorCode = "nowpayments_provider_check_failed";
                payment.ErrorMessage = $"NOWPayments provider check failed before tenant fulfillment. {ex.Message}";
                await _workflow.SaveAsync(CancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }

            if (remoteStatus != null)
            {
                data.Apply(remoteStatus);
                payment.SetNowPaymentsData(data);
                await _workflow.SaveAsync(CancellationToken);
            }

            var providerReportedPaid = remoteStatus != null &&
                                       NowPaymentsStatuses.IsPaid(remoteStatus.payment_status ?? data.PaymentStatus);
            if (!providerReportedPaid && (requiresProviderRefresh || !NowPaymentsStatuses.IsPaid(data.PaymentStatus ?? payment.PaymentStatus)))
                return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == payment.TenantBotOrderId || x.OrderId == payment.OrderId,
            CancellationToken));
        if (order == null)
            return NowPaymentsSettlementResult.NotFound();

        return await FULFILLPAIDTENANTORDERASYNC(order, Source, null, payment, false, CancellationToken, retryAuthorization);
    }

    /// <summary>
    /// Refreshes a tenant NOWPayments row before manual or repeated fulfillment attempts.
    /// </summary>
    /// <param name="payment">
    /// Local users.db NOWPayments row attached to a tenant order. The row may still contain only invoice data when a
    /// super-admin enters an order id before the provider has emitted a paid IPN.
    /// </param>
    /// <param name="data">
    /// Parsed NOWPayments data stored on the local row. The method updates this instance only after a provider
    /// response is returned.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for NOWPayments API calls.</param>
    /// <returns>
    /// Provider payment status when NOWPayments can identify the payment; otherwise <c>null</c>.
    /// </returns>
    /// <remarks>
    /// Tenant fulfillment must never rely on a local manual status flip. This helper mirrors the wallet-charge
    /// manual-check rule: use payment id first, then invoice/order lookup, and fulfill only when the provider status
    /// is accepted by <see cref="NowPaymentsStatuses.IsPaid(string)"/>.
    /// </remarks>
    private async Task<NowPaymentsPaymentStatusResult> REFRESHTENANTNOWPAYMENTSSTATUSASYNC(
        SwapinoPaymentInfo payment,
        NowPaymentsPaymentRecordData data,
        CancellationToken cancellationToken)
    {
        var paymentId = payment.PaymentId ?? data.PaymentId;
        if (!string.IsNullOrWhiteSpace(paymentId))
            return await _nowPayments.GetPaymentStatusAsync(paymentId, cancellationToken);

        return await _nowPayments.FindPaymentStatusByInvoiceOrOrderAsync(
            payment.InvoiceId ?? data.InvoiceId,
            payment.OrderId ?? data.OrderId,
            cancellationToken);
    }

    /// <summary>
    /// Retries fulfillment of one proven-paid, unfulfilled tenant purchase after an operator-reviewed absence.
    /// </summary>
    /// <param name="inboxSequence">
    /// Internal terminal-recovery inbox sequence selected by the operator. The sequence, rather than Telegram text, must link
    /// the original <c>tenant-create:{orderId}</c> operation to the paid tenant order.
    /// </param>
    /// <param name="operatorTelegramUserId">Authenticated positive Telegram id of the global super-admin reviewer.</param>
    /// <param name="reviewReference">
    /// Existing <c>review-N</c> reference stored by the authoritative-absence review for this inbox sequence.
    /// </param>
    /// <param name="cancellationToken">Bounded operator-command token for database, XUI, wallet, and notification work.</param>
    /// <returns>A sanitized operator result that contains no account identity, panel response, token, or payload.</returns>
    /// <remarks>
    /// This recovery accepts purchase orders only and requires durable paid-provider evidence, no fulfillment or tenant
    /// ledger row, and an exact persisted creation link for the order. Attempt selection is delegated to the central
    /// <see cref="TenantProvisioningAttemptCoordinator" />: the reviewed action is carried as a durable
    /// <see cref="TenantProvisioningRetryAuthorizationKind.ReviewedRecovery" /> authorization, so a terminal attempt
    /// advances to the next <c>tenant-create:{orderId}:retry:N</c> generation, while Reserved/PostStarted/Ambiguous/
    /// Applied attempts are reused without any new account or second POST. Replaying the same review reference after it
    /// already granted a generation never allocates another one. No invoice or payment is created here.
    /// </remarks>
    /// <exception cref="ArgumentException">The sequence, authenticated operator, or review reference is invalid.</exception>
    /// <example><code>await tenantService.RetryPaidUnfulfilledPurchaseAsync(sequence, adminId, "review-205", token);</code></example>
    public async Task<string> RetryPaidUnfulfilledPurchaseAsync(
        long inboxSequence,
        long operatorTelegramUserId,
        string reviewReference,
        CancellationToken cancellationToken)
    {
        if (inboxSequence <= 0 || operatorTelegramUserId <= 0 || reviewReference == null ||
            !System.Text.RegularExpressions.Regex.IsMatch(reviewReference, @"\Areview-[0-9]{1,12}\z"))
            throw new ArgumentException("A reviewed uncertain sequence and review-N reference are required.");

        var review = await _workflow.ReadAsync(async db => await db.TelegramUpdateInbox.AsNoTracking()
            .Where(x => x.Sequence == inboxSequence &&
                (x.Status == "completed_with_review" || x.Status == "uncertain") &&
                x.ReviewedByTelegramUserId == operatorTelegramUserId && x.ReviewReference == reviewReference)
            .Select(x => new { x.Sequence }).SingleOrDefaultAsync(cancellationToken));
        if (review == null)
            return "Tenant retry refused: reviewed_uncertain_inbox_required.";

        var linkedKeys = await _workflow.ReadAsync(async db => await db.XuiV3CreationOperations.AsNoTracking()
            .Where(x => x.InboxSequence == inboxSequence && x.OperationKey.StartsWith("tenant-create:"))
            .Select(x => new { x.OperationKey, x.Outcome }).ToListAsync(cancellationToken));
        var orderIds = linkedKeys.Select(x => TryParseTenantCreationOrderId(x.OperationKey))
            .Where(x => x.HasValue).Select(x => x.Value).Distinct().ToArray();
        if (orderIds.Length != 1)
            return "Tenant retry refused: exact_order_link_required.";

        var orderId = orderIds[0];
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == orderId, cancellationToken));
        if (order == null || !string.Equals(order.OrderKind, TenantBotOrderKinds.Purchase, StringComparison.OrdinalIgnoreCase))
            return "Tenant retry refused: unsupported_or_missing_order.";
        if (order.IsFulfilled)
            return "Tenant retry already completed.";

        var ledgerExists = await _workflow.ReadAsync(async db => await db.TenantBotLedgerEntries.AsNoTracking()
            .AnyAsync(x => x.TenantBotOrderId == order.Id, cancellationToken));
        if (ledgerExists || !string.IsNullOrWhiteSpace(order.CreatedAccountEmail) ||
            !string.IsNullOrWhiteSpace(order.CreatedAccountJson))
            return "Tenant retry refused: existing_fulfillment_evidence.";
        if (!await HasDurablePaidTenantOrderEvidenceAsync(order, cancellationToken))
            return "Tenant retry refused: durable_paid_evidence_required.";

        // The reviewed command becomes the durable retry authorization. The coordinator reuses non-terminal attempts
        // and opens the next retry:N generation only when the latest attempt is DefinitiveRejected and this exact
        // review reference has not already granted an attempt.
        var retryAuthorization = TenantProvisioningRetryAuthorization.ReviewedRecovery(
            operatorTelegramUserId,
            orderId,
            reviewReference);
        await FULFILLPAIDTENANTORDERASYNC(
            order,
            $"inbox-reviewed-{reviewReference}",
            null,
            null,
            string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase),
            cancellationToken,
            retryAuthorization);

        var completed = await _workflow.ReadAsync(async db => await db.TenantBotOrders.AsNoTracking()
            .Where(x => x.Id == order.Id).Select(x => x.IsFulfilled).SingleAsync(cancellationToken));
        return completed ? "Tenant paid order fulfilled through the reviewed retry." :
            "Tenant retry remains incomplete; inspect the durable creation outcome before any further action.";
    }

    /// <summary>Checks immutable local provider evidence before an operator recovery can reuse a paid tenant order.</summary>
    /// <param name="order">Detached purchase order whose provider and linked payment ids identify users.db evidence.</param>
    /// <param name="cancellationToken">Cancellation token for read-only users.db queries.</param>
    /// <returns>
    /// <c>true</c> only when the order has a paid timestamp and its linked provider row (or approved manual receipt)
    /// independently records a final paid state; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>No provider request or write occurs. Unknown providers fail closed.</remarks>
    private async Task<bool> HasDurablePaidTenantOrderEvidenceAsync(
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        if (!order.PaidAtUtc.HasValue)
            return false;

        if (string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase))
            return await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.AsNoTracking().AnyAsync(x =>
                x.TenantBotOrderId == order.Id && x.Status == TenantManualPaymentReceiptStatuses.Approved &&
                x.ApprovedAtUtc != null && x.FinalConfirmedAtUtc != null, cancellationToken));
        if (string.Equals(order.PaymentProvider, "hooshpay", StringComparison.OrdinalIgnoreCase))
        {
            var evidence = await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.AsNoTracking()
                .Where(x => x.TenantBotOrderId == order.Id).Select(x => new { x.PaidAtUtc, x.PaymentStatus })
                .SingleOrDefaultAsync(cancellationToken));
            return evidence?.PaidAtUtc != null && HooshPayStatuses.IsPaid(evidence.PaymentStatus);
        }
        if (string.Equals(order.PaymentProvider, "nowpayments", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(order.PaymentProvider, "swapino", StringComparison.OrdinalIgnoreCase))
        {
            var evidence = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.AsNoTracking()
                .Where(x => x.TenantBotOrderId == order.Id).Select(x => new { x.PaidAtUtc, x.PaymentStatus })
                .SingleOrDefaultAsync(cancellationToken));
            return evidence?.PaidAtUtc != null && NowPaymentsStatuses.IsPaid(evidence.PaymentStatus);
        }
        if (string.Equals(order.PaymentProvider, "tetraminator", StringComparison.OrdinalIgnoreCase))
        {
            var evidence = await _workflow.ReadAsync(async db => await db.TetraminatorPaymentInfos.AsNoTracking()
                .Where(x => x.TenantBotOrderId == order.Id).Select(x => new { x.PaidAtUtc, x.PaymentStatus })
                .SingleOrDefaultAsync(cancellationToken));
            return evidence?.PaidAtUtc != null && TetraminatorStatuses.IsPaid(evidence.PaymentStatus);
        }
        if (string.Equals(order.PaymentProvider, "atlaspay", StringComparison.OrdinalIgnoreCase))
        {
            var evidence = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.AsNoTracking()
                .Where(x => x.TenantBotOrderId == order.Id).Select(x => new { x.PaidAtUtc, x.ProviderStatus, x.RequiresManualDelivery })
                .SingleOrDefaultAsync(cancellationToken));
            return evidence?.PaidAtUtc != null && AtlasPayStatuses.IsSuccess(evidence.ProviderStatus) && !evidence.RequiresManualDelivery;
        }
        if (string.Equals(order.PaymentProvider, "uniquepay", StringComparison.OrdinalIgnoreCase))
        {
            var evidence = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.AsNoTracking()
                .Where(x => x.TenantBotOrderId == order.Id).Select(x => new { x.PaidAtUtc, x.PaymentStatus })
                .SingleOrDefaultAsync(cancellationToken));
            return evidence?.PaidAtUtc != null && UniquePayStatuses.IsPaid(evidence.PaymentStatus);
        }
        return false;
    }

    /// <summary>Parses the internal order id from an exact persisted tenant creation business key.</summary>
    /// <param name="operationKey">Persisted operation key; command text is never accepted by the caller.</param>
    /// <returns>The positive users.db tenant-order id, or null when the key is malformed or belongs to another flow.</returns>
    private static int? TryParseTenantCreationOrderId(string operationKey)
    {
        const string prefix = "tenant-create:";
        if (operationKey?.StartsWith(prefix, StringComparison.Ordinal) != true)
            return null;
        var value = operationKey[prefix.Length..].Split(':')[0];
        return int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out var orderId) && orderId > 0
            ? orderId
            : null;
    }

    /// <summary>
    /// Performs shared one-time purchase or renewal fulfillment for a paid tenant storefront order.
    /// </summary>
    /// <param name="order">Tenant-scoped order linking the customer, owner, payment provider, and selected plan.</param>
    /// <param name="Source">Non-secret audit source such as IPN, manual check, or assistant confirmation.</param>
    /// <param name="HOOSHPAYPAYMENT">Optional tracked HooshPay row when HooshPay funded the order.</param>
    /// <param name="NOWPAYMENTSPAYMENT">Optional tracked NowPayments row when cryptocurrency funded the order.</param>
    /// <param name="DEBITOWNERBASECOST">
    /// <c>true</c> for card-to-card receipts where the tenant owner received money directly and must pay base cost from
    /// the bot wallet; <c>false</c> for platform gateways where only owner profit is credited.
    /// </param>
    /// <param name="CancellationToken">Token that cancels users.db, credentials.db, Telegram, and XUI operations.</param>
    /// <param name="retryAuthorization">
    /// Typed explicit retry authorization supplied only by owner, super-admin, or reviewed-recovery callers. Null
    /// marks automatic fulfillment, which can reuse non-terminal attempts but can never allocate a new retry
    /// generation after a definitive rejection. Callers must never pass customer text here.
    /// </param>
    /// <returns>A settlement result with owner-wallet before/after balances when fulfillment succeeds.</returns>
    /// <remarks>
    /// Idempotency:
    /// callback, customer check, and manual paths share a gate for the same tenant order and reload the order before checking
    /// <see cref="TenantBotOrder.IsFulfilled" />. Renewal orders are routed to the durable renewal saga before the
    /// account-creation branch. A completed order returns without creating/updating XUI, mutating an owner wallet, or
    /// appending another ledger entry. Before a paid purchase mutates XUI, its unlimited plan must still be enabled and
    /// tenant-visible; a hidden or removed plan fails the order without creating an account or settling owner funds.
    /// Purchase fulfillment delegates attempt selection to <see cref="TenantProvisioningAttemptCoordinator" /> so the
    /// original <c>tenant-create:{orderId}</c> operation is never reused with changed parameters after a definitive
    /// rejection and no automatic callback can silently advance the attempt generation.
    /// Timing begins only after the paid order, tenant, owner, customer, and plan are ready for execution. The central
    /// audit reports accumulated panel API time and total fulfillment time and never includes gateway waiting time.
    /// </remarks>
    private async Task<NowPaymentsSettlementResult> FULFILLPAIDTENANTORDERASYNC(
        TenantBotOrder order,
        string Source,
        HooshPayPaymentInfo HOOSHPAYPAYMENT,
        SwapinoPaymentInfo NOWPAYMENTSPAYMENT,
        bool DEBITOWNERBASECOST,
        CancellationToken CancellationToken,
        TenantProvisioningRetryAuthorization retryAuthorization = null)
    {
        using var tenantFulfillmentGateLease = await TenantFulfillmentGate.EnterAsync(order.Id.ToString(CultureInfo.InvariantCulture), CancellationToken);
        try
        {
            // Reload under the order-keyed gate so callback, manual check, and IPN cannot all act on stale
            // IsFulfilled values captured before another path completed the same tenant order.
            order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(x => x.Id == order.Id, CancellationToken));
            if (order == null)
                return NowPaymentsSettlementResult.NotFound();
            await _workflow.ReloadAsync(order, CancellationToken);
            if (order.IsFulfilled)
                return NowPaymentsSettlementResult.AlreadyAdded(order.OwnerBalanceAfter ?? 0);

        order.PaymentStatus = TenantBotOrderStatuses.Paid;
        order.PaidAtUtc ??= DateTime.UtcNow;
        order.UpdatedAtUtc = DateTime.UtcNow;
        if (HOOSHPAYPAYMENT != null)
        {
            HOOSHPAYPAYMENT.PaymentStatus = HooshPayStatuses.Paid;
            HOOSHPAYPAYMENT.PaidAtUtc ??= DateTime.UtcNow;
        }

        if (NOWPAYMENTSPAYMENT != null)
        {
            NOWPAYMENTSPAYMENT.PaymentStatus = NowPaymentsStatuses.Finished;
            NOWPAYMENTSPAYMENT.PaidAtUtc ??= DateTime.UtcNow;
        }

        await _workflow.SaveAsync(CancellationToken);

        var TENANTCONFIG = _botRegistry.GetById(order.TenantBotId);
        var tenant = await _workflow.ReadAsync(async db => await db.BotInstances.FirstOrDefaultAsync(x => x.Id == order.TenantBotId, CancellationToken));
        var owner = await _credentialsDbContext.GetUserStatusWithId(order.OwnerTelegramUserId);
        var customer = await _credentialsDbContext.GetUserStatusWithId(order.CustomerTelegramUserId);
        if (owner == null || customer == null || tenant == null)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = "tenant owner or customer was not found.";
            await _workflow.SaveAsync(CancellationToken);
            return NowPaymentsSettlementResult.UserNotFound();
        }

        var selection = new XuiV3PurchaseSelection
        {
            ServiceKey = order.ServiceKey,
            TrafficGb = order.TrafficGb,
            DurationKey = order.DurationKey,
            UnlimitedPlanKey = order.UnlimitedPlanKey,
            AccountCount = 1
        };

        if (string.Equals(order.OrderKind, TenantBotOrderKinds.Renew, StringComparison.OrdinalIgnoreCase))
        {
            // Renewal must enter the account-level mutation lock; falling through to CreateAccountAsync would deliver
            // a new account for a paid renewal and bypass delayed-commit reconciliation.
            using (_botContextAccessor.Push(new BotRuntimeContext
            {
                Config = TENANTCONFIG,
                Client = _botClientProvider.GetClient(order.TenantBotId)
            }))
            {
                return await FULFILLPAIDTENANTRENEWORDERASYNC(
                    order,
                    owner,
                    customer,
                    tenant,
                    selection,
                    Source,
                    DEBITOWNERBASECOST,
                    CancellationToken);
            }
        }

        XuiV3ResolvedPurchase resolvedPurchase;
        try
        {
            // The resolved purchase is captured rather than discarded: when this order already holds a delivered
            // provisional client, its exact quota and duration are what the same-client finalization must apply.
            resolvedPurchase = _purchaseService.ResolveTenantPurchase(selection, false);
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException or OverflowException)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = "Tenant purchase plan is no longer available for fulfillment.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
            _logger.LogWarning(
                ex,
                "Paid tenant purchase fulfillment rejected by current plan audience. tenantBotId={TenantBotId}, orderId={OrderId}, serviceKey={ServiceKey}",
                order.TenantBotId,
                order.OrderId,
                order.ServiceKey);
            await NOTIFYTENANTCUSTOMERFAILUREASYNC(
                order,
                "پلن این سفارش دیگر در فروشگاه فعال نیست و اکانتی ساخته نشد. لطفاً با پشتیبانی تماس بگیرید.",
                CancellationToken);
            return NowPaymentsSettlementResult.InvalidAmount();
        }

        using var operationTiming = XuiOperationTiming.Start();
        var fulfillmentCommitted = false;
        using (_botContextAccessor.Push(new BotRuntimeContext
        {
            Config = TENANTCONFIG,
            Client = _botClientProvider.GetClient(order.TenantBotId)
        }))
        {
            try
            {
                // The coordinator maps the paid order to its current immutable attempt: it reuses Reserved,
                // PostStarted, Ambiguous, and Applied attempts and opens retry:(highest+1) only when the latest
                // attempt is DefinitiveRejected AND this call carries a new explicit durable authorization.
                // Provisional tenant card branch. When this order already holds a delivered courtesy client the SAME
                // client is upgraded here and the normal account creation below is skipped entirely, which is what makes
                // "one account forever" true for a card order regardless of which confirmation path was used.
                var provisionalOutcome = await TRYTENANTCARDPROVISIONALFINALIZATIONASYNC(
                    order,
                    resolvedPurchase,
                    CancellationToken);
                if (provisionalOutcome.Handled && !provisionalOutcome.Success)
                {
                    await HANDLETENANTCARDPROVISIONALBLOCKEDASYNC(order, provisionalOutcome, Source, CancellationToken);
                    return NowPaymentsSettlementResult.InvalidAmount();
                }

                var attempt = provisionalOutcome.Handled
                    ? null
                    : await _tenantProvisioningCoordinator.ResolvePurchaseAttemptAsync(
                        order.Id,
                        retryAuthorization,
                        CancellationToken);
                if (attempt != null && !attempt.Allowed)
                {
                    // Automatic callbacks and checks never allocate another generation after a definitive
                    // rejection. A fixed safe reason is recorded instead of the raw reservation exception.
                    order.PaymentStatus = TenantBotOrderStatuses.Failed;
                    order.ErrorMessage = attempt.Refusal;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(CancellationToken);
                    _logger.LogWarning(
                        "Paid tenant purchase cannot start a new provisioning attempt without a fresh explicit confirmation. tenantBotId={TenantBotId}, orderId={OrderId}, serviceKey={ServiceKey}",
                        order.TenantBotId,
                        order.OrderId,
                        order.ServiceKey);
                    return NowPaymentsSettlementResult.InvalidAmount();
                }

                var created = provisionalOutcome.Handled
                    ? provisionalOutcome.Created
                    : await _purchaseService.CreateAccountAsync(
                    customer,
                    BuildConfiguredPanelServerInfo(),
                    selection,
                    _appConfig.XuiV3ApiBaseUrl,
                    CancellationToken,
                    new XuiV3AccountMetadataOptions
                    {
                        OperationKey = attempt.OperationKey,
                        AuthorizedByKey = attempt.AuthorizedByKey,
                        UserComment = $"tenant sale VIA @{tenant.Username}; Buyer={order.CustomerTelegramUserId}; tenant={order.TenantBotId}",
                        PriceTomanOverride = order.SalePriceToman,
                        CreatedByBotId = order.TenantBotId,
                        LastUpdatedByBotId = order.TenantBotId,
                        CreatedByTelegramUserId = order.CustomerTelegramUserId,
                        LastUpdatedByTelegramUserId = order.OwnerTelegramUserId,
                        LastAction = "tenant-Bot-sale",
                        SaveUserStatus = true
                    });

                if (!created.Success)
                {
                    order.PaymentStatus = TenantBotOrderStatuses.Failed;
                    order.ErrorMessage = created.Message;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(CancellationToken);
                    await NOTIFYTENANTCUSTOMERFAILUREASYNC(order, created.Message, CancellationToken);
                    LOGTENANTORDER(order, owner, customer, Source, "account-Create-failed", timing: operationTiming.Snapshot());
                    return NowPaymentsSettlementResult.InvalidAmount();
                }

                var settlement = await SETTLETENANTOWNERWALLETASYNC(
                    order,
                    owner,
                    DEBITOWNERBASECOST,
                    referenceType: "tenant-order",
                    CancellationToken);

                order.IsFulfilled = true;
                order.IsOwnerCredited = settlement.OwnerDelta > 0;
                order.OwnerWalletDelta = settlement.OwnerDelta;
                order.OwnerBalanceBefore = settlement.BotWalletBefore;
                order.OwnerBalanceAfter = settlement.BotWalletAfter;
                order.PaymentStatus = TenantBotOrderStatuses.Fulfilled;
                order.FulfillmentSource = Source;
                order.CreatedAccountEmail = created.Email;
                order.CreatedSubLink = created.SubLink;
                order.CreatedAccountJson = JsonConvert.SerializeObject(created);
                order.FulfilledAtUtc = DateTime.UtcNow;
                order.UpdatedAtUtc = DateTime.UtcNow;

                _workflow.Add(new TenantBotLedgerEntry
                {
                    TenantBotId = order.TenantBotId,
                    TenantBotUsername = order.TenantBotUsername,
                    TenantBotOrderId = order.Id,
                    OrderId = order.OrderId,
                    OwnerTelegramUserId = order.OwnerTelegramUserId,
                    CustomerTelegramUserId = order.CustomerTelegramUserId,
                    SalePriceToman = order.SalePriceToman,
                    BaseCostToman = order.BaseCostToman,
                    ProfitToman = settlement.OwnerDelta,
                    OwnerBalanceBefore = settlement.BotWalletBefore,
                    OwnerBalanceAfter = settlement.BotWalletAfter,
                    Description = $"tenant Bot sale VIA @{order.TenantBotUsername}",
                    CreatedAtUtc = DateTime.UtcNow
                });

                var notificationQueueStarted = Stopwatch.GetTimestamp();
                ADDTENANTORDERNOTIFICATIONINTENTSFORCOMMIT(
                    order,
                    includeOwnerAccountDetails: string.Equals(Source, "assistant-final", StringComparison.OrdinalIgnoreCase));
                await _workflow.SaveAsync(CancellationToken);
                fulfillmentCommitted = true;
                await OBSERVETENANTFUNDINGSETTLEMENTBESTEFFORTASYNC(tenant, settlement, CancellationToken);
                var notificationQueueElapsed = Stopwatch.GetElapsedTime(notificationQueueStarted);
                var coreTiming = operationTiming.Snapshot();

                await QueueGozargahSyncBestEffortAsync(
                    "tenant-create",
                    () => _gozargahSiteSyncService.QueueCreateAsync(
                        order.OwnerTelegramUserId,
                        order.CustomerTelegramUserId,
                        created,
                        order.OrderId,
                        order.TenantBotId,
                        CancellationToken,
                        deferSend: true));

                var callbackTotal = operationTiming.TotalElapsed;
                LOGTENANTORDER(order, owner, customer, Source, "fulfilled", settlement, coreTiming, notificationQueueElapsed);
                LOGTENANTFULFILLMENTTIMING(order, coreTiming, notificationQueueElapsed, callbackTotal);
                return NowPaymentsSettlementResult.Applied(settlement.BotWalletBefore, settlement.BotWalletAfter);
            }
            catch (Exception ex)
            {
                if (fulfillmentCommitted)
                {
                    _logger.LogWarning(ex, "Tenant post-commit work failed after durable fulfillment. orderId={OrderId} ErrorType={ErrorType}", order.OrderId, ex.GetType().Name);
                    return NowPaymentsSettlementResult.Applied(order.OwnerBalanceBefore ?? 0, order.OwnerBalanceAfter ?? 0);
                }
                order.PaymentStatus = TenantBotOrderStatuses.Failed;
                order.ErrorMessage = ex.Message;
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
                await NOTIFYTENANTCUSTOMERFAILUREASYNC(order, ex.Message, CancellationToken);
                LOGTENANTORDER(order, owner, customer, Source, $"Exception ({ex.GetType().Name})", timing: operationTiming.Snapshot());
                return NowPaymentsSettlementResult.InvalidAmount();
            }
        }
    }
        finally
        {
            tenantFulfillmentGateLease.Dispose();
        }
    }

    /// <summary>
    /// Refreshes a tenant order and detects whether fulfillment has already been recorded.
    /// </summary>
    /// <param name="order">
    /// Tenant order entity passed from an IPN, manual check, or Sales Assistant confirmation flow. The entity may be
    /// stale because the shared <see cref="UserDbContext"/> can already be tracking an older version of the same row.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the reload and ledger lookup.</param>
    /// <returns>
    /// <c>true</c> when the order is already fulfilled or when the unique tenant-order ledger row already exists;
    /// otherwise <c>false</c> and the caller may continue with account delivery.
    /// </returns>
    /// <remarks>
    /// This is the idempotency gate for tenant fulfillment. A customer can click "check status" while an IPN has
    /// already fulfilled the same order, and a singleton EF context may still expose a stale pending entity. Reloading
    /// the row and checking the unique ledger prevents duplicate XUI accounts, duplicate owner settlement, and the
    /// SQLite <c>UNIQUE constraint failed: TenantBotLedgerEntries.TenantBotOrderId</c> crash.
    /// </remarks>
    private async Task<bool> ISTENANTORDERALREADYFULFILLEDASYNC(
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        if (order == null)
            return false;

        try
        {
            await _workflow.ReloadAsync(order, cancellationToken);
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogDebug(ex, "Tenant order reload skipped before fulfillment. orderId={OrderId}", order.OrderId);
        }

        if (order.IsFulfilled)
            return true;

        return await _workflow.ReadAsync(async db => await db.TenantBotLedgerEntries
            .AsNoTracking()
            .AnyAsync(x => x.TenantBotOrderId == order.Id, cancellationToken));
    }

    /// <summary>
    /// PROMPTS A tenant customer to upload or Replace the photo receipt for A card-to-card order.
    /// </summary>
    /// <param name="botClient">tenant Bot client used to Send the PROMPT.</param>
    /// <param name="ChatId">customer chat Id.</param>
    /// <param name="ORDERDBID">internal users.db Id of the tenant order.</param>
    /// <param name="CustomerTelegramUserId">Telegram User Id used as an ownership guard.</param>
    /// <param name="CancellationToken">Cancellation Token for users.db and Telegram work.</param>
    /// <remarks>
    /// this method does not Create or FULFILL ANYTHING. it only keeps the customer ORIENTED and MAKES
    /// RE-UPLOADING A receipt DISCOVERABLE from the Original order Message.
    ///
    /// It does record the durable receipt-upload target for this exact order through
    /// <see cref="UserStateStore.SetPendingReceiptTargetAsync" />, scoped to the active tenant bot plus
    /// <paramref name="CustomerTelegramUserId" />. That binding is what makes the following image attach to this order
    /// instead of to whichever card order happened to become the newest one before the upload arrived.
    /// </remarks>
    private async Task PromptTenantReceiptUploadAsync(
        ITelegramBotClient botClient,
        ChatId ChatId,
        int ORDERDBID,
        long CustomerTelegramUserId,
        CancellationToken CancellationToken)
    {
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == ORDERDBID &&
                 x.CustomerTelegramUserId == CustomerTelegramUserId &&
                 x.PaymentProvider == "tenant_card" &&
                 !x.IsFulfilled,
            CancellationToken));

        if (order == null)
        {
            await botClient.SendMessage(ChatId, "سفارش کارت‌به‌کارت فعالی برای ارسال رسید پیدا نشد.", cancellationToken: CancellationToken);
            return;
        }

        order.PaymentStatus = TenantBotOrderStatuses.AwaitingReceipt;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);

        // Durable exact-order binding. The image that follows this prompt must attach to THIS order, so the target is
        // recorded in bot-scoped customer state (BotId + TelegramUserId) rather than rediscovered as "the newest
        // eligible card order", which could silently attach the receipt to a different order opened in the meantime.
        await _state.SetPendingReceiptTargetAsync(CustomerTelegramUserId, order.Id, CancellationToken);

        await botClient.SendMessage(
            ChatId,
            "لطفاً عکس رسید کارت‌به‌کارت همین سفارش را ارسال کنید.\n" +
            $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n" +
            $"مبلغ سفارش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n\n" +
            "اگر قبلاً رسید فرستاده‌اید، ارسال عکس جدید جایگزین رسید قبلی همین سفارش می‌شود.",
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantCardPaymentKeyboard(order),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// creates A manual card-to-card receipt from a customer image message and FORWARDS it to the sales assistant Bot.
    /// </summary>
    /// <param name="botClient">tenant Bot client that received the receipt image.</param>
    /// <param name="Message">
    /// customer message carrying the receipt. Either a Telegram photo, whose largest rendition is stored, or a Telegram
    /// image document (JPG, PNG, WebP). See <see cref="TenantReceiptMediaResolver" /> for what is accepted.
    /// </param>
    /// <param name="tenant">current tenant Bot that owns the pending order.</param>
    /// <param name="customer">credentials profile of the tenant customer who sent the receipt.</param>
    /// <param name="receiptMedia">
    /// Resolved file id and kind for the image in <paramref name="Message" />. Required; a null or empty resolution is
    /// rejected without touching the database.
    /// </param>
    /// <param name="CancellationToken">Cancellation Token for users.db and Telegram calls.</param>
    /// <returns>A task completing after the receipt and its durable owner-notification intent are committed.</returns>
    /// <remarks>
    /// <para>
    /// This method does not FULFILL the order. It stores an auditable pending receipt and its durable Sales Assistant
    /// relay intent, then hands the image to the Central sales assistant where the tenant owner must APPROVE and then
    /// finally confirm it. The receipt is committed BEFORE the courtesy provisional client is requested, so an
    /// unavailable XUI panel can never stop the store owner from receiving and reviewing the receipt.
    /// </para>
    /// <para>
    /// The target order comes from the durable bot-scoped receipt-upload target recorded by
    /// <see cref="PromptTenantReceiptUploadAsync" />, which is what stops an upload started for one order from attaching
    /// to a different card order that became newest in the meantime. The fallback to the newest eligible card order is
    /// retained only for uploads that began before the durable target existed.
    /// </para>
    /// </remarks>
    private async Task CREATETENANTMANUALRECEIPTASYNC(
        ITelegramBotClient botClient,
        Message Message,
        BotInstance tenant,
        CredUser customer,
        TenantReceiptMedia receiptMedia,
        CancellationToken CancellationToken)
    {
        if (receiptMedia == null || string.IsNullOrWhiteSpace(receiptMedia.FileId))
        {
            await botClient.SendMessage(Message.Chat.Id, "فایل رسید معتبر نیست.", cancellationToken: CancellationToken);
            return;
        }

        var order = await RESOLVETENANTRECEIPTTARGETORDERASYNC(tenant, customer.TelegramUserId, CancellationToken);
        if (order == null)
        {
            // A stale or forged target must fail closed, so the pointer is dropped instead of being retried forever.
            await _state.ClearPendingReceiptTargetAsync(customer.TelegramUserId, CancellationToken);
            await botClient.SendMessage(Message.Chat.Id, "سفارش کارت‌به‌کارت فعالی برای این رسید پیدا نشد.", cancellationToken: CancellationToken);
            return;
        }

        // Receipt row + owner-notification outbox row commit together, and only then is any panel work attempted.
        await PERSISTTENANTMANUALRECEIPTASYNC(order.Id, receiptMedia.FileId, CancellationToken);
        await _state.ClearPendingReceiptTargetAsync(customer.TelegramUserId, CancellationToken);

        await botClient.SendMessage(
            Message.Chat.Id,
            "✅ رسید ثبت شد و برای تایید مدیر ارسال شد.",
            cancellationToken: CancellationToken);

        await PROVISIONTENANTCARDPROVISIONALASYNC(botClient, Message.Chat.Id, customer, order.Id, CancellationToken);
    }

    /// <summary>
    /// Resolves the exact tenant card-to-card order one incoming receipt image belongs to.
    /// </summary>
    /// <param name="tenant">Tenant storefront bot that received the image; part of the target's identity.</param>
    /// <param name="customerTelegramUserId">Telegram user id of the sender; also part of the target's identity.</param>
    /// <param name="CancellationToken">Cancellation token for the short reads.</param>
    /// <returns>
    /// The unfulfilled card order whose receipt the sender explicitly requested, or <c>null</c> when the recorded target
    /// no longer qualifies or no target was ever recorded.
    /// </returns>
    /// <remarks>
    /// A recorded target is honoured only if it is still this bot's, this customer's, card-funded, unfulfilled, and in an
    /// eligible receipt state. Anything else returns <c>null</c> so the caller fails closed instead of guessing, because
    /// the previous "newest eligible order" behavior could attach a receipt to the wrong order. The newest-eligible
    /// fallback is used only when no target exists at all, which is the state of uploads started before the durable
    /// target column was introduced.
    /// </remarks>
    private async Task<TenantBotOrder> RESOLVETENANTRECEIPTTARGETORDERASYNC(
        BotInstance tenant,
        long customerTelegramUserId,
        CancellationToken CancellationToken)
    {
        var targetOrderDbId = await _state.GetPendingReceiptTargetAsync(customerTelegramUserId, CancellationToken);
        if (targetOrderDbId.HasValue)
        {
            return await _workflow.ReadAsync(async db => await db.TenantBotOrders
                .Where(x => x.Id == targetOrderDbId.Value &&
                            x.TenantBotId == tenant.Id &&
                            x.CustomerTelegramUserId == customerTelegramUserId &&
                            x.PaymentProvider == "tenant_card" &&
                            !x.IsFulfilled &&
                            (x.PaymentStatus == TenantBotOrderStatuses.AwaitingReceipt ||
                             x.PaymentStatus == TenantBotOrderStatuses.ReceiptSubmitted ||
                             x.PaymentStatus == TenantBotOrderStatuses.ReceiptRejected))
                .FirstOrDefaultAsync(CancellationToken));
        }

        return await _workflow.ReadAsync(async db => await db.TenantBotOrders
            .Where(x => x.TenantBotId == tenant.Id &&
                        x.CustomerTelegramUserId == customerTelegramUserId &&
                        x.PaymentProvider == "tenant_card" &&
                        !x.IsFulfilled &&
                        (x.PaymentStatus == TenantBotOrderStatuses.AwaitingReceipt ||
                         x.PaymentStatus == TenantBotOrderStatuses.ReceiptSubmitted ||
                         x.PaymentStatus == TenantBotOrderStatuses.ReceiptRejected))
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(CancellationToken));
    }

    /// <summary>
    /// Sends the single 1 GB / 1 day courtesy client to a tenant card-to-card customer while their receipt is under review.
    /// </summary>
    /// <param name="botClient">Tenant storefront bot used to deliver the details; never another tenant's bot.</param>
    /// <param name="chatId">Customer chat that receives the provisional account details.</param>
    /// <param name="customer">
    /// Detached credentials profile of the customer. <see cref="XuiV3AccountMetadataOptions.SaveUserStatus" /> is disabled
    /// by the provisioning service, so the courtesy account never overwrites the customer's own conversation state.
    /// </param>
    /// <param name="orderDbId">Internal <c>users.db</c> id of the just-persisted card order.</param>
    /// <param name="CancellationToken">Cancellation token for users.db, panel, and Telegram work.</param>
    /// <returns>A task completing after the provisional attempt and any customer delivery.</returns>
    /// <remarks>
    /// <para>
    /// Best-effort on the Telegram side by design: the receipt and its owner notification are already durable before
    /// this runs, so a provisioning or send failure can never lose the owner's ability to review the payment. Nothing
    /// here settles money, debits a wallet, writes a ledger row, marks the order paid or fulfilled, or inverts the
    /// customer's purchased entitlement.
    /// </para>
    /// <para>
    /// Skipped entirely when <see cref="AppConfig.TenantCardProvisionalDeliveryEnabled" /> is off, which keeps production
    /// behavior identical to the previous release until an operator turns the feature on.
    /// </para>
    /// </remarks>
    private async Task PROVISIONTENANTCARDPROVISIONALASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        CredUser customer,
        int orderDbId,
        CancellationToken CancellationToken)
    {
        if (!ISPROVISIONALTENANTCARDENABLED())
            return;

        try
        {
            var provisional = await _tenantCardProvisionalProvisioning.ProvisionAsync(
                customer,
                BuildConfiguredPanelServerInfo(),
                orderDbId,
                CancellationToken);

            if (provisional.Status is not (TenantCardProvisionalProvisioningStatus.Created
                or TenantCardProvisionalProvisioningStatus.AlreadyDelivered))
                return;

            if (string.IsNullOrWhiteSpace(provisional.Email))
                return;

            await SENDTENANTCARDPROVISIONALDETAILSASYNC(botClient, chatId, provisional, CancellationToken);

            // Marked delivered only after the customer actually received the details, so "account exists" and "customer
            // was told" stay independently observable and a failed send never triggers another panel create.
            await _tenantCardProvisionalProvisioning.MarkDeliveredAsync(orderDbId, CancellationToken);
        }
        catch (OperationCanceledException) when (CancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Provisional tenant card delivery failed after the receipt was persisted. orderId={OrderId} ErrorType={ErrorType}",
                orderDbId, ex.GetType().Name);
        }
    }

    /// <summary>Tells the customer about their temporary courtesy account in clear, non-misleading Persian.</summary>
    /// <param name="botClient">Tenant storefront bot used for the send.</param>
    /// <param name="chatId">Customer chat id.</param>
    /// <param name="provisional">Proven provisional identity and courtesy limits.</param>
    /// <param name="CancellationToken">Cancellation token for the Telegram call.</param>
    /// <returns>A task completing after the message is sent.</returns>
    /// <remarks>
    /// The text deliberately avoids any claim that the order is paid or fulfilled, states that the same account will be
    /// upgraded after approval, and states that a rejected receipt disables the temporary account.
    /// </remarks>
    private async Task SENDTENANTCARDPROVISIONALDETAILSASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        TenantCardProvisionalProvisioningResult provisional,
        CancellationToken CancellationToken)
    {
        var text =
            "🎁 <b>اکانت موقت شما فعال شد</b>\n\n" +
            "این اکانت موقت است تا زمانی که رسید کارت‌به‌کارت شما توسط مدیر فروشگاه بررسی شود.\n" +
            $"📦 حجم موقت: <code>{provisional.TrafficGb} GB</code>\n" +
            $"⏳ مدت موقت: <code>{provisional.DurationDays} روز</code>\n" +
            $"🧾 شماره سفارش: <code>{Html(provisional.PublicOrderId)}</code>\n\n" +
            "پس از تایید رسید، همین اکانت به بسته خریداری‌شده شما ارتقا پیدا می‌کند و اکانت جدیدی ساخته نمی‌شود.\n" +
            "در صورت رد رسید، این اکانت موقت غیرفعال می‌شود.";

        if (!string.IsNullOrWhiteSpace(provisional.SubLink))
            text += $"\n\n🔗 لینک اشتراک:\n<code>{Html(provisional.SubLink)}</code>";

        await botClient.SendMessage(
            chatId,
            text,
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantReplyKeyboard(),
            cancellationToken: CancellationToken);
    }

    /// <summary>Reads the live global switch that enables provisional tenant card delivery.</summary>
    /// <returns><c>true</c> when the feature is currently enabled; otherwise <c>false</c>, including when unset.</returns>
    /// <remarks>
    /// Read from configuration on every call rather than from the startup snapshot, so an operator edit is honored by the
    /// next receipt without a code change. A missing key keeps the feature off, which preserves legacy behavior.
    /// </remarks>
    private bool ISPROVISIONALTENANTCARDENABLED()
        => _configuration.Get<AppConfig>()?.TenantCardProvisionalDeliveryEnabled ?? false;

    /// <summary>
    /// Outcome of the provisional tenant card fulfillment probe.
    /// </summary>
    /// <param name="Handled">
    /// <c>true</c> when this order is a provisional tenant card purchase and the caller must NOT run the normal
    /// new-account creation path.
    /// </param>
    /// <param name="Success"><c>true</c> only when the same client's purchased entitlement is proven applied.</param>
    /// <param name="Created">
    /// Account-creation result describing the finalized client, suitable for the shared settlement tail. Null unless
    /// <paramref name="Success" /> is <c>true</c>.
    /// </param>
    /// <param name="Message">Safe Persian explanation shown when the order could not be finalized automatically.</param>
    /// <remarks>
    /// A non-handled outcome is the only case where the normal catalog purchase path may run, and it is returned only
    /// when the panel is proven to hold no provisional client for this order.
    /// </remarks>
    private sealed record TENANTCARDPROVISIONALOUTCOME(
        bool Handled,
        bool Success,
        XuiV3AccountCreationResult Created,
        string Message);

    /// <summary>
    /// Decides how one approved tenant card-to-card purchase must be fulfilled and, when required, upgrades the existing
    /// courtesy client in place.
    /// </summary>
    /// <param name="order">
    /// Tracked tenant order being fulfilled. On success its provisional state is advanced to <c>finalized</c> here, so the
    /// caller's existing save commits that transition atomically with fulfillment.
    /// </param>
    /// <param name="resolvedPurchase">
    /// Authoritative completed purchase for the order's original selection. Supplies the exact purchased byte quota and
    /// the purchased duration that the final client must carry.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for users.db, panel, and identity-verification work.</param>
    /// <returns>
    /// A handled outcome when this order is a provisional tenant card purchase. <c>Handled</c> with <c>Success</c>
    /// <c>false</c> means the caller must record the block and settle nothing; <c>Handled</c> <c>false</c> means the order
    /// has no provisional client and the normal path is safe.
    /// </returns>
    /// <remarks>
    /// <para>
    /// <b>Why this is the single boundary.</b> Every authorized confirmation path -- Sales Assistant final confirmation,
    /// owner <c>OrderId</c> confirmation, and super-admin recovery -- funnels through
    /// <see cref="FULFILLPAIDTENANTORDERASYNC" />, so routing the provisional decision here is what makes all three obey the
    /// same state machine and stops any of them from creating a second XUI client.
    /// </para>
    /// <para>
    /// <b>Fail-closed rules.</b> A provisional create that may have reached the panel but is not proven is escalated to
    /// manual review rather than retried or duplicated. Only a key that was never reserved, is still reserved, or was
    /// definitively rejected by the panel allows the normal path, because only those outcomes prove no client exists.
    /// </para>
    /// <para>
    /// Financial boundary: this method never debits a wallet, writes a ledger row, marks the order fulfilled, or sends a
    /// final-sale notification. Those remain the caller's shared settlement tail, which runs only after this returns
    /// <c>Success</c>.
    /// </para>
    /// </remarks>
    private async Task<TENANTCARDPROVISIONALOUTCOME> TRYTENANTCARDPROVISIONALFINALIZATIONASYNC(
        TenantBotOrder order,
        XuiV3ResolvedPurchase resolvedPurchase,
        CancellationToken cancellationToken)
    {
        if (!ISPROVISIONALTENANTCARDENABLED() ||
            !string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(order.OrderKind, TenantBotOrderKinds.Purchase, StringComparison.OrdinalIgnoreCase))
        {
            return new TENANTCARDPROVISIONALOUTCOME(false, false, null, null);
        }

        var hasProvenIdentity = !string.IsNullOrWhiteSpace(order.ProvisionalAccountEmail)
                                && !string.IsNullOrWhiteSpace(order.ProvisionalAccountUuid);

        if (!hasProvenIdentity)
        {
            if (string.Equals(order.ProvisionalDeliveryState, TenantCardProvisionalStates.ManualReview, StringComparison.Ordinal))
            {
                return new TENANTCARDPROVISIONALOUTCOME(
                    true,
                    false,
                    null,
                    "وضعیت این سفارش نیاز به بررسی دستی دارد و اکانت جدیدی ساخته نشد. لطفاً با پشتیبانی تماس بگیرید.");
            }

            // The panel must be PROVEN free of a provisional client before the normal create is allowed to run again,
            // otherwise an unreconciled POST could exist and produce a duplicate client.
            var panelUntouched = await _tenantCardProvisionalProvisioning
                .IsPanelProvenUntouchedAsync(order.OrderId, cancellationToken);
            if (!panelUntouched)
            {
                await _tenantCardProvisionalProvisioning.MarkManualReviewAsync(
                    order.Id, "provisional_create_ambiguous", cancellationToken);
                order.ProvisionalDeliveryState = TenantCardProvisionalStates.ManualReview;
                order.ProvisionalErrorCode = "provisional_create_ambiguous";
                order.UpdatedAtUtc = DateTime.UtcNow;
                return new TENANTCARDPROVISIONALOUTCOME(
                    true,
                    false,
                    null,
                    "وضعیت اکانت موقت این سفارش مبهم است و برای جلوگیری از ساخت اکانت تکراری، بررسی دستی لازم است. لطفاً با پشتیبانی تماس بگیرید.");
            }

            // The provisional attempt never reached the panel or was definitively rejected: the normal full-order path is safe.
            return new TENANTCARDPROVISIONALOUTCOME(false, false, null, null);
        }

        var finalization = await _tenantCardProvisionalFinalization.FinalizeAsync(
            new TenantCardProvisionalFinalizationRequest(
                order.Id,
                order.OrderId,
                BuildConfiguredPanelServerInfo(),
                order.ProvisionalAccountEmail,
                order.ProvisionalAccountUuid,
                order.ProvisionalSubId,
                XuiV3PurchaseService.ResolveServiceInboundIds(resolvedPurchase.Service),
                resolvedPurchase.TrafficBytes,
                resolvedPurchase.DurationDays > 0 ? resolvedPurchase.DurationDays : null),
            cancellationToken);

        if (finalization.Status is not (TenantCardProvisionalFinalizationStatus.Finalized
            or TenantCardProvisionalFinalizationStatus.AlreadyFinalized))
        {
            if (finalization.Status == TenantCardProvisionalFinalizationStatus.ManualReview)
            {
                order.ProvisionalDeliveryState = TenantCardProvisionalStates.ManualReview;
                order.ProvisionalErrorCode = finalization.ReasonCode;
            }

            order.UpdatedAtUtc = DateTime.UtcNow;

            // No settlement of any kind happens here: the customer's purchased entitlement is not yet proven applied.
            return new TENANTCARDPROVISIONALOUTCOME(
                true,
                false,
                null,
                finalization.Status == TenantCardProvisionalFinalizationStatus.ManualReview
                    ? "تایید رسید ثبت شد اما ارتقای اکانت موقت نیاز به بررسی دستی دارد و هیچ تغییر مالی اعمال نشد. لطفاً با پشتیبانی تماس بگیرید."
                    : "تایید رسید ثبت شد اما پنل به‌موقع پاسخ نداد. چند دقیقه دیگر همین سفارش را دوباره تایید کنید؛ اکانت تکراری ساخته نمی‌شود.");
        }

        // The same client now carries the exact purchased entitlement. The caller's shared settlement tail records the
        // account details, debits the owner base cost, writes the ledger row, and queues notifications exactly once.
        order.ProvisionalDeliveryState = TenantCardProvisionalStates.Finalized;
        order.ProvisionalFinalizedAtUtc ??= DateTime.UtcNow;
        order.ProvisionalErrorCode = null;
        order.UpdatedAtUtc = DateTime.UtcNow;

        return new TENANTCARDPROVISIONALOUTCOME(
            true,
            true,
            new XuiV3AccountCreationResult
            {
                Success = true,
                Email = order.ProvisionalAccountEmail,
                Uuid = order.ProvisionalAccountUuid,
                SubId = string.IsNullOrWhiteSpace(order.ProvisionalSubId) ? order.ProvisionalAccountEmail : order.ProvisionalSubId,
                SubLink = ApiServicev3.BuildSubscriptionLink(
                    BuildConfiguredPanelServerInfo(),
                    string.IsNullOrWhiteSpace(order.ProvisionalSubId) ? order.ProvisionalAccountEmail : order.ProvisionalSubId),
                TrafficGb = resolvedPurchase.TrafficGb,
                TrafficBytes = resolvedPurchase.TrafficBytes,
                DurationDays = resolvedPurchase.DurationDays > 0 ? resolvedPurchase.DurationDays : null,
                InboundIds = XuiV3PurchaseService.ResolveServiceInboundIds(resolvedPurchase.Service),
                Message = "provisional-upgraded"
            },
            null);
    }

    /// <summary>
    /// Records that an approved tenant card purchase could not be finalized automatically and settles nothing.
    /// </summary>
    /// <param name="order">Tracked tenant order that must stay unfulfilled.</param>
    /// <param name="outcome">The blocked probe outcome carrying the operator-visible explanation.</param>
    /// <param name="source">Fulfillment source label used for the operational audit log.</param>
    /// <param name="cancellationToken">Cancellation token for the short save and the Telegram failure notice.</param>
    /// <returns>A task completing after the block is recorded and the customer is told.</returns>
    /// <remarks>
    /// This deliberately does not mark the order failed, does not debit the owner, does not write a ledger row, and does
    /// not enqueue a sale notification. The receipt stays approved so an operator can retry or reconcile, and no second
    /// XUI client is created.
    /// </remarks>
    private async Task HANDLETENANTCARDPROVISIONALBLOCKEDASYNC(
        TenantBotOrder order,
        TENANTCARDPROVISIONALOUTCOME outcome,
        string source,
        CancellationToken cancellationToken)
    {
        order.ErrorMessage = outcome.Message;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(cancellationToken);

        _logger.LogWarning(
            "Tenant card provisional order could not be finalized and was left unsettled. tenantBotId={TenantBotId} orderId={OrderId} source={Source} provisionalState={ProvisionalState}",
            order.TenantBotId, order.OrderId, source, order.ProvisionalDeliveryState);

        await NOTIFYTENANTCUSTOMERFAILUREASYNC(order, outcome.Message, cancellationToken);
    }

    /// <summary>Atomically saves the receipt state and its durable Sales Assistant relay intent in users.db.</summary>
    private Task<int> PERSISTTENANTMANUALRECEIPTASYNC(int orderDbId, string photoFileId, CancellationToken cancellationToken)
    {
        return _workflow.WriteAsync(async db =>
        {
            await using var transaction = await db.Database.BeginTransactionAsync(cancellationToken);
            var order = await db.TenantBotOrders.SingleAsync(x => x.Id == orderDbId, cancellationToken);
            var receipt = order.ManualReceiptId.HasValue
                ? await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.Id == order.ManualReceiptId.Value, cancellationToken)
                : await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.TenantBotOrderId == order.Id, cancellationToken);

            // A rejected receipt is an immutable review attempt. A legitimate customer resubmission gets a new
            // receipt id/outbox key so the old assistant buttons remain historical while the new photo can be reviewed once.
            if (receipt?.Status == TenantManualPaymentReceiptStatuses.Rejected)
                receipt = null;

            if (receipt == null)
            {
                receipt = new TenantManualPaymentReceipt
                {
                    TenantBotOrderId = order.Id,
                    OrderId = order.OrderId,
                    TenantBotId = order.TenantBotId,
                    TenantBotUsername = order.TenantBotUsername,
                    OwnerTelegramUserId = order.OwnerTelegramUserId,
                    CustomerTelegramUserId = order.CustomerTelegramUserId,
                    CustomerChatId = order.CustomerChatId,
                    AmountToman = order.SalePriceToman,
                    CreatedAtUtc = DateTime.UtcNow
                };
                db.TenantManualPaymentReceipts.Add(receipt);
            }

            receipt.PhotoFileId = photoFileId;
            receipt.Status = TenantManualPaymentReceiptStatuses.Pending;
            receipt.ReviewerTelegramUserId = null;
            receipt.ApprovedAtUtc = null;
            receipt.RejectedAtUtc = null;
            receipt.FinalConfirmedAtUtc = null;
            receipt.UpdatedAtUtc = DateTime.UtcNow;
            order.PaymentStatus = TenantBotOrderStatuses.ReceiptSubmitted;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await db.SaveChangesAsync(cancellationToken);

            order.ManualReceiptId = receipt.Id;
            if (!await db.TenantManualReceiptNotifications.AnyAsync(x => x.ReceiptId == receipt.Id, cancellationToken))
            {
                db.TenantManualReceiptNotifications.Add(new TenantManualReceiptNotification
                {
                    ReceiptId = receipt.Id,
                    Status = TenantManualReceiptNotificationStatuses.Pending,
                    CreatedAtUtc = DateTime.UtcNow,
                    UpdatedAtUtc = DateTime.UtcNow
                });
            }

            await db.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return receipt.Id;
        }, cancellationToken);
    }

    /// <summary>
    /// Final-confirms a tenant card-to-card receipt from the Sales Assistant and fulfills the linked order once.
    /// </summary>
    /// <param name="RECEIPTID">
    /// Internal <c>users.db</c> id of the receipt selected in the Sales Assistant bot.
    /// </param>
    /// <param name="ReviewerTelegramUserId">
    /// Numeric Telegram user id of the tenant owner who pressed final confirmation in the assistant bot.
    /// The value must match the receipt owner.
    /// </param>
    /// <param name="CancellationToken">
    /// Cancellation token for database updates, owner wallet debit, XUI account creation, ledger writes, and Telegram notifications.
    /// </param>
    /// <returns>
    /// A Persian result string shown as the Telegram callback alert in the Sales Assistant.
    /// </returns>
    /// <remarks>
    /// The tenant owner must be the reviewer. The method is idempotent: fulfilled orders do not create
    /// another XUI account, ledger entry, or customer delivery. Repeated confirmations only resend account
    /// details to the owner when useful, keeping the customer from receiving duplicate account messages.
    /// </remarks>
    public async Task<string> APPROVEMANUALRECEIPTASYNC(int RECEIPTID, long ReviewerTelegramUserId, CancellationToken CancellationToken)
    {
        var receipt = await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.Id == RECEIPTID, CancellationToken));
        if (receipt == null)
            return "رسید پیدا نشد.";

        if (receipt.OwnerTelegramUserId != ReviewerTelegramUserId)
            return "فقط صاحب همین ربات فروشگاهی می‌تواند این رسید را تایید کند.";

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == receipt.TenantBotOrderId || x.OrderId == receipt.OrderId,
            CancellationToken));
        if (order == null)
            return "سفارش مرتبط با رسید پیدا نشد.";

        if (order.IsFulfilled)
        {
            await ENSURETENANTORDERNOTIFICATIONINTENTASYNC(order.Id, TenantOrderNotificationKinds.OwnerAccountDetailsAfterAssistantFinal, CancellationToken);
            return "این سفارش قبلاً تایید و ساخته شده است؛ ارسال مشخصات ذخیره‌شده برای شما در صف پایدار دستیار فروش قرار گرفت.";
        }

        if (!IsTenantTransportAvailable(order.TenantBotId))
        {
            return "فروشگاه این سفارش غیرفعال است یا توکن همان ربات در دسترس نیست. هیچ تغییر مالی یا ساخت اکانتی انجام نشد؛ ابتدا همان فروشگاه را دوباره فعال کنید و سپس تایید نهایی را تکرار کنید.";
        }

        receipt.Status = TenantManualPaymentReceiptStatuses.Approved;
        receipt.ReviewerTelegramUserId = ReviewerTelegramUserId;
        receipt.ApprovedAtUtc = DateTime.UtcNow;
        receipt.FinalConfirmedAtUtc = DateTime.UtcNow;
        receipt.UpdatedAtUtc = DateTime.UtcNow;
        order.PaymentStatus = TenantBotOrderStatuses.ReceiptApproved;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);

        // The owner's final confirmation is an explicit recovery action: it authorizes the next retry generation
        // under a durable per-update identity when the latest attempt was definitively rejected.
        var retryAuthorization = TenantProvisioningRetryAuthorization.TryTelegramConfirmation(
            TenantProvisioningRetryAuthorizationKind.OwnerExplicit,
            ReviewerTelegramUserId,
            order.Id);
        var settlement = await FULFILLPAIDTENANTORDERASYNC(order, "assistant-final", null, null, true, CancellationToken, retryAuthorization);
        if (settlement.Status == NowPaymentsSettlementStatus.Applied || settlement.Status == NowPaymentsSettlementStatus.AlreadyAdded)
        {
            await ENSURETENANTORDERNOTIFICATIONINTENTASYNC(order.Id, TenantOrderNotificationKinds.OwnerAccountDetailsAfterAssistantFinal, CancellationToken);
            return "رسید تایید شد و سفارش پردازش شد؛ ارسال مشخصات برای شما در صف پایدار قرار گرفت.";
        }

        if (IsTenantFulfillmentTimeout(order.ErrorMessage))
            return "رسید تایید شد، اما پنل ساخت اکانت پاسخ نداد. چند دقیقه دیگر دوباره تایید را بزنید.";

        return "تایید رسید ثبت شد ولی ساخت اکانت موفق نبود. لاگ را بررسی کنید.";
    }

    /// <summary>
    /// Rejects a tenant card-to-card receipt and disables any provisional courtesy client that was already delivered.
    /// </summary>
    /// <param name="RECEIPTID">Internal <c>users.db</c> id of the receipt selected in the Sales Assistant bot.</param>
    /// <param name="ReviewerTelegramUserId">
    /// Numeric Telegram user id of the tenant owner performing the rejection. It must equal the receipt's owner, and it is
    /// recorded as the reviewer for audit.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for database updates and panel work.</param>
    /// <returns>A Persian result string shown as the Telegram callback alert in the Sales Assistant.</returns>
    /// <remarks>
    /// <para>
    /// Rejecting a receipt is not only a review outcome once provisional delivery is enabled: the customer may already
    /// hold a working courtesy client, and leaving it enabled would grant service for a payment the owner refused. The
    /// rejection therefore also runs the durable revoke saga, which disables that exact client and proves the result by
    /// read-back.
    /// </para>
    /// <para>
    /// Financial boundary: nothing here debits or credits a wallet, writes a ledger row, marks the order fulfilled, or
    /// sends a sale notification. A fulfilled order is never revoked, because its client is the purchased account rather
    /// than a courtesy one.
    /// </para>
    /// <para>
    /// Idempotent: an already-rejected receipt is not rewritten, and a revoked saga only re-reads and re-proves the
    /// disabled panel state, so a duplicate reject callback cannot issue another mutation.
    /// </para>
    /// </remarks>
    /// <example>
    /// <code>
    /// var result = await tenantService.REJECTMANUALRECEIPTASYNC(receiptId, callback.From.Id, cancellationToken);
    /// await SafeAnswerCallbackQueryAsync(botClient, callback.Id, result, showAlert: true, cancellationToken: cancellationToken);
    /// </code>
    /// </example>
    public async Task<string> REJECTMANUALRECEIPTASYNC(
        int RECEIPTID,
        long ReviewerTelegramUserId,
        CancellationToken CancellationToken)
    {
        var receipt = await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.Id == RECEIPTID, CancellationToken));
        if (receipt == null)
            return "رسید پیدا نشد.";

        if (receipt.OwnerTelegramUserId != ReviewerTelegramUserId)
            return "فقط صاحب همین ربات فروشگاهی می‌تواند این رسید را رد کند.";

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == receipt.TenantBotOrderId || x.OrderId == receipt.OrderId,
            CancellationToken));
        if (order == null)
            return "سفارش مرتبط با رسید پیدا نشد.";

        // The review outcome is recorded first and independently of the panel, so the owner's decision is never lost
        // because XUI was unreachable.
        if (receipt.Status != TenantManualPaymentReceiptStatuses.Rejected)
        {
            receipt.Status = TenantManualPaymentReceiptStatuses.Rejected;
            receipt.ReviewerTelegramUserId = ReviewerTelegramUserId;
            receipt.RejectedAtUtc = DateTime.UtcNow;
            receipt.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
        }

        var revokeNote = await REVOKETENANTCARDPROVISIONALASYNC(order, CancellationToken);
        return revokeNote ?? "رسید رد شد.";
    }

    /// <summary>
    /// Revokes the provisional courtesy client of a rejected tenant card-to-card order, when one exists.
    /// </summary>
    /// <param name="order">Tracked tenant order whose receipt was just rejected.</param>
    /// <param name="cancellationToken">Cancellation token for users.db and panel work.</param>
    /// <returns>
    /// A Persian note describing the revoke outcome, or <c>null</c> when the order had no revocable provisional client and
    /// the caller should show its own default rejection message.
    /// </returns>
    /// <remarks>
    /// Skips a fulfilled order because its panel client is the purchased account, not a courtesy one. Placement is not part
    /// of the revoke identity check: the provisional email plus panel UUID are the strongest identity available, and
    /// requiring a placement set that a later catalog edit could change would permanently block revocation.
    /// </remarks>
    private async Task<string> REVOKETENANTCARDPROVISIONALASYNC(
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        if (!ISPROVISIONALTENANTCARDENABLED() || order.IsFulfilled)
            return null;

        var hasProvenIdentity = !string.IsNullOrWhiteSpace(order.ProvisionalAccountEmail)
                                && !string.IsNullOrWhiteSpace(order.ProvisionalAccountUuid);
        var revocable = hasProvenIdentity &&
                        (string.Equals(order.ProvisionalDeliveryState, TenantCardProvisionalStates.Provisioning, StringComparison.Ordinal) ||
                         string.Equals(order.ProvisionalDeliveryState, TenantCardProvisionalStates.Delivered, StringComparison.Ordinal) ||
                         string.Equals(order.ProvisionalDeliveryState, TenantCardProvisionalStates.Finalizing, StringComparison.Ordinal) ||
                         string.Equals(order.ProvisionalDeliveryState, TenantCardProvisionalStates.Revoking, StringComparison.Ordinal));

        if (!revocable)
            return null;

        try
        {
            order.ProvisionalDeliveryState = TenantCardProvisionalStates.Revoking;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);

            var result = await _tenantCardProvisionalRevocation.RevokeAsync(
                new TenantCardProvisionalRevocationRequest(
                    order.Id,
                    order.OrderId,
                    BuildConfiguredPanelServerInfo(),
                    order.ProvisionalAccountEmail,
                    order.ProvisionalAccountUuid,
                    order.ProvisionalSubId,
                    Array.Empty<int>()),
                cancellationToken);

            switch (result.Status)
            {
                case TenantCardProvisionalRevocationStatus.Revoked:
                case TenantCardProvisionalRevocationStatus.AlreadyRevoked:
                    order.ProvisionalDeliveryState = TenantCardProvisionalStates.Revoked;
                    order.ProvisionalRevokedAtUtc ??= DateTime.UtcNow;
                    order.ProvisionalErrorCode = null;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(cancellationToken);
                    return "رسید رد شد و اکانت موقت غیرفعال شد.";

                case TenantCardProvisionalRevocationStatus.ManualReview:
                    order.ProvisionalDeliveryState = TenantCardProvisionalStates.ManualReview;
                    order.ProvisionalErrorCode = result.ReasonCode;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(cancellationToken);
                    return "رسید رد شد، اما غیرفعال‌سازی اکانت موقت نیاز به بررسی دستی دارد. لطفاً با پشتیبانی تماس بگیرید.";

                default:
                    return "رسید رد شد؛ غیرفعال‌سازی اکانت موقت در صف تلاش مجدد است.";
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Provisional revoke failed after the receipt was rejected. orderId={OrderId} ErrorType={ErrorType}",
                order.OrderId, ex.GetType().Name);
            return "رسید رد شد؛ غیرفعال‌سازی اکانت موقت در صف تلاش مجدد است.";
        }
    }

    /// <summary>
    /// Manually approves one tenant card-to-card order by its public order id from the owner panel.
    /// </summary>
    /// <param name="botClient">Main owned bot client used to answer the colleague owner.</param>
    /// <param name="Message">Owner text message containing the exact public <c>OrderId</c>.</param>
    /// <param name="owner">Colleague profile that must own the target tenant order.</param>
    /// <param name="CancellationToken">Cancellation token for database, wallet, XUI, and Telegram work.</param>
    /// <remarks>
    /// This method is used when a card-to-card receipt was not approved through the Sales Assistant. It creates
    /// a receipt audit row when needed, marks it approved, and delegates fulfillment to the same idempotent
    /// method used by assistant final confirmation. If the order was already fulfilled, the method does not
    /// create another account or ledger entry and only resends existing account details to the tenant owner.
    /// </remarks>
    /// <returns>A task completing after owner/order validation, authorized fulfillment and its result response.</returns>
    private async Task CONFIRMMANUALCARDORDERBYORDERIDASYNC(
        ITelegramBotClient botClient,
        Message Message,
        CredUser owner,
        CancellationToken CancellationToken)
    {
        var orderId = Message.Text?.Trim();
        if (string.IsNullOrWhiteSpace(orderId))
        {
            await botClient.SendMessage(Message.Chat.Id, "OrderId نمی‌تواند خالی باشد. دوباره OrderId سفارش کارت‌به‌کارت را ارسال کنید.", cancellationToken: CancellationToken);
            return;
        }

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.OwnerTelegramUserId == owner.TelegramUserId && x.OrderId == orderId && x.TenantBotId == _selectedOwnerStore.Id,
            CancellationToken));

        if (order == null)
        {
            await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
            await botClient.SendMessage(Message.Chat.Id, "سفارشی با این OrderId برای ربات فروشگاهی شما پیدا نشد.", cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
            return;
        }

        if (!string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase))
        {
            await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
            await botClient.SendMessage(Message.Chat.Id, "این سفارش مربوط به پرداخت کارت‌به‌کارت همکار نیست و از این مسیر قابل تایید دستی نیست.", cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
            return;
        }

        var receipt = await ENSUREMANUALRECEIPTASYNC(order, owner.TelegramUserId, CancellationToken);
        if (order.IsFulfilled)
        {
            await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
            await SENDTENANTORDERACCOUNTDETAILSASYNC(order, sendCustomer: false, sendOwner: true, CancellationToken);
            await botClient.SendMessage(Message.Chat.Id, "این سفارش قبلاً تایید شده بود. مشخصات اکانت فقط برای شما دوباره ارسال شد.", cancellationToken: CancellationToken);
            await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
            return;
        }

        receipt.Status = TenantManualPaymentReceiptStatuses.Approved;
        receipt.ReviewerTelegramUserId = owner.TelegramUserId;
        receipt.ApprovedAtUtc = DateTime.UtcNow;
        receipt.FinalConfirmedAtUtc = DateTime.UtcNow;
        receipt.UpdatedAtUtc = DateTime.UtcNow;
        order.PaymentStatus = TenantBotOrderStatuses.ReceiptApproved;
        order.ManualReceiptId = receipt.Id;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);

        // The owner's explicit OrderId re-confirmation authorizes the next retry generation after a rejection.
        var retryAuthorization = TenantProvisioningRetryAuthorization.TryTelegramConfirmation(
            TenantProvisioningRetryAuthorizationKind.OwnerExplicit,
            owner.TelegramUserId,
            order.Id);
        var settlement = await FULFILLPAIDTENANTORDERASYNC(order, "owner-orderid-manual", null, null, true, CancellationToken, retryAuthorization);
        await _state.ClearUserStatus(new User { Id = owner.TelegramUserId });
        if (settlement.Status == NowPaymentsSettlementStatus.Applied || settlement.Status == NowPaymentsSettlementStatus.AlreadyAdded)
        {
            await SENDTENANTORDERACCOUNTDETAILSASYNC(order, sendCustomer: false, sendOwner: true, CancellationToken);
            await botClient.SendMessage(Message.Chat.Id, "پرداخت کارت‌به‌کارت تایید شد، سفارش پردازش شد و مشخصات اکانت ارسال شد.", cancellationToken: CancellationToken);
        }
        else
        {
            await botClient.SendMessage(Message.Chat.Id, "تایید ثبت شد، اما ساخت اکانت موفق نبود. لاگ را بررسی کنید.", cancellationToken: CancellationToken);
        }

        await SHOWOWNERPANELASYNC(botClient, Message.Chat.Id, owner, null, CancellationToken);
    }

    /// <summary>
    /// Lets a super-admin confirm or retry a tenant storefront order by its public <c>OrderId</c>.
    /// </summary>
    /// <param name="orderId">
    /// Public tenant order id copied from the tenant bot, Sales Assistant, or operational log. The lookup is global
    /// across tenant owners because only super-admin flows call this method.
    /// </param>
    /// <param name="superAdminTelegramUserId">
    /// Numeric Telegram user id of the super-admin performing the manual confirmation. It is stored as the reviewer
    /// on audit-only manual receipt rows when the order uses tenant card-to-card payment.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for users.db, wallet, XUI, ledger, and Telegram delivery.</param>
    /// <returns>
    /// HTML-formatted status text when a tenant order was found and processed; <c>null</c> when the supplied id does
    /// not belong to a tenant order and the caller should continue checking other payment providers.
    /// </returns>
    /// <remarks>
    /// This method is idempotent. Fulfilled orders are not charged or created again; stored account details are only
    /// resent. Unfulfilled orders run the same fulfillment path used by IPN, customer checks, owner card approval,
    /// and Sales Assistant final confirmation.
    /// </remarks>
    public async Task<string> CONFIRMTENANTORDERBYSUPERADMINASYNC(
        string orderId,
        long superAdminTelegramUserId,
        CancellationToken CancellationToken)
    {
        orderId = orderId?.Trim();
        if (string.IsNullOrWhiteSpace(orderId))
            return null;

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(x => x.OrderId == orderId, CancellationToken));
        if (order == null)
            return null;

        if (order.IsFulfilled)
        {
            await SENDTENANTORDERACCOUNTDETAILSASYNC(order, sendCustomer: true, sendOwner: true, CancellationToken);
            return BUILDSUPERADMINTENANTORDERRESULTTEXT(order, null, "این سفارش قبلاً تحویل شده بود؛ مشخصات ذخیره‌شده دوباره برای خریدار و همکار ارسال شد.");
        }

        NowPaymentsSettlementResult settlement;
        // This super-admin command is an explicit recovery action, so fulfillment may advance a definitively
        // rejected attempt to the next generation under a durable per-update authorization.
        var retryAuthorization = TenantProvisioningRetryAuthorization.TryTelegramConfirmation(
            TenantProvisioningRetryAuthorizationKind.SuperAdminExplicit,
            superAdminTelegramUserId,
            order.Id);
        if (string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase))
        {
            var receipt = await ENSUREMANUALRECEIPTASYNC(order, superAdminTelegramUserId, CancellationToken);
            receipt.Status = TenantManualPaymentReceiptStatuses.Approved;
            receipt.ReviewerTelegramUserId = superAdminTelegramUserId;
            receipt.ApprovedAtUtc ??= DateTime.UtcNow;
            receipt.FinalConfirmedAtUtc = DateTime.UtcNow;
            receipt.UpdatedAtUtc = DateTime.UtcNow;
            order.PaymentStatus = TenantBotOrderStatuses.ReceiptApproved;
            order.ManualReceiptId = receipt.Id;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);

            settlement = await FULFILLPAIDTENANTORDERASYNC(order, "super-admin-orderid-manual", null, null, true, CancellationToken, retryAuthorization);
        }
        else
        {
            var hooshPay = await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.FirstOrDefaultAsync(
                x => x.TenantBotOrderId == order.Id || x.OrderId == order.OrderId,
                CancellationToken));
            if (hooshPay != null)
            {
                settlement = await ApplyPaidTenantOrderAsync(hooshPay, "super-admin-orderid-manual", CancellationToken, retryAuthorization);
            }
            else
            {
                var uniquePay = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.FirstOrDefaultAsync(
                    x => x.TenantBotOrderId == order.Id || x.HashId == order.OrderId,
                    CancellationToken));
                if (uniquePay != null)
                {
                    var inquiry = await _uniquePay.CheckInvoiceAsync(uniquePay.HashId, CancellationToken);
                    uniquePay.Apply(
                        inquiry,
                        DateTime.UtcNow.AddSeconds(Math.Clamp(_appConfig.UniquePayReconciliationIntervalSeconds, 10, 3600)));
                    var providerTerminalStatus = UniquePayStatuses.GetProviderTerminalStatus(inquiry.Invoice);
                    if (providerTerminalStatus != null)
                    {
                        uniquePay.PaymentStatus = providerTerminalStatus;
                        uniquePay.ErrorCode = $"provider_{providerTerminalStatus}";
                        uniquePay.ErrorMessage = "UniquePay reported a terminal unpaid invoice state.";
                        uniquePay.NextInquiryAtUtc = null;
                    }
                    else if (UniquePayPaymentVerifier.IsVerifiedPaid(uniquePay, inquiry, out var errorCode))
                    {
                        uniquePay.ErrorCode = null;
                        uniquePay.ErrorMessage = null;
                        uniquePay.PaymentStatus = UniquePayStatuses.Paid;
                        uniquePay.PaidAtUtc ??= DateTime.UtcNow;
                        uniquePay.NextInquiryAtUtc = null;
                    }
                    else
                    {
                        uniquePay.ErrorCode = errorCode;
                        uniquePay.ErrorMessage = errorCode == "provider_not_paid"
                            ? null
                            : "UniquePay verification failed.";
                        if (errorCode != "provider_not_paid")
                        {
                            uniquePay.PaymentStatus = UniquePayStatuses.Failed;
                            uniquePay.NextInquiryAtUtc = null;
                        }
                    }
                    await _workflow.SaveAsync(CancellationToken);
                    settlement = await ApplyPaidTenantOrderAsync(uniquePay, "super-admin-orderid-manual", CancellationToken, retryAuthorization);
                }
                else
                {
                var nowPayments = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.FirstOrDefaultAsync(
                    x => x.TenantBotOrderId == order.Id || x.OrderId == order.OrderId,
                    CancellationToken));
                settlement = nowPayments != null
                    ? await ApplyPaidTenantOrderAsync(nowPayments, "super-admin-orderid-manual", CancellationToken, retryAuthorization)
                    : await FULFILLPAIDTENANTORDERASYNC(order, "super-admin-orderid-manual", null, null, false, CancellationToken, retryAuthorization);
                }
            }
        }

        var note = settlement?.Status == NowPaymentsSettlementStatus.Applied
            ? "سفارش تایید و پردازش شد."
            : settlement?.Status == NowPaymentsSettlementStatus.AlreadyAdded
                ? "این سفارش قبلاً پردازش شده بود؛ تحویل دوباره ساخته نشد."
                : IsTenantFulfillmentTimeout(order.ErrorMessage)
                    ? "تایید ثبت شد، اما پنل ساخت اکانت timeout داد. همین OrderId را چند دقیقه دیگر دوباره بررسی کنید."
                    : "تایید ثبت شد، اما تکمیل سفارش موفق نبود. خطای سفارش را بررسی کنید.";

        return BUILDSUPERADMINTENANTORDERRESULTTEXT(order, settlement, note);
    }

    /// <summary>
    /// Builds the HTML result shown to super-admins after confirming a tenant order by <c>OrderId</c>.
    /// </summary>
    /// <param name="order">Tenant order that was found by public order id.</param>
    /// <param name="settlement">Optional settlement result returned by the fulfillment path.</param>
    /// <param name="note">Human-readable outcome summary shown at the top of the admin response.</param>
    /// <returns>HTML-safe Telegram message with order, fulfillment, and latest error details.</returns>
    private static string BUILDSUPERADMINTENANTORDERRESULTTEXT(
        TenantBotOrder order,
        NowPaymentsSettlementResult settlement,
        string note)
    {
        return "✅ <b>بررسی سفارش tenant</b>\n\n" +
               $"{Html(note)}\n\n" +
               $"OrderId: <code>{Html(order.OrderId)}</code>\n" +
               $"ربات: <code>{Html(order.TenantBotId)}</code> @{Html(order.TenantBotUsername)}\n" +
               $"مالک: <code>{order.OwnerTelegramUserId}</code>\n" +
               $"خریدار: <code>{order.CustomerTelegramUserId}</code>\n" +
               $"نوع سفارش: <code>{Html(order.OrderKind)}</code>\n" +
               $"درگاه: <code>{Html(order.PaymentProvider)}</code>\n" +
               $"وضعیت پرداخت: <code>{Html(order.PaymentStatus)}</code>\n" +
               $"وضعیت settlement: <code>{Html(settlement?.Status.ToString() ?? "-")}</code>\n" +
               $"تحویل: <code>{Html(order.IsFulfilled ? "انجام شده" : "انجام نشده")}</code>\n" +
               $"اکانت: <code>{Html(order.CreatedAccountEmail)}</code>" +
               BuildTenantOrderErrorLine(order);
    }

    /// <summary>
    /// Gets the existing manual receipt row for an order or creates an audit-only row when no photo receipt exists.
    /// </summary>
    /// <param name="order">Tenant card-to-card order that is being manually approved.</param>
    /// <param name="reviewerTelegramUserId">Telegram user id of the colleague owner approving the order.</param>
    /// <param name="CancellationToken">Cancellation token for users.db access.</param>
    /// <returns>
    /// A tracked receipt entity linked to the tenant order. The row may have a null photo id when approval was
    /// performed by OrderId instead of a customer-uploaded receipt photo.
    /// </returns>
    /// <remarks>
    /// The database has a unique index on <see cref="TenantManualPaymentReceipt.TenantBotOrderId" />, so this method
    /// always reuses an existing row before creating a new one.
    /// </remarks>
    private async Task<TenantManualPaymentReceipt> ENSUREMANUALRECEIPTASYNC(
        TenantBotOrder order,
        long reviewerTelegramUserId,
        CancellationToken CancellationToken)
    {
        var receipt = order.ManualReceiptId.HasValue
            ? await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.Id == order.ManualReceiptId.Value, CancellationToken))
            : await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.TenantBotOrderId == order.Id, CancellationToken));

        if (receipt != null)
            return receipt;

        receipt = new TenantManualPaymentReceipt
        {
            TenantBotOrderId = order.Id,
            OrderId = order.OrderId,
            TenantBotId = order.TenantBotId,
            TenantBotUsername = order.TenantBotUsername,
            OwnerTelegramUserId = order.OwnerTelegramUserId,
            CustomerTelegramUserId = order.CustomerTelegramUserId,
            CustomerChatId = order.CustomerChatId,
            AmountToman = order.SalePriceToman,
            Status = TenantManualPaymentReceiptStatuses.Pending,
            ReviewerTelegramUserId = reviewerTelegramUserId,
            CreatedAtUtc = DateTime.UtcNow,
            UpdatedAtUtc = DateTime.UtcNow
        };

        _workflow.Add(receipt);
        await _workflow.SaveAsync(CancellationToken);
        order.ManualReceiptId = receipt.Id;
        return receipt;
    }

    /// <summary>
    /// Resends account details for a fulfilled manual receipt order when the Sales Assistant requests it.
    /// </summary>
    /// <param name="RECEIPTID">Internal users.db receipt id selected from a Sales Assistant callback.</param>
    /// <param name="ReviewerTelegramUserId">Telegram user id of the owner requesting the resend.</param>
    /// <param name="CancellationToken">Cancellation token for database and Telegram work.</param>
    /// <returns>Human-readable Persian result shown in the Sales Assistant callback alert.</returns>
    public async Task<string> RESENDMANUALRECEIPTACCOUNTASYNC(int RECEIPTID, long ReviewerTelegramUserId, CancellationToken CancellationToken)
    {
        var receipt = await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(x => x.Id == RECEIPTID, CancellationToken));
        if (receipt == null)
            return "رسید پیدا نشد.";

        if (receipt.OwnerTelegramUserId != ReviewerTelegramUserId)
            return "فقط صاحب همین ربات فروشگاهی می‌تواند مشخصات این سفارش را دریافت کند.";

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == receipt.TenantBotOrderId || x.OrderId == receipt.OrderId,
            CancellationToken));
        if (order == null)
            return "سفارش مرتبط با رسید پیدا نشد.";

        if (!order.IsFulfilled)
            return "این سفارش هنوز ساخته نشده است و مشخصات اکانت برای ارسال مجدد وجود ندارد.";

        var transportAvailable = IsTenantTransportAvailable(order.TenantBotId);
        await SENDTENANTORDERACCOUNTDETAILSASYNC(order, sendCustomer: transportAvailable, sendOwner: true, CancellationToken);
        return transportAvailable
            ? "مشخصات اکانت از دستیار فروش برای شما و از همان ربات فروشگاهی برای خریدار دوباره ارسال شد."
            : "مشخصات ذخیره‌شده از دستیار فروش برای شما ارسال شد. فروشگاه غیرفعال است یا توکن همان ربات در دسترس نیست؛ ارسال به خریدار فقط پس از فعال‌سازی مجدد همان فروشگاه ممکن است.";
    }

    /// <summary>
    /// Finds the newest tenant order for the current Bot and customer, then Runs the normal order-status check.
    /// </summary>
    /// <param name="botClient">Telegram client for the current tenant Bot.</param>
    /// <param name="ChatId">chat that should Receive the manual-check result.</param>
    /// <param name="CustomerTelegramUserId">Telegram User Id of the storefront customer.</param>
    /// <param name="CancellationToken">Cancellation Token for database and Telegram calls.</param>
    private async Task CHECKLATESTCUSTOMERORDERASYNC(ITelegramBotClient botClient, ChatId ChatId, long CustomerTelegramUserId, CancellationToken CancellationToken)
    {
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders
            .Where(x => x.TenantBotId == BotContextAccessor.CurrentBotId && x.CustomerTelegramUserId == CustomerTelegramUserId)
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(CancellationToken));

        if (order == null)
        {
            await botClient.SendMessage(ChatId, "سفارش فعالی برای بررسی پیدا نشد.", cancellationToken: CancellationToken);
            return;
        }

        await CheckTenantOrderAsync(botClient, ChatId, order.Id, CustomerTelegramUserId, CancellationToken);
    }

    /// <summary>
    /// Verifies a specific tenant order against its payment provider and replays fulfilled account details when needed.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant Bot that owns the order.</param>
    /// <param name="ChatId">chat that Receives the current payment status.</param>
    /// <param name="ORDERDBID">Internal users.db id of the tenant order embedded in the tenant callback.</param>
    /// <param name="CustomerTelegramUserId">
    /// Numeric Telegram user id of the tenant customer who clicked the status button. The order must belong to
    /// this user and to the current tenant bot context.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for provider API calls, users.db writes, and Telegram replies.</param>
    /// <returns>A task that completes after a provider-specific status or fulfillment result is sent.</returns>
    /// <remarks>
    /// This method is used by tenant payment keyboards and payment return checks. It is idempotent: fulfilled
    /// orders are never built or charged again; their stored account details are resent to the buyer instead.
    /// </remarks>
    private async Task CheckTenantOrderAsync(ITelegramBotClient botClient, ChatId ChatId, int ORDERDBID, long CustomerTelegramUserId, CancellationToken CancellationToken)
    {
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders.FirstOrDefaultAsync(
            x => x.Id == ORDERDBID &&
                 x.TenantBotId == BotContextAccessor.CurrentBotId &&
                 x.CustomerTelegramUserId == CustomerTelegramUserId,
            CancellationToken));
        if (order == null)
        {
            await botClient.SendMessage(ChatId, "سفارش پیدا نشد.", cancellationToken: CancellationToken);
            return;
        }

        if (order.IsFulfilled)
        {
            await RESENDFULFILLEDTENANTORDERTOCUSTOMERASYNC(botClient, ChatId, order, CancellationToken);
            return;
        }

        if (IsPendingTenantCardOrder(order))
        {
            await botClient.SendMessage(
                ChatId,
                "در انتظار پرداخت و تایید مدیر.",
                replyMarkup: BuildTenantCardPaymentKeyboard(order),
                cancellationToken: CancellationToken);
            return;
        }

        if (string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase))
        {
            await botClient.SendMessage(
                ChatId,
                "پرداخت شما توسط مدیر تایید شده است، اما ساخت اکانت هنوز کامل نشده یا نیاز به تلاش مجدد دارد. لطفاً کمی صبر کنید یا با پشتیبانی فروشگاه تماس بگیرید.",
                cancellationToken: CancellationToken);
            return;
        }

        if (order.AtlasPayPaymentInfoId.HasValue ||
            string.Equals(order.PaymentProvider, "AtlasPay", StringComparison.OrdinalIgnoreCase))
        {
            var atlasPayment = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.AsNoTracking().FirstOrDefaultAsync(x =>
                (x.Id == order.AtlasPayPaymentInfoId || x.TenantBotOrderId == order.Id) &&
                x.TenantBotOrderId == order.Id && x.TelegramUserId == CustomerTelegramUserId && x.BotId == order.TenantBotId,
                CancellationToken));
            if (atlasPayment == null)
            { await botClient.SendMessage(ChatId, "فاکتور اطلس‌پی این سفارش پیدا نشد.", cancellationToken: CancellationToken); return; }
            // Provider-traffic guard: the tenant storefront has no server callback, so each check is a real provider
            // request. The cooldown uses the last inquiry recorded by any caller, including the background worker, so
            // repeated taps by the customer cannot produce a burst of AtlasPay requests or mutate financial state.
            if (AtlasPayManualCheckPolicy.IsWithinCooldown(atlasPayment, _appConfig.AtlasPayManualCheckMinIntervalSeconds,
                    DateTime.UtcNow, out var waitSeconds))
            {
                await botClient.SendMessage(ChatId, $"لطفاً {waitSeconds} ثانیه دیگر دوباره بررسی کنید.",
                    cancellationToken: CancellationToken);
                return;
            }
            var settlement = await _atlasPayReconciliation.ReconcilePaymentAsync(atlasPayment.Id, "customer-check", useVerify: true, CancellationToken);
            var latest = await _workflow.ReadAsync(async db => await db.AtlasPayPaymentInfos.AsNoTracking().FirstAsync(x => x.Id == atlasPayment.Id, CancellationToken));
            if (settlement.Status is NowPaymentsSettlementStatus.Applied or NowPaymentsSettlementStatus.AlreadyAdded)
            { await SENDTENANTSETTLEMENTCHECKRESULTASYNC(botClient, ChatId, order, settlement, CancellationToken); return; }
            string text;
            if (latest.RequiresManualDelivery || latest.SettlementState == AtlasPaySettlementStates.ManualReview)
                text = "⚠️ پرداخت شما ثبت شده اما به دلیل مغایرت مبلغ نیاز به بررسی دستی دارد.";
            else if (AtlasPayStatuses.IsTerminal(latest.ProviderStatus))
                text = latest.ProviderStatus == "expired" ? "مهلت فاکتور اطلس‌پی منقضی شده و سفارش تحویل نشد."
                    : latest.ProviderStatus == "cancelled" ? "فاکتور اطلس‌پی لغو شده و سفارش تحویل نشد."
                    : "پرداخت اطلس‌پی رد شده و سفارش تحویل نشد.";
            else text = "پرداخت اطلس‌پی هنوز تایید نشده است.";
            await botClient.SendMessage(ChatId, text,
                replyMarkup: latest.SettlementState != AtlasPaySettlementStates.ManualReview && !AtlasPayStatuses.IsTerminal(latest.ProviderStatus)
                    ? BuildTenantPaymentKeyboard(order, latest.CustomerStartLink) : null,
                cancellationToken: CancellationToken);
            return;
        }

        if (order.UniquePayPaymentInfoId.HasValue ||
            string.Equals(order.PaymentProvider, "UniquePay", StringComparison.OrdinalIgnoreCase))
        {
            var uniquePayment = await _workflow.ReadAsync(async db => await db.UniquePayPaymentInfos.FirstOrDefaultAsync(
                x => x.Id == order.UniquePayPaymentInfoId || x.TenantBotOrderId == order.Id,
                CancellationToken));
            if (uniquePayment == null)
            {
                await botClient.SendMessage(ChatId, "فاکتور یونیک‌پی این سفارش پیدا نشد.", cancellationToken: CancellationToken);
                return;
            }

            try
            {
                var inquiry = await _uniquePay.CheckInvoiceAsync(uniquePayment.HashId, CancellationToken);
                uniquePayment.Apply(
                    inquiry,
                    DateTime.UtcNow.AddSeconds(Math.Clamp(_appConfig.UniquePayReconciliationIntervalSeconds, 10, 3600)));
                var providerTerminalStatus = UniquePayStatuses.GetProviderTerminalStatus(inquiry.Invoice);
                if (providerTerminalStatus != null)
                {
                    uniquePayment.PaymentStatus = providerTerminalStatus;
                    uniquePayment.ErrorCode = $"provider_{providerTerminalStatus}";
                    uniquePayment.ErrorMessage = "UniquePay reported a terminal unpaid invoice state.";
                    uniquePayment.NextInquiryAtUtc = null;
                    uniquePayment.UpdatedAtUtc = DateTime.UtcNow;
                    await _workflow.SaveAsync(CancellationToken);
                    await botClient.SendMessage(
                        ChatId,
                        string.Equals(providerTerminalStatus, UniquePayStatuses.Expired, StringComparison.Ordinal)
                            ? "مهلت فاکتور یونیک‌پی این سفارش منقضی شده و سفارش تحویل نشد."
                            : string.Equals(providerTerminalStatus, UniquePayStatuses.Cancelled, StringComparison.Ordinal)
                                ? "فاکتور یونیک‌پی این سفارش لغو شده و سفارش تحویل نشد."
                                : "فاکتور یونیک‌پی ناموفق اعلام شد و سفارش تحویل نشد.",
                        cancellationToken: CancellationToken);
                    return;
                }

                var verified = UniquePayPaymentVerifier.IsVerifiedPaid(uniquePayment, inquiry, out var errorCode);
                uniquePayment.ErrorCode = verified || errorCode == "provider_not_paid" ? null : errorCode;
                uniquePayment.ErrorMessage = verified || errorCode == "provider_not_paid" ? null : "UniquePay verification failed.";
                if (verified)
                {
                    uniquePayment.PaymentStatus = UniquePayStatuses.Paid;
                    uniquePayment.PaidAtUtc ??= DateTime.UtcNow;
                    uniquePayment.NextInquiryAtUtc = null;
                    order.PaymentStatus = TenantBotOrderStatuses.Paid;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                }
                else if (errorCode != "provider_not_paid")
                {
                    uniquePayment.PaymentStatus = UniquePayStatuses.Failed;
                    uniquePayment.NextInquiryAtUtc = null;
                }
                await _workflow.SaveAsync(CancellationToken);

                if (verified)
                {
                    var settlement = await ApplyPaidTenantOrderAsync(uniquePayment, "manual-check", CancellationToken);
                    await SENDTENANTSETTLEMENTCHECKRESULTASYNC(botClient, ChatId, order, settlement, CancellationToken);
                    return;
                }

                await botClient.SendMessage(
                    ChatId,
                    errorCode == "provider_not_paid"
                        ? "پرداخت یونیک‌پی هنوز تایید نشده است."
                        : "اطلاعات پرداخت یونیک‌پی با سفارش تطبیق نداشت و سفارش تحویل نشد.",
                    replyMarkup: errorCode == "provider_not_paid"
                        ? BuildTenantPaymentKeyboard(order, uniquePayment.PaymentLink)
                        : null,
                    cancellationToken: CancellationToken);
                return;
            }
            catch (Exception ex)
            {
                uniquePayment.ErrorCode = "provider_inquiry_failed";
                uniquePayment.ErrorMessage = ex.Message;
                uniquePayment.NextInquiryAtUtc = DateTime.UtcNow.AddSeconds(Math.Clamp(
                    _appConfig.UniquePayReconciliationIntervalSeconds,
                    10,
                    3600));
                uniquePayment.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
                _logger.LogWarning(
                    ex,
                    "Tenant UniquePay customer inquiry failed. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}",
                    order.TenantBotId,
                    order.OrderId,
                    uniquePayment.Id);
                await botClient.SendMessage(
                    ChatId,
                    "فعلاً امکان استعلام یونیک‌پی وجود ندارد. کمی بعد دوباره دکمه بررسی وضعیت را بزنید.",
                    replyMarkup: BuildTenantPaymentKeyboard(order, uniquePayment.PaymentLink),
                    cancellationToken: CancellationToken);
                return;
            }
        }

        if (order.TetraminatorPaymentInfoId.HasValue ||
            string.Equals(order.PaymentProvider, "Tetraminator", StringComparison.OrdinalIgnoreCase))
        {
            var tetraminatorPayment = await _workflow.ReadAsync(async db => await db.TetraminatorPaymentInfos.FirstOrDefaultAsync(
                x => x.Id == order.TetraminatorPaymentInfoId || x.TenantBotOrderId == order.Id,
                CancellationToken));
            if (tetraminatorPayment == null || string.IsNullOrWhiteSpace(tetraminatorPayment.PayId))
            {
                await botClient.SendMessage(ChatId, "فاکتور تترامیناتور این سفارش پیدا نشد.", cancellationToken: CancellationToken);
                return;
            }

            try
            {
                var inquiry = await _tetraminator.InquiryAsync(tetraminatorPayment.PayId, CancellationToken);
                tetraminatorPayment.RawResponseJson = JsonConvert.SerializeObject(inquiry);
                tetraminatorPayment.Apply(inquiry);
                var verified = TetraminatorPaymentVerifier.IsVerifiedPaid(tetraminatorPayment, inquiry, out var errorCode);
                tetraminatorPayment.ErrorCode = errorCode;
                tetraminatorPayment.ErrorMessage = verified ? null : errorCode;
                if (verified)
                {
                    tetraminatorPayment.PaymentStatus = TetraminatorStatuses.Paid;
                    tetraminatorPayment.PaidAtUtc ??= DateTime.UtcNow;
                    order.PaymentStatus = TenantBotOrderStatuses.Paid;
                    order.UpdatedAtUtc = DateTime.UtcNow;
                }
                await _workflow.SaveAsync(CancellationToken);

                if (verified)
                {
                    var settlement = await ApplyPaidTenantOrderAsync(tetraminatorPayment, "manual-check", CancellationToken);
                    await SENDTENANTSETTLEMENTCHECKRESULTASYNC(botClient, ChatId, order, settlement, CancellationToken);
                    return;
                }

                await botClient.SendMessage(
                    ChatId,
                    errorCode == "provider_not_paid"
                        ? $"پرداخت هنوز تایید نشده است.\nوضعیت فعلی: <code>{Html(tetraminatorPayment.PaymentStatus)}</code>"
                        : "اطلاعات پرداخت تترامیناتور با سفارش تطبیق نداشت و سفارش تحویل نشد.",
                    parseMode: ParseMode.Html,
                    replyMarkup: BuildTenantPaymentKeyboard(order, tetraminatorPayment.PaymentLink),
                    cancellationToken: CancellationToken);
                return;
            }
            catch (Exception ex)
            {
                tetraminatorPayment.ErrorCode = "provider_inquiry_failed";
                tetraminatorPayment.ErrorMessage = ex.Message;
                tetraminatorPayment.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
                _logger.LogWarning(
                    ex,
                    "Tenant Tetraminator customer inquiry failed. tenantBotId={TenantBotId}, orderId={OrderId}, paymentId={PaymentId}",
                    order.TenantBotId,
                    order.OrderId,
                    tetraminatorPayment.Id);
                await botClient.SendMessage(
                    ChatId,
                    "فعلاً امکان استعلام تترامیناتور وجود ندارد. کمی بعد دوباره دکمه بررسی وضعیت را بزنید.",
                    replyMarkup: BuildTenantPaymentKeyboard(order, tetraminatorPayment.PaymentLink),
                    cancellationToken: CancellationToken);
                return;
            }
        }

        var payment = await _workflow.ReadAsync(async db => await db.HooshPayPaymentInfos.FirstOrDefaultAsync(
            x => x.Id == order.HooshPayPaymentInfoId || x.TenantBotOrderId == order.Id,
            CancellationToken));
        if (payment == null && order.NowPaymentsPaymentInfoId.HasValue)
        {
            var CRYPTOPAYMENT = await _workflow.ReadAsync(async db => await db.SwapinoPaymentInfos.FirstOrDefaultAsync(
                x => x.Id == order.NowPaymentsPaymentInfoId.Value || x.TenantBotOrderId == order.Id,
                CancellationToken));
            if (CRYPTOPAYMENT == null)
            {
                await botClient.SendMessage(ChatId, "فاکتور پرداخت این سفارش پیدا نشد.", cancellationToken: CancellationToken);
                return;
            }

            var Data = CRYPTOPAYMENT.GetNowPaymentsData();
            var status = await _nowPayments.FindPaymentStatusByInvoiceOrOrderAsync(
                Data.InvoiceId,
                CRYPTOPAYMENT.OrderId,
                CancellationToken);
            if (status != null)
            {
                Data.Apply(status);
                CRYPTOPAYMENT.SetNowPaymentsData(Data);
                order.PaymentStatus = NowPaymentsStatuses.IsPaid(Data.PaymentStatus)
                    ? TenantBotOrderStatuses.Paid
                    : TenantBotOrderStatuses.Pending;
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(CancellationToken);
            }

            if (NowPaymentsStatuses.IsPaid(CRYPTOPAYMENT.PaymentStatus))
            {
                var settlement = await ApplyPaidTenantOrderAsync(CRYPTOPAYMENT, "manual-check", CancellationToken);
                await SENDTENANTSETTLEMENTCHECKRESULTASYNC(botClient, ChatId, order, settlement, CancellationToken);
                return;
            }

            await botClient.SendMessage(
                ChatId,
                $"پرداخت هنوز تایید نشده است.\nوضعیت فعلی: <code>{Html(CRYPTOPAYMENT.PaymentStatus)}</code>",
                parseMode: ParseMode.Html,
                replyMarkup: BuildTenantPaymentKeyboard(order, CRYPTOPAYMENT.InvoiceUrl),
                cancellationToken: CancellationToken);
            return;
        }
        if (payment == null || string.IsNullOrWhiteSpace(payment.InvoiceUid))
        {
            await botClient.SendMessage(ChatId, "فاکتور پرداخت این سفارش پیدا نشد.", cancellationToken: CancellationToken);
            return;
        }

        // manual checks REUSE HooshPay Verify, then Run the same fulfillment path as ipn.
        var Verify = await _hooshPay.VerifyInvoiceAsync(payment.InvoiceUid, CancellationToken);
        payment.RawResponseJson = JsonConvert.SerializeObject(Verify);
        payment.Apply(Verify?.data);
        order.PaymentStatus = HooshPayStatuses.IsPaid(payment.PaymentStatus) || Verify?.paid == true
            ? TenantBotOrderStatuses.Paid
            : TenantBotOrderStatuses.Pending;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await _workflow.SaveAsync(CancellationToken);

        if (Verify?.paid == true || HooshPayStatuses.IsPaid(payment.PaymentStatus))
        {
            var settlement = await ApplyPaidTenantOrderAsync(payment, "manual-check", CancellationToken);
            await SENDTENANTSETTLEMENTCHECKRESULTASYNC(botClient, ChatId, order, settlement, CancellationToken);
            return;
        }

        await botClient.SendMessage(
            ChatId,
            $"پرداخت هنوز تایید نشده است.\nوضعیت فعلی: <code>{Html(payment.PaymentStatus)}</code>",
            parseMode: ParseMode.Html,
            replyMarkup: BuildTenantPaymentKeyboard(order, payment),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Checks whether an unfulfilled tenant order is waiting for owner-side card-to-card payment review.
    /// </summary>
    /// <param name="order">
    /// Tenant order selected by the current customer status callback. The order must already be guarded by
    /// tenant bot id and customer Telegram user id before this helper is called.
    /// </param>
    /// <returns>
    /// <c>true</c> when the order uses the tenant owner's card-to-card provider and is still before owner approval;
    /// otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Card-to-card tenant orders do not have a HooshPay or NOWPayments invoice to verify. Until the owner or
    /// Sales Assistant confirms the receipt, customer status checks should keep the receipt upload/status
    /// keyboard visible. Once the receipt is approved, even if XUI fulfillment times out, the customer should see
    /// a post-approval retry message rather than another "waiting for payment" message.
    /// </remarks>
    private static bool IsPendingTenantCardOrder(TenantBotOrder order)
    {
        if (order == null || order.IsFulfilled)
            return false;

        if (!string.Equals(order.PaymentProvider, "tenant_card", StringComparison.OrdinalIgnoreCase))
            return false;

        return string.Equals(order.PaymentStatus, TenantBotOrderStatuses.Pending, StringComparison.OrdinalIgnoreCase) ||
               string.Equals(order.PaymentStatus, TenantBotOrderStatuses.AwaitingReceipt, StringComparison.OrdinalIgnoreCase) ||
               string.Equals(order.PaymentStatus, TenantBotOrderStatuses.ReceiptSubmitted, StringComparison.OrdinalIgnoreCase) ||
               string.Equals(order.PaymentStatus, TenantBotOrderStatuses.ReceiptRejected, StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Sends the customer-facing result after a manual tenant payment-status check triggers fulfillment.
    /// </summary>
    /// <param name="botClient">Tenant bot client that should answer the customer in the current chat.</param>
    /// <param name="chatId">Telegram chat id where the status-check result should be posted.</param>
    /// <param name="order">Tenant order that was checked and may now be fulfilled.</param>
    /// <param name="settlement">
    /// Result returned by the idempotent tenant fulfillment path. <c>Applied</c> means a new account was
    /// created during this check; <c>AlreadyAdded</c> means the order had already been fulfilled.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for Telegram delivery.</param>
    /// <returns>A task that completes after the result message and any safe resend attempt finish.</returns>
    /// <remarks>
    /// The method is notification-only. It never creates XUI accounts, credits/debits wallets, or writes ledger
    /// rows. Duplicate callbacks are handled by resending stored account data when the settlement was already
    /// applied earlier.
    /// </remarks>
    private async Task SENDTENANTSETTLEMENTCHECKRESULTASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        TenantBotOrder order,
        NowPaymentsSettlementResult settlement,
        CancellationToken cancellationToken)
    {
        if (settlement?.Status == NowPaymentsSettlementStatus.Applied)
        {
            await botClient.SendMessage(
                chatId,
                "✅ پرداخت تایید شد و مشخصات اکانت برای شما ارسال شد.",
                cancellationToken: cancellationToken);
            return;
        }

        if (settlement?.Status == NowPaymentsSettlementStatus.AlreadyAdded || order.IsFulfilled)
        {
            await RESENDFULFILLEDTENANTORDERTOCUSTOMERASYNC(botClient, chatId, order, cancellationToken);
            return;
        }

        await botClient.SendMessage(
            chatId,
            "پرداخت تایید شد، اما تکمیل سفارش با خطا روبه‌رو شد. موضوع برای بررسی ثبت شد.",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Replays stored account details for a tenant order that has already been fulfilled.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to post the explanatory status message.</param>
    /// <param name="chatId">Telegram chat id where the customer clicked the status-check button.</param>
    /// <param name="order">Fulfilled tenant order whose stored account details should be resent.</param>
    /// <param name="cancellationToken">Cancellation token for Telegram delivery.</param>
    /// <returns>A task that completes after the resend attempt and status message have finished.</returns>
    /// <remarks>
    /// This is the duplicate-safe path for old payment buttons, repeated manual checks, and callbacks after
    /// IPN or Sales Assistant fulfillment. It does not touch payment status, owner balance, ledger rows, or XUI.
    /// </remarks>
    private async Task RESENDFULFILLEDTENANTORDERTOCUSTOMERASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        TenantBotOrder order,
        CancellationToken cancellationToken)
    {
        var sent = await SENDTENANTORDERACCOUNTDETAILSASYNC(order, sendCustomer: true, sendOwner: false, CancellationToken: cancellationToken);
        await botClient.SendMessage(
            chatId,
            sent
                ? "✅ این سفارش قبلاً تایید شده بود. مشخصات اکانت دوباره برای شما ارسال شد."
                : "✅ این سفارش قبلاً تایید شده بود، اما مشخصات ذخیره‌شده‌ای برای ارسال مجدد پیدا نشد. لطفاً با پشتیبانی تماس بگیرید.",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// marks the customer's newest UNFULFILLED order in the current tenant Bot as Cancelled after A payment-return Cancel.
    /// </summary>
    /// <param name="botClient">Telegram client used to notify the customer.</param>
    /// <param name="ChatId">customer chat Id.</param>
    /// <param name="CustomerTelegramUserId">Telegram User Id of the customer whose pending order is Cancelled.</param>
    /// <param name="CancellationToken">Cancellation Token for database and Telegram work.</param>
    private async Task MARKLATESTCUSTOMERORDERCANCELLEDASYNC(ITelegramBotClient botClient, ChatId ChatId, long CustomerTelegramUserId, CancellationToken CancellationToken)
    {
        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders
            .Where(x => x.TenantBotId == BotContextAccessor.CurrentBotId &&
                        x.CustomerTelegramUserId == CustomerTelegramUserId &&
                        !x.IsFulfilled)
            .OrderByDescending(x => x.CreatedAtUtc)
            .FirstOrDefaultAsync(CancellationToken));

        if (order != null)
        {
            order.PaymentStatus = "cancelled_by_user";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(CancellationToken);
        }

        await botClient.SendMessage(ChatId, "پرداخت توسط کاربر کنسل شد و سفارش بسته شد.", cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Sends the created account details to the tenant customer after fulfillment.
    /// </summary>
    /// <param name="order">fulfilled tenant order containing the target customer chat.</param>
    /// <param name="created">result returned by the XuiV3 purchase service after account creation.</param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <remarks>
    /// Delivery is best-effort and intentionally does not throw back into fulfillment. A Telegram delivery
    /// failure after XUI creation and ledger writes must not mark the already-created order as failed.
    /// </remarks>
    private async Task NOTIFYTENANTCUSTOMERSUCCESSASYNC(TenantBotOrder order, XuiV3AccountCreationResult created, CancellationToken CancellationToken)
    {
        try
        {
            await SENDCREATEDACCOUNTDETAILSASYNC(
                _botClientProvider.GetClient(order.TenantBotId),
                GetTenantCustomerDeliveryChatId(order),
                created,
                CancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Tenant account delivery to customer failed after fulfillment. orderId={OrderId}", order.OrderId);
        }
    }

    /// <summary>
    /// Resends the fulfilled tenant order account details to the buyer and/or the tenant owner.
    /// </summary>
    /// <param name="order">Fulfilled tenant order containing the serialized account creation result.</param>
    /// <param name="sendCustomer">Whether the buyer should receive the account again from the tenant bot.</param>
    /// <param name="sendOwner">Whether the colleague owner should receive the account from the tenant bot.</param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <returns><c>true</c> when account details were available for sending; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// This method never changes wallet, ledger, payment, or XUI state. It only replays stored fulfillment data
    /// and is therefore safe to call after duplicate manual approvals or duplicate Sales Assistant callbacks.
    /// </remarks>
    private async Task<bool> SENDTENANTORDERACCOUNTDETAILSASYNC(
        TenantBotOrder order,
        bool sendCustomer,
        bool sendOwner,
        CancellationToken CancellationToken)
    {
        var created = BUILDCREATEDACCOUNTRESULTFROMORDER(order);
        if (created == null || string.IsNullOrWhiteSpace(created.Email) && string.IsNullOrWhiteSpace(created.SubLink))
            return false;

        if (sendCustomer && TryGetUsableTenantClient(order.TenantBotId, out var tenantClient))
        {
            try
            {
                await SENDCREATEDACCOUNTDETAILSASYNC(tenantClient, GetTenantCustomerDeliveryChatId(order), created, CancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Tenant account resend to customer failed. orderId={OrderId}", order.OrderId);
            }
        }

        if (sendOwner)
        {
            var assistant = _botRegistry.Bots.FirstOrDefault(x =>
                string.Equals(x.Type, BotInstanceTypes.SalesAssistant, StringComparison.OrdinalIgnoreCase));
            if (assistant != null && assistant.Enabled && !string.IsNullOrWhiteSpace(assistant.Token))
            {
                try
                {
                    await _botClientProvider.GetClient(assistant.Id).SendMessage(
                        order.OwnerTelegramUserId,
                        "مشخصات اکانت ساخته‌شده:\n\n" + _purchaseService.BuildCreatedAccountText(created),
                        parseMode: ParseMode.Html,
                        cancellationToken: CancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Tenant account resend to owner through sales assistant failed. orderId={OrderId}", order.OrderId);
                }
            }
        }

        return true;
    }

    private bool IsTenantTransportAvailable(string tenantBotId)
    {
        if (string.IsNullOrWhiteSpace(tenantBotId)) return false;
        var bot = _botRegistry.GetById(tenantBotId);
        return bot != null &&
               string.Equals(bot.Id, tenantBotId, StringComparison.OrdinalIgnoreCase) &&
               bot.Enabled &&
               !string.IsNullOrWhiteSpace(bot.Token);
    }

    private bool TryGetUsableTenantClient(string tenantBotId, out ITelegramBotClient client)
    {
        client = null;
        if (!IsTenantTransportAvailable(tenantBotId)) return false;
        try
        {
            client = _botClientProvider.GetClient(tenantBotId);
            return true;
        }
        catch (BotTransportUnavailableException)
        {
            return false;
        }
    }

    /// <summary>
    /// Resolves the best Telegram chat id for sending tenant order details to the buyer.
    /// </summary>
    /// <param name="order">
    /// Tenant order that stores both the original customer chat id and the numeric Telegram user id.
    /// </param>
    /// <returns>
    /// The original customer chat id when it is available; otherwise the buyer's Telegram user id as a private
    /// chat fallback.
    /// </returns>
    /// <remarks>
    /// Older or manually-created tenant orders may have <see cref="TenantBotOrder.CustomerChatId"/> unset.
    /// Telegram private chat ids normally match user ids, so the fallback lets duplicate checks and manual
    /// confirmations still deliver account details without changing order or wallet state.
    /// </remarks>
    private static ChatId GetTenantCustomerDeliveryChatId(TenantBotOrder order)
    {
        return order.CustomerChatId == 0 ? order.CustomerTelegramUserId : order.CustomerChatId;
    }

    /// <summary>
    /// Sends one created account result as text or QR photo to a Telegram chat.
    /// </summary>
    /// <param name="botClient">Telegram bot client that should send the account details.</param>
    /// <param name="chatId">Target Telegram chat id for the buyer or tenant owner.</param>
    /// <param name="created">Stored account creation result.</param>
    /// <param name="CancellationToken">Cancellation token for Telegram delivery.</param>
    /// <remarks>
    /// When a subscription link exists, the QR is regenerated locally from the stored link. No panel call is made.
    /// </remarks>
    private async Task SENDCREATEDACCOUNTDETAILSASYNC(
        ITelegramBotClient botClient,
        ChatId chatId,
        XuiV3AccountCreationResult created,
        CancellationToken CancellationToken)
    {
        var Text = _purchaseService.BuildCreatedAccountText(created);
        if (!string.IsNullOrWhiteSpace(created.SubLink))
        {
            using var qrStream = new MemoryStream(QrCodeGen.GenerateQRCodeWithMargin(created.SubLink, 200));
            await botClient.SendPhoto(
                chatId: chatId,
                photo: InputFile.FromStream(qrStream, "subscription-qr.png"),
                caption: Text,
                parseMode: ParseMode.Html,
                cancellationToken: CancellationToken);
            return;
        }

        await botClient.SendMessage(chatId, Text, parseMode: ParseMode.Html, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Rebuilds a minimal account creation result from stored tenant order fulfillment fields.
    /// </summary>
    /// <param name="order">Fulfilled tenant order that stores account JSON and fallback account fields.</param>
    /// <returns>
    /// A successful account creation result suitable for display, or <c>null</c> when the order has no stored
    /// account identity.
    /// </returns>
    private static XuiV3AccountCreationResult BUILDCREATEDACCOUNTRESULTFROMORDER(TenantBotOrder order)
    {
        XuiV3AccountCreationResult created = null;
        if (!string.IsNullOrWhiteSpace(order?.CreatedAccountJson))
        {
            try
            {
                created = JsonConvert.DeserializeObject<XuiV3AccountCreationResult>(order.CreatedAccountJson);
            }
            catch
            {
                created = null;
            }
        }

        created ??= new XuiV3AccountCreationResult();
        created.Success = true;
        if (string.IsNullOrWhiteSpace(created.Email))
            created.Email = order?.CreatedAccountEmail;
        if (string.IsNullOrWhiteSpace(created.SubLink))
            created.SubLink = order?.CreatedSubLink;

        return string.IsNullOrWhiteSpace(created.Email) && string.IsNullOrWhiteSpace(created.SubLink)
            ? null
            : created;
    }

    /// <summary>
    /// NOTIFIES the customer that payment was accepted but account creation failed and must be reviewed.
    /// </summary>
    /// <param name="order">tenant order whose customer should be notified.</param>
    /// <param name="Error">internal Error Text kept for diagnostics; it is not EXPOSED VERBATIM to the customer.</param>
    /// <param name="CancellationToken">Cancellation Token for Telegram delivery.</param>
    private async Task NOTIFYTENANTCUSTOMERFAILUREASYNC(TenantBotOrder order, string Error, CancellationToken CancellationToken)
    {
        try
        {
            await _botClientProvider.GetClient(order.TenantBotId).SendMessage(
                order.CustomerChatId,
                "پرداخت شما تایید شد، اما ساخت اکانت با خطا روبه‌رو شد. موضوع برای بررسی ثبت شد.",
                cancellationToken: CancellationToken);
        }
        catch
        {
        }
    }

    /// <summary>
    /// Notifies a tenant customer that payment is accepted but XUI account delivery is waiting for a retry.
    /// </summary>
    /// <param name="order">
    /// Tenant order whose payment or manual receipt has already been accepted. The order remains unfulfilled and
    /// must keep enough state for the tenant owner or payment checker to retry the same fulfillment path.
    /// </param>
    /// <param name="Error">
    /// Internal timeout text recorded for operators. The raw value is not shown to the customer because it may
    /// contain infrastructure details from the XUI panel or HTTP stack.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for the best-effort Telegram notification.</param>
    /// <returns>A task that completes after the notification is sent or skipped.</returns>
    /// <remarks>
    /// A panel timeout is not treated as a definitive account-creation failure. The order stays in a retryable
    /// approved state so Sales Assistant callbacks can attempt fulfillment again without creating wallet or ledger
    /// changes until the XUI account is actually created.
    /// </remarks>
    private async Task NOTIFYTENANTCUSTOMERRETRYABLEFULFILLMENTASYNC(TenantBotOrder order, string Error, CancellationToken CancellationToken)
    {
        try
        {
            await _botClientProvider.GetClient(order.TenantBotId).SendMessage(
                GetTenantCustomerDeliveryChatId(order),
                "✅ پرداخت شما تایید شد، اما پنل ساخت اکانت در این لحظه پاسخ نداد. سفارش برای تلاش مجدد ثبت شد و پس از ساخت موفق، مشخصات اکانت برای شما ارسال می‌شود.",
                cancellationToken: CancellationToken);
        }
        catch
        {
        }
    }

    /// <summary>
    /// Applies the tenant owner's financial settlement for a fulfilled tenant purchase or renewal.
    /// </summary>
    /// <param name="order">
    /// Tenant order that has already succeeded on the XUI panel and is about to be marked fulfilled locally.
    /// </param>
    /// <param name="owner">
    /// Credentials row for the colleague who owns the tenant storefront. The method refreshes
    /// <see cref="CredUser.AccountBalance"/> after any bot-wallet mutation.
    /// </param>
    /// <param name="debitOwnerBaseCost">
    /// <c>true</c> for card-to-card flows where the owner received the customer money and must pay base cost;
    /// <c>false</c> for platform gateways where the owner should receive profit.
    /// </param>
    /// <param name="referenceType">
    /// Ledger reference type, such as <c>tenant-order</c> or <c>tenant-renew-order</c>, used to identify the
    /// fulfilled local order in wallet history.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for credentials, site-wallet, and ledger operations.</param>
    /// <returns>
    /// Settlement result containing bot-wallet before/after values, optional Gozargah website wallet before/after
    /// values, selected wallet source, owner delta, and any warning that should be shown to the owner.
    /// </returns>
    /// <remarks>
    /// Card-to-card settlement is intentionally ordered: debit the owner's bot wallet when it can cover the base
    /// cost, otherwise debit the Gozargah website wallet only when it is connected and sufficient, otherwise allow
    /// the owner's bot wallet to go negative and warn the owner. Platform-gateway settlement never debits the site
    /// wallet; it only credits tenant profit to the bot wallet and records a live site-wallet snapshot for audit logs.
    /// A durable per-order route pins the funding source before any debit. Remote uncertainty never authorizes
    /// compensation; owner admission covers only settlement, outside provisioning and SQLite transactions.
    /// </remarks>
    /// <exception cref="SiteWalletDebitUncertainException">The website debit needs reconciliation; no second wallet may be charged.</exception>
    /// <exception cref="InvalidOperationException">The owner, amount, funding intent or required local receipt does not match the order.</exception>
    private async Task<TenantOwnerWalletSettlementResult> SETTLETENANTOWNERWALLETASYNC(
        TenantBotOrder order,
        CredUser owner,
        bool debitOwnerBaseCost,
        string referenceType,
        CancellationToken cancellationToken)
    {
        if (owner?.TelegramUserId != order.OwnerTelegramUserId)
            throw new InvalidOperationException("Tenant settlement requires the order's shared wallet owner.");
        using var ownerAdmission = await OwnerSettlementGate.EnterAsync(order.OwnerTelegramUserId.ToString(CultureInfo.InvariantCulture), cancellationToken);
        var botBefore = await _credentialsDbContext.GetAccountBalance(order.OwnerTelegramUserId);
        owner.AccountBalance = botBefore;
        var siteBefore = await GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(order.OwnerTelegramUserId, cancellationToken);

        if (!debitOwnerBaseCost)
        {
            var ownerDelta = order.ProfitToman;
            if (ownerDelta > 0)
                await _credentialsDbContext.AddFund(order.OwnerTelegramUserId, ownerDelta, $"tenant:{order.Id}:profit");
            var profitReceipt = await _credentialsDbContext.GetWalletOperationAsync($"tenant:{order.Id}:profit", cancellationToken);
            if (ownerDelta > 0 && profitReceipt == null) throw new InvalidOperationException("Owner profit receipt is missing.");
            botBefore = profitReceipt?.BeforeBalance ?? botBefore;
            var botAfter = profitReceipt?.AfterBalance ?? botBefore;
            owner.AccountBalance = botAfter;
            var siteAfter = await GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(order.OwnerTelegramUserId, cancellationToken);

            await RECORDTENANTOWNERWALLETLEDGERASYNC(
                order,
                WalletLedgerDirections.Credit,
                ownerDelta,
                botBefore,
                botAfter,
                WalletLedgerReasons.TenantGatewayProfit,
                provider: order.PaymentProvider,
                referenceType,
                description: "سود فروش tenant با درگاه پلتفرم",
                cancellationToken);

            return TenantOwnerWalletSettlementResult.Create(
                TenantOwnerWalletSources.PlatformGatewayProfit,
                ownerDelta,
                botBefore,
                botAfter,
                siteBefore,
                siteAfter);
        }

        var route = await _workflow.ReadAsync(db => db.Set<TenantWalletRoute>().AsNoTracking().SingleOrDefaultAsync(x => x.Id == order.Id, cancellationToken));
        if (route == null)
        {
            // A legacy committed local receipt takes priority over today's balance, preventing source switching on restart.
            var receipt = await _credentialsDbContext.GetWalletOperationAsync($"tenant:{order.Id}:base-cost", cancellationToken);
            var source = receipt != null || botBefore >= order.BaseCostToman ? "bot"
                : (await _gozargahSiteSyncService.CheckSiteWalletEligibilityAsync(order.OwnerTelegramUserId, order.BaseCostToman, cancellationToken)).CanUse ? "site" : "negative";
            route = await _workflow.WriteAsync(async db =>
            {
                var row = new TenantWalletRoute { Id = order.Id, OwnerTelegramUserId = order.OwnerTelegramUserId, AmountToman = order.BaseCostToman, Source = source };
                db.Add(row);
                await db.SaveChangesAsync(cancellationToken);
                return row;
            }, cancellationToken);
        }
        if (route.OwnerTelegramUserId != order.OwnerTelegramUserId || route.AmountToman != order.BaseCostToman)
            throw new InvalidOperationException("Tenant settlement identity conflicts with its funding intent.");
        var routeSource = route.Source;
        if (routeSource == "review")
        {
            var existingDebit = await _credentialsDbContext.GetWalletOperationAsync($"tenant:{order.Id}:base-cost", cancellationToken);
            if (existingDebit == null) throw new SiteWalletDebitUncertainException($"legacy-tenant:{order.Id}");
            if (existingDebit.TelegramUserId != order.OwnerTelegramUserId || existingDebit.AmountToman != -order.BaseCostToman)
                throw new InvalidOperationException("Historical funding receipt conflicts with the tenant order.");
            await _workflow.WriteAsync(db => db.Set<TenantWalletRoute>().Where(x => x.Id == order.Id && x.Source == "review")
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.Source, "bot"), cancellationToken), cancellationToken);
            routeSource = "bot";
        }
        if (routeSource is not ("bot" or "site" or "negative")) throw new InvalidOperationException("Unknown tenant funding source.");

        if (routeSource == "bot")
        {
            await _credentialsDbContext.Pay(owner, order.BaseCostToman, $"tenant:{order.Id}:base-cost");
            var debitReceipt = await _credentialsDbContext.GetWalletOperationAsync($"tenant:{order.Id}:base-cost", cancellationToken)
                ?? throw new InvalidOperationException("Owner debit receipt is missing.");
            botBefore = debitReceipt.BeforeBalance;
            var botAfter = debitReceipt.AfterBalance;
            owner.AccountBalance = botAfter;
            var siteAfter = await GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(order.OwnerTelegramUserId, cancellationToken);

            await RECORDTENANTOWNERWALLETLEDGERASYNC(
                order,
                WalletLedgerDirections.Debit,
                order.BaseCostToman,
                botBefore,
                botAfter,
                WalletLedgerReasons.TenantCardBaseCost,
                provider: order.PaymentProvider,
                referenceType,
                description: "کسر هزینه پایه فروش کارت‌به‌کارت tenant از کیف پول ربات",
                cancellationToken);

            return TenantOwnerWalletSettlementResult.Create(
                TenantOwnerWalletSources.BotWallet,
                -order.BaseCostToman,
                botBefore,
                botAfter,
                siteBefore,
                siteAfter);
        }

        if (routeSource == "site")
        {
            var siteDebit = await _gozargahSiteSyncService.DeductSiteWalletAfterPanelSuccessAsync(
                order.OwnerTelegramUserId,
                order.BaseCostToman,
                "tenant-base-cost",
                order.Id.ToString(CultureInfo.InvariantCulture),
                $"Tenant card base cost: {order.OrderId}",
                cancellationToken);
            if (siteDebit.Success)
            {
                var botAfter = await _credentialsDbContext.GetAccountBalance(order.OwnerTelegramUserId);
                owner.AccountBalance = botAfter;
                var siteDebitBefore = TenantSiteWalletSnapshot.Connected(siteDebit.BeforeWallet);
                var siteDebitAfter = TenantSiteWalletSnapshot.Connected(siteDebit.AfterWallet);

                await RECORDTENANTOWNERWALLETLEDGERASYNC(
                    order,
                    WalletLedgerDirections.Debit,
                    order.BaseCostToman,
                    siteDebit.BeforeWallet,
                    siteDebit.AfterWallet,
                    WalletLedgerReasons.TenantCardBaseCost,
                    provider: "gozargah_site_wallet",
                    referenceType,
                    description: "کسر هزینه پایه فروش کارت‌به‌کارت tenant از کیف پول سایت گذرگاه",
                    cancellationToken);

                return TenantOwnerWalletSettlementResult.Create(
                    TenantOwnerWalletSources.GozargahSiteWallet,
                    -order.BaseCostToman,
                    botBefore,
                    botAfter,
                    siteDebitBefore,
                    siteDebitAfter);
            }
            // Failure here means the owner eligibility check prevented the POST. Attempted/ambiguous debits throw.
            await _workflow.WriteAsync(db => db.Set<TenantWalletRoute>().Where(x => x.Id == order.Id && x.Source == "site")
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.Source, "negative"), cancellationToken), cancellationToken);
        }

        await _credentialsDbContext.Pay(owner, order.BaseCostToman, $"tenant:{order.Id}:base-cost");
        var negativeReceipt = await _credentialsDbContext.GetWalletOperationAsync($"tenant:{order.Id}:base-cost", cancellationToken)
            ?? throw new InvalidOperationException("Owner overdraft receipt is missing.");
        botBefore = negativeReceipt.BeforeBalance;
        var negativeBotAfter = negativeReceipt.AfterBalance;
        owner.AccountBalance = negativeBotAfter;
        var negativeSiteAfter = await GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(order.OwnerTelegramUserId, cancellationToken);
        var warning =
            "⚠️ موجودی کیف پول ربات شما برای هزینه پایه کافی نبود و کیف پول سایت گذرگاه هم قابل استفاده نبود. " +
            "هزینه پایه از کیف پول ربات کسر شد و موجودی شما منفی شد. لطفاً موجودی را افزایش دهید؛ در غیر اینصورت اکانت مشتری ممکن است غیرفعال شود.";

        await RECORDTENANTOWNERWALLETLEDGERASYNC(
            order,
            WalletLedgerDirections.Debit,
            order.BaseCostToman,
            botBefore,
            negativeBotAfter,
            WalletLedgerReasons.TenantCardBaseCost,
            provider: order.PaymentProvider,
            referenceType,
            description: "کسر هزینه پایه فروش کارت‌به‌کارت tenant با منفی شدن کیف پول ربات",
            cancellationToken);

        return TenantOwnerWalletSettlementResult.Create(
            TenantOwnerWalletSources.NegativeBotWallet,
            -order.BaseCostToman,
            botBefore,
            negativeBotAfter,
            siteBefore,
            negativeSiteAfter,
            warning);
    }

    /// <summary>
    /// Records the wallet ledger row for a tenant owner settlement.
    /// </summary>
    /// <param name="order">Tenant order that caused the financial movement.</param>
    /// <param name="direction">Ledger direction, credit or debit.</param>
    /// <param name="amountToman">Positive amount in toman to record. Zero values are ignored by the ledger service.</param>
    /// <param name="beforeBalance">Balance of the selected wallet before the movement.</param>
    /// <param name="afterBalance">Balance of the selected wallet after the movement.</param>
    /// <param name="reason">Business reason key used by wallet history and admin audit.</param>
    /// <param name="provider">Provider/source key, for example <c>tenant_card</c> or <c>gozargah_site_wallet</c>.</param>
    /// <param name="referenceType">Local reference type for the order.</param>
    /// <param name="description">Human-readable audit description.</param>
    /// <param name="cancellationToken">Cancellation token for users.db insert.</param>
    /// <returns>A task that completes after the ledger row is saved or skipped for a zero amount.</returns>
    /// <remarks>The order is scoped to its tenant and reloaded under an order-specific gate. Wallet receipt keys are derived from that durable order identity.</remarks>
    private Task RECORDTENANTOWNERWALLETLEDGERASYNC(
        TenantBotOrder order,
        string direction,
        long amountToman,
        long beforeBalance,
        long afterBalance,
        string reason,
        string provider,
        string referenceType,
        string description,
        CancellationToken cancellationToken)
    {
        return _walletLedgerService.RecordAsync(
            order.OwnerTelegramUserId,
            direction,
            amountToman,
            beforeBalance,
            afterBalance,
            reason,
            provider: provider,
            referenceType: referenceType,
            referenceId: order.Id.ToString(CultureInfo.InvariantCulture),
            orderId: order.OrderId,
            description: description,
            ownerTelegramUserId: order.OwnerTelegramUserId,
            counterpartyTelegramUserId: order.CustomerTelegramUserId,
            botId: order.TenantBotId,
            botUsername: order.TenantBotUsername,
            botType: BotInstanceTypes.Tenant,
            idempotencyKey: provider == "gozargah_site_wallet" ? $"tenant:{order.Id}:site-base-cost"
                : direction == WalletLedgerDirections.Credit ? $"tenant:{order.Id}:profit" : $"tenant:{order.Id}:base-cost",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Reads a display-only Gozargah website wallet snapshot for tenant owner audit logs.
    /// </summary>
    /// <param name="ownerTelegramUserId">Telegram user id of the tenant owner whose website wallet should be checked.</param>
    /// <param name="cancellationToken">Cancellation token for the site-wallet eligibility lookup.</param>
    /// <returns>
    /// A snapshot containing either the current site-wallet balance or a short display status such as
    /// <c>متصل نشده</c> or <c>در دسترس نیست</c>.
    /// </returns>
    /// <remarks>
    /// The lookup uses an amount of zero so it never reserves or debits money. It is used only for logs and owner
    /// messages; actual site-wallet debits still call the dedicated debit endpoint after account delivery succeeds.
    /// </remarks>
    private async Task<TenantSiteWalletSnapshot> GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(
        long ownerTelegramUserId,
        CancellationToken cancellationToken)
    {
        try
        {
            var eligibility = await _gozargahSiteSyncService.CheckSiteWalletEligibilityAsync(
                ownerTelegramUserId,
                0,
                cancellationToken);

            if (eligibility.User != null ||
                eligibility.CanUse ||
                string.Equals(eligibility.Message, "موجودی کیف پول سایت کافی نیست.", StringComparison.OrdinalIgnoreCase))
            {
                return TenantSiteWalletSnapshot.Connected(eligibility.WalletToman);
            }

            return TenantSiteWalletSnapshot.Unavailable(NORMALIZEGOZARGAHSITEWALLETSTATUS(eligibility.Message));
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Tenant owner site-wallet snapshot failed. owner={OwnerTelegramUserId}", ownerTelegramUserId);
            return TenantSiteWalletSnapshot.Unavailable("در دسترس نیست");
        }
    }

    /// <summary>
    /// Normalizes website wallet lookup messages for tenant audit display.
    /// </summary>
    /// <param name="message">Raw user-facing message returned by the Gozargah wallet eligibility helper.</param>
    /// <returns>A short Persian status safe for tenant sale logs.</returns>
    private static string NORMALIZEGOZARGAHSITEWALLETSTATUS(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return "در دسترس نیست";

        return message.Contains("not found", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("HTTP 404", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("پیدا نشد", StringComparison.OrdinalIgnoreCase)
            ? "متصل نشده"
            : "در دسترس نیست";
    }

    /// <summary>
    /// Detects XUI or HTTP timeout errors that should keep tenant fulfillment retryable.
    /// </summary>
    /// <param name="error">
    /// Exception or message returned by the XUI creation path. It may be a <see cref="TaskCanceledException"/>,
    /// <see cref="TimeoutException"/>, Telegram request timeout, or plain provider message.
    /// </param>
    /// <returns>
    /// <c>true</c> when the error indicates an external timeout and the order should remain retryable; otherwise
    /// <c>false</c> for definitive validation or business failures.
    /// </returns>
    /// <remarks>
    /// This helper deliberately does not classify every exception as retryable. Duplicate-safe retry is only offered
    /// for timeout-style failures where the payment is accepted but the panel did not answer in time.
    /// </remarks>
    private static bool IsTenantFulfillmentTimeout(object error)
    {
        if (error is TimeoutException || error is TaskCanceledException)
            return true;

        var message = error switch
        {
            Exception ex => ex.Message,
            string text => text,
            _ => null
        } ?? string.Empty;

        return message.Contains("HttpClient.Timeout", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("request timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("timed out", StringComparison.OrdinalIgnoreCase) ||
               message.Contains("A task was canceled", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// NOTIFIES the colleague owner through the default Bot that A tenant storefront sale was completed.
    /// </summary>
    /// <param name="order">fulfilled tenant order with sale, cost, profit, and balance fields.</param>
    /// <param name="owner">Credential record for the colleague who owns the tenant Bot.</param>
    /// <param name="customer">Credential record for the Buyer.</param>
    /// <param name="CancellationToken">Cancellation Token for Telegram delivery.</param>
    /// <param name="settlement">
    /// Optional settlement details used to show which wallet paid or received money. Null is allowed for legacy
    /// callers and shows only the order's persisted bot-wallet balances.
    /// </param>
    private async Task NOTIFYTENANTOWNERSUCCESSASYNC(
        TenantBotOrder order,
        CredUser owner,
        CredUser customer,
        CancellationToken CancellationToken,
        TenantOwnerWalletSettlementResult settlement = null)
    {
        try
        {
            var settlementText = settlement == null
                ? string.Empty
                : "\n" +
                  $"منبع تسویه: <code>{Html(settlement.SourceDisplayName)}</code>\n" +
                  $"کیف پول سایت قبل: <code>{Html(FormatTenantSiteWalletSnapshot(settlement.SiteWalletBefore))}</code>\n" +
                  $"کیف پول سایت بعد: <code>{Html(FormatTenantSiteWalletSnapshot(settlement.SiteWalletAfter))}</code>" +
                  (string.IsNullOrWhiteSpace(settlement.WarningMessage) ? string.Empty : $"\n\n{Html(settlement.WarningMessage)}");

            var botClient = _botClientProvider.GetClient(_botRegistry.DefaultBot.Id);
            await botClient.SendMessage(
                owner.ChatID == 0 ? owner.TelegramUserId : owner.ChatID,
                "✅ فروش ربات فروشگاهی انجام شد.\n\n" +
                $"ربات: @{Html(order.TenantBotUsername)}\n" +
                $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n" +
                $"مبلغ فروش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
                $"هزینه همکار: <code>{Html(order.BaseCostToman.FormatCurrency())}</code>\n" +
                $"سود اضافه‌شده به موجودی شما: <code>{Html(order.ProfitToman.FormatCurrency())}</code>\n" +
                $"موجودی قبل: <code>{Html(order.OwnerBalanceBefore?.FormatCurrency())}</code>\n" +
                $"موجودی بعد: <code>{Html(order.OwnerBalanceAfter?.FormatCurrency())}</code>" +
                settlementText,
                parseMode: ParseMode.Html,
                cancellationToken: CancellationToken);
        }
        catch
        {
        }
    }

    /// <summary>
    /// Writes the operational payment/account log for a tenant storefront order.
    /// </summary>
    /// <param name="order">Tenant-scoped order supplying plan, bot, provider, and amount context.</param>
    /// <param name="owner">Colleague owner whose Telegram identity and settlement balance appear in the audit.</param>
    /// <param name="customer">Customer who paid for or requested the tenant order.</param>
    /// <param name="Source">Non-secret settlement source such as IPN, manual check, or exception path.</param>
    /// <param name="result">Coarse final result of the current order-processing attempt.</param>
    /// <param name="settlement">
    /// Optional owner settlement result. Successful tenant fulfillment passes this value so the audit log can show
    /// bot-wallet and Gozargah website-wallet before/after values without adding new database columns.
    /// </param>
    /// <param name="timing">
    /// Optional panel-API and end-to-end duration snapshot for create or renewal fulfillment. Payment-only order logs
    /// pass null because waiting for a gateway is not an XUI activity and must not be reported as API latency.
    /// </param>
    /// <remarks>
    /// The method sends an HTML audit and does not itself mutate the order, wallets, ledger, payment, or XUI panel.
    /// The persisted customer payment provider is rendered separately from the owner's settlement source.
    /// UUID locks, subscription identifiers, configuration links, provider bodies, and tokens are excluded.
    /// </remarks>
    private void LOGTENANTORDER(
        TenantBotOrder order,
        CredUser owner,
        CredUser customer,
        string Source,
        string result,
        TenantOwnerWalletSettlementResult settlement = null,
        XuiOperationTimingSnapshot? timing = null,
        TimeSpan? notificationQueueElapsed = null)
    {
        var settlementText = settlement == null
            ? string.Empty
            : $"منبع تسویه همکار: <code>{Html(settlement.SourceDisplayName)}</code>\n" +
              $"کیف پول ربات قبل: <code>{Html(settlement.BotWalletBefore.FormatCurrency())}</code>\n" +
              $"کیف پول ربات بعد: <code>{Html(settlement.BotWalletAfter.FormatCurrency())}</code>\n" +
              $"کیف پول سایت قبل: <code>{Html(FormatTenantSiteWalletSnapshot(settlement.SiteWalletBefore))}</code>\n" +
              $"کیف پول سایت بعد: <code>{Html(FormatTenantSiteWalletSnapshot(settlement.SiteWalletAfter))}</code>\n" +
              (string.IsNullOrWhiteSpace(settlement.WarningMessage)
                  ? string.Empty
                  : $"هشدار: <code>{Html(settlement.WarningMessage)}</code>\n");

        var Message = "📌 فروش ربات فروشگاهی\n\n" +
                      $"نتیجه: <code>{Html(result)}</code>\n" +
                      $"منبع تایید: <code>{Html(Source)}</code>\n" +
                      $"روش پرداخت مشتری: <code>{TenantPaymentProviderLabel(order.PaymentProvider)}</code>\n" +
                      $"ربات tenant: <code>{Html(order.TenantBotId)}</code> @{Html(order.TenantBotUsername)}\n\n" +
                      BuildTenantBotPurchaseLogContext(order) +
                      "📌 مالک فروشگاه\n" +
                      $"{TelegramUserLinkFormatter.HtmlSummary(owner)}\n\n" +
                      "📌 مشتری\n" +
                      $"{TelegramUserLinkFormatter.HtmlSummary(customer)}\n\n" +
                      $"order Id: <code>{Html(order.OrderId)}</code>\n" +
                      $"فروش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
                      $"هزینه پایه: <code>{Html(order.BaseCostToman.FormatCurrency())}</code>\n" +
                      $"سود همکار: <code>{Html(order.ProfitToman.FormatCurrency())}</code>\n" +
                      settlementText +
                      $"اکانت: <code>{Html(order.CreatedAccountEmail)}</code>" +
                      BuildTenantOrderErrorLine(order) +
                      (timing.HasValue
                          ? "\n\n" + (notificationQueueElapsed.HasValue
                              ? BUILDTENANTFULFILLMENTTIMINGHTML(timing.Value, notificationQueueElapsed.Value)
                              : XuiOperationTiming.BuildHtmlLines(timing.Value))
                          : string.Empty);

        _logger.LogPayment(Message);
    }


    internal static string BUILDTENANTFULFILLMENTTIMINGHTML(XuiOperationTimingSnapshot timing, TimeSpan notificationQueueElapsed)
    {
        return $"زمان API پنل: <code>{XuiOperationTiming.Format(timing.PanelApiElapsed)}</code>\n" +
               $"زمان هسته عملیات تا ثبت پایدار: <code>{XuiOperationTiming.Format(timing.TotalElapsed)}</code>\n" +
               $"زمان ثبت/صف اعلان‌ها: <code>{XuiOperationTiming.Format(notificationQueueElapsed)}</code>";
    }

    private void LOGTENANTFULFILLMENTTIMING(TenantBotOrder order, XuiOperationTimingSnapshot coreTiming, TimeSpan notificationQueueElapsed, TimeSpan callbackTotal)
    {
        _logger.LogInformation(
            "Tenant fulfillment timing. orderId={OrderId} panelApiMs={PanelApiMs:0} coreFulfillmentMs={CoreFulfillmentMs:0} notificationQueueMs={NotificationQueueMs:0} callbackTotalMs={CallbackTotalMs:0}",
            order.OrderId,
            coreTiming.PanelApiElapsed.TotalMilliseconds,
            coreTiming.TotalElapsed.TotalMilliseconds,
            notificationQueueElapsed.TotalMilliseconds,
            callbackTotal.TotalMilliseconds);
    }

    /// <summary>Maps the persisted order gateway to a safe customer-payment label for purchase and renewal logs.</summary>
    /// <param name="provider">Nullable provider key from the tenant order, never a credential.</param>
    /// <returns>A fixed display label; unknown values are not echoed into logs.</returns>
    /// <remarks>This is presentation only and does not identify or change the owner's funding source.</remarks>
    /// <example><code>var label = TenantPaymentProviderLabel(order.PaymentProvider);</code></example>
    private static string TenantPaymentProviderLabel(string provider) => provider?.Trim().ToLowerInvariant() switch
    {
        "tenant_card" => "کارت‌به‌کارت شخصی فروشگاه",
        "hooshpay" => "هوش‌پی",
        "tetraminator" => "تترامیناتور",
        "nowpayments" or "swapino" => "NOWPayments",
        "uniquepay" => "یونیک‌پی",
        _ => "نامشخص"
    };

    /// <summary>
    /// Formats a Gozargah website wallet snapshot for tenant owner messages and private audit logs.
    /// </summary>
    /// <param name="snapshot">
    /// Snapshot returned by <see cref="GETTENANTOWNERSITEWALLETSNAPSHOTASYNC(long, CancellationToken)"/> or by a
    /// successful website-wallet debit.
    /// </param>
    /// <returns>
    /// Formatted balance in toman when the website wallet is connected; otherwise a short status such as
    /// <c>متصل نشده</c> or <c>در دسترس نیست</c>.
    /// </returns>
    private static string FormatTenantSiteWalletSnapshot(TenantSiteWalletSnapshot snapshot)
    {
        if (snapshot?.IsConnected == true)
            return snapshot.WalletToman.GetValueOrDefault().FormatCurrency();

        return string.IsNullOrWhiteSpace(snapshot?.StatusText) ? "در دسترس نیست" : snapshot.StatusText;
    }

    /// <summary>
    /// Clears stale tenant-order fulfillment errors after an order is successfully delivered.
    /// </summary>
    /// <param name="order">
    /// Tracked tenant order that has just been marked fulfilled. The method clears the order error and, when a
    /// manual receipt is linked, clears the tracked receipt error as well.
    /// </param>
    /// <param name="CancellationToken">
    /// Cancellation token for the optional receipt lookup in users.db.
    /// </param>
    /// <returns>
    /// A task that completes after the tracked order and optional receipt have been updated in memory. The caller
    /// remains responsible for the surrounding <see cref="DbContext.SaveChangesAsync(CancellationToken)" /> call.
    /// </returns>
    /// <remarks>
    /// Tenant fulfillment can time out on the first attempt and later succeed from a retry, owner confirmation, or
    /// super-admin recovery path. This helper prevents that old timeout text from appearing in successful order
    /// details, Sales Assistant details, or central purchase logs after the account is actually delivered.
    /// </remarks>
    private async Task CLEARTENANTORDERFULFILLMENTERRORASYNC(
        TenantBotOrder order,
        CancellationToken CancellationToken)
    {
        order.ErrorMessage = null;

        var receipt = order.ManualReceiptId.HasValue
            ? await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(
                x => x.Id == order.ManualReceiptId.Value,
                CancellationToken))
            : await _workflow.ReadAsync(async db => await db.TenantManualPaymentReceipts.FirstOrDefaultAsync(
                x => x.TenantBotOrderId == order.Id || x.OrderId == order.OrderId,
                CancellationToken));

        if (receipt != null)
            receipt.ErrorMessage = null;
    }

    /// <summary>
    /// Builds the optional HTML error line for tenant order detail and audit messages.
    /// </summary>
    /// <param name="order">
    /// Tenant order whose latest delivery state controls whether an error should be displayed.
    /// </param>
    /// <returns>
    /// An HTML-safe line break plus error text when the order is still unfulfilled and has an error; otherwise an
    /// empty string so stale timeout errors are hidden after successful fulfillment.
    /// </returns>
    /// <remarks>
    /// Financial and fulfillment logs should not keep showing historical timeout text once a later retry has
    /// delivered the account. Failure paths still show the latest error for troubleshooting.
    /// </remarks>
    private static string BuildTenantOrderErrorLine(TenantBotOrder order)
    {
        return order.IsFulfilled || string.IsNullOrWhiteSpace(order.ErrorMessage)
            ? string.Empty
            : $"\nخطا: <code>{Html(order.ErrorMessage)}</code>";
    }

    /// <summary>
    /// Attempts to enqueue one Gozargah lifecycle event without changing the durable tenant-order outcome.
    /// </summary>
    /// <param name="operation">Short operation label used only for bounded diagnostics.</param>
    /// <param name="enqueue">Outbox enqueue/send delegate for the already-fulfilled account operation.</param>
    /// <returns>A task that completes after the best-effort enqueue attempt.</returns>
    /// <remarks>
    /// Account creation, renewal, settlement, and ledger writes are durable before this method is called. A database,
    /// API, timeout, or cancellation failure while recording the optional website mirror must therefore be isolated;
    /// the existing Gozargah retry worker can recover rows that were persisted successfully.
    /// </remarks>
    private static IReadOnlyList<string> GETTENANTORDERNOTIFICATIONKINDS(bool includeOwnerAccountDetails)
    {
        var kinds = new List<string>
        {
            TenantOrderNotificationKinds.CustomerAccountDelivery,
            TenantOrderNotificationKinds.OwnerSaleNotification,
            TenantOrderNotificationKinds.SalesAssistantSaleNotification
        };
        if (includeOwnerAccountDetails) kinds.Add(TenantOrderNotificationKinds.OwnerAccountDetailsAfterAssistantFinal);
        return kinds;
    }

    private void ADDTENANTORDERNOTIFICATIONINTENTSFORCOMMIT(TenantBotOrder order, bool includeOwnerAccountDetails)
    {
        var now = DateTime.UtcNow;
        foreach (var kind in GETTENANTORDERNOTIFICATIONKINDS(includeOwnerAccountDetails))
            _workflow.Add(new TenantOrderNotification
            {
                TenantBotOrderId = order.Id, Kind = kind, Status = TenantOrderNotificationStatuses.Pending,
                CreatedAtUtc = now, UpdatedAtUtc = now
            });
    }

    internal async Task<int> ENSURETENANTORDERNOTIFICATIONINTENTASYNC(int orderId, string kind, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(kind)) return 0;
        try
        {
            return await _workflow.WriteAsync(async db =>
            {
                var fulfilled = await db.TenantBotOrders.AsNoTracking().AnyAsync(x => x.Id == orderId && x.IsFulfilled, cancellationToken);
                if (!fulfilled || await db.TenantOrderNotifications.AsNoTracking().AnyAsync(x => x.TenantBotOrderId == orderId && x.Kind == kind, cancellationToken)) return 0;
                var now = DateTime.UtcNow;
                db.TenantOrderNotifications.Add(new TenantOrderNotification { TenantBotOrderId = orderId, Kind = kind, Status = TenantOrderNotificationStatuses.Pending, CreatedAtUtc = now, UpdatedAtUtc = now });
                return await db.SaveChangesAsync(cancellationToken);
            }, cancellationToken);
        }
        catch (DbUpdateException)
        {
            // Only a provable concurrent unique-key insert is benign. Re-read with a fresh short-lived context:
            // if the required (orderId, kind) row now exists the race lost, otherwise the persistence really
            // failed and the exception must propagate instead of pretending the intent is queued.
            var exists = await _workflow.ReadAsync(async db => await db.TenantOrderNotifications.AsNoTracking()
                .AnyAsync(x => x.TenantBotOrderId == orderId && x.Kind == kind, cancellationToken));
            if (exists)
            {
                _logger.LogDebug("Tenant notification intent ensure raced with another callback. orderId={OrderId} kind={Kind}", orderId, kind);
                return 0;
            }
            throw;
        }
    }

    internal async Task<int> ENSURETENANTORDERNOTIFICATIONINTENTSASYNC(
        int orderId, bool includeOwnerAccountDetails, CancellationToken cancellationToken)
    {
        try
        {
            return await _workflow.WriteAsync(async db =>
            {
                var order = await db.TenantBotOrders.AsNoTracking().SingleOrDefaultAsync(x => x.Id == orderId, cancellationToken);
                if (order?.IsFulfilled != true) return 0;
                var required = GETTENANTORDERNOTIFICATIONKINDS(includeOwnerAccountDetails);
                var existing = await db.TenantOrderNotifications.AsNoTracking()
                    .Where(x => x.TenantBotOrderId == orderId).Select(x => x.Kind).ToListAsync(cancellationToken);
                var missing = required.Except(existing, StringComparer.Ordinal).ToArray();
                if (missing.Length == 0) return 0;
                var now = DateTime.UtcNow;
                db.TenantOrderNotifications.AddRange(missing.Select(kind => new TenantOrderNotification
                { TenantBotOrderId = orderId, Kind = kind, Status = TenantOrderNotificationStatuses.Pending, CreatedAtUtc = now, UpdatedAtUtc = now }));
                return await db.SaveChangesAsync(cancellationToken);
            }, cancellationToken);
        }
        catch (DbUpdateException)
        {
            // Only benign when every required kind now exists after a fresh read; a real persistence failure
            // (disk full, schema mismatch, unrelated constraint) must propagate so callers never report
            // "queued durably" for an intent that was not actually persisted.
            var existingKinds = await _workflow.ReadAsync(async db => await db.TenantOrderNotifications.AsNoTracking()
                .Where(x => x.TenantBotOrderId == orderId).Select(x => x.Kind).ToListAsync(cancellationToken));
            var required = GETTENANTORDERNOTIFICATIONKINDS(includeOwnerAccountDetails);
            if (required.All(kind => existingKinds.Contains(kind, StringComparer.Ordinal)))
            {
                _logger.LogDebug("Tenant notification intent ensure raced with another callback. orderId={OrderId}", orderId);
                return 0;
            }
            throw;
        }
    }

    internal static bool CANQUEUEUNDERFUNDEDALERT(BotInstance tenant) =>
        tenant != null && string.Equals(tenant.Type, BotInstanceTypes.Tenant, StringComparison.OrdinalIgnoreCase) &&
        tenant.Enabled && !string.IsNullOrWhiteSpace(tenant.Token) && tenant.OwnerTelegramUserId > 0;

    private async Task OBSERVETENANTSTOREFRONTACCESSBESTEFFORTASYNC(
        BotInstance tenant, TenantAccessEvaluation evaluation, CancellationToken cancellationToken)
    {
        try
        {
            var canAlert = CANQUEUEUNDERFUNDEDALERT(tenant);
            await _serviceProvider.GetRequiredService<TenantStorefrontFundingAlertService>().ObserveAsync(
                tenant,
                evaluation,
                customerAttempt: canAlert && evaluation.Decision == TenantAccessDecision.InsufficientFunding,
                allowUnderfundedAlerts: canAlert,
                cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            _logger.LogWarning("Tenant storefront funding alert queue failed. tenantBotId={TenantBotId} ErrorType={ErrorType}",
                tenant?.Id, ex.GetType().Name);
        }
    }

    private async Task OBSERVETENANTFUNDINGSETTLEMENTBESTEFFORTASYNC(
        BotInstance tenant, TenantOwnerWalletSettlementResult settlement, CancellationToken cancellationToken)
    {
        try
        {
            var access = _serviceProvider.GetRequiredService<TenantAccessService>();
            var alerts = _serviceProvider.GetRequiredService<TenantStorefrontFundingAlertService>();
            var before = access.ClassifyFundingSnapshot(
                settlement.BotWalletBefore,
                settlement.SiteWalletBefore?.IsConnected == true,
                settlement.SiteWalletBefore?.WalletToman);
            var after = access.ClassifyFundingSnapshot(
                settlement.BotWalletAfter,
                settlement.SiteWalletAfter?.IsConnected == true,
                settlement.SiteWalletAfter?.WalletToman);
            var canAlert = CANQUEUEUNDERFUNDEDALERT(tenant);
            if (before.Decision == TenantAccessDecision.Allowed && after.Decision == TenantAccessDecision.InsufficientFunding)
                await alerts.ObserveAsync(tenant, before, false, canAlert, cancellationToken);
            await alerts.ObserveAsync(tenant, after, false, canAlert, cancellationToken);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex)
        {
            _logger.LogWarning("Tenant post-settlement funding observation failed. tenantBotId={TenantBotId} ErrorType={ErrorType}",
                tenant?.Id, ex.GetType().Name);
        }
    }

    private async Task QueueGozargahSyncBestEffortAsync(string operation, Func<Task> enqueue)
    {
        try
        {
            await enqueue();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Tenant Gozargah sync enqueue failed after durable fulfillment. operation={Operation}",
                operation);
        }
    }

    /// <summary>
    /// Builds the tenant bot metadata block added to tenant sale and renewal logs.
    /// </summary>
    /// <param name="order">
    /// Tenant order whose <see cref="TenantBotOrder.TenantBotId"/> identifies the storefront that received the
    /// customer payment.
    /// </param>
    /// <returns>
    /// HTML-safe lines containing bot id, username, brand, type, forced-join channels, and support contact for the
    /// storefront. Missing runtime settings are represented with <c>-</c>.
    /// </returns>
    /// <remarks>
    /// Tenant payment settlement can happen from IPN or Sales Assistant callbacks where the customer update context is
    /// not active. Reading the runtime registry from the order id keeps central purchase logs attributable to the
    /// storefront even outside a normal tenant Telegram update.
    /// </remarks>
    private string BuildTenantBotPurchaseLogContext(TenantBotOrder order)
    {
        var bot = _botRegistry.GetById(order?.TenantBotId);
        var username = string.IsNullOrWhiteSpace(bot?.Username)
            ? order?.TenantBotUsername
            : bot.Username.Trim().TrimStart('@');

        var builder = new StringBuilder();
        builder.AppendLine($"BotId: <code>{Html(order?.TenantBotId)}</code>");
        builder.AppendLine($"BotUsername: {FormatTelegramLogReference(string.IsNullOrWhiteSpace(username) ? null : "@" + username)}");
        builder.AppendLine($"Brand: <code>{Html(bot?.BrandName)}</code>");
        builder.AppendLine($"BotType: <code>{Html(bot?.Type ?? BotInstanceTypes.Tenant)}</code>");
        builder.AppendLine($"Channels: {FormatTelegramLogReferences(bot?.TenantChannelIds)}");
        builder.AppendLine($"Support: {FormatTelegramLogReference(bot?.SupportAccount)}");
        builder.AppendLine();
        return builder.ToString();
    }

    /// <summary>
    /// Formats multiple Telegram references for tenant purchase logs.
    /// </summary>
    /// <param name="references">Tenant forced-join channels or related Telegram references.</param>
    /// <returns>Comma-separated HTML-safe references, or <c>-</c> when no references are configured.</returns>
    private static string FormatTelegramLogReferences(IEnumerable<string> references)
    {
        var formatted = (references ?? Array.Empty<string>())
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Select(FormatTelegramLogReference)
            .ToArray();
        return formatted.Length == 0 ? "<code>-</code>" : string.Join(", ", formatted);
    }

    /// <summary>
    /// Formats one Telegram username, t.me link, private id, or free-form value for tenant purchase logs.
    /// </summary>
    /// <param name="reference">Raw tenant channel or support value.</param>
    /// <returns>Clickable HTML when the value is public Telegram username/link; otherwise HTML-safe text.</returns>
    private static string FormatTelegramLogReference(string reference)
    {
        var value = reference?.Trim();
        if (string.IsNullOrWhiteSpace(value))
            return "<code>-</code>";

        var normalizedSupport = NormalizeTenantSupportAccount(value);
        if (!string.IsNullOrWhiteSpace(normalizedSupport))
        {
            var username = normalizedSupport.TrimStart('@');
            return $"<a href=\"https://t.me/{HtmlAttribute(username)}\">@{Html(username)}</a>";
        }

        if (Uri.TryCreate(value, UriKind.Absolute, out var uri) &&
            (string.Equals(uri.Host, "t.me", StringComparison.OrdinalIgnoreCase) ||
             string.Equals(uri.Host, "telegram.me", StringComparison.OrdinalIgnoreCase)))
        {
            return $"<a href=\"{HtmlAttribute(uri.ToString())}\">{Html(value)}</a>";
        }

        return long.TryParse(value, out _)
            ? $"<code>{Html(value)}</code>"
            : Html(value);
    }

    /// <summary>
    /// Builds the tenant storefront tariff message from global service rules and tenant-specific sale pricing.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot row that owns the storefront. Its non-negative markup percent can replace the public tariff with a
    /// marked-up colleague base cost; null uses the public normal-customer tariff.
    /// </param>
    /// <returns>
    /// HTML-formatted Persian tariff text safe for the tenant bot to send to its customers. Disabled durations and
    /// unlimited plans are omitted. Every metered service exposes its effective per-GB/per-day storefront rates and
    /// exactly one formula example whose final total is the authoritative whole-toman tenant sale price.
    /// </returns>
    /// <remarks>
    /// Per-unit display never reveals the owner's colleague base cost. With no markup it shows public rates; with
    /// markup it shows effective colleague rates after the tenant percentage. Final example/order prices are always
    /// obtained from <see cref="CalculateTenantPrice" />, not reconstructed from formatted presentation strings.
    /// Unlimited lists contain only tenant-visible plans; fixed-public-price plans show the configured public amount
    /// without exposing colleague base cost or profit. This method performs no database writes, wallet changes,
    /// gateway calls, or Telegram sends.
    /// </remarks>
    /// <example>
    /// <code>
    /// var text = BUILDTENANTTARIFFSTEXT(tenant);
    /// </code>
    /// </example>
    private string BUILDTENANTTARIFFSTEXT(BotInstance tenant)
    {
        var Builder = new System.Text.StringBuilder();
        Builder.AppendLine("📋 <b>تعرفه‌های فروشگاه</b>");
        Builder.AppendLine();
        Builder.AppendLine("✨ برای استفاده روزمره، پلن‌های نامحدود با حد مصرف منصفانه پیشنهاد می‌شوند.");
        Builder.AppendLine("🌍 لوکیشن‌های فعال فعلی: آلمان، آمریکا و فنلاند. لوکیشن‌های بیشتری هم به‌زودی اضافه می‌شود.");
        Builder.AppendLine();

        foreach (var service in _purchaseService.GetEnabledServices())
        {
            var serviceIcon = service.IsUnlimited
                ? "🚀"
                : string.Equals(service.Key, "national", StringComparison.OrdinalIgnoreCase) ? "🌐" : "🌍";
            Builder.AppendLine($"{serviceIcon} <b>{Html(service.DisplayName)}</b>");
            if (service.IsUnlimited)
            {
                foreach (var plan in XuiV3PurchaseService.GetUnlimitedPlansForTenant(service).OrderBy(x => x.Days))
                {
                    var selection = new XuiV3PurchaseSelection { ServiceKey = service.Key, UnlimitedPlanKey = plan.Key };
                    var Price = CalculateTenantPrice(tenant, selection).SalePriceToman;
                    Builder.AppendLine($"• {Html(plan.DisplayName)} | حد مصرف منصفانه <code>{plan.FairUsageGb} GB</code> | کاربر مجاز <code>{plan.MaxUsers}</code> | <b>{Html(Price.FormatCurrency())}</b>");
                }
            }
            else
            {
                var visibleTrafficOptions = XuiV3PurchaseService.GetVisibleTrafficOptions(service);
                var traffic = string.Join("، ", visibleTrafficOptions.Select(x => $"{x}GB"));
                Builder.AppendLine($"💾 حجم‌های قابل انتخاب: <code>{Html(traffic)}</code>");
                var enabledDurations = XuiV3PurchaseService.GetEnabledDurationOptions(service);
                var durationNames = string.Join(
                    "، ",
                    enabledDurations.OrderBy(duration => duration.Days).Select(duration => duration.DisplayName));
                if (!string.IsNullOrWhiteSpace(durationNames))
                    Builder.AppendLine($"⏳ مدت‌های فعال: <code>{Html(durationNames)}</code>");

                if (service.CustomDurationDays?.IsEnabled == true)
                {
                    Builder.AppendLine(
                        $"🗓 مدت دلخواه: <code>{service.CustomDurationDays.MinimumDays} تا {service.CustomDurationDays.MaximumDays} روز</code>");
                }

                var hasDailyPrice = (service.PricePerDay?.User ?? 0L) > 0 ||
                                    (service.PricePerDay?.Colleague ?? 0L) > 0;
                var effectivePricePerGb = CalculateTenantEffectiveMeteredRateToman(
                    tenant,
                    service,
                    isDailyRate: false);
                Builder.AppendLine($"💰 نرخ هر گیگ: <b>{Html(FormatTenantPriceAmount(effectivePricePerGb))}</b>");
                if (hasDailyPrice)
                    Builder.AppendLine($"📅 نرخ هر روز: <b>{Html(FormatTenantPriceAmount(CalculateTenantEffectiveMeteredRateToman(tenant, service, isDailyRate: true)))}</b>");

                if ((hasDailyPrice || service.LifetimePriceMultiplier != 1D) &&
                    enabledDurations.Any(duration => duration.Days == 0))
                {
                    Builder.AppendLine($"♾ ضریب مدت نامحدود: <code>{Html(XuiV3PurchaseService.FormatLifetimeMultiplier(service.LifetimePriceMultiplier))}</code>");
                }

                var sampleTraffic = visibleTrafficOptions.FirstOrDefault();
                var sampleDuration = hasDailyPrice
                    ? enabledDurations.Where(duration => duration.Days > 0).OrderBy(duration => duration.Days).FirstOrDefault()
                    : enabledDurations.OrderBy(duration => duration.Days).FirstOrDefault();
                if (sampleTraffic > 0 && sampleDuration != null)
                {
                    var selection = new XuiV3PurchaseSelection { ServiceKey = service.Key, TrafficGb = sampleTraffic, DurationKey = sampleDuration.Key };
                    var samplePrice = CalculateTenantPrice(tenant, selection).SalePriceToman;
                    var formula = $"{sampleTraffic}GB × {FormatTenantPriceAmount(effectivePricePerGb)}";
                    if (hasDailyPrice && sampleDuration.Days > 0)
                    {
                        var effectiveDailyPrice = CalculateTenantEffectiveMeteredRateToman(tenant, service, isDailyRate: true);
                        formula += $" + {sampleDuration.Days} روز × {FormatTenantPriceAmount(effectiveDailyPrice)}";
                    }

                    Builder.AppendLine("🧮 <b>یک نمونه محاسبه:</b>");
                    Builder.AppendLine($"<code>{Html(formula)} = {Html(samplePrice.FormatCurrency())}</code>");
                }
            }

            Builder.AppendLine();
        }

        Builder.AppendLine("💡 برای شرایط قطعی یا اختلال شدید اینترنت، داشتن یک کانفیگ نت ملی با زمان انقضای نامحدود هم توصیه می‌شود.");
        return Builder.ToString();
    }

    /// <summary>
    /// Builds the payment INSTRUCTION Text for A tenant order after the HooshPay invoice is created.
    /// </summary>
    /// <param name="order">tenant order containing sale Price and public order Id.</param>
    /// <param name="payment">HooshPay payment row containing Payable amount, fee, and invoice Data.</param>
    /// <returns>Html-formatted payment Text for the customer.</returns>
    private string BuildTenantPaymentText(TenantBotOrder order, HooshPayPaymentInfo payment)
    {
        var Payable = payment.PayableAmountToman > 0 ? payment.PayableAmountToman : payment.AmountToman + payment.FeeAmountToman;
        return "✅ فاکتور پرداخت ساخته شد.\n\n" +
               $"مبلغ سفارش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
               $"مبلغ قابل پرداخت با کارمزد درگاه: <code>{Html(Payable.FormatCurrency())}</code>\n" +
               $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n\n" +
               "پس از پرداخت موفق، اکانت شما به صورت خودکار ساخته و ارسال می‌شود. اگر پرداخت انجام شد و پیام ساخت اکانت را نگرفتید، دکمه بررسی وضعیت را بزنید.";
    }

    /// <summary>
    /// Builds the payment-provider choice text for a tenant renewal order.
    /// </summary>
    /// <param name="order">Pending tenant renewal order.</param>
    /// <returns>HTML-formatted Telegram text explaining the renewal order, amount, and fulfillment timing.</returns>
    /// <remarks>
    /// This method reads only persisted display fields. It never activates a provider, approves a card receipt, mutates
    /// a wallet or ledger, or calls XUI. Provider callbacks and settlement remain the sole authorization for fulfillment.
    /// </remarks>
    private static string BuildTenantRenewOrderPaymentChoiceText(TenantBotOrder order)
    {
        return "💳 <b>روش پرداخت تمدید را انتخاب کنید</b>\n\n" +
               $"اکانت: <code>{Html(order.TargetAccountEmail)}</code>\n" +
               $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n" +
               $"مبلغ تمدید: <b>{Html(order.SalePriceToman.FormatCurrency())}</b>\n\n" +
               "قیمت تمدید دقیقاً مثل قیمت خرید همین پلن در فروشگاه محاسبه شده است.\n\n" +
               BuildTenantPaymentTimingNotice(isRenewal: true);
    }

    /// <summary>
    /// Builds the shared tenant-storefront explanation of automatic online payment and administrator-reviewed card payment.
    /// </summary>
    /// <param name="isRenewal">
    /// <c>true</c> when the pending action renews an existing account; <c>false</c> when it creates and delivers a new
    /// account. This value changes only the customer-facing action verbs and never affects provider availability.
    /// </param>
    /// <returns>
    /// HTML-formatted Persian guidance safe to append to tenant purchase and renewal payment-choice messages.
    /// </returns>
    /// <remarks>
    /// This presentation helper performs no payment-provider call, order write, wallet or ledger mutation, Telegram
    /// send, or XUI mutation. Online completion still depends on the existing verified settlement pipeline; card-to-card
    /// remains pending until the tenant owner approves the receipt.
    /// </remarks>
    /// <example>
    /// <code>
    /// var notice = BuildTenantPaymentTimingNotice(isRenewal: true);
    /// </code>
    /// </example>
    private static string BuildTenantPaymentTimingNotice(bool isRenewal)
    {
        var onlineResult = isRenewal
            ? "اکانت به‌صورت خودکار و آنی تمدید می‌شود."
            : "اکانت به‌صورت خودکار و آنی ساخته و ارسال می‌شود.";
        var cardResult = isRenewal ? "تمدید انجام می‌شود" : "ساخت و ارسال اکانت انجام می‌شود";

        return $"⚡ <b>پرداخت آنلاین:</b> پس از تأیید موفق درگاه، {onlineResult}\n" +
               $"🧾 <b>کارت‌به‌کارت:</b> پس از بررسی و تأیید مدیر فروشگاه، {cardResult} و ممکن است کمی زمان ببرد.";
    }

    /// <summary>
    /// Determines whether a tenant can create a new HooshPay invoice.
    /// </summary>
    /// <param name="tenant">Tenant storefront whose database preference is combined with the live global switch.</param>
    /// <param name="amountToman">
    /// Gross tenant sale amount in Iranian toman. The amount must satisfy HooshPay's inclusive provider range before
    /// a payment row or external request can be created.
    /// </param>
    /// <returns>
    /// <c>true</c> only when HooshPay is enabled globally and for the specified tenant and the amount is supported;
    /// otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This guard applies only to new invoice creation. Existing HooshPay rows continue through inquiry, IPN, and
    /// settlement so disabling the gateway cannot strand a customer who already paid.
    /// </remarks>
    private bool IsTenantHooshPayAvailable(BotInstance tenant, long amountToman)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) &&
           tenant?.TenantHooshPayEnabled == true &&
           HooshPayAmountPolicy.IsValid(amountToman);

    /// <summary>
    /// Builds the safe customer-facing explanation used when a tenant HooshPay callback is no longer available.
    /// </summary>
    /// <param name="tenant">Tenant storefront whose local gateway state is safe to inspect but not expose.</param>
    /// <param name="amountToman">Rejected tenant sale amount in Iranian toman.</param>
    /// <returns>A Persian alert that exposes only public amount limits and no credentials or endpoint details.</returns>
    private string BuildTenantHooshPayUnavailableMessage(BotInstance tenant, long amountToman)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.HooshPay) && tenant?.TenantHooshPayEnabled == true
            ? HooshPayAmountPolicy.BuildUserMessage()
            : "درگاه هوش‌پی برای این فروشگاه در حال حاضر غیرفعال است.";

    /// <summary>
    /// Determines whether a tenant can create a new Tetraminator invoice for the requested sale amount.
    /// </summary>
    /// <param name="tenant">Tenant storefront whose independent preference is combined with global configuration.</param>
    /// <param name="amountToman">Gross customer payment amount in Iranian toman.</param>
    /// <returns>
    /// <c>true</c> only when the global gateway, tenant preference, and configured minimum amount all allow invoice creation.
    /// </returns>
    /// <remarks>
    /// This guard applies only to new invoices. Existing invoice inquiry and settlement deliberately ignore later
    /// global or tenant disablement so a customer payment cannot become stranded.
    /// </remarks>
    private bool IsTenantTetraminatorAvailable(BotInstance tenant, long amountToman)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.Tetraminator) &&
           tenant?.TenantTetraminatorEnabled == true &&
           amountToman >= _appConfig.TetraminatorMinimumAmountToman;

    /// <summary>
    /// Determines whether a tenant can create a new UniquePay invoice for a purchase or renewal.
    /// </summary>
    /// <param name="tenant">Tenant storefront whose local preference is combined with the live global switch.</param>
    /// <param name="amountToman">
    /// Gross tenant sale amount in Iranian toman. Exactly 50,000 and lower values are rejected before persistence or
    /// provider contact.
    /// </param>
    /// <returns>
    /// <c>true</c> only when UniquePay is globally enabled, this tenant's preference is enabled, and the amount is
    /// greater than 50,000 toman. Existing rows remain inquiry/settlement eligible after disablement.
    /// </returns>
    private bool IsTenantUniquePayAvailable(BotInstance tenant, long amountToman)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) &&
           tenant?.TenantUniquePayEnabled == true &&
           UniquePayAmountPolicy.IsValid(amountToman);

    private bool IsTenantAtlasPayAvailable(BotInstance tenant)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay) && tenant?.TenantAtlasPayEnabled == true;

    private string BuildTenantAtlasPayUnavailableMessage(BotInstance tenant)
        => !_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.AtlasPay)
            ? "درگاه اطلس‌پی در تنظیمات سراسری خاموش یا ناقص است."
            : tenant?.TenantAtlasPayEnabled != true
                ? "درگاه اطلس‌پی برای این فروشگاه خاموش است."
                : "درگاه اطلس‌پی در حال حاضر در دسترس نیست.";

    /// <summary>
    /// Builds the safe customer-facing explanation for a disabled tenant UniquePay callback.
    /// </summary>
    /// <param name="tenant">Tenant storefront whose local gateway state is safe to inspect but not expose.</param>
    /// <param name="amountToman">Rejected tenant sale amount in Iranian toman.</param>
    /// <returns>Persian message containing only the public amount boundary when relevant.</returns>
    private string BuildTenantUniquePayUnavailableMessage(BotInstance tenant, long amountToman)
        => _gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.UniquePay) && tenant?.TenantUniquePayEnabled == true
            ? UniquePayAmountPolicy.BuildUserMessage()
            : "درگاه یونیک‌پی برای این فروشگاه در حال حاضر غیرفعال است.";

    /// <summary>
    /// Builds the customer-facing reason why a new tenant Tetraminator invoice cannot be created.
    /// </summary>
    /// <param name="amountToman">Requested tenant sale amount in Iranian toman.</param>
    /// <returns>A safe Persian message that exposes no provider credentials or endpoint data.</returns>
    private string BuildTenantTetraminatorUnavailableMessage(long amountToman)
        => amountToman < _appConfig.TetraminatorMinimumAmountToman
            ? $"حداقل مبلغ پرداخت با تترامیناتور {_appConfig.TetraminatorMinimumAmountToman.FormatCurrency()} است."
            : "درگاه تترامیناتور برای این فروشگاه در حال حاضر غیرفعال است.";

    /// <summary>
    /// Appends a tenant order id to the configured unsigned Tetraminator callback URL.
    /// </summary>
    /// <param name="orderId">Unique local tenant order id used only to locate the persisted payment row.</param>
    /// <returns>An absolute callback URL that preserves any existing query parameters.</returns>
    /// <remarks>
    /// The order id is a lookup hint, not proof of payment. The callback endpoint must still inquire the saved
    /// provider pay id and compare the exact toman amount before fulfillment.
    /// </remarks>
    private string BuildTenantTetraminatorCallbackUrl(string orderId)
    {
        var builder = new UriBuilder(_appConfig.TetraminatorCallbackUrl);
        var prefix = string.IsNullOrWhiteSpace(builder.Query) ? string.Empty : builder.Query.TrimStart('?') + "&";
        builder.Query = prefix + "order_id=" + Uri.EscapeDataString(orderId);
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Builds payment provider callbacks for an already-created tenant renewal order.
    /// </summary>
    /// <param name="order">Tenant renewal order whose database id is embedded in callbacks.</param>
    /// <param name="tenant">Tenant bot whose enabled gateway settings decide which buttons are visible.</param>
    /// <returns>Inline keyboard containing instant online providers, administrator-reviewed card payment, and status check.</returns>
    /// <remarks>
    /// Labels explain timing and currency only: the rial methods (HooshPay, Tetraminator, UniquePay, AtlasPay, and the
    /// tenant owner's personal card-to-card option) end with a <c>ریالی</c> marker, while the NOWPayments cryptocurrency
    /// button deliberately does not. Stable callback values, gateway amount policies, provider fees, settlement checks,
    /// wallet idempotency, and XUI fulfillment behavior are unchanged. This builder has no external side effects.
    /// </remarks>
    private InlineKeyboardMarkup BuildTenantRenewPaymentProviderKeyboard(TenantBotOrder order, BotInstance tenant)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (IsTenantHooshPayAvailable(tenant, order.SalePriceToman))
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ هوش‌پی آنی | ریالی", CUSTOMERCALLBACKPREFIX + $"RNHP:{order.Id}") });
        if (IsTenantTetraminatorAvailable(tenant, order.SalePriceToman))
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ تترامیناتور آنی | ریالی", CUSTOMERCALLBACKPREFIX + $"RNTM:{order.Id}") });
        if (IsTenantUniquePayAvailable(tenant, order.SalePriceToman))
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ یونیک‌پی آنی | کارمزد ۱۲٪ | ریالی", CUSTOMERCALLBACKPREFIX + $"RNUP:{order.Id}") });
        if (IsTenantAtlasPayAvailable(tenant))
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("💳 اطلس‌پی | کارت‌به‌کارت آنی | ریالی", CUSTOMERCALLBACKPREFIX + $"RNAP:{order.Id}") });
        if (_gatewayAvailability.Snapshot.IsEnabled(PaymentGateway.NowPayments) && tenant.TenantNowPaymentsEnabled)
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("⚡ ارز دیجیتال آنی", CUSTOMERCALLBACKPREFIX + $"RNNP:{order.Id}") });
        if (tenant.TenantCardPaymentEnabled && !string.IsNullOrWhiteSpace(tenant.TenantCardNumber))
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("🧾 کارت‌به‌کارت به فروشگاه | ریالی", CUSTOMERCALLBACKPREFIX + $"RNCARD:{order.Id}") });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت سفارش", CUSTOMERCALLBACKPREFIX + $"chk:{order.Id}") });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بازگشت به فروشگاه", CUSTOMERCALLBACKPREFIX + "home") });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the customer-FACING invoice Text for tenant orders paid through non-HooshPay GATEWAYS.
    /// </summary>
    /// <param name="order">tenant order containing sale amount and public order Id.</param>
    /// <param name="PROVIDERDISPLAYNAME">Human-readable gateway name, already safe to expose to the customer.</param>
    /// <returns>Html-formatted invoice Text for the storefront customer.</returns>
    private static string BUILDTENANTGATEWAYPAYMENTTEXT(TenantBotOrder order, string PROVIDERDISPLAYNAME)
    {
        return "✅ فاکتور پرداخت ساخته شد.\n\n" +
               $"درگاه: <b>{Html(PROVIDERDISPLAYNAME)}</b>\n" +
               $"مبلغ سفارش: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
               $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n\n" +
               "پس از پرداخت موفق، اکانت شما به صورت خودکار ساخته و ارسال می‌شود. اگر پرداخت انجام شد و پیام ساخت اکانت را نگرفتید، دکمه بررسی وضعیت را بزنید.";
    }

    /// <summary>
    /// Builds the inline keyboard for PAYING A tenant order and manually checking its status.
    /// </summary>
    /// <param name="order">tenant order whose Id is EMBEDDED into the status-check callback.</param>
    /// <param name="payment">HooshPay payment Info whose payment URL is EXPOSED as A URL button.</param>
    /// <returns>inline keyboard with payment and status-check actions.</returns>
    private static InlineKeyboardMarkup BuildTenantPaymentKeyboard(TenantBotOrder order, HooshPayPaymentInfo payment)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (!string.IsNullOrWhiteSpace(payment.PaymentUrl))
            rows.Add(new[] { InlineKeyboardButton.WithUrl("پرداخت", payment.PaymentUrl) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت پرداخت", CUSTOMERCALLBACKPREFIX + $"chk:{order.Id}") });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the inline keyboard for an EXISTING tenant AtlasPay invoice: the official provider payment link plus the
    /// tenant-scoped manual status check.
    /// </summary>
    /// <param name="payment">
    /// Persisted tenant AtlasPay payment row. The provider checkout link is read from <c>CustomerStartLink</c>, and the
    /// local numeric row id becomes the callback payload. A <c>null</c> or unsaved row yields fewer buttons.
    /// </param>
    /// <returns>
    /// An inline keyboard containing the rial AtlasPay payment button when a provider link exists and the
    /// <c>apchk_</c> status-check button when the row has been persisted. Either entry may be omitted; the returned
    /// markup is never <c>null</c> and may be empty.
    /// </returns>
    /// <remarks>
    /// Display labels only. The callback payload stays <c>apchk_{payment.Id}</c>, and the tenant customer check still
    /// re-verifies the payment against the official AtlasPay API before any wallet credit, order fulfillment, or ledger
    /// effect. The payment button carries the <c>ریالی</c> marker because AtlasPay settles in Iranian tomans; AtlasPay
    /// exposes no provider webhook in this integration, so no callback data depends on the button text.
    /// </remarks>
    internal static InlineKeyboardMarkup BuildTenantAtlasPayPaymentKeyboard(AtlasPayPaymentInfo payment)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (!string.IsNullOrWhiteSpace(payment?.CustomerStartLink))
            rows.Add(new[] { InlineKeyboardButton.WithUrl("💳 پرداخت با اطلس‌پی | ریالی", payment.CustomerStartLink) });
        if (payment != null && payment.Id > 0)
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("🔄 بررسی وضعیت پرداخت", $"apchk_{payment.Id}") });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the inline keyboard for GATEWAYS whose payment URL is stored directly on the tenant order.
    /// </summary>
    /// <param name="order">tenant order whose Id is EMBEDDED into the manual status-check callback.</param>
    /// <param name="PaymentUrl">external gateway URL; when empty only the status-check button is shown.</param>
    /// <returns>inline keyboard with payment URL and status-check CONTROLS.</returns>
    private static InlineKeyboardMarkup BuildTenantPaymentKeyboard(TenantBotOrder order, string PaymentUrl)
    {
        var rows = new List<InlineKeyboardButton[]>();
        if (!string.IsNullOrWhiteSpace(PaymentUrl))
            rows.Add(new[] { InlineKeyboardButton.WithUrl("پرداخت", PaymentUrl) });
        rows.Add(new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت پرداخت", CUSTOMERCALLBACKPREFIX + $"chk:{order.Id}") });
        return new InlineKeyboardMarkup(rows);
    }

    /// <summary>
    /// Builds the inline CONTROLS shown on A tenant card-to-card order.
    /// </summary>
    /// <param name="order">tenant order whose Id is EMBEDDED into receipt upload and status callbacks.</param>
    /// <returns>inline keyboard that lets the customer Send or Replace A receipt and check order status.</returns>
    private static InlineKeyboardMarkup BuildTenantCardPaymentKeyboard(TenantBotOrder order)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[] { InlineKeyboardButton.WithCallbackData("ارسال / تعویض رسید", CUSTOMERCALLBACKPREFIX + $"receipt:{order.Id}") },
            new[] { InlineKeyboardButton.WithCallbackData("بررسی وضعیت سفارش", CUSTOMERCALLBACKPREFIX + $"chk:{order.Id}") },
            new[] { InlineKeyboardButton.WithCallbackData("بازگشت به فروشگاه", CUSTOMERCALLBACKPREFIX + "home") }
        });
    }

    /// <summary>
    /// edits an existing tenant Menu Message when POSSIBLE; otherwise sends A new one.
    /// </summary>
    /// <param name="botClient">Telegram client for the tenant Bot.</param>
    /// <param name="ChatId">target chat Id.</param>
    /// <param name="MessageId">Message Id to edit; when null A new Message is sent.</param>
    /// <param name="Text">Message body.</param>
    /// <param name="keyboard">inline keyboard attached to the Message.</param>
    /// <param name="CancellationToken">Cancellation Token for Telegram calls.</param>
    /// <param name="ParseMode">Telegram Parse Mode used for the Message body.</param>
    private async Task EDITORSENDASYNC(
        ITelegramBotClient botClient,
        ChatId ChatId,
        int? MessageId,
        string Text,
        InlineKeyboardMarkup keyboard,
        CancellationToken CancellationToken,
        ParseMode ParseMode = ParseMode.Html)
    {
        if (MessageId.HasValue)
        {
            await SafeEditMessageTextAsync(botClient, 
                ChatId,
                MessageId.Value,
                Text,
                parseMode: ParseMode,
                replyMarkup: keyboard,
                cancellationToken: CancellationToken);
            return;
        }

        await botClient.SendMessage(ChatId, Text, parseMode: ParseMode, replyMarkup: keyboard, cancellationToken: CancellationToken);
    }

    /// <summary>
    /// Calculates customer sale price, owner base cost, and owner profit for a tenant-storefront selection.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot row that owns the storefront. Its markup is a non-negative percentage; null means no custom markup.
    /// </param>
    /// <param name="selection">
    /// Global service selection made by the tenant customer, including metered traffic and duration or a fixed
    /// unlimited-plan key. The selection must remain enabled in the current catalog.
    /// </param>
    /// <returns>
    /// A whole-toman breakdown containing the customer sale amount, colleague owner base cost, and non-negative owner
    /// profit. The result is detached and callers persist it on the tenant order before settlement.
    /// </returns>
    /// <remarks>
    /// The shared resolver first applies per-GB, per-day, or lifetime-multiplier pricing for both public and colleague
    /// roles. For ordinary plans, a positive tenant markup replaces the public sale with the colleague total multiplied
    /// by that markup and the sale is never below owner base cost. A plan with <c>TenantUsesUserPrice</c> instead fixes
    /// sale to its public/user total, keeps colleague total as base cost, and ignores tenant markup. This method does
    /// not debit or credit a wallet and does not create an order, ledger entry, gateway invoice, or XUI account.
    /// </remarks>
    /// <exception cref="InvalidOperationException">
    /// Thrown when the selected global plan is invalid, disabled, hidden from tenants, or has invalid financial data.
    /// </exception>
    /// <exception cref="ArgumentException">Thrown when generic selection values are malformed.</exception>
    /// <exception cref="OverflowException">Thrown when a calculated whole-toman amount exceeds <see cref="long" />.</exception>
    /// <example>
    /// <code>
    /// var price = CalculateTenantPrice(
    ///     tenant,
    ///     new XuiV3PurchaseSelection { ServiceKey = "unlimited", UnlimitedPlanKey = "configured-plan-key" });
    /// </code>
    /// </example>
    private TenantPriceResult CalculateTenantPrice(BotInstance tenant, XuiV3PurchaseSelection selection)
    {
        var PUBLICRESOLVED = _purchaseService.ResolveTenantPurchase(selection, false);
        var COLLEAGUERESOLVED = _purchaseService.ResolveTenantPurchase(selection, true);
        var BASECOST = COLLEAGUERESOLVED.PriceToman;
        var sale = PUBLICRESOLVED.PriceToman;

        if (PUBLICRESOLVED.UnlimitedPlan?.TenantUsesUserPrice == true)
        {
            return new TenantPriceResult
            {
                SalePriceToman = sale,
                BaseCostToman = BASECOST,
                ProfitToman = Math.Max(0, sale - BASECOST)
            };
        }

        var markup = Math.Max(0, tenant?.TenantPriceMarkupPercent ?? 0);
        // default sale Price is public TARIFF; A custom markup overrides it from colleague base cost.
        if (markup > 0)
            sale = (long)Math.Ceiling(BASECOST * (1M + markup / 100M));

        if (sale < BASECOST)
            sale = BASECOST;

        return new TenantPriceResult
        {
            SalePriceToman = sale,
            BaseCostToman = BASECOST,
            ProfitToman = Math.Max(0, sale - BASECOST)
        };
    }

    /// <summary>
    /// Builds a customer-visible traffic and duration calculation for one tenant metered sale.
    /// </summary>
    /// <param name="tenant">
    /// Tenant storefront whose non-negative markup percentage determines the customer-visible effective rates.
    /// </param>
    /// <param name="resolved">
    /// Public-role selection resolved by the central purchase service. Unlimited selections and null values produce
    /// an empty result.
    /// </param>
    /// <param name="salePriceToman">
    /// Authoritative final tenant sale price in whole Iranian toman returned by <see cref="CalculateTenantPrice" />.
    /// It must be non-negative and already include any tenant markup and final upward rounding.
    /// </param>
    /// <returns>
    /// Plain Persian calculation text suitable for an HTML Telegram message, or an empty string for fixed-price
    /// unlimited selections. The text exposes only public or effective sale rates, never the owner's colleague cost.
    /// </returns>
    /// <remarks>
    /// Without markup, the shared public-price breakdown is reused verbatim. With markup, each visible rate is derived
    /// from the colleague rate multiplied by <c>1 + markup / 100</c>, while the final line uses the authoritative tenant
    /// sale total so component formatting cannot change an order amount. This method has no persistence, wallet,
    /// gateway, ledger, Telegram-send, or XUI side effects.
    /// </remarks>
    /// <example>
    /// <code>
    /// var details = BuildTenantMeteredPriceBreakdownText(tenant, resolved, price.SalePriceToman);
    /// </code>
    /// </example>
    private static string BuildTenantMeteredPriceBreakdownText(
        BotInstance tenant,
        XuiV3ResolvedPurchase resolved,
        long salePriceToman)
    {
        var breakdown = resolved?.MeteredPriceBreakdown;
        if (breakdown == null)
            return string.Empty;

        var markup = Math.Max(0, tenant?.TenantPriceMarkupPercent ?? 0);
        if (markup <= 0)
            return XuiV3PurchaseService.BuildMeteredPriceBreakdownText(resolved);

        var saleFactor = 1M + markup / 100M;
        var effectivePricePerGb = resolved.Service.GetPricePerGb(isColleague: true) * saleFactor;
        var trafficSubtotal = breakdown.TrafficGb * effectivePricePerGb;
        var builder = new StringBuilder();
        builder.AppendLine("جزئیات محاسبه قیمت:");
        builder.AppendLine(
            $"• حجم: {breakdown.TrafficGb} GB × نرخ هر گیگ {FormatTenantPriceAmount(effectivePricePerGb)} " +
            $"= جمع حجم {FormatTenantPriceAmount(trafficSubtotal)}");

        decimal rawTotal;
        if (breakdown.IsLifetime)
        {
            rawTotal = trafficSubtotal * Convert.ToDecimal(breakdown.LifetimePriceMultiplier);
            builder.AppendLine(
                $"• زمان نامحدود: جمع حجم × ضریب {XuiV3PurchaseService.FormatLifetimeMultiplier(breakdown.LifetimePriceMultiplier)} " +
                $"= {salePriceToman.FormatCurrency()}");
        }
        else
        {
            var effectivePricePerDay = resolved.Service.GetPricePerDay(isColleague: true) * saleFactor;
            var durationSubtotal = breakdown.DurationDays * effectivePricePerDay;
            rawTotal = trafficSubtotal + durationSubtotal;
            builder.AppendLine(
                $"• زمان: {breakdown.DurationDays} روز × نرخ هر روز {FormatTenantPriceAmount(effectivePricePerDay)} " +
                $"= جمع زمان {FormatTenantPriceAmount(durationSubtotal)}");
        }

        var roundingText = rawTotal == salePriceToman ? string.Empty : " (گرد شده رو به بالا)";
        builder.Append($"• جمع قیمت: {salePriceToman.FormatCurrency()}{roundingText}");
        return builder.ToString();
    }

    /// <summary>
    /// Formats a potentially fractional tenant sale-rate component without silently rounding its arithmetic.
    /// </summary>
    /// <param name="amountToman">
    /// Non-negative rate or subtotal in Iranian toman. Up to four fractional digits are retained for display.
    /// </param>
    /// <returns>A culture-invariant grouped amount followed by the Persian toman unit.</returns>
    /// <remarks>
    /// This formatter is presentation-only. Wallets and tenant orders continue to store the final upward-rounded
    /// whole-toman amount calculated by <see cref="CalculateTenantPrice" />.
    /// </remarks>
    /// <example>
    /// <code>
    /// var text = FormatTenantPriceAmount(4025.5M); // "4,025.5 تومان"
    /// </code>
    /// </example>
    private static string FormatTenantPriceAmount(decimal amountToman)
    {
        var format = amountToman == decimal.Truncate(amountToman) ? "#,0" : "#,0.####";
        return amountToman.ToString(format, CultureInfo.InvariantCulture) + " تومان";
    }

    /// <summary>
    /// Calculates one customer-visible effective per-GB or per-day rate for a tenant metered tariff.
    /// </summary>
    /// <param name="tenant">
    /// Tenant bot whose non-negative markup percentage controls storefront sale pricing. Null uses the public tariff.
    /// </param>
    /// <param name="service">
    /// Global metered service containing role-specific per-GB and per-day rates in Iranian toman. It must come from the validated
    /// current catalog and must not be an unlimited fixed-price service.
    /// </param>
    /// <param name="isDailyRate">
    /// <c>true</c> to resolve the price of one finite day; <c>false</c> to resolve the price of one GB. The caller must
    /// display the returned value with the matching unit and must not treat it as a final order total.
    /// </param>
    /// <returns>
    /// Effective sale rate in Iranian toman. Fractional rates are retained for transparent arithmetic; the final order
    /// total is rounded only by <see cref="CalculateTenantPrice" />. The result does not expose the raw colleague rate.
    /// </returns>
    /// <remarks>
    /// With no positive markup, the selected public per-GB or per-day tariff is returned. With markup, the corresponding
    /// colleague rate is multiplied by <c>1 + markup / 100</c>. Final order totals continue to use
    /// <see cref="CalculateTenantPrice" /> so combined rounding and traffic pricing remain authoritative.
    /// This method has no persistence, wallet, Telegram, gateway, ledger, or XUI side effects.
    /// </remarks>
    /// <exception cref="ArgumentNullException">Thrown when <paramref name="service" /> is null.</exception>
    /// <exception cref="InvalidOperationException">Thrown when the selected configured rate is negative.</exception>
    /// <example>
    /// <code>
    /// var effectivePerGb = CalculateTenantEffectiveMeteredRateToman(tenant, service, isDailyRate: false);
    /// </code>
    /// </example>
    private static decimal CalculateTenantEffectiveMeteredRateToman(
        BotInstance tenant,
        XuiV3ServiceDefinition service,
        bool isDailyRate)
    {
        if (service == null)
            throw new ArgumentNullException(nameof(service));

        var markup = Math.Max(0, tenant?.TenantPriceMarkupPercent ?? 0);
        var effectiveRate = markup > 0
            ? (isDailyRate ? service.GetPricePerDay(isColleague: true) : service.GetPricePerGb(isColleague: true)) *
              (1M + markup / 100M)
            : isDailyRate
                ? service.GetPricePerDay(isColleague: false)
                : service.GetPricePerGb(isColleague: false);

        if (effectiveRate < 0M)
            throw new InvalidOperationException($"Service '{service.Key}' cannot have a negative effective metered rate.");

        return effectiveRate;
    }

    /// <summary>
    /// Builds A persisted tenant order from A selected plan and A calculated Price BREAKDOWN.
    /// </summary>
    /// <param name="tenant">tenant Bot that owns the storefront and Receives the financial result.</param>
    /// <param name="customer">credentials profile of the storefront customer.</param>
    /// <param name="ChatId">Telegram chat Id where the customer should Receive payment and fulfillment messages.</param>
    /// <param name="selection">selected service, Traffic, Duration, or Unlimited plan.</param>
    /// <param name="Price">sale Price, base cost, and profit in toman.</param>
    /// <param name="Provider">payment Provider key stored on the order for audit and ledger filtering.</param>
    /// <returns>A new UNSAVED <see cref="TenantBotOrder" /> ready to be added to users.db.</returns>
    /// <remarks>
    /// the order Id is generated before Any gateway request so ASYNCHRONOUS ipn or receipt callbacks can
    /// be CORRELATED with the local tenant order. the returned Entity is not TRACKED UNTIL the caller Adds it.
    /// </remarks>
    private static TenantBotOrder CreateTenantOrder(
        BotInstance tenant,
        CredUser customer,
        ChatId ChatId,
        XuiV3PurchaseSelection selection,
        TenantPriceResult Price,
        string Provider)
    {
        return new TenantBotOrder
        {
            OrderId = CreateTenantOrderId(tenant, customer.TelegramUserId),
            TenantBotId = tenant.Id,
            TenantBotUsername = tenant.Username,
            OwnerTelegramUserId = tenant.OwnerTelegramUserId ?? 0,
            CustomerTelegramUserId = customer.TelegramUserId,
            CustomerChatId = ChatId.Identifier ?? customer.TelegramUserId,
            CustomerUsername = customer.Username,
            CustomerFirstName = customer.FirstName,
            CustomerLastName = customer.LastName,
            OrderKind = TenantBotOrderKinds.Purchase,
            ServiceKey = selection.ServiceKey,
            TrafficGb = selection.TrafficGb,
            DurationKey = selection.DurationKey,
            UnlimitedPlanKey = selection.UnlimitedPlanKey,
            AccountCount = 1,
            SalePriceToman = Price.SalePriceToman,
            BaseCostToman = Price.BaseCostToman,
            ProfitToman = Price.ProfitToman,
            PaymentProvider = Provider,
            PaymentStatus = TenantBotOrderStatuses.Pending,
            CreatedAtUtc = DateTime.UtcNow
        };
    }

    /// <summary>
    /// Encodes a tenant purchase selection into a compact callback action.
    /// </summary>
    /// <param name="selection">
    /// Selected global service and either an unlimited plan or metered traffic with a configured or <c>days-N</c>
    /// duration key.
    /// </param>
    /// <returns>Callback suffix used after the tenant customer callback prefix.</returns>
    /// <remarks>
    /// The action carries selection state only. Every payment-provider handler resolves it against the current global
    /// catalog before creating an order or invoice, so a stale custom-duration callback cannot create a financial effect.
    /// </remarks>
    /// <example>
    /// <code>
    /// var action = BUILDPAYACTION(selection);
    /// </code>
    /// </example>
    private static string BUILDPAYACTION(XuiV3PurchaseSelection selection)
    {
        if (!string.IsNullOrWhiteSpace(selection.UnlimitedPlanKey))
            return $"Pay:u:{selection.ServiceKey}:{selection.UnlimitedPlanKey}";

        return $"Pay:m:{selection.ServiceKey}:{selection.TrafficGb}:{selection.DurationKey}";
    }

    /// <summary>
    /// Parses the compact callback action generated by <see cref="BUILDPAYACTION" /> back into a purchase selection.
    /// </summary>
    /// <param name="action">
    /// Callback action received from Telegram. Metered actions may contain a canonical <c>days-N</c> duration key.
    /// </param>
    /// <returns>A detached purchase selection when the callback shape is valid; otherwise <c>null</c>.</returns>
    /// <remarks>
    /// Shape parsing does not validate current service availability, preset enablement, or the custom-day range.
    /// Callers must pass the result to central tenant pricing before any order, invoice, wallet, ledger, or XUI effect.
    /// </remarks>
    /// <example>
    /// <code>
    /// var selection = PARSESELECTIONFROMPAYACTION("Pay:m:normal:100:days-3");
    /// </code>
    /// </example>
    private static XuiV3PurchaseSelection PARSESELECTIONFROMPAYACTION(string action)
    {
        var parts = action.Split(':');
        if (parts.Length == 4 && parts[1] == "u")
            return new XuiV3PurchaseSelection { ServiceKey = parts[2], UnlimitedPlanKey = parts[3] };

        if (parts.Length == 5 && parts[1] == "m" && int.TryParse(parts[3], out var GB))
            return new XuiV3PurchaseSelection { ServiceKey = parts[2], TrafficGb = GB, DurationKey = parts[4] };

        return null;
    }

    /// <summary>
    /// Loads the tenant Bot row that matches the current async Bot context.
    /// </summary>
    /// <param name="CancellationToken">Cancellation Token for the database Query.</param>
    /// <returns>tenant Bot row for the current Bot Id, or null when the update is not from A tenant Bot.</returns>
    private async Task<BotInstance> GetCurrentTenantBotAsync(CancellationToken CancellationToken)
    {
        return await _workflow.ReadAsync(async db => await db.BotInstances.FirstOrDefaultAsync(x => x.Id == BotContextAccessor.CurrentBotId, CancellationToken));
    }

    /// <summary>Displays the authenticated owner's stores and a redelivery-safe add button.</summary>
    /// <param name="client">Current owned-bot Telegram client.</param>
    /// <param name="chatId">Owner panel Telegram chat id.</param>
    /// <param name="owner">Authenticated colleague profile; shared wallet identity.</param>
    /// <param name="token">Cancellation of reads and the Telegram response.</param>
    /// <returns>A task completing after the store list is sent.</returns>
    /// <remarks>Does not select a default store. Disabled/reset rows remain listed and count toward the global limit.</remarks>
    private async Task ShowOwnerStoreListAsync(ITelegramBotClient client, long chatId, CredUser owner, CancellationToken token)
    {
        var stores = await _serviceProvider.GetRequiredService<TenantStoreStore>().ListAsync(owner.TelegramUserId, token);
        var rows = stores.Select(store => new[] { InlineKeyboardButton.WithCallbackData(
            $"{store.TenantStoreNumber}. {store.BrandName ?? "فروشگاه"} · @{store.Username ?? "ثبت‌نشده"} · {(store.Enabled ? "روشن" : "خاموش")}",
            TenantOwnerCallback.Encode(store, "panel")) }).ToList();
        if (stores.Count < _appConfig.TenantMaxStoresPerOwner)
            rows.Add(new[] { InlineKeyboardButton.WithCallbackData("➕ افزودن فروشگاه", $"TBM:add:{DateTimeOffset.UtcNow.ToUnixTimeSeconds():X}:" + Guid.NewGuid().ToString("N")) });
        var balance = await _credentialsDbContext.GetAccountBalance(owner.TelegramUserId);
        await client.SendMessage(chatId,
            $"🏪 فروشگاه‌های شما ({stores.Count}/{_appConfig.TenantMaxStoresPerOwner})\n\nکیف پول مشترک مالک: {balance.FormatCurrency()} تومان\nتمام فروشگاه‌ها از یک حساب گذرگاه متعلق به شما استفاده می‌کنند.\nفروشگاه مورد نظر را انتخاب کنید.",
            replyMarkup: new InlineKeyboardMarkup(rows), cancellationToken: token);
    }

    /// <summary>
    /// Reloads the explicitly selected storefront and rechecks its authenticated owner.
    /// </summary>
    /// <param name="OwnerTelegramUserId">Telegram User Id of the colleague owner.</param>
    /// <param name="CancellationToken">Cancellation Token for the database Query.</param>
    /// <returns>Detached selected store, or null when no authorized selection exists. Never selects another store.</returns>
    /// <remarks>The execution selection comes only from an addressed callback or persisted owned-bot/user input state.</remarks>
    /// <exception cref="DbUpdateConcurrencyException">Another owned-bot execution changed this store since selection; reopen its panel.</exception>
    private async Task<BotInstance> GetSelectedOwnerStoreAsync(long OwnerTelegramUserId, CancellationToken CancellationToken)
    {
        if (_selectedOwnerStore?.OwnerTelegramUserId != OwnerTelegramUserId) return null;
        var expectedRevision = (_selectedOwnerStore.UpdatedAtUtc ?? _selectedOwnerStore.CreatedAtUtc).Ticks;
        var selectedId = _selectedOwnerStore.Id;
        _selectedOwnerStore = await _workflow.ReadAsync(async db => await db.BotInstances.FirstOrDefaultAsync(
            x => x.Id == selectedId && x.Type == BotInstanceTypes.Tenant && x.OwnerTelegramUserId == OwnerTelegramUserId,
            CancellationToken));
        // A second owned bot may edit after callback validation. Never silently advance the validated baseline before a write.
        if (_selectedOwnerStore != null && (_selectedOwnerStore.UpdatedAtUtc ?? _selectedOwnerStore.CreatedAtUtc).Ticks != expectedRevision)
            throw new DbUpdateConcurrencyException("The selected storefront changed; reopen its panel.");
        return _selectedOwnerStore;
    }

    /// <summary>
    /// Requires the selected colleague storefront before a settings write; allocation occurs only through the add button.
    /// </summary>
    /// <param name="owner">Credential User record for the colleague who owns the storefront.</param>
    /// <param name="CancellationToken">Cancellation Token for the database operation.</param>
    /// <returns>Detached owner-authorized store tracked by the workflow's optimistic write baseline.</returns>
    /// <exception cref="InvalidOperationException">The selection is missing or no longer belongs to this owner.</exception>
    /// <remarks>Never creates an implicit first store, copies another store's settings or creates financial accounts.</remarks>
    private async Task<BotInstance> RequireSelectedOwnerStoreAsync(CredUser owner, CancellationToken CancellationToken)
    {
        return await GetSelectedOwnerStoreAsync(owner.TelegramUserId, CancellationToken)
            ?? throw new InvalidOperationException("An owner-authorized storefront selection is required.");
    }

    /// <summary>
    /// ANSWERS A Telegram callback without ALLOWING Expired callback ids to Escape and stop the update pipeline.
    /// </summary>
    /// <param name="botClient">Telegram Bot client that received the callback Query.</param>
    /// <param name="callbackQueryId">OPAQUE callback Query Id from Telegram; valid only for A short time.</param>
    /// <param name="Text">optional ALERT or TOAST Text shown to the User.</param>
    /// <param name="showAlert">whether Telegram should show the Text as an ALERT DIALOG instead of A TOAST.</param>
    /// <param name="URL">optional URL Supported by Telegram callback ANSWERS.</param>
    /// <param name="CACHETIME">optional Telegram callback Cache time in seconds.</param>
    /// <param name="CancellationToken">Cancellation Token for the Telegram API call.</param>
    /// <remarks>
    /// Telegram returns <c>Bad request: Query is too old</c> when A callback is ANSWERED after its short TTL.
    /// that CONDITION is not A Business failure and must Never stop owned Bot or tenant Bot receivers.
    /// </remarks>
    private async Task SafeAnswerCallbackQueryAsync(
        ITelegramBotClient botClient,
        string callbackQueryId,
        string text = null,
        bool? showAlert = null,
        string url = null,
        int? cacheTime = null,
        CancellationToken cancellationToken = default)
    {
        await TelegramCallbackAnswerPolicy.TryAnswerAsync(
            botClient, callbackQueryId, text, showAlert, url, cacheTime, cancellationToken,
            _logger, BotContextAccessor.CurrentBotId, timeout: _interactionTimeouts.CallbackAnswer);
    }

    /// <summary>
    /// edits A Telegram Message without ALLOWING HARMLESS edit failures to stop the Bot receiver.
    /// </summary>
    /// <param name="botClient">Telegram Bot client that owns the Message.</param>
    /// <param name="ChatId">Telegram chat Id containing the Message to edit.</param>
    /// <param name="MessageId">Telegram Message Id to edit.</param>
    /// <param name="Text">new Message Text.</param>
    /// <param name="ParseMode">optional Parse Mode used for the edited Text.</param>
    /// <param name="replyMarkup">optional inline keyboard for the edited Message.</param>
    /// <param name="CancellationToken">Cancellation Token for the Telegram API call.</param>
    /// <remarks>
    /// Telegram rejects edits when the new content and markup are IDENTICAL to the current Message.
    /// that is A no-OP from our Business PERSPECTIVE and must not break owned Bot or tenant Bot flows.
    /// </remarks>
    internal static bool ISTELEGRAMMESSAGENOTMODIFIED(int errorCode, string message) =>
        errorCode == 400 && message?.Contains("message is not modified", StringComparison.OrdinalIgnoreCase) == true;

    internal static bool ISTELEGRAMEDITTARGETMISSING(int errorCode, string message) =>
        errorCode == 400 && message?.Contains("message to edit not found", StringComparison.OrdinalIgnoreCase) == true;

    private async Task SafeEditMessageTextAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        int messageId,
        string text,
        ParseMode? parseMode = null,
        InlineKeyboardMarkup replyMarkup = null,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await botClient.EditMessageText(
                chatId,
                messageId,
                text,
                parseMode: parseMode ?? ParseMode.None,
                replyMarkup: replyMarkup,
                cancellationToken: cancellationToken);
        }
        catch (ApiRequestException ex) when (ISTELEGRAMMESSAGENOTMODIFIED(ex.ErrorCode, ex.Message))
        {
            // Telegram confirms the requested content and markup are already present: semantic success/no-op.
        }
        catch (ApiRequestException ex) when (ISTELEGRAMEDITTARGETMISSING(ex.ErrorCode, ex.Message))
        {
            _logger.LogWarning(ex, "Telegram message edit target was not found; edit was swallowed to keep the receiver alive. ChatId={ChatId}, MessageId={MessageId}", chatId, messageId);
        }
        catch (ApiRequestException ex)
        {
            _logger.LogWarning(ex, "Telegram Message edit failed but was SWALLOWED to Keep the receiver ALIVE. ChatId={ChatId}, MessageId={MessageId}", chatId, messageId);
        }
    }

    /// <summary>
    /// Checks whether a tenant customer satisfies the storefront forced-join rule before continuing the flow.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to query Telegram and send the join prompt.</param>
    /// <param name="Message">Incoming customer message containing the tenant-scoped Telegram user and private chat ids.</param>
    /// <param name="tenant">Current tenant bot whose configured channel list owns the forced-join rule.</param>
    /// <param name="CancellationToken">Token that cancels Telegram membership checks and prompt delivery.</param>
    /// <returns>
    /// <c>true</c> when forced join is disabled or the customer belongs to every configured channel; otherwise
    /// <c>false</c> after the join or verification-failure prompt has been sent.
    /// </returns>
    /// <remarks>
    /// This overload extracts the customer identity from the incoming update and delegates to the common
    /// message/callback implementation. Telegram failures remain fail-closed and never grant storefront access.
    /// </remarks>
    private async Task<bool> EnsureTenantCustomerJoinAsync(
        ITelegramBotClient botClient,
        Message Message,
        BotInstance tenant,
        CancellationToken CancellationToken)
    {
        return await EnsureTenantCustomerJoinAsync(
            botClient,
            Message.Chat.Id,
            Message.From.Id,
            tenant,
            CancellationToken);
    }

    /// <summary>
    /// Checks the tenant forced-join rule for either a message or a callback query.
    /// </summary>
    /// <param name="botClient">Tenant bot client used to call Telegram and send the join prompt.</param>
    /// <param name="chatId">
    /// Telegram chat id where the customer should receive the join prompt. This is usually the private chat
    /// with the tenant bot, not the forced-join channel id.
    /// </param>
    /// <param name="telegramUserId">
    /// Numeric Telegram user id whose channel membership is checked with <c>GetChatMember</c>.
    /// Usernames or chat ids must not be passed here.
    /// </param>
    /// <param name="tenant">
    /// Tenant bot that owns the forced-join channel list. Only this tenant's configured channels are checked.
    /// </param>
    /// <param name="CancellationToken">Cancellation token for Telegram API calls and prompt delivery.</param>
    /// <param name="isJoinRetry">
    /// <c>true</c> when the customer clicked the explicit "عضو شدم" button; the rejection message is then
    /// phrased as a retry result instead of a first-time join prompt.
    /// </param>
    /// <returns>
    /// <c>true</c> when forced join is disabled, no channel is configured, or the user is a member of every
    /// configured channel; otherwise <c>false</c> after a join prompt has been sent.
    /// </returns>
    /// <remarks>
    /// This method is intentionally used before every tenant customer message and callback action. It prevents
    /// old inline buttons, payment checks, receipt uploads, and menu callbacks from bypassing mandatory join.
    /// Telegram access errors are treated as a failed check so the storefront remains closed instead of silently
    /// allowing the customer through. Only error 400 containing <c>PARTICIPANT_ID_INVALID</c> is retried, exactly
    /// once after a bounded delay; permission errors and unrelated validation failures are never retried.
    /// </remarks>
    private async Task<bool> EnsureTenantCustomerJoinAsync(
        ITelegramBotClient botClient,
        ChatId chatId,
        long telegramUserId,
        BotInstance tenant,
        CancellationToken CancellationToken,
        bool isJoinRetry = false)
    {
        if (!tenant.TenantMandatoryJoinEnabled)
            return true;

        var Channels = GETTENANTCHANNELIDS(tenant).ToList();
        if (Channels.Count == 0)
            return true;

        foreach (var channel in Channels)
        {
            try
            {
                var member = await ExecuteTenantParticipantLookupWithRetryAsync(
                    token => botClient.GetChatMember(channel, telegramUserId, token),
                    CancellationToken,
                    ex => _logger.LogDebug(
                        ex,
                        "Tenant forced-join participant lookup will be retried once. TenantBotId={TenantBotId}, channel={channel}, telegramError={TelegramError}",
                        tenant.Id,
                        channel,
                        ex.Message));
                if (IsAcceptedTenantJoinStatus(member.Status))
                    continue;

                await SENDTENANTJOINPROMPTASYNC(
                    botClient,
                    chatId,
                    Channels,
                    CancellationToken,
                    isJoinRetry ? "هنوز عضو کانال نشده‌اید. بعد از عضویت دوباره روی «عضو شدم» بزنید." : null);
                return false;
            }
            catch (OperationCanceledException) when (CancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "tenant forced-join check failed. TenantBotId={TenantBotId}, channel={channel}", tenant.Id, channel);
                await SENDTENANTJOINPROMPTASYNC(
                    botClient,
                    chatId,
                    Channels,
                    CancellationToken,
                    "امکان تایید عضویت شما وجود ندارد. لطفاً مطمئن شوید در کانال عضو شده‌اید و دوباره تلاش کنید.");
                return false;
            }
        }

        return true;
    }

    /// <summary>
    /// Executes one customer membership lookup and retries only Telegram's narrow participant-id race once.
    /// </summary>
    /// <typeparam name="TResult">The Telegram membership result type returned by the supplied lookup.</typeparam>
    /// <param name="lookupAsync">
    /// Required tenant-scoped Telegram lookup. The delegate must query the same channel and numeric customer id
    /// on every invocation and must not suppress Telegram exceptions.
    /// </param>
    /// <param name="cancellationToken">Token that cancels both Telegram calls and the bounded retry delay.</param>
    /// <param name="onTransientRetry">
    /// Optional local diagnostic callback invoked once before retrying. It must not log bot tokens or credentials.
    /// </param>
    /// <returns>The result of the first successful lookup, including a successful single retry.</returns>
    /// <remarks>
    /// The first error is retried only when <see cref="IsParticipantIdInvalid" /> matches. A second failure is
    /// returned to the caller as an exception, so the storefront remains fail-closed. Permission errors, arbitrary
    /// HTTP 400 responses, and all other failures are never retried.
    /// </remarks>
    /// <example>
    /// <code>
    /// var member = await ExecuteTenantParticipantLookupWithRetryAsync(
    ///     token => botClient.GetChatMember(channel, telegramUserId, token),
    ///     cancellationToken);
    /// </code>
    /// </example>
    private static async Task<TResult> ExecuteTenantParticipantLookupWithRetryAsync<TResult>(
        Func<CancellationToken, Task<TResult>> lookupAsync,
        CancellationToken cancellationToken,
        Action<ApiRequestException> onTransientRetry = null)
    {
        ArgumentNullException.ThrowIfNull(lookupAsync);

        try
        {
            return await lookupAsync(cancellationToken);
        }
        catch (ApiRequestException ex) when (IsParticipantIdInvalid(ex))
        {
            onTransientRetry?.Invoke(ex);
            await Task.Delay(TimeSpan.FromMilliseconds(500), cancellationToken);
            return await lookupAsync(cancellationToken);
        }
    }

    /// <summary>
    /// Determines whether Telegram reported the transient participant-id lookup condition eligible for one retry.
    /// </summary>
    /// <param name="exception">Telegram API exception raised by an actual customer <c>GetChatMember</c> request.</param>
    /// <returns>
    /// <c>true</c> only for error code 400 whose message contains <c>PARTICIPANT_ID_INVALID</c>, case-insensitively;
    /// otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This classifier intentionally excludes other HTTP 400 responses and every permission error. It contains no
    /// tenant, token, channel, or customer identifiers and has no side effects.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (IsParticipantIdInvalid(exception))
    /// {
    ///     // Retry the same customer lookup once after a bounded delay.
    /// }
    /// </code>
    /// </example>
    private static bool IsParticipantIdInvalid(ApiRequestException exception)
    {
        return exception?.ErrorCode == 400 &&
               exception.Message?.Contains("PARTICIPANT_ID_INVALID", StringComparison.OrdinalIgnoreCase) == true;
    }

    /// <summary>
    /// Determines whether a Telegram membership status satisfies tenant storefront forced join.
    /// </summary>
    /// <param name="status">Status returned by Telegram for the actual tenant customer and configured channel.</param>
    /// <returns>
    /// <c>true</c> for <see cref="ChatMemberStatus.Member" />, <see cref="ChatMemberStatus.Administrator" />, or
    /// <see cref="ChatMemberStatus.Creator" />; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>This policy is tenant-agnostic, side-effect-free, and does not weaken runtime membership checks.</remarks>
    private static bool IsAcceptedTenantJoinStatus(ChatMemberStatus status)
    {
        return status is ChatMemberStatus.Member or ChatMemberStatus.Administrator or ChatMemberStatus.Creator;
    }

    /// <summary>
    /// Verifies that the tenant bot can access and administer its configured forced-join channels.
    /// </summary>
    /// <param name="tenant">Tenant bot whose token identity and tenant-scoped channel list are validated.</param>
    /// <param name="CancellationToken">Token that cancels the bounded Telegram capability probe.</param>
    /// <returns>An activation result containing an actionable Persian owner-facing error when validation fails.</returns>
    /// <remarks>
    /// The check uses the tenant bot token, not the default owned bot. It verifies bot identity, channel access,
    /// administrator-list access, and that the tenant bot itself is an administrator. It deliberately never probes
    /// <c>OwnerTelegramUserId</c>: owner membership is unrelated to the bot capability used later for customers.
    /// Successful and failed outcomes retain the existing tenant/token/channel-scoped cache lifetimes.
    /// </remarks>
    private async Task<(bool ISVALID, string ErrorMessage)> VALIDATETENANTMANDATORYJOINASYNC(BotInstance tenant, CancellationToken CancellationToken)
    {
        var Channels = GETTENANTCHANNELIDS(tenant).ToList();
        if (Channels.Count == 0)
            return (false, "اول کانال جوین اجباری را ثبت کنید.");

        if (string.IsNullOrWhiteSpace(tenant.Token))
            return (false, "اول توکن ربات فروشگاهی را ثبت کنید.");

        var cacheKey = BuildTenantJoinCapabilityCacheKey(tenant, Channels);
        if (TryGetTenantJoinCapabilityCache(cacheKey, out var cachedResult))
            return cachedResult;

        string activeChannel = null;
        try
        {
            var client = _botClientProvider.GetClient(tenant.Id);
            using var probeCts = CreateTenantTelegramProbeCancellation(CancellationToken);
            var me = await client.GetMe(probeCts.Token);
            foreach (var channel in Channels)
            {
                activeChannel = channel;
                await client.GetChat(channel, probeCts.Token);
            var administrators = await client.GetChatAdministrators(channel, cancellationToken: probeCts.Token);
                if (!administrators.Any(member => member.User.Id == me.Id))
                {
                    var notAdmin = (false, $"ربات فروشگاهی در کانال {channel} ادمین نیست. ابتدا ربات را به کانال اضافه و admin کنید.");
                    SetTenantJoinCapabilityCache(cacheKey, notAdmin, TimeSpan.FromSeconds(15));
                    return notAdmin;
                }
            }

            var valid = (true, (string)null);
            SetTenantJoinCapabilityCache(cacheKey, valid, TimeSpan.FromMinutes(1));
            return valid;
        }
        catch (ApiRequestException ex) when (IsTenantJoinCapabilityPermissionFailure(ex))
        {
            var permissionFailure = (
                false,
                "ربات فروشگاهی امکان خواندن اعضای کانال را ندارد. ربات را در کانال admin کنید و دوباره تلاش کنید.");
            SetTenantJoinCapabilityCache(cacheKey, permissionFailure, TimeSpan.FromSeconds(15));
            _logger.LogInformation(
                "Tenant forced-join capability validation rejected channel permissions. TenantBotId={TenantBotId}, channel={channel}, telegramError={TelegramError}",
                tenant.Id,
                activeChannel,
                ex.Message);
            return permissionFailure;
        }
        catch (ApiRequestException ex)
        {
            var telegramValidationFailure = (
                false,
                "تلگرام کانال ثبت‌شده را نپذیرفت یا موقتاً نتوانست آن را بررسی کند. نام کاربری یا شناسه کانال را بررسی و دوباره تلاش کنید.");
            SetTenantJoinCapabilityCache(cacheKey, telegramValidationFailure, TimeSpan.FromSeconds(15));
            _logger.LogInformation(
                "Tenant forced-join capability validation failed without a proven permission error. TenantBotId={TenantBotId}, channel={channel}, telegramError={TelegramError}",
                tenant.Id,
                activeChannel,
                ex.Message);
            return telegramValidationFailure;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "tenant forced-join validation failed. TenantBotId={TenantBotId}, channel={channel}",
                tenant.Id,
                activeChannel);
            return (false, "امکان بررسی کانال جوین اجباری وجود ندارد. تنظیمات کانال و دسترسی ربات را بررسی و دوباره تلاش کنید.");
        }
    }

    /// <summary>
    /// Determines whether a Telegram capability-probe failure proves missing channel access or administrator rights.
    /// </summary>
    /// <param name="exception">Telegram API exception raised while reading the channel or administrator list.</param>
    /// <returns>
    /// <c>true</c> for Telegram 403 or a narrowly recognized Telegram 400 administrator/member-access message;
    /// otherwise <c>false</c> so arbitrary validation failures are not mislabeled as permission problems.
    /// </returns>
    /// <remarks>
    /// This method is used only by activation-time capability validation. It does not classify customer
    /// <c>GetChatMember</c> results and never grants storefront access.
    /// </remarks>
    private static bool IsTenantJoinCapabilityPermissionFailure(ApiRequestException exception)
    {
        if (exception?.ErrorCode == 403)
            return true;

        if (exception?.ErrorCode != 400 || string.IsNullOrWhiteSpace(exception.Message))
            return false;

        return exception.Message.Contains("CHAT_ADMIN_REQUIRED", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("bot is not a member", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("not enough rights", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("need administrator rights", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("member list is inaccessible", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Builds a non-secret cache key for one tenant token identity and forced-join channel set.
    /// </summary>
    /// <param name="tenant">Tenant bot row containing the internal id and BotFather token identity.</param>
    /// <param name="channels">Normalized channel usernames or ids currently configured for forced join.</param>
    /// <returns>A stable key that changes automatically when the bot token identity or channel list changes.</returns>
    /// <remarks>
    /// Only the numeric bot-id prefix is used; the token secret is never retained in the cache key or logs.
    /// </remarks>
    private static string BuildTenantJoinCapabilityCacheKey(BotInstance tenant, IEnumerable<string> channels)
    {
        var telegramBotId = TelegramBotTokenIdentity.ExtractBotId(tenant?.Token)?.ToString(CultureInfo.InvariantCulture) ?? "unknown";
        var channelKey = string.Join(",", (channels ?? Enumerable.Empty<string>())
            .Select(channel => channel?.Trim().ToLowerInvariant())
            .Where(channel => !string.IsNullOrWhiteSpace(channel))
            .OrderBy(channel => channel, StringComparer.Ordinal));
        return $"{tenant?.Id}|{telegramBotId}|{channelKey}";
    }

    /// <summary>
    /// Reads a non-expired forced-join capability result from the process-local cache.
    /// </summary>
    /// <param name="cacheKey">Key produced by <see cref="BuildTenantJoinCapabilityCacheKey" />.</param>
    /// <param name="result">Receives the cached validation tuple when available.</param>
    /// <returns><c>true</c> when a non-expired entry was found; otherwise <c>false</c>.</returns>
    private bool TryGetTenantJoinCapabilityCache(
        string cacheKey,
        out (bool ISVALID, string ErrorMessage) result)
    {
        lock (_tenantJoinCapabilitySync)
        {
            if (_tenantJoinCapabilityCache.TryGetValue(cacheKey, out var entry) && entry.ExpiresAtUtc > DateTime.UtcNow)
            {
                result = (entry.IsValid, entry.ErrorMessage);
                return true;
            }

            _tenantJoinCapabilityCache.Remove(cacheKey);
        }

        result = default;
        return false;
    }

    /// <summary>
    /// Stores a forced-join capability result for a bounded process-local duration.
    /// </summary>
    /// <param name="cacheKey">Non-secret tenant/token/channel key.</param>
    /// <param name="result">Validation result returned to the owner enable flow.</param>
    /// <param name="lifetime">Positive cache lifetime; failures use a short duration and successes use a longer one.</param>
    private void SetTenantJoinCapabilityCache(
        string cacheKey,
        (bool ISVALID, string ErrorMessage) result,
        TimeSpan lifetime)
    {
        lock (_tenantJoinCapabilitySync)
        {
            _tenantJoinCapabilityCache[cacheKey] = new TenantJoinCapabilityCacheEntry
            {
                IsValid = result.ISVALID,
                ErrorMessage = result.ErrorMessage,
                ExpiresAtUtc = DateTime.UtcNow.Add(lifetime)
            };
        }
    }

    /// <summary>
    /// Process-local forced-join capability cache value scoped by tenant, Telegram bot identity, and channel set.
    /// </summary>
    private sealed class TenantJoinCapabilityCacheEntry
    {
        /// <summary>Whether Telegram proved the tenant bot can read members for every configured channel.</summary>
        public bool IsValid { get; set; }

        /// <summary>Owner-facing validation message when <see cref="IsValid" /> is false.</summary>
        public string ErrorMessage { get; set; }

        /// <summary>UTC expiry after which Telegram capability is probed again.</summary>
        public DateTime ExpiresAtUtc { get; set; }
    }

    /// <summary>
    /// Creates a bounded cancellation scope for owner-panel Telegram validation calls.
    /// </summary>
    /// <param name="outerCancellationToken">Update-handler token that must also cancel the validation probe.</param>
    /// <returns>
    /// Disposable linked source that expires after the configured Telegram bot startup probe timeout, clamped to
    /// five through sixty seconds.
    /// </returns>
    /// <remarks>
    /// Panel refresh, token validation, and forced-join capability checks share this bound so none can hold a
    /// Telegram callback open for the library's default one-hundred-second HTTP timeout.
    /// </remarks>
    private CancellationTokenSource CreateTenantTelegramProbeCancellation(CancellationToken outerCancellationToken)
    {
        var seconds = Math.Clamp(_appConfig.TelegramBotStartupProbeTimeoutSeconds, 5, 60);
        var source = CancellationTokenSource.CreateLinkedTokenSource(outerCancellationToken);
        source.CancelAfter(TimeSpan.FromSeconds(seconds));
        return source;
    }

    /// <summary>
    /// sends A tenant customer the channel buttons required for forced join.
    /// </summary>
    /// <param name="botClient">tenant Bot client used to Send the PROMPT.</param>
    /// <param name="ChatId">customer chat Id.</param>
    /// <param name="Channels">tenant channel ids or USERNAMES configured by the owner.</param>
    /// <param name="CancellationToken">Cancellation Token for Telegram delivery.</param>
    /// <param name="PromptText">
    /// Optional customer-facing text used when a retry or Telegram access error needs a more specific message.
    /// When null, the default first-time join prompt is sent.
    /// </param>
    private static async Task SENDTENANTJOINPROMPTASYNC(
        ITelegramBotClient botClient,
        ChatId ChatId,
        IReadOnlyCollection<string> Channels,
        CancellationToken CancellationToken,
        string PromptText = null)
    {
        var rows = Channels
            .Select(channel =>
            {
                var URL = channel.StartsWith("@", StringComparison.Ordinal)
                    ? $"HTTPS://t.me/{channel.TrimStart('@')}"
                    : channel;
                return new[] { InlineKeyboardButton.WithUrl("عضویت در کانال", URL) };
            })
            .Append(new[] { InlineKeyboardButton.WithCallbackData("عضو شدم", CUSTOMERCALLBACKPREFIX + "joincheck") })
            .ToArray();

        await botClient.SendMessage(
            ChatId,
            PromptText ?? "برای استفاده از فروشگاه ابتدا در کانال معرفی‌شده عضو شوید و سپس دوباره تلاش کنید.",
            replyMarkup: new InlineKeyboardMarkup(rows),
            cancellationToken: CancellationToken);
    }

    /// <summary>
    /// reads the tenant forced-join channel List from its Json Column.
    /// </summary>
    /// <param name="tenant">tenant Bot whose channel settings should be Parsed.</param>
    /// <returns>A non-null SEQUENCE of normalized channel USERNAMES, ids, or URLs.</returns>
    private static IEnumerable<string> GETTENANTCHANNELIDS(BotInstance tenant)
    {
        if (string.IsNullOrWhiteSpace(tenant?.TenantChannelIdsJson))
            return Array.Empty<string>();

        try
        {
            return JsonConvert.DeserializeObject<List<string>>(tenant.TenantChannelIdsJson)?
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray() ?? Array.Empty<string>();
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    /// <summary>
    /// Resumes settlement of an applied tenant renewal operation outside provider and Telegram callback flows.
    /// </summary>
    /// <param name="operation">Applied tenant operation containing the immutable tenant order id.</param>
    /// <param name="cancellationToken">Host shutdown token for order, wallet, ledger, panel-read, and notification work.</param>
    /// <returns>
    /// <c>true</c> when the tenant order was already fulfilled or fulfillment completed; <c>false</c> when the order
    /// cannot yet be safely settled and must remain locked.
    /// </returns>
    /// <remarks>
    /// The existing process-wide tenant fulfillment gate, order <c>IsFulfilled</c> check, and ledger uniqueness remain
    /// the financial idempotency boundary. This method never calls UpdateClient for an existing operation; the normal
    /// fulfillment path sees the applied operation and proceeds directly to one-time settlement.
    /// </remarks>
    /// <example><code>await tenantService.SettleRecoveredTenantRenewalAsync(operation, stoppingToken)</code></example>
    public async Task<bool> SettleRecoveredTenantRenewalAsync(
        XuiV3RenewalOperation operation,
        CancellationToken cancellationToken)
    {
        if (operation == null ||
            string.IsNullOrWhiteSpace(operation.TenantBotOrderId) ||
            operation.Status != XuiV3RenewalOperationStatuses.Applied)
        {
            return false;
        }

        var order = await _workflow.ReadAsync(async db => await db.TenantBotOrders
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.OrderId == operation.TenantBotOrderId, cancellationToken));
        if (order == null)
            return false;

        if (order.IsFulfilled)
        {
            await _renewalOperationStore.MarkSettledAsync(operation, cancellationToken);
            return true;
        }

        await FULFILLPAIDTENANTORDERASYNC(
            order,
            "renewal-background-reconciliation",
            null,
            null,
            order.ManualReceiptId.HasValue,
            cancellationToken);
        var refreshed = await _workflow.ReadAsync(async db => await db.TenantBotOrders
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == order.Id, cancellationToken));
        return refreshed?.IsFulfilled == true;
    }

    /// <summary>
    /// Fulfills a paid tenant renewal order by updating the existing XUI client instead of creating a new one.
    /// </summary>
    /// <param name="order">Paid tenant order whose <see cref="TenantBotOrder.OrderKind"/> is <c>renew</c>.</param>
    /// <param name="owner">Tenant owner whose wallet receives profit or is debited for card-to-card base cost.</param>
    /// <param name="customer">
    /// Tenant customer who pays for the renewal. For legacy owner-based orders this is also the account owner; for
    /// exact-lock orders it may be a different Telegram user and must not become the account owner.
    /// </param>
    /// <param name="tenant">Tenant bot that owns the storefront.</param>
    /// <param name="selection">Renewal service/plan selection stored on the order.</param>
    /// <param name="source">Settlement source such as IPN, manual check, or assistant confirmation.</param>
    /// <param name="debitOwnerBaseCost">Whether the owner should be debited base cost instead of credited profit.</param>
    /// <param name="cancellationToken">Cancellation token for panel, database, ledger, and Telegram operations.</param>
    /// <returns>
    /// Settlement result describing the owner balance movement or failure reason.
    /// </returns>
    /// <remarks>
    /// This method is called only from the tenant order fulfillment gate after duplicate-order checks.
    /// It reloads the target first and requires owner authorization for legacy orders or an exact stored email/UUID
    /// match for all new orders. It updates XUI first; wallet and ledger changes are recorded only after panel success.
    /// Rejected panel updates store and display a fixed safe status; raw response bodies and UUID locks are never copied
    /// into tenant order errors, Telegram messages, or central payment logs.
    /// The volume-reminder cycle is advanced best-effort after the update/reset and before settlement persistence;
    /// reminder-state failure cannot roll back the panel renewal or alter owner/customer balances.
    /// The selected unlimited plan is revalidated against tenant visibility before renewal calculation or XUI mutation.
    /// The identity-checked detail comment must also resolve to the same service key stored on the paid order. A transient
    /// detail-read failure remains retryable; a definitive metadata mismatch fails before UpdateClient and requires support.
    /// A customer-selected legacy category is honored only while the fresh compatible-service candidate set still contains
    /// the paid order's service. Historical paid ambiguous orders with no evidence mode stop for support review; they are
    /// not refunded automatically and never reach UpdateClient.
    /// The central order audit reports accumulated panel API time and total renewal/settlement time; time waiting for
    /// the payment provider or customer action is excluded.
    /// </remarks>
    private async Task<NowPaymentsSettlementResult> FULFILLPAIDTENANTRENEWORDERASYNC(
        TenantBotOrder order,
        CredUser owner,
        CredUser customer,
        BotInstance tenant,
        XuiV3PurchaseSelection selection,
        string source,
        bool debitOwnerBaseCost,
        CancellationToken cancellationToken)
    {
        if (await ISTENANTORDERALREADYFULFILLEDASYNC(order, cancellationToken))
            return NowPaymentsSettlementResult.AlreadyAdded(order.OwnerBalanceAfter ?? 0);

        using var operationTiming = XuiOperationTiming.Start();
        var serverInfo = BuildConfiguredPanelServerInfo();
        var hasExactTargetLock = !string.IsNullOrWhiteSpace(order.TargetAccountUuid);
        var client = hasExactTargetLock
            ? await FINDTENANTRENEWTARGETBYLOCKASYNC(
                serverInfo,
                order.TargetAccountEmail,
                order.TargetAccountUuid,
                cancellationToken)
            : await FindTenantClientAsync(serverInfo, order.TargetAccountEmail, cancellationToken);
        client = await LOADFRESHTENANTRENEWSNAPSHOTASYNC(serverInfo, client, cancellationToken);
        var targetAuthorized = hasExactTargetLock ||
                               (client != null &&
                                ClientBelongsToTenantCustomer(client, order.CustomerTelegramUserId, order.TenantBotId));
        if (client == null || !targetAuthorized)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = hasExactTargetLock
                ? "Target account was not found or its exact identity lock no longer matches."
                : "Target account was not found or does not belong to this tenant customer.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await NOTIFYTENANTCUSTOMERFAILUREASYNC(order, "اکانت هدف تمدید پیدا نشد یا اطلاعات هویتی آن تغییر کرده است.", cancellationToken);
            LOGTENANTORDER(order, owner, customer, source, "renew-target-authorization-failed", timing: operationTiming.Snapshot());
            return NowPaymentsSettlementResult.NotFound();
        }

        var serviceResolution = await ResolveTenantRenewalServiceAsync(serverInfo, client, cancellationToken);
        if (!serviceResolution.Success &&
            serviceResolution.Status == XuiV3TenantRenewalServiceResolutionStatus.DetailUnavailable)
        {
            _logger.LogWarning(
                "Paid tenant renewal service revalidation is temporarily unavailable. tenantBotId={TenantBotId}, orderId={OrderId}",
                order.TenantBotId,
                order.OrderId);
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        var serviceAuthorized = TryAuthorizeTenantRenewalService(
            serviceResolution,
            order.ServiceKey,
            order.RenewalServiceResolutionMode,
            out var liveService,
            out var effectiveResolutionMode,
            out _);
        if (!serviceAuthorized ||
            !string.Equals(liveService.Key, order.ServiceKey, StringComparison.OrdinalIgnoreCase))
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = serviceResolution.RequiresCustomerSelection &&
                                 string.IsNullOrWhiteSpace(order.RenewalServiceResolutionMode)
                ? "Paid legacy renewal has no durable service-category evidence and requires support review."
                : "Tenant renewal target service does not match the paid order service.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogError(
                "Paid tenant renewal rejected before XUI mutation because the live account service differed. tenantBotId={TenantBotId}, orderId={OrderId}, storedServiceKey={StoredServiceKey}, resolutionStatus={ResolutionStatus}, liveServiceKey={LiveServiceKey}",
                order.TenantBotId,
                order.OrderId,
                order.ServiceKey,
                serviceResolution.Status,
                liveService?.Key ?? serviceResolution.Service?.Key ?? "none");
            await NOTIFYTENANTCUSTOMERFAILUREASYNC(
                order,
                "نوع سرویس فعلی اکانت با سفارش پرداخت‌شده یکسان نیست؛ اکانت تغییر نکرد. لطفاً برای بررسی پرداخت با پشتیبانی تماس بگیرید.",
                cancellationToken);
            return NowPaymentsSettlementResult.InvalidAmount();
        }

        if (!string.Equals(
                order.RenewalServiceResolutionMode,
                effectiveResolutionMode,
                StringComparison.Ordinal))
        {
            order.RenewalServiceResolutionMode = effectiveResolutionMode;
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
        }

        XuiV3ResolvedPurchase resolved;
        try
        {
            resolved = _purchaseService.ResolveTenantPurchase(selection, false);
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException or OverflowException)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Failed;
            order.ErrorMessage = "Tenant renewal plan is no longer available for fulfillment.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            _logger.LogWarning(
                ex,
                "Paid tenant renewal fulfillment rejected by current plan audience. tenantBotId={TenantBotId}, orderId={OrderId}, serviceKey={ServiceKey}",
                order.TenantBotId,
                order.OrderId,
                order.ServiceKey);
            await NOTIFYTENANTCUSTOMERFAILUREASYNC(
                order,
                "پلن تمدید این سفارش دیگر در فروشگاه فعال نیست و اکانت تغییر نکرد. لطفاً با پشتیبانی تماس بگیرید.",
                cancellationToken);
            return NowPaymentsSettlementResult.InvalidAmount();
        }

        resolved.PriceToman = order.SalePriceToman;
        var tenantRenewalOperationKey = "tenant-renew-" + order.OrderId;
        var blockingOperation = await _renewalOperationStore.FindBlockingOperationAsync(
            client.Uuid,
            client.Email,
            tenantRenewalOperationKey,
            cancellationToken);
        if (blockingOperation != null)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Pending;
            order.ErrorMessage = "تمدید قبلی این اکانت در حال بررسی خودکار است و تمدید جدید موقتاً قفل شده است.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await NOTIFYTENANTCUSTOMERRETRYABLEFULFILLMENTASYNC(order, order.ErrorMessage, cancellationToken);
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        var renewal = XuiV3RenewalPolicy.Calculate(
            client,
            resolved,
            "tenant-renew",
            order.CustomerTelegramUserId,
            allowActorAsOwnerFallback: !hasExactTargetLock);

        // Exactly-once renewal guard: one operation row per tenant order. Repeated IPN/callback/check executions
        // resolve to the same row and never issue another XUI update.
        var existingOperation = await _renewalOperationStore.GetByKeyAsync(tenantRenewalOperationKey, cancellationToken);
        if (existingOperation != null)
        {
            return await ReconcileExistingTenantRenewalAsync(
                existingOperation, order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                operationTiming, cancellationToken);
        }

        XuiV3RenewalOperation tenantRenewalOperation;
        try
        {
            tenantRenewalOperation = await CreateTenantRenewalOperationAsync(
                tenantRenewalOperationKey, order, tenant, client, renewal, cancellationToken);
        }
        catch (XuiV3RenewalOperationStore.AccountRenewalLockedException)
        {
            order.PaymentStatus = TenantBotOrderStatuses.Pending;
            order.ErrorMessage = "تمدید قبلی این اکانت در حال بررسی خودکار است و تمدید جدید موقتاً قفل شده است.";
            order.UpdatedAtUtc = DateTime.UtcNow;
            await _workflow.SaveAsync(cancellationToken);
            await NOTIFYTENANTCUSTOMERRETRYABLEFULFILLMENTASYNC(order, order.ErrorMessage, cancellationToken);
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }
        if (tenantRenewalOperation == null)
        {
            var racedOperation = await _renewalOperationStore.GetByKeyAsync(tenantRenewalOperationKey, cancellationToken);
            if (racedOperation != null)
            {
                return await ReconcileExistingTenantRenewalAsync(
                    racedOperation, order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                    operationTiming, cancellationToken);
            }

            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        if (!await _renewalOperationStore.TryClaimFreshAsync(tenantRenewalOperation, cancellationToken))
        {
            return await ReconcileExistingTenantRenewalAsync(
                tenantRenewalOperation, order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                operationTiming, cancellationToken);
        }

        if (!await _renewalOperationStore.MarkMutationStartedAsync(tenantRenewalOperation, cancellationToken))
        {
            return await ReconcileExistingTenantRenewalAsync(
                tenantRenewalOperation, order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                operationTiming, cancellationToken);
        }

        var tenantMutationSucceeded = false;
        try
        {
            // The tenant renewal mutation is sent exactly once with the absolute target; it is never blindly retried.
            var updateResponse = await ApiServicev3.UpdateClientAsync(
                serverInfo,
                _configuration,
                client.Email,
                renewal.Payload,
                cancellationToken,
                XuiV3RequestRetryMode.NoAutomaticRetry);
            tenantMutationSucceeded = updateResponse.Success;
            if (!tenantMutationSucceeded)
            {
                await _renewalOperationStore.MarkFailedAsync(
                    tenantRenewalOperation,
                    SanitizeTenantRenewalFailure(updateResponse.Msg),
                    cancellationToken);
                order.PaymentStatus = TenantBotOrderStatuses.Failed;
                order.ErrorMessage = "Panel renewal update was rejected.";
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
                await NOTIFYTENANTCUSTOMERFAILUREASYNC(
                    order,
                    "تمدید در پنل انجام نشد. لطفاً کمی بعد وضعیت سفارش را دوباره بررسی کنید.",
                    cancellationToken);
                LOGTENANTORDER(order, owner, customer, source, "renew-update-failed", timing: operationTiming.Snapshot());
                return NowPaymentsSettlementResult.InvalidAmount();
            }
        }
        catch (Exception ex) when (ApiServicev3.IsTransientXuiTransportException(ex, cancellationToken))
        {
            // Ambiguous timeout: never send another update. Read the panel back and compare with the stored target.
            var (comparison, recoveredClient) = await _renewalOperationStore.RecoverByReadBackAsync(
                tenantRenewalOperation, serverInfo, _configuration, cancellationToken);
            if (comparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Applied)
            {
                tenantMutationSucceeded = true;
                client = recoveredClient ?? client;
            }
            else
            {
                await _renewalOperationStore.MarkAmbiguousAsync(
                    tenantRenewalOperation,
                    comparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Unavailable
                        ? "Tenant renewal update timed out and the read-back could not determine the outcome."
                        : "Tenant renewal update timed out and the read-back showed the target was not applied.",
                    cancellationToken,
                    comparison);
                order.PaymentStatus = TenantBotOrderStatuses.Pending;
                order.ErrorMessage = "نتیجه تمدید در پنل هنوز قطعی نیست؛ درخواست خودکار بررسی می‌شود و تمدید جدید این اکانت موقتاً قفل است.";
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
                _logger.LogWarning(
                    ex,
                    "Tenant renewal outcome is ambiguous; the mutation will not be replayed. renewalOperationId={RenewalOperationId}, orderId={OrderId}",
                    tenantRenewalOperation.OperationId,
                    order.OrderId);
                LOGTENANTORDER(order, owner, customer, source, "renew-ambiguous", timing: operationTiming.Snapshot());
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }
        }

        if (!await _renewalOperationStore.MarkAppliedAsync(tenantRenewalOperation, cancellationToken))
        {
            return await ReconcileExistingTenantRenewalAsync(
                tenantRenewalOperation, order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                operationTiming, cancellationToken);
        }

        return await CompleteTenantRenewalFulfillmentAsync(
            order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
            client, renewal, tenantRenewalOperation, operationTiming, cancellationToken);
    }

    /// <summary>
    /// Persists a new tenant renewal operation with the exact absolute target before the XUI mutation.
    /// </summary>
    /// <param name="operationKey">Stable key <c>tenant-renew-{orderId}</c>.</param>
    /// <param name="order">Paid tenant renewal order that owns the operation.</param>
    /// <param name="tenant">Tenant bot that owns the storefront.</param>
    /// <param name="client">Fresh panel client whose pre-renewal state is snapshotted.</param>
    /// <param name="renewal">Renewal calculation containing the absolute target payload.</param>
    /// <param name="cancellationToken">Token that cancels the users.db insert.</param>
    /// <returns>
    /// The newly created operation, or <c>null</c> when a concurrent duplicate inserted the same key first.
    /// </returns>
    private async Task<XuiV3RenewalOperation> CreateTenantRenewalOperationAsync(
        string operationKey,
        TenantBotOrder order,
        BotInstance tenant,
        XuiV3Client client,
        XuiV3RenewalCalculation renewal,
        CancellationToken cancellationToken)
    {
        var draft = new XuiV3RenewalOperationStore.RenewalOperationDraft
        {
            OperationKey = operationKey,
            BotId = tenant?.Id ?? order.TenantBotId,
            TenantBotId = order.TenantBotId,
            TenantBotOrderId = order.OrderId,
            TelegramUserId = order.CustomerTelegramUserId,
            TargetEmail = client.Email,
            // The operation lock is panel-derived even for compatible legacy tenant orders without an order UUID.
            TargetUuid = client.Uuid ?? string.Empty,
            ServiceKey = order.ServiceKey,
            AddedTrafficGb = renewal.RenewedTrafficGb,
            AddedTrafficBytes = renewal.RenewedTrafficBytes,
            AddedDurationDays = renewal.AddedDurationDays,
            PriceToman = order.SalePriceToman,
            PaymentMethod = "tenant_order",
            ExpectedTotalBytesBefore = renewal.CurrentTotalBytes,
            ExpectedExpiryTimeBefore = renewal.CurrentExpiryTime,
            TargetTotalBytes = renewal.Payload.TotalGB,
            TargetExpiryTime = renewal.Payload.ExpiryTime,
            MutationPayloadJson = JsonConvert.SerializeObject(renewal.Payload),
            PreMutationSnapshotJson = XuiV3RenewalOperationStore.BuildPreMutationSnapshotJson(client),
            ShouldResetTraffic = renewal.ShouldResetTraffic,
            IsUnlimited = renewal.IsUnlimited,
            ExpectedInboundIds = client.InboundIds ?? new List<int>()
        };

        var (operation, created) = await _renewalOperationStore.CreateOrGetAsync(draft, cancellationToken);
        return created ? operation : null;
    }

    /// <summary>
    /// Resolves an already-existing tenant renewal operation without sending any new XUI mutation.
    /// </summary>
    /// <param name="operation">Existing operation row returned by the deduplication lookup.</param>
    /// <param name="order">Paid tenant renewal order.</param>
    /// <param name="owner">Tenant owner profile.</param>
    /// <param name="customer">Tenant customer profile.</param>
    /// <param name="tenant">Tenant bot instance.</param>
    /// <param name="selection">Renewal plan selection stored on the order.</param>
    /// <param name="source">Settlement source for audit.</param>
    /// <param name="debitOwnerBaseCost">Whether the owner is debited base cost instead of credited profit.</param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, and Telegram operations.</param>
    /// <returns>
    /// The fulfillment result. Applied operations continue the order fulfillment exactly once; ambiguous operations
    /// are reconciled read-only; in-progress operations return without mutating.
    /// </returns>
    private async Task<NowPaymentsSettlementResult> ReconcileExistingTenantRenewalAsync(
        XuiV3RenewalOperation operation,
        TenantBotOrder order,
        CredUser owner,
        CredUser customer,
        BotInstance tenant,
        XuiV3PurchaseSelection selection,
        string source,
        bool debitOwnerBaseCost,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        switch (operation.Status)
        {
            case XuiV3RenewalOperationStatuses.Applied:
                break;

            case XuiV3RenewalOperationStatuses.Ambiguous:
            {
                var (comparison, recoveredClient) = await _renewalOperationStore.RecoverByReadBackAsync(
                    operation, serverInfo, _configuration, cancellationToken);
                if (comparison.Outcome != XuiV3RenewalOperationStore.RecoveryOutcome.Applied)
                {
                    _logger.LogWarning(
                        "Tenant renewal remains ambiguous; no mutation will be replayed. renewalOperationId={RenewalOperationId}, orderId={OrderId}",
                        operation.OperationId,
                        order.OrderId);
                    return NowPaymentsSettlementResult.ProviderNotPaid();
                }

                if (!await _renewalOperationStore.ResolveAmbiguousToAppliedAsync(operation, comparison, cancellationToken))
                    return NowPaymentsSettlementResult.AlreadyAdded(order.OwnerBalanceAfter ?? 0);

                var renewal = RebuildTenantRenewalForOperation(operation);
                var payload = RebuildTenantPayloadForOperation(operation);
                if (payload != null)
                {
                    recoveredClient ??= BuildTenantMirroredClientForPayload(payload);
                    recoveredClient.TotalGB = payload.TotalGB;
                    recoveredClient.ExpiryTime = payload.ExpiryTime;
                    recoveredClient.Comment = payload.Comment;
                }

                return await CompleteTenantRenewalFulfillmentAsync(
                    order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
                    recoveredClient, renewal, operation, operationTiming, cancellationToken);
            }

            case XuiV3RenewalOperationStatuses.Failed:
                return NowPaymentsSettlementResult.InvalidAmount();

            case XuiV3RenewalOperationStatuses.ManualReview:
                order.PaymentStatus = TenantBotOrderStatuses.Pending;
                order.ErrorMessage = "نتیجه تمدید برای بررسی دستی ثبت شده و تمدید جدید این اکانت همچنان قفل است.";
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();

            default:
                order.PaymentStatus = TenantBotOrderStatuses.Pending;
                order.ErrorMessage = "تمدید در حال انجام یا بررسی خودکار است و برای جلوگیری از تکرار موقتاً قفل شده است.";
                order.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        // Applied: reload the order and continue the one-time fulfillment when it did not complete yet.
        if (await ISTENANTORDERALREADYFULFILLEDASYNC(order, cancellationToken))
            return NowPaymentsSettlementResult.AlreadyAdded(order.OwnerBalanceAfter ?? 0);

        var (readComparison, readClient) = await _renewalOperationStore.RecoverByReadBackAsync(
            operation, serverInfo, _configuration, cancellationToken);
        var appliedClient = readComparison.Outcome == XuiV3RenewalOperationStore.RecoveryOutcome.Applied && readClient != null
            ? readClient
            : BuildTenantMirroredClientForPayload(RebuildTenantPayloadForOperation(operation));
        return await CompleteTenantRenewalFulfillmentAsync(
            order, owner, customer, tenant, selection, source, debitOwnerBaseCost,
            appliedClient, RebuildTenantRenewalForOperation(operation), operation, operationTiming, cancellationToken);
    }

    /// <summary>
    /// Rebuilds a display-only tenant renewal calculation from a stored operation after a crash take-over.
    /// </summary>
    /// <param name="operation">Operation whose stored target values feed the reconstruction.</param>
    /// <returns>A detached renewal calculation used by reset and display code; it is never sent to XUI again.</returns>
    private static XuiV3RenewalCalculation RebuildTenantRenewalForOperation(XuiV3RenewalOperation operation)
    {
        return new XuiV3RenewalCalculation
        {
            Payload = RebuildTenantPayloadForOperation(operation),
            IsUnlimited = operation.IsUnlimited,
            ShouldResetTraffic = operation.ShouldResetTraffic,
            CurrentTotalBytes = operation.ExpectedTotalBytesBefore,
            CurrentExpiryTime = operation.ExpectedExpiryTimeBefore,
            RenewedTrafficGb = operation.AddedTrafficGb,
            RenewedTrafficBytes = operation.AddedTrafficBytes,
            TotalBytesAfterRenew = operation.TargetTotalBytes,
            UpdatedExpiryTime = operation.TargetExpiryTime,
            AddedDurationDays = operation.AddedDurationDays,
            FinalDurationDays = operation.AddedDurationDays,
            TargetAvailableTrafficGb = operation.AddedTrafficGb,
            TargetAvailableTrafficBytes = operation.AddedTrafficBytes
        };
    }

    /// <summary>
    /// Deserializes the exact tenant renewal mutation payload persisted before the original attempt.
    /// </summary>
    /// <param name="operation">Operation whose stored payload JSON is loaded.</param>
    /// <returns>The exact payload, or <c>null</c> when it is missing or corrupt.</returns>
    private static XuiV3ClientPayload RebuildTenantPayloadForOperation(XuiV3RenewalOperation operation)
    {
        if (string.IsNullOrWhiteSpace(operation.MutationPayloadJson))
            return null;

        try
        {
            return JsonConvert.DeserializeObject<XuiV3ClientPayload>(operation.MutationPayloadJson);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Builds a minimal client view from the stored tenant payload for fulfillment rendering.
    /// </summary>
    /// <param name="payload">Stored absolute payload that was applied to the panel.</param>
    /// <returns>A detached client mirroring the payload fields, or <c>null</c> when the payload is missing.</returns>
    private static XuiV3Client BuildTenantMirroredClientForPayload(XuiV3ClientPayload payload)
    {
        if (payload == null)
            return null;

        return new XuiV3Client
        {
            Email = payload.Email,
            SubId = payload.SubId,
            TotalGB = payload.TotalGB,
            ExpiryTime = payload.ExpiryTime,
            Comment = payload.Comment,
            Enable = payload.Enable,
            TgId = payload.TgId,
            Uuid = payload.Uuid,
            Traffic = new XuiV3ClientTraffic { Email = payload.Email, TotalGB = payload.TotalGB, ExpiryTime = payload.ExpiryTime, Enable = payload.Enable }
        };
    }

    /// <summary>
    /// Bounds a tenant panel rejection message for storage on the renewal operation row.
    /// </summary>
    /// <param name="panelMessage">Raw panel message.</param>
    /// <returns>A bounded sanitized message safe for the private diagnostics column.</returns>
    private static string SanitizeTenantRenewalFailure(string panelMessage)
    {
        var value = string.IsNullOrWhiteSpace(panelMessage)
            ? "panel rejected the renewal"
            : panelMessage.Trim();
        return value.Length <= 500 ? value : value[..500];
    }

    /// <summary>
    /// Completes the one-time tenant renewal fulfillment after the XUI mutation is applied exactly once.
    /// </summary>
    /// <param name="order">Paid tenant renewal order that becomes fulfilled.</param>
    /// <param name="owner">Tenant owner whose wallet is settled.</param>
    /// <param name="customer">Tenant customer who pays.</param>
    /// <param name="tenant">Tenant bot instance.</param>
    /// <param name="selection">Renewal plan selection stored on the order.</param>
    /// <param name="source">Settlement source such as IPN, manual check, or assistant confirmation.</param>
    /// <param name="debitOwnerBaseCost">Whether the owner is debited base cost instead of credited profit.</param>
    /// <param name="client">Fresh panel client whose fields mirror the applied payload.</param>
    /// <param name="renewal">Renewal calculation used for reset and display values.</param>
    /// <param name="renewalOperation">
    /// Applied durable operation whose account lock is released only after order settlement is persisted.
    /// </param>
    /// <param name="operationTiming">Active operation timer used for audits.</param>
    /// <param name="cancellationToken">Token that cancels panel, users.db, ledger, and Telegram operations.</param>
    /// <returns>The settlement result; the order-level ledger uniqueness prevents any duplicate settlement.</returns>
    private async Task<NowPaymentsSettlementResult> CompleteTenantRenewalFulfillmentAsync(
        TenantBotOrder order,
        CredUser owner,
        CredUser customer,
        BotInstance tenant,
        XuiV3PurchaseSelection selection,
        string source,
        bool debitOwnerBaseCost,
        XuiV3Client client,
        XuiV3RenewalCalculation renewal,
        XuiV3RenewalOperation renewalOperation,
        XuiOperationTiming operationTiming,
        CancellationToken cancellationToken)
    {
        var serverInfo = BuildConfiguredPanelServerInfo();
        var fulfillmentCommitted = false;
        var trafficResetApplied = !renewal.ShouldResetTraffic ||
                                  await RESETTENANTRENEWEDTRAFFICASYNC(
                                      serverInfo,
                                      client.Email,
                                      cancellationToken);

        await _volumeReminderStateStore.TryBeginNewCycleAfterRenewalAsync(
            serverInfo,
            client,
            renewal,
            trafficResetApplied,
            cancellationToken);

        client.TotalGB = renewal.Payload.TotalGB;
        client.ExpiryTime = renewal.Payload.ExpiryTime;
        client.Comment = renewal.Payload.Comment;

        var settlement = await SETTLETENANTOWNERWALLETASYNC(
            order,
            owner,
            debitOwnerBaseCost,
            referenceType: "tenant-renew-order",
            cancellationToken);

        order.IsFulfilled = true;
        order.IsOwnerCredited = settlement.OwnerDelta > 0;
        order.OwnerWalletDelta = settlement.OwnerDelta;
        order.OwnerBalanceBefore = settlement.BotWalletBefore;
        order.OwnerBalanceAfter = settlement.BotWalletAfter;
        order.PaymentStatus = TenantBotOrderStatuses.Fulfilled;
        order.FulfillmentSource = source;
        order.CreatedAccountEmail = client.Email;
        order.CreatedSubLink = ApiServicev3.BuildSubscriptionLink(serverInfo, client.SubId ?? client.Email);
        order.CreatedAccountJson = JsonConvert.SerializeObject(new XuiV3AccountCreationResult
        {
            Success = true,
            Email = client.Email,
            SubId = client.SubId,
            SubLink = order.CreatedSubLink,
            TrafficGb = renewal.RenewedTrafficGb,
            TrafficBytes = renewal.TotalBytesAfterRenew,
            ExpiryTime = renewal.UpdatedExpiryTime,
            DurationDays = renewal.FinalDurationDays,
            Comment = renewal.Payload.Comment
        });
        order.FulfilledAtUtc = DateTime.UtcNow;
        order.UpdatedAtUtc = DateTime.UtcNow;
        await CLEARTENANTORDERFULFILLMENTERRORASYNC(order, cancellationToken);

        _workflow.Add(new TenantBotLedgerEntry
        {
            TenantBotId = order.TenantBotId,
            TenantBotUsername = order.TenantBotUsername,
            TenantBotOrderId = order.Id,
            OrderId = order.OrderId,
            OwnerTelegramUserId = order.OwnerTelegramUserId,
            CustomerTelegramUserId = order.CustomerTelegramUserId,
            SalePriceToman = order.SalePriceToman,
            BaseCostToman = order.BaseCostToman,
            ProfitToman = settlement.OwnerDelta,
            OwnerBalanceBefore = settlement.BotWalletBefore,
            OwnerBalanceAfter = settlement.BotWalletAfter,
            Description = $"tenant Bot renewal VIA @{order.TenantBotUsername}",
            CreatedAtUtc = DateTime.UtcNow
        });

        var notificationQueueStarted = Stopwatch.GetTimestamp();
        ADDTENANTORDERNOTIFICATIONINTENTSFORCOMMIT(
            order,
            includeOwnerAccountDetails: string.Equals(source, "assistant-final", StringComparison.OrdinalIgnoreCase));
        await _workflow.SaveAsync(cancellationToken);
        fulfillmentCommitted = true;
        var notificationQueueElapsed = Stopwatch.GetElapsedTime(notificationQueueStarted);

        try
        {
            // Tenant order and ledger are now durable. Releasing the operation lock before this point could allow a
            // second renewal while the first panel mutation was applied but its owner settlement was still incomplete.
            await MarkTenantRenewalOperationSettledAfterCommitAsync(renewalOperation, cancellationToken);
            await OBSERVETENANTFUNDINGSETTLEMENTBESTEFFORTASYNC(tenant, settlement, cancellationToken);
            var coreTiming = operationTiming.Snapshot();

            await QueueGozargahSyncBestEffortAsync(
                "tenant-renew",
                () => _gozargahSiteSyncService.QueueUpdateAsync(
                    order.OwnerTelegramUserId,
                    order.CustomerTelegramUserId,
                    client,
                    serverInfo,
                    order.OrderId,
                    order.TenantBotId,
                    cancellationToken,
                    deferSend: true));

            var callbackTotal = operationTiming.TotalElapsed;
            LOGTENANTORDER(order, owner, customer, source, "renew-fulfilled", settlement, coreTiming, notificationQueueElapsed);
            LOGTENANTFULFILLMENTTIMING(order, coreTiming, notificationQueueElapsed, callbackTotal);
        }
        catch (Exception ex)
        {
            if (!fulfillmentCommitted)
                throw;

            // The renewal, ledger, and notification intents are durable. Post-commit bookkeeping (the operation
            // settlement flag or the optional website mirror) must never turn a fulfilled renewal back into a
            // failure or repeat a financial/XUI mutation; the recovery worker settles the operation from its
            // durable Applied state on a later cycle.
            _logger.LogWarning(
                ex,
                "Tenant renewal post-commit work failed after durable fulfillment. orderId={OrderId} ErrorType={ErrorType}",
                order.OrderId,
                ex.GetType().Name);
        }
        return NowPaymentsSettlementResult.Applied(settlement.BotWalletBefore, settlement.BotWalletAfter);
    }

    /// <summary>
    /// Marks a tenant renewal operation as settled after the durable order, ledger, and notification commit.
    /// </summary>
    /// <param name="renewalOperation">Applied renewal operation whose account lock is released by settlement.</param>
    /// <param name="cancellationToken">Cancellation of the short users.db update.</param>
    /// <returns>A task completing after the settlement flag is persisted.</returns>
    /// <remarks>
    /// This seam exists so regression tests can inject a failure at the post-commit boundary; production behavior is
    /// exactly the renewal-operation store call. A failure here must never revert the already-durable fulfillment.
    /// </remarks>
    internal virtual Task MarkTenantRenewalOperationSettledAfterCommitAsync(
        XuiV3RenewalOperation renewalOperation,
        CancellationToken cancellationToken)
        => _renewalOperationStore.MarkSettledAsync(renewalOperation, cancellationToken);

    /// <summary>
    /// Resets traffic counters after a tenant renewal when the shared renewal policy requires it.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor.</param>
    /// <param name="email">XUI client email whose counters should be reset.</param>
    /// <param name="cancellationToken">Cancellation token for panel API calls.</param>
    /// <returns>
    /// <c>true</c> when the primary reset endpoint or the zero-counter fallback succeeds; otherwise <c>false</c>. The
    /// caller uses this only to record conservative post-renewal reminder usage and retains existing fulfillment rules.
    /// </returns>
    /// <remarks>
    /// This method changes only panel traffic counters. It does not write tenant orders, owner wallets, ledgers, or
    /// reminder state; those effects remain owned by their existing callers.
    /// </remarks>
    private async Task<bool> RESETTENANTRENEWEDTRAFFICASYNC(
        ServerInfo serverInfo,
        string email,
        CancellationToken cancellationToken)
    {
        var resetResponse = await ApiServicev3.ResetClientTrafficAsync(serverInfo, _configuration, email, cancellationToken);
        if (resetResponse.Success)
            return true;

        var fallbackResponse = await ApiServicev3.UpdateClientTrafficAsync(
            serverInfo,
            _configuration,
            email,
            0,
            0,
            cancellationToken);
        return fallbackResponse.Success;
    }

    /// <summary>
    /// Sends the customer-facing success message for a fulfilled tenant renewal order.
    /// </summary>
    /// <param name="order">
    /// Fulfilled tenant renewal order containing tenant id, customer chat id, payment amount in toman, account email,
    /// order id, and subscription link. The order must already be persisted as fulfilled.
    /// </param>
    /// <param name="renewal">
    /// Shared renewal result that was successfully applied to XUI. Its exact added traffic, total quota, reset flag,
    /// and final duration are safe to include in the customer notification.
    /// </param>
    /// <param name="cancellationToken">Token that cancels only the best-effort Telegram delivery operation.</param>
    /// <returns>A task that completes after the best-effort tenant-bot notification attempt.</returns>
    /// <remarks>
    /// Notification failure is logged and does not roll back account renewal or financial settlement. Unlimited text
    /// reports the exact selected traffic added, or the replacement traffic when the expired account was reset.
    /// </remarks>
    private async Task SENDTENANTRENEWSUCCESSASYNC(
        TenantBotOrder order,
        XuiV3RenewalCalculation renewal,
        CancellationToken cancellationToken)
    {
        try
        {
            var text =
                "✅ <b>اکانت شما با موفقیت تمدید شد.</b>\n\n" +
                $"اکانت: <code>{Html(order.CreatedAccountEmail)}</code>\n" +
                $"شماره سفارش: <code>{Html(order.OrderId)}</code>\n" +
                $"مبلغ پرداختی: <code>{Html(order.SalePriceToman.FormatCurrency())}</code>\n" +
                (renewal.IsUnlimited
                    ? renewal.ShouldResetTraffic
                        ? $"حجم جدید بعد از ریست مصرف: <code>{Html(renewal.RenewedTrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n"
                        : $"حجم اضافه: <code>{Html(renewal.RenewedTrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n" +
                          $"حجم کل بعد از تمدید: <code>{Html(XuiV3PurchaseService.FormatTrafficSize(renewal.TotalBytesAfterRenew))}</code>\n"
                    : $"حجم تمدید: <code>{Html(renewal.RenewedTrafficGb.ToString(CultureInfo.InvariantCulture))} GB</code>\n") +
                $"مدت نهایی: <code>{Html(renewal.FinalDurationDays <= 0 ? "نامحدود" : renewal.FinalDurationDays + " روز")}</code>\n" +
                $"ساب‌لینک: <code>{Html(order.CreatedSubLink)}</code>";

            await _botClientProvider.GetClient(order.TenantBotId).SendMessage(
                order.CustomerChatId,
                text,
                parseMode: ParseMode.Html,
                cancellationToken: cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Tenant renewal success notification failed. orderId={OrderId}", order.OrderId);
        }
    }

    /// <summary>
    /// Reloads a tenant renewal target and verifies its email-plus-UUID lock or the legacy storefront-owner fallback.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor used for the fresh account lookup.</param>
    /// <param name="user">
    /// Current tenant-scoped renewal state containing the target account email and a normalized UUID lock for all new
    /// renewals. Legacy states may leave the UUID empty.
    /// </param>
    /// <param name="customerTelegramUserId">
    /// Numeric Telegram id of the payer. It is used for ownership only by legacy states without a UUID lock.
    /// </param>
    /// <param name="tenantBotId">Internal tenant bot id that scopes owner-based account metadata.</param>
    /// <param name="cancellationToken">Token that cancels panel reads.</param>
    /// <returns>
    /// The fresh detached panel client when authorization still matches, or <c>null</c> when the account was deleted,
    /// rebuilt with another UUID, moved outside the tenant, or no longer belongs to the customer.
    /// </returns>
    /// <remarks>
    /// The exact lock authorizes renewal only and grants no configuration or management access. The method has no
    /// wallet, order, Telegram, or panel mutation side effects and must be called again at each financial boundary.
    /// </remarks>
    private async Task<XuiV3Client> GetAuthorizedTenantRenewClientAsync(
        ServerInfo serverInfo,
        User user,
        long customerTelegramUserId,
        string tenantBotId,
        CancellationToken cancellationToken)
    {
        if (user == null || string.IsNullOrWhiteSpace(user.ConfigLink))
            return null;

        if (string.IsNullOrWhiteSpace(user.RenewTargetUuid))
        {
            var legacyClient = await FindTenantClientAsync(serverInfo, user.ConfigLink, cancellationToken);
            return ClientBelongsToTenantCustomer(legacyClient, customerTelegramUserId, tenantBotId)
                ? legacyClient
                : null;
        }

        return await FINDTENANTRENEWTARGETBYLOCKASYNC(
            serverInfo,
            user.ConfigLink,
            user.RenewTargetUuid,
            cancellationToken);
    }

    /// <summary>
    /// Finds exactly one tenant renewal client whose current email and UUID match a persisted target lock.
    /// </summary>
    /// <param name="serverInfo">Configured XUI panel descriptor used for one fresh client-list read.</param>
    /// <param name="email">Panel email saved in tenant state or order; it is required and never logged.</param>
    /// <param name="canonicalUuid">Canonical UUID saved independently from payment state; it is sensitive and never logged.</param>
    /// <param name="cancellationToken">Token that cancels the authenticated panel read.</param>
    /// <returns>
    /// The unique detached client matching both fields, or <c>null</c> when input is invalid, the client was deleted or
    /// rebuilt, the panel read fails, or duplicate rows make selection ambiguous.
    /// </returns>
    /// <remarks>
    /// This read-only helper is shared by preview/order validation and paid fulfillment. It never applies tenant
    /// ownership because the exact lock grants renewal only; management handlers continue enforcing ownership.
    /// </remarks>
    private async Task<XuiV3Client> FINDTENANTRENEWTARGETBYLOCKASYNC(
        ServerInfo serverInfo,
        string email,
        string canonicalUuid,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(email) ||
            !TryNormalizeTenantClientUuid(canonicalUuid, out var targetUuid))
        {
            return null;
        }

        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
            return null;

        var matches = response.Obj?
            .Where(client =>
                string.Equals(client.Email?.Trim(), email.Trim(), StringComparison.OrdinalIgnoreCase) &&
                TryNormalizeTenantClientUuid(client.Uuid, out var clientUuid) &&
                string.Equals(clientUuid, targetUuid, StringComparison.OrdinalIgnoreCase))
            .Take(2)
            .ToList() ?? new List<XuiV3Client>();
        return matches.Count == 1 ? matches[0] : null;
    }

    /// <summary>
    /// Reloads an authorized tenant renewal target from the complete list for a consistent pre-mutation snapshot.
    /// </summary>
    /// <param name="serverInfo">Configured panel descriptor used only for the authenticated client-list GET.</param>
    /// <param name="authorizedClient">Previously authorized tenant target with exact email and optional UUID.</param>
    /// <param name="cancellationToken">Token that cancels the read-only panel request.</param>
    /// <returns>The unique exact identity match, or null when safe identity observation is impossible.</returns>
    /// <remarks>
    /// Renewal does not modify inbound membership, so an empty attachment set is valid. This method has no order,
    /// wallet, Telegram, or panel mutation effects.
    /// </remarks>
    /// <example><code>client = await LOADFRESHTENANTRENEWSNAPSHOTASYNC(server, client, token)</code></example>
    private async Task<XuiV3Client> LOADFRESHTENANTRENEWSNAPSHOTASYNC(
        ServerInfo serverInfo,
        XuiV3Client authorizedClient,
        CancellationToken cancellationToken)
    {
        if (authorizedClient == null)
            return null;

        var response = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
        if (!response.Success)
            return null;

        var normalizedUuid = XuiV3RenewalOperationStore.NormalizeUuid(authorizedClient.Uuid);
        var normalizedEmail = XuiV3RenewalOperationStore.NormalizeEmail(authorizedClient.Email);
        var matches = (response.Obj ?? new List<XuiV3Client>())
            .Where(x =>
                string.Equals(
                    XuiV3RenewalOperationStore.NormalizeEmail(x.Email),
                    normalizedEmail,
                    StringComparison.Ordinal) &&
                (string.IsNullOrEmpty(normalizedUuid) ||
                 string.Equals(
                     XuiV3RenewalOperationStore.NormalizeUuid(x.Uuid),
                     normalizedUuid,
                     StringComparison.Ordinal)))
            .Take(2)
            .ToList();
        return matches.Count == 1 ? matches[0] : null;
    }

    /// <summary>
    /// Finds an XUI client for tenant renewal from email, UUID, config link, or subscription link input.
    /// </summary>
    /// <param name="serverInfo">Configured XUI v3 panel descriptor.</param>
    /// <param name="input">Customer-provided account identifier.</param>
    /// <param name="cancellationToken">Cancellation token for panel API calls.</param>
    /// <returns>
    /// The matched XUI client, or <c>null</c> when no client matches the normalized identifier or the panel
    /// rejects a direct lookup with a not-found response.
    /// </returns>
    /// <remarks>
    /// This legacy lookup only locates a candidate. Tenant ownership or an exact UUID lock is checked separately before renewal
    /// is allowed. Direct <c>GET clients/get</c>
    /// calls can return HTTP 404 for unknown emails, so those failures are treated as a miss and the method
    /// falls back to listing clients instead of allowing an exception to stop the tenant receiver. The identifier is
    /// never included in logs because it may be a UUID, SubId, or configuration URL. UUID/link input skips the direct
    /// identifier-bearing endpoint entirely so exception telemetry cannot capture a sensitive request URI.
    /// </remarks>
    private async Task<XuiV3Client> FindTenantClientAsync(ServerInfo serverInfo, string input, CancellationToken cancellationToken)
    {
        var candidate = NormalizeTenantAccountInput(input);
        if (string.IsNullOrWhiteSpace(candidate))
            return null;

        var lookupKind = XuiV3RenewalTargetParser.TryExtractUuid(input, out _)
            ? "uuid"
            : Uri.TryCreate(input, UriKind.Absolute, out _) ? "link" : "account";

        if (string.Equals(lookupKind, "account", StringComparison.Ordinal))
        {
            try
            {
                var direct = await ApiServicev3.GetClientAsync(serverInfo, _configuration, candidate, cancellationToken);
                if (direct.Success &&
                    direct.Obj != null &&
                    string.Equals(direct.Obj.Email?.Trim(), candidate.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    return direct.Obj;
                }
            }
            catch (XuiV3ApiException ex) when (ex.StatusCode == 404)
            {
                _logger.LogInformation(
                    "Tenant renewal direct XUI lookup returned not found. lookupKind={LookupKind}, statusCode={StatusCode}",
                    lookupKind,
                    ex.StatusCode);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(
                    "Tenant renewal direct XUI lookup failed. lookupKind={LookupKind}, errorType={ErrorType}",
                    lookupKind,
                    ex.GetType().Name);
            }
        }

        try
        {
            var clientsResponse = await ApiServicev3.GetClientsAsync(serverInfo, _configuration, cancellationToken);
            var clients = clientsResponse.Obj ?? new List<XuiV3Client>();
            return clients.FirstOrDefault(client =>
                string.Equals(client.Email, candidate, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(client.Uuid, candidate, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(client.SubId, candidate, StringComparison.OrdinalIgnoreCase));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "Tenant renewal client list lookup failed. lookupKind={LookupKind}, errorType={ErrorType}",
                lookupKind,
                ex.GetType().Name);
            return null;
        }
    }

    /// <summary>
    /// Normalizes account identifiers entered in tenant renewal flows.
    /// </summary>
    /// <param name="input">Raw customer input such as an email, UUID, VLESS link, VMess link, or subscription URL.</param>
    /// <returns>
    /// A likely email, UUID, or subscription id. Empty input and Telegram slash commands return <c>null</c>
    /// because commands must never be sent to the XUI <c>clients/get</c> endpoint as account identifiers.
    /// </returns>
    private static string NormalizeTenantAccountInput(string input)
    {
        var value = input?.Trim();
        if (string.IsNullOrWhiteSpace(value))
            return null;

        if (value.StartsWith("/", StringComparison.Ordinal))
            return null;

        if (value.StartsWith("vless://", StringComparison.OrdinalIgnoreCase))
        {
            var withoutScheme = value["vless://".Length..];
            var atIndex = withoutScheme.IndexOf('@');
            return atIndex > 0 ? withoutScheme[..atIndex] : withoutScheme.Split('?', '#')[0];
        }

        if (Uri.TryCreate(value, UriKind.Absolute, out var uri))
        {
            var lastSegment = uri.Segments.LastOrDefault()?.Trim('/');
            if (!string.IsNullOrWhiteSpace(lastSegment))
                return WebUtility.UrlDecode(lastSegment);
        }

        return value.Trim().Trim('`');
    }

    /// <summary>
    /// Normalizes a UUID field that must contain only one complete non-empty GUID.
    /// </summary>
    /// <param name="value">UUID read from panel client data or a previously canonicalized users.db/order proof.</param>
    /// <param name="uuid">Canonical dashed UUID when valid; otherwise an empty string.</param>
    /// <returns><c>true</c> only when the entire trimmed value is a valid non-empty GUID.</returns>
    /// <remarks>
    /// Customer input uses <see cref="XuiV3RenewalTargetParser"/> to extract UUIDs from VLESS/VMess text. Authorization
    /// boundaries use this stricter helper so extra text in a panel field or persisted proof can never compare as exact.
    /// </remarks>
    private static bool TryNormalizeTenantClientUuid(string value, out string uuid)
    {
        uuid = string.Empty;
        if (!Guid.TryParse(value?.Trim(), out var parsed) || parsed == Guid.Empty)
            return false;

        uuid = parsed.ToString();
        return true;
    }

    /// <summary>
    /// Checks whether a found XUI client belongs to the tenant customer and storefront.
    /// </summary>
    /// <param name="client">XUI client found on the configured panel.</param>
    /// <param name="customerTelegramUserId">Numeric Telegram user id of the tenant customer.</param>
    /// <param name="tenantBotId">Internal tenant bot id that owns the storefront.</param>
    /// <returns>
    /// <c>true</c> when the client belongs to the customer and is either created by the same tenant or has no
    /// bot ownership metadata from older records.
    /// </returns>
    private static bool ClientBelongsToTenantCustomer(XuiV3Client client, long customerTelegramUserId, string tenantBotId)
    {
        var metadata = TryReadTenantMetadata(client?.Comment);
        var ownerMatches = client?.TgId == customerTelegramUserId || metadata?.TelegramUserId == customerTelegramUserId;
        var tenantMatches = string.IsNullOrWhiteSpace(metadata?.CreatedByBotId) ||
                            string.Equals(metadata.CreatedByBotId, tenantBotId, StringComparison.OrdinalIgnoreCase);
        return ownerMatches && tenantMatches;
    }

    /// <summary>
    /// Reads the authoritative tenant renewal comment and resolves the account's current service category.
    /// </summary>
    /// <param name="serverInfo">
    /// Configured XUI v3 panel descriptor used only for authenticated read-only client detail access.
    /// </param>
    /// <param name="listClient">
    /// Exact client already authorized by email plus UUID, or by the legacy tenant-owner rule. Its identifiers and
    /// comment are sensitive and are never included in operational logs.
    /// </param>
    /// <param name="cancellationToken">Token that cancels the read-only panel request.</param>
    /// <returns>
    /// A sanitized service decision. Success contains the enabled category used by renewal; failure must stop state,
    /// order, payment-provider, wallet, and XUI mutation work until the customer starts or retries safely. On success,
    /// <paramref name="listClient" /> is enriched in memory with the authoritative structured comment when available.
    /// </returns>
    /// <remarks>
    /// <c>clients/list</c> can omit the comment needed to distinguish normal and unlimited accounts that share inbounds.
    /// This method therefore reads <c>clients/get/{email}</c>, validates email/UUID/numeric-id identity, and delegates the
    /// policy decision to the side-effect-free resolver. A transient detail failure may use already-readable list metadata
    /// but never the normal legacy fallback, preventing a network outage from changing the account category. Copying the
    /// verified comment onto the detached list row ensures the renewal policy preserves the original owner and audit history;
    /// it does not write to the panel or database. Expected legacy category selection is logged locally at Debug, while
    /// unavailable, conflicting, or mismatched detail evidence remains a sanitized Warning without client identifiers.
    /// </remarks>
    /// <example>
    /// <code>
    /// var resolution = await ResolveTenantRenewalServiceAsync(server, client, cancellationToken);
    /// if (!resolution.Success)
    ///     return;
    /// </code>
    /// </example>
    private async Task<XuiV3TenantRenewalServiceResolution> ResolveTenantRenewalServiceAsync(
        ServerInfo serverInfo,
        XuiV3Client listClient,
        CancellationToken cancellationToken)
    {
        if (listClient == null || string.IsNullOrWhiteSpace(listClient.Email))
        {
            return XuiV3TenantRenewalServiceResolver.Resolve(
                listClient,
                detailClient: null,
                XuiV3TenantClientDetailAvailability.NotFound,
                _purchaseService.GetEnabledServices());
        }

        XuiV3Client detailClient = null;
        var detailAvailability = XuiV3TenantClientDetailAvailability.Unavailable;
        try
        {
            var response = await ApiServicev3.GetClientAsync(
                serverInfo,
                _configuration,
                listClient.Email,
                cancellationToken);
            if (response.Success && response.Obj != null)
            {
                detailClient = response.Obj;
                detailAvailability = XuiV3TenantClientDetailAvailability.Available;
            }
        }
        catch (XuiV3ApiException ex) when (ex.StatusCode == StatusCodes.Status404NotFound)
        {
            detailAvailability = XuiV3TenantClientDetailAvailability.NotFound;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                "Tenant renewal client-detail lookup failed; service fallback is restricted to readable list metadata. errorType={ErrorType}",
                ex.GetType().Name);
        }

        var resolution = XuiV3TenantRenewalServiceResolver.Resolve(
            listClient,
            detailClient,
            detailAvailability,
            _purchaseService.GetEnabledServices());
        if (resolution.Success && !string.IsNullOrWhiteSpace(resolution.AuthoritativeComment))
        {
            // The list endpoint may omit comment metadata. Keep the verified detail comment on this detached snapshot so
            // renewal calculation preserves the original owner/service audit fields instead of rebuilding them from payer state.
            listClient.Comment = resolution.AuthoritativeComment;
        }

        if (resolution.Success)
        {
            _logger.LogDebug(
                "Tenant renewal service resolved. source={ResolutionSource}, serviceKey={ServiceKey}",
                resolution.Source,
                resolution.Service.Key);
        }
        else if (resolution.RequiresCustomerSelection)
        {
            _logger.LogDebug(
                "Tenant renewal service resolution requires explicit legacy category selection. candidateCount={CandidateCount}",
                resolution.CandidateServices.Count);
        }
        else
        {
            _logger.LogWarning(
                "Tenant renewal service resolution rejected. status={ResolutionStatus}",
                resolution.Status);
        }

        return resolution;
    }

    /// <summary>
    /// Authorizes a resolved or explicitly selected legacy service for one tenant renewal state or order.
    /// </summary>
    /// <param name="resolution">
    /// Fresh identity-checked service resolution produced from the current panel client and catalog.
    /// </param>
    /// <param name="selectedServiceKey">
    /// Service key stored in the current bot-scoped state or tenant order. It may be empty before category selection.
    /// </param>
    /// <param name="storedResolutionMode">
    /// Previously persisted evidence mode. Only <c>customer_selected_legacy</c> can authorize one candidate from an
    /// otherwise ambiguous legacy result; null historical values never imply such authorization.
    /// </param>
    /// <param name="service">Receives the currently authorized service, or <c>null</c> when authorization fails.</param>
    /// <param name="effectiveResolutionMode">
    /// Receives the current mode that must be persisted to state or order. Authoritative live metadata supersedes an
    /// older manual choice for the same service.
    /// </param>
    /// <param name="candidateServices">
    /// Receives tenant-visible compatible services when explicit legacy selection is required. The collection contains
    /// no account identifiers and may be empty.
    /// </param>
    /// <returns>
    /// <c>true</c> when one service is authorized by current metadata/deterministic evidence or by a matching persisted
    /// manual legacy choice; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This method is side-effect free. It never writes users.db, creates an order or provider invoice, changes a wallet,
    /// calls Telegram, or mutates XUI. Unlimited candidates must still have at least one tenant-visible plan. A crafted
    /// service key cannot authorize a category that is absent from the fresh compatible candidate set.
    /// </remarks>
    /// <example>
    /// <code>
    /// if (!TryAuthorizeTenantRenewalService(resolution, state.SelectedCountry,
    ///         state.RenewalServiceResolutionMode, out var service, out var mode, out var candidates))
    ///     showCategorySelector(candidates);
    /// </code>
    /// </example>
    private static bool TryAuthorizeTenantRenewalService(
        XuiV3TenantRenewalServiceResolution resolution,
        string selectedServiceKey,
        string storedResolutionMode,
        out XuiV3ServiceDefinition service,
        out string effectiveResolutionMode,
        out IReadOnlyList<XuiV3ServiceDefinition> candidateServices)
    {
        service = null;
        effectiveResolutionMode = null;
        candidateServices = GetTenantRenewalCandidateServices(resolution);

        if (resolution?.Success == true)
        {
            service = resolution.Service;
            effectiveResolutionMode = resolution.Source is
                XuiV3TenantRenewalServiceResolutionSource.DetailMetadata or
                XuiV3TenantRenewalServiceResolutionSource.ListMetadata
                    ? TenantRenewalServiceResolutionModes.Metadata
                    : TenantRenewalServiceResolutionModes.LegacyDeterministic;
            return IsTenantRenewalServiceVisible(service);
        }

        if (resolution?.RequiresCustomerSelection != true ||
            !string.Equals(
                storedResolutionMode,
                TenantRenewalServiceResolutionModes.CustomerSelectedLegacy,
                StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(selectedServiceKey))
        {
            return false;
        }

        service = candidateServices.FirstOrDefault(candidate =>
            string.Equals(candidate.Key, selectedServiceKey.Trim(), StringComparison.OrdinalIgnoreCase));
        if (service == null)
            return false;

        effectiveResolutionMode = TenantRenewalServiceResolutionModes.CustomerSelectedLegacy;
        return true;
    }

    /// <summary>
    /// Filters an ambiguous legacy resolution to services that can actually be sold in a tenant storefront.
    /// </summary>
    /// <param name="resolution">Fresh resolver result whose candidate definitions contain no account identity.</param>
    /// <returns>
    /// Distinct enabled tenant-compatible services ordered by display name. Unlimited services without any
    /// tenant-visible plan are excluded. The collection may be empty.
    /// </returns>
    /// <remarks>
    /// This filter contains no account identity and performs no persistence or external call. It must be rerun against
    /// every fresh resolution before accepting a persisted customer-selected legacy category.
    /// </remarks>
    private static IReadOnlyList<XuiV3ServiceDefinition> GetTenantRenewalCandidateServices(
        XuiV3TenantRenewalServiceResolution resolution)
    {
        return resolution?.CandidateServices?
            .Where(IsTenantRenewalServiceVisible)
            .DistinctBy(service => service.Key, StringComparer.OrdinalIgnoreCase)
            .OrderBy(service => service.DisplayName, StringComparer.Ordinal)
            .ToList() ?? new List<XuiV3ServiceDefinition>();
    }

    /// <summary>Checks whether one enabled service has a usable tenant renewal selector.</summary>
    /// <param name="service">Current catalog service definition.</param>
    /// <returns>
    /// <c>true</c> for an enabled metered service, or for an enabled unlimited service with at least one tenant-visible
    /// enabled plan; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// This side-effect-free audience check does not resolve price or authorize account ownership. Final selection and
    /// order paths still use central tenant pricing and the exact email/UUID target lock.
    /// </remarks>
    private static bool IsTenantRenewalServiceVisible(XuiV3ServiceDefinition service)
    {
        return service?.IsEnabled == true &&
               (!service.IsUnlimited || XuiV3PurchaseService.GetUnlimitedPlansForTenant(service).Any());
    }

    /// <summary>
    /// Maps a sanitized tenant renewal service resolution failure to customer-facing retry guidance.
    /// </summary>
    /// <param name="status">Resolver status containing no client identifiers or raw metadata.</param>
    /// <returns>Persian text safe to display in a tenant customer chat.</returns>
    private static string BuildTenantRenewServiceResolutionFailureText(
        XuiV3TenantRenewalServiceResolutionStatus status)
    {
        return status switch
        {
            XuiV3TenantRenewalServiceResolutionStatus.DetailUnavailable =>
                "دریافت اطلاعات کامل نوع سرویس از پنل موقتاً ناموفق بود. کمی بعد دوباره تلاش کنید؛ هیچ سفارش یا پرداختی ساخته نشد.",
            XuiV3TenantRenewalServiceResolutionStatus.ClientMissing or
            XuiV3TenantRenewalServiceResolutionStatus.IdentityMismatch =>
                "اکانت هدف حذف شده یا اطلاعات هویتی آن تغییر کرده است. هیچ سفارش یا پرداختی ساخته نشد.",
            XuiV3TenantRenewalServiceResolutionStatus.MetadataConflict =>
                "اطلاعات نوع سرویس این اکانت در پنل ناسازگار است و تمدید امن آن ممکن نیست. لطفاً با پشتیبانی تماس بگیرید.",
            XuiV3TenantRenewalServiceResolutionStatus.ServiceUnavailable =>
                "نوع سرویس ثبت‌شده برای این اکانت در حال حاضر در فروشگاه فعال نیست.",
            XuiV3TenantRenewalServiceResolutionStatus.ServiceSelectionRequired =>
                "این اکانت قدیمی metadata قابل‌اعتماد ندارد؛ برای ادامه باید نوع سرویس را از گزینه‌های سازگار انتخاب کنید.",
            _ => "این اکانت مربوط به پلن‌های فعال فروشگاه نیست و از این مسیر قابل تمدید نیست."
        };
    }

    /// <summary>
    /// Parses XUI client metadata from the panel comment field.
    /// </summary>
    /// <param name="comment">Raw JSON comment stored on the XUI client.</param>
    /// <returns>Parsed metadata, or <c>null</c> when the comment is empty or not JSON metadata.</returns>
    private static XuiV3ClientMetadata TryReadTenantMetadata(string comment)
    {
        if (string.IsNullOrWhiteSpace(comment))
            return null;

        try
        {
            return JsonConvert.DeserializeObject<XuiV3ClientMetadata>(comment);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Normalizes owner-provided channel Text into A Telegram Username or URL that can be stored in users.db.
    /// </summary>
    /// <param name="Text">Raw owner input, COMMONLY an @Username, t.me link, or numeric channel Id.</param>
    /// <returns>normalized channel identifier, or null when the input is BLANK.</returns>
    private static string NORMALIZETELEGRAMCHANNEL(string Text)
    {
        var value = Text?.Trim();
        if (string.IsNullOrWhiteSpace(value))
            return null;

        if (value.StartsWith("HTTPS://t.me/", StringComparison.OrdinalIgnoreCase))
            value = "@" + value.Split('/', StringSplitOptions.RemoveEmptyEntries).Last().TrimStart('@');
        else if (!value.StartsWith("@", StringComparison.Ordinal) && !long.TryParse(value, out _))
            value = "@" + value.TrimStart('@');

        return value;
    }

    /// <summary>
    /// Converts the globally configured XuiV3 panel settings into the <see cref="ServerInfo"/> object
    /// expected by the existing account-creation service.
    /// </summary>
    /// <returns>configured XuiV3 server descriptor.</returns>
    private ServerInfo BuildConfiguredPanelServerInfo()
    {
        if (string.IsNullOrWhiteSpace(_appConfig.XuiV3ApiBaseUrl))
            throw new InvalidOperationException("XuiV3ApiBaseUrl is not configured.");

        return new ServerInfo
        {
            ApiVersion = "v3",
            ApiToken = _appConfig.XuiV3ApiToken,
            Url = _appConfig.XuiV3ApiBaseUrl.TrimEnd('/'),
            RootPath = (_appConfig.XuiV3ApiRootPath ?? string.Empty).Trim('/'),
            SubLinkUrl = string.IsNullOrWhiteSpace(_appConfig.XuiV3SubLinkBaseUrl)
                ? null
                : _appConfig.XuiV3SubLinkBaseUrl.TrimEnd('/'),
            Name = "configured v3 panel"
        };
    }

    /// <summary>
    /// creates the public order Id used by tenant HooshPay invoices and operational logs.
    /// </summary>
    /// <param name="tenant">tenant Bot that owns the storefront order.</param>
    /// <param name="CustomerTelegramUserId">Telegram User Id of the customer.</param>
    /// <returns>Unique order Id containing tenant-owner Id, customer Id, timestamp, and random suffix.</returns>
    private static string CreateTenantOrderId(BotInstance tenant, long CustomerTelegramUserId)
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        return $"TENANTBOT-{DateTime.UtcNow:yyyyMMddHHmmss}-{tenant.OwnerTelegramUserId}-{CustomerTelegramUserId}-{suffix}";
    }

    /// <summary>
    /// Converts A boolean Configuration state into the icon used in the owner setup panel.
    /// </summary>
    /// <param name="Ok">whether the setup field is configured.</param>
    /// <returns>Success or failure icon Text.</returns>
    private static string STATUSICON(bool Ok)
    {
        return Ok ? "✅" : "❌";
    }

    /// <summary>
    /// Builds the compact text shown on one order-list callback button.
    /// </summary>
    /// <param name="order">Tenant order represented by the button.</param>
    /// <returns>A short Telegram button label containing status, amount, and final balance.</returns>
    private static string BuildOwnerOrderButtonText(TenantBotOrder order)
    {
        var icon = order.IsFulfilled ? "✅" : order.PaymentStatus == TenantBotOrderStatuses.Failed ? "❌" : "⏳";
        var kind = string.Equals(order.OrderKind, TenantBotOrderKinds.Renew, StringComparison.OrdinalIgnoreCase) ? "تمدید" : "خرید";
        var shortId = string.IsNullOrWhiteSpace(order.OrderId) ? order.Id.ToString(CultureInfo.InvariantCulture) : order.OrderId[^Math.Min(8, order.OrderId.Length)..];
        return $"{icon} {kind} #{shortId} | {order.SalePriceToman.FormatCurrency()} | {FormatTenantOrderDate(order.CreatedAtUtc)}";
    }

    /// <summary>
    /// Formats a tenant order timestamp for compact Persian order reports.
    /// </summary>
    /// <param name="utc">UTC timestamp stored in users.db.</param>
    /// <returns>Shamsi date/time text when conversion helpers are available.</returns>
    private static string FormatTenantOrderDate(DateTime utc)
    {
        var tehran = utc.AddMinutes(210);
        return $"{tehran.ConvertToHijriShamsi()} {tehran:HH:mm}";
    }

    /// <summary>
    /// Builds a clickable Telegram user link for owner-facing reports.
    /// </summary>
    /// <param name="telegramUserId">Numeric Telegram user id of the customer.</param>
    /// <param name="displayName">Display name shown in the clickable link.</param>
    /// <returns>HTML anchor using the <c>tg://user</c> Telegram deep link.</returns>
    private static string BuildTelegramUserLink(long telegramUserId, string displayName)
    {
        var safeName = string.IsNullOrWhiteSpace(displayName) ? telegramUserId.ToString(CultureInfo.InvariantCulture) : displayName;
        return $"<a href=\"tg://user?id={telegramUserId}\">{Html(safeName)}</a>";
    }

    /// <summary>
    /// Builds the best available display name for a tenant customer stored on an order.
    /// </summary>
    /// <param name="order">Tenant order containing cached Telegram profile fields.</param>
    /// <returns>Full name, username, or numeric id text.</returns>
    private static string BuildCustomerDisplayName(TenantBotOrder order)
    {
        var fullName = string.Join(" ", new[] { order.CustomerFirstName, order.CustomerLastName }.Where(x => !string.IsNullOrWhiteSpace(x)));
        if (!string.IsNullOrWhiteSpace(fullName))
            return fullName;
        if (!string.IsNullOrWhiteSpace(order.CustomerUsername))
            return "@" + order.CustomerUsername.TrimStart('@');
        return order.CustomerTelegramUserId.ToString(CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Converts tenant order kind values to Persian display text.
    /// </summary>
    /// <param name="order">Tenant order whose kind should be displayed.</param>
    /// <returns>Human-readable order kind.</returns>
    private static string GetOrderKindDisplay(TenantBotOrder order)
    {
        return string.Equals(order.OrderKind, TenantBotOrderKinds.Renew, StringComparison.OrdinalIgnoreCase)
            ? "تمدید اکانت"
            : "خرید اکانت";
    }

    /// <summary>
    /// Encodes Text before inserting it into Telegram Html messages.
    /// </summary>
    /// <param name="value">Raw Text that may contain Telegram Html-sensitive characters.</param>
    /// <returns>Html-encoded Text; null becomes an empty string.</returns>
    private static string Html(string value)
    {
        return WebUtility.HtmlEncode(value ?? string.Empty);
    }

    /// <summary>
    /// Encodes text before inserting it into a Telegram HTML attribute.
    /// </summary>
    /// <param name="value">Raw attribute text such as a Telegram username or URL.</param>
    /// <returns>HTML-encoded attribute text; null becomes an empty string.</returns>
    private static string HtmlAttribute(string value)
    {
        return WebUtility.HtmlEncode(value ?? string.Empty);
    }

    /// <summary>
    /// Reads tenant tutorial links from the bot instance JSON column.
    /// </summary>
    /// <param name="tenant">Tenant bot whose tutorial JSON should be parsed.</param>
    /// <returns>A safe sequence of tutorial links; invalid JSON returns an empty list.</returns>
    private static IEnumerable<TenantTutorialLink> ReadTenantTutorials(BotInstance tenant)
    {
        if (string.IsNullOrWhiteSpace(tenant?.TenantTutorialsJson))
            return Array.Empty<TenantTutorialLink>();

        try
        {
            return JsonConvert.DeserializeObject<List<TenantTutorialLink>>(tenant.TenantTutorialsJson)?
                .Where(x => !string.IsNullOrWhiteSpace(x.Title) && !string.IsNullOrWhiteSpace(x.Url))
                .ToList() ?? new List<TenantTutorialLink>();
        }
        catch
        {
            return Array.Empty<TenantTutorialLink>();
        }
    }

    /// <summary>
    /// Parses a Telegram post URL into the chat and message id required by <c>ForwardMessage</c>.
    /// </summary>
    /// <param name="text">Owner-provided URL such as <c>https://t.me/channel/123</c>.</param>
    /// <param name="chatId">Parsed public chat username or private channel id.</param>
    /// <param name="messageId">Parsed Telegram message id.</param>
    /// <returns><c>true</c> when the URL can be forwarded by Telegram.</returns>
    private static bool TryParseTelegramPostLink(string text, out ChatId chatId, out int messageId)
    {
        chatId = null;
        messageId = 0;
        if (!Uri.TryCreate(text?.Trim(), UriKind.Absolute, out var uri))
            return false;

        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length < 2 || !int.TryParse(segments[^1], NumberStyles.Integer, CultureInfo.InvariantCulture, out messageId))
            return false;

        if (segments[0] == "c" && segments.Length >= 3)
        {
            chatId = new ChatId(long.Parse("-100" + segments[1], CultureInfo.InvariantCulture));
            return true;
        }

        chatId = new ChatId("@" + segments[0].TrimStart('@'));
        return true;
    }

    /// <summary>
    /// One tenant-owned tutorial link configured by a colleague.
    /// </summary>
    private sealed class TenantTutorialLink
    {
        /// <summary>
        /// User-facing tutorial title shown on a Telegram URL button.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Telegram or web URL opened when customers tap the tutorial button.
        /// </summary>
        public string Url { get; set; }
    }


    /// <summary>
    /// Result object returned by the tenant token duplicate guard.
    /// </summary>
    /// <remarks>
    /// The result intentionally stores only a conflict type label. It does not carry the conflicting token or
    /// any other secret so it is safe to include in structured logs.
    /// </remarks>
    private sealed class TenantTokenConflictResult
    {
        /// <summary>
        /// Shared no-conflict instance used when the token can be assigned to the current tenant owner.
        /// </summary>
        public static readonly TenantTokenConflictResult None = new();

        /// <summary>
        /// Indicates whether another bot already owns the entered token, token bot id, or username.
        /// </summary>
        public bool HasConflict { get; private init; }

        /// <summary>
        /// Non-secret source label such as <c>tenant-token</c> or <c>owned-username</c>.
        /// </summary>
        public string ConflictType { get; private init; }

        /// <summary>
        /// Creates a conflict result with a non-secret reason label.
        /// </summary>
        /// <param name="conflictType">
        /// Short internal label describing which duplicate rule matched. The value must not include a token.
        /// </param>
        /// <returns>A result whose <see cref="HasConflict" /> property is <c>true</c>.</returns>
        public static TenantTokenConflictResult Conflict(string conflictType)
        {
            return new TenantTokenConflictResult
            {
                HasConflict = true,
                ConflictType = conflictType
            };
        }
    }

    /// <summary>
    /// Source keys for tenant owner settlement movements.
    /// </summary>
    /// <remarks>
    /// These values are internal audit labels. They describe which wallet paid the base cost or received tenant
    /// profit and are displayed in private logs and owner notifications.
    /// </remarks>
    private static class TenantOwnerWalletSources
    {
        /// <summary>
        /// The tenant owner's bot wallet paid the card-to-card base cost.
        /// </summary>
        public const string BotWallet = "bot_wallet";

        /// <summary>
        /// The tenant owner's Gozargah website wallet paid the card-to-card base cost.
        /// </summary>
        public const string GozargahSiteWallet = "gozargah_site_wallet";

        /// <summary>
        /// The tenant owner's bot wallet was allowed to go negative for card-to-card base cost.
        /// </summary>
        public const string NegativeBotWallet = "negative_bot_wallet";

        /// <summary>
        /// A platform gateway sale credited profit to the tenant owner's bot wallet.
        /// </summary>
        public const string PlatformGatewayProfit = "platform_gateway_profit";
    }

    /// <summary>
    /// Display-only snapshot of a tenant owner's Gozargah website wallet.
    /// </summary>
    private sealed class TenantSiteWalletSnapshot
    {
        /// <summary>
        /// Whether the website wallet exists and its balance was read successfully.
        /// </summary>
        public bool IsConnected { get; private init; }

        /// <summary>
        /// Website wallet balance in toman when <see cref="IsConnected"/> is true.
        /// </summary>
        public long? WalletToman { get; private init; }

        /// <summary>
        /// Short display status such as <c>متصل نشده</c> or <c>در دسترس نیست</c> when not connected.
        /// </summary>
        public string StatusText { get; private init; }

        /// <summary>
        /// Creates a connected website-wallet snapshot.
        /// </summary>
        /// <param name="walletToman">Current website wallet balance in toman.</param>
        /// <returns>Connected snapshot with a readable balance.</returns>
        public static TenantSiteWalletSnapshot Connected(long walletToman)
            => new() { IsConnected = true, WalletToman = walletToman };

        /// <summary>
        /// Creates an unavailable website-wallet snapshot.
        /// </summary>
        /// <param name="statusText">Short Persian status safe for owner messages and private logs.</param>
        /// <returns>Unavailable snapshot with no balance.</returns>
        public static TenantSiteWalletSnapshot Unavailable(string statusText)
            => new() { StatusText = string.IsNullOrWhiteSpace(statusText) ? "در دسترس نیست" : statusText };
    }

    /// <summary>
    /// Result of settling the tenant owner's wallet side for one fulfilled storefront order.
    /// </summary>
    private sealed class TenantOwnerWalletSettlementResult
    {
        /// <summary>
        /// Internal source key from <see cref="TenantOwnerWalletSources"/>.
        /// </summary>
        public string WalletSource { get; private init; }

        /// <summary>
        /// Human-readable Persian source label shown to the owner and in private audit logs.
        /// </summary>
        public string SourceDisplayName { get; private init; }

        /// <summary>
        /// Signed tenant owner financial delta in toman. Positive values credit profit; negative values represent
        /// a base-cost debit from either bot wallet or website wallet.
        /// </summary>
        public long OwnerDelta { get; private init; }

        /// <summary>
        /// Tenant owner's bot-wallet balance before the settlement.
        /// </summary>
        public long BotWalletBefore { get; private init; }

        /// <summary>
        /// Tenant owner's bot-wallet balance after the settlement.
        /// </summary>
        public long BotWalletAfter { get; private init; }

        /// <summary>
        /// Website wallet snapshot before settlement. It is display-only and may be unavailable.
        /// </summary>
        public TenantSiteWalletSnapshot SiteWalletBefore { get; private init; }

        /// <summary>
        /// Website wallet snapshot after settlement. It is display-only unless the website wallet paid base cost.
        /// </summary>
        public TenantSiteWalletSnapshot SiteWalletAfter { get; private init; }

        /// <summary>
        /// Optional owner-facing warning, currently used when the bot wallet falls back to a negative balance.
        /// </summary>
        public string WarningMessage { get; private init; }

        /// <summary>
        /// Creates a settlement result with source, balances, website snapshots, and optional warning.
        /// </summary>
        /// <param name="walletSource">Internal source key from <see cref="TenantOwnerWalletSources"/>.</param>
        /// <param name="ownerDelta">Signed owner delta in toman.</param>
        /// <param name="botWalletBefore">Bot-wallet balance before settlement.</param>
        /// <param name="botWalletAfter">Bot-wallet balance after settlement.</param>
        /// <param name="siteWalletBefore">Website wallet snapshot before settlement.</param>
        /// <param name="siteWalletAfter">Website wallet snapshot after settlement.</param>
        /// <param name="warningMessage">Optional owner-facing warning text.</param>
        /// <returns>Settlement result consumed by order persistence, ledger, owner messages, and private logs.</returns>
        public static TenantOwnerWalletSettlementResult Create(
            string walletSource,
            long ownerDelta,
            long botWalletBefore,
            long botWalletAfter,
            TenantSiteWalletSnapshot siteWalletBefore,
            TenantSiteWalletSnapshot siteWalletAfter,
            string warningMessage = null)
        {
            return new TenantOwnerWalletSettlementResult
            {
                WalletSource = walletSource,
                SourceDisplayName = walletSource switch
                {
                    TenantOwnerWalletSources.BotWallet => "کیف پول ربات",
                    TenantOwnerWalletSources.GozargahSiteWallet => "کیف پول سایت گذرگاه",
                    TenantOwnerWalletSources.NegativeBotWallet => "منفی شدن کیف پول ربات",
                    TenantOwnerWalletSources.PlatformGatewayProfit => "سود درگاه پلتفرم",
                    _ => walletSource
                },
                OwnerDelta = ownerDelta,
                BotWalletBefore = botWalletBefore,
                BotWalletAfter = botWalletAfter,
                SiteWalletBefore = siteWalletBefore,
                SiteWalletAfter = siteWalletAfter,
                WarningMessage = warningMessage
            };
        }
    }

    /// <summary>
    /// Carries the authoritative whole-toman sale, base-cost, and profit amounts for one tenant storefront selection.
    /// </summary>
    /// <remarks>
    /// Instances are detached calculation results. Callers persist the values on an order before payment and must not
    /// recalculate profit independently during settlement. All values use Iranian toman major units.
    /// </remarks>
    private sealed class TenantPriceResult
    {
        /// <summary>Gets or sets the exact amount charged to the tenant customer in Iranian toman.</summary>
        public long SalePriceToman { get; set; }

        /// <summary>Gets or sets the tenant owner's colleague-rate base cost in Iranian toman.</summary>
        public long BaseCostToman { get; set; }

        /// <summary>Gets or sets the non-negative tenant profit in Iranian toman.</summary>
        public long ProfitToman { get; set; }
    }
}
