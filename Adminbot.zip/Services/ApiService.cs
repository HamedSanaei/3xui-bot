using System.Diagnostics.Tracing;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Adminbot.Domain;
using Adminbot.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


public class ApiService
{
    /// <summary>
    /// Logs a non-fatal legacy panel login failure without throwing into Telegram update handlers.
    /// </summary>
    /// <param name="message">Short diagnostic message describing the failed login step.</param>
    /// <param name="exception">Optional exception raised by URL parsing, HTTP, cookie parsing, or database access.</param>
    /// <remarks>
    /// The legacy account-creation flow treats a null cookie as a recoverable login failure. Logging here is
    /// intentionally console-based because this static service does not own an <c>ILogger</c> instance.
    /// </remarks>
    private static void LogLoginCookieFailure(string message, Exception exception = null)
    {
        Console.WriteLine(exception == null
            ? $"[ApiService] Login cookie failure: {message}"
            : $"[ApiService] Login cookie failure: {message}. {exception.GetType().Name}: {exception.Message}");
    }

    /// <summary>
    /// Builds an absolute-path route for legacy x-ui panels while tolerating an empty root path.
    /// </summary>
    /// <param name="rootPath">
    /// Optional x-ui root path from server configuration. Leading and trailing slashes are ignored.
    /// Empty values mean the panel endpoint is mounted at the domain root.
    /// </param>
    /// <param name="suffix">
    /// Endpoint suffix such as <c>login</c> or <c>panel/api/inbounds/list</c>. Leading slashes are ignored.
    /// </param>
    /// <returns>A route beginning with one slash and containing no duplicate slash caused by an empty root path.</returns>
    private static string BuildPanelRoute(string rootPath, string suffix)
    {
        var normalizedRoot = (rootPath ?? string.Empty).Trim('/');
        var normalizedSuffix = (suffix ?? string.Empty).TrimStart('/');
        return string.IsNullOrWhiteSpace(normalizedRoot)
            ? "/" + normalizedSuffix
            : "/" + normalizedRoot + "/" + normalizedSuffix;
    }

    /// <summary>
    /// Validates the minimum server settings required for a legacy x-ui login request.
    /// </summary>
    /// <param name="serverInfo">Server configuration selected by the purchase flow.</param>
    /// <param name="baseUri">
    /// Absolute HTTP or HTTPS base URI parsed from <paramref name="serverInfo"/> when validation succeeds.
    /// </param>
    /// <returns><c>true</c> when login can be attempted; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// Invalid configuration is handled as a login failure instead of an exception so Telegram account creation
    /// can return a normal failure message to the user.
    /// </remarks>
    private static bool TryValidateLoginServer(ServerInfo serverInfo, out Uri baseUri)
    {
        baseUri = null;
        if (serverInfo == null)
        {
            LogLoginCookieFailure("ServerInfo is null.");
            return false;
        }

        if (string.IsNullOrWhiteSpace(serverInfo.Url))
        {
            LogLoginCookieFailure("ServerInfo.Url is empty.");
            return false;
        }

        if (!Uri.TryCreate(serverInfo.Url.TrimEnd('/'), UriKind.Absolute, out baseUri) ||
            (baseUri.Scheme != Uri.UriSchemeHttp && baseUri.Scheme != Uri.UriSchemeHttps))
        {
            LogLoginCookieFailure($"ServerInfo.Url is invalid: {serverInfo.Url}");
            baseUri = null;
            return false;
        }

        return true;
    }

    /// <summary>
    /// Logs into a legacy x-ui panel and returns a reusable session cookie value.
    /// </summary>
    /// <param name="serverInfo">
    /// Legacy x-ui server configuration selected by the account creation or update flow.
    /// The value may have an empty <c>RootPath</c>, but must contain a valid absolute HTTP or HTTPS <c>Url</c>.
    /// </param>
    /// <returns>
    /// The raw session value without the cookie name when login or cached-cookie validation succeeds;
    /// otherwise <c>null</c>. A null return means callers must stop account creation/update gracefully.
    /// </returns>
    /// <remarks>
    /// This method is intentionally fail-closed and exception-safe. Null server config, invalid URLs, missing
    /// <c>Set-Cookie</c> headers, empty cookie values, HTTP failures, database errors, and unexpected exceptions
    /// are logged and converted to <c>null</c> so Telegram update handlers do not crash.
    /// TLS negotiation is delegated to <see cref="HttpClient" /> and the operating system so obsolete global
    /// <see cref="ServicePointManager" /> settings cannot weaken or misrepresent the connection policy.
    /// </remarks>
    public static async Task<string> LoginAndGetSessionCookie(ServerInfo serverInfo)

    {
        try
        {
            if (!TryValidateLoginServer(serverInfo, out var baseUri))
                return null;

            using HttpClient httpClient = new HttpClient();
            string username = serverInfo.Username;
            string password = serverInfo.Password;
            string apiUrl = baseUri.ToString().TrimEnd('/');
            string rootPath = serverInfo.RootPath;

            string completeSessionCookie = string.Empty;
            var loginData = new
            {
                Username = username,
                Password = password
            };

            //check the databas if exist return
            using var context = new UserDbContext();
            var dbCookie = await context.Cookies.FirstOrDefaultAsync(c => c.Url == apiUrl);
            if (dbCookie != null)
            {
                string cookie = dbCookie.SessionCookie;
                DateTimeOffset currentUtcTime = DateTimeOffset.UtcNow;


                if (!string.IsNullOrWhiteSpace(cookie) &&
                    dbCookie.ExpirationDate > currentUtcTime &&
                    await IsCookieValid(serverInfo, cookie))
                    return dbCookie.SessionCookie;
            }
            if (dbCookie?.ExpirationDate < DateTimeOffset.UtcNow || dbCookie == null || string.IsNullOrWhiteSpace(dbCookie.SessionCookie))
            {
                // valid nist 
                // Set the base address of your API
                httpClient.BaseAddress = baseUri;
                HttpResponseMessage response = await httpClient.PostAsJsonAsync(BuildPanelRoute(rootPath, "login"), loginData);

                if (response.IsSuccessStatusCode)
                {
                    // Read the content as a string
                    string responseContent = await response.Content.ReadAsStringAsync();

                    // Retrieve the session cookie if present
                    if (response.Headers.TryGetValues("Set-Cookie", out var setCookieHeaders))
                    {
                        // Extract the session cookie from the Set-Cookie header
                        completeSessionCookie = setCookieHeaders.FirstOrDefault(cookie => cookie.StartsWith("session") || cookie.StartsWith("3x-ui="));
                    }
                    else
                    {
                        LogLoginCookieFailure($"Login response did not include Set-Cookie. Url={apiUrl}");
                        return null;
                    }

                    if (string.IsNullOrWhiteSpace(completeSessionCookie))
                    {
                        LogLoginCookieFailure($"Login Set-Cookie did not include session or 3x-ui cookie. Url={apiUrl}");
                        return null;
                    }

                    // Do something with the session cookie, e.g., store it for future use
                    TryExtractExpirationDate(completeSessionCookie, out var expirationDate);
                    var purecookie = GetSessionCookie(completeSessionCookie);
                    if (string.IsNullOrWhiteSpace(purecookie))
                    {
                        LogLoginCookieFailure($"Extracted session cookie is empty. Url={apiUrl}");
                        return null;
                    }

                    if (dbCookie != null)
                    {
                        dbCookie.ExpirationDate = expirationDate;
                        dbCookie.SessionCookie = purecookie;
                        context.Cookies.Update(dbCookie);
                        await context.SaveChangesAsync();
                    }
                    else
                    {
                        CookieData cookieData = new CookieData { Id = Guid.NewGuid(), Url = apiUrl, ExpirationDate = expirationDate, SessionCookie = purecookie };
                        await context.Cookies.AddAsync(cookieData);
                        await context.SaveChangesAsync();
                    }

                }
                else
                {
                    // Handle the case where the request was not successful
                    LogLoginCookieFailure($"Login HTTP failed. Url={apiUrl}, Status={response.StatusCode}, Reason={response.ReasonPhrase}");
                }
            }
            return GetSessionCookie(completeSessionCookie);
        }
        catch (Exception ex)
        {
            LogLoginCookieFailure("Unexpected login failure.", ex);
            return null;
        }
    }

    /// <summary>
    /// Verifies a cached x-ui session cookie by calling the inbound list endpoint.
    /// </summary>
    /// <param name="serverInfo">Legacy x-ui server configuration used to build the validation URL.</param>
    /// <param name="cookie">Session cookie value without the cookie name.</param>
    /// <returns><c>true</c> when the panel accepts the cookie; otherwise <c>false</c>.</returns>
    /// <remarks>
    /// Any malformed URL, empty cookie, HTTP failure, or exception is treated as an invalid cache entry.
    /// </remarks>
    private static async Task<bool> IsCookieValid(ServerInfo serverInfo, string cookie)
    {
        if (!TryValidateLoginServer(serverInfo, out var baseUri) || string.IsNullOrWhiteSpace(cookie))
            return false;

        var loginData = new
        {
            Username = serverInfo.Username,
            Password = serverInfo.Password
        };

        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();
        cookieContainer.Add(baseUri, new Cookie("session", cookie));
        cookieContainer.Add(baseUri, new Cookie("3x-ui", cookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;


        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        try
        {
            var route = new Uri(baseUri, BuildPanelRoute(serverInfo.RootPath, "panel/api/inbounds/list"));
            HttpResponseMessage response = await httpClient.GetAsync(route);
            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (System.Exception ex)
        {

            LogLoginCookieFailure("Cached cookie validation failed.", ex);
            return false;
        }


    }

    /// <summary>
    /// Extracts the raw cookie value from a legacy x-ui Set-Cookie header.
    /// </summary>
    /// <param name="cookie">Set-Cookie header value for either <c>session</c> or <c>3x-ui</c>.</param>
    /// <returns>The cookie value without name/attributes, or <c>null</c> when no supported cookie exists.</returns>
    private static string GetSessionCookie(string cookie)
    {
        if (string.IsNullOrWhiteSpace(cookie))
            return null;

        var cookieParts = cookie.Split(';');
        if (cookieParts.Length == 0)
            return null;

        if (cookieParts[0].Trim().StartsWith("session="))
        {
            // Extract the main part of the session cookie
            return cookieParts[0].Trim().Substring("session=".Length);
        }
        else if (cookieParts[0].Trim().StartsWith("3x-ui="))
        {
            return cookieParts[0].Trim().Substring("3x-ui=".Length);
        }

        // Return null or an empty string if the session cookie is not found
        return null;
    }

    //it called by methodes in program.cs
    /// <summary>Creates one legacy v2 account and saves its bot-scoped delivery state.</summary>
    /// <param name="accountDto">Required private panel request and global Telegram owner; never log its authentication cookie.</param>
    /// <returns>True for proven creation and saved state; false for a handled panel/HTTP failure.</returns>
    /// <remarks>Panel I/O is outside SQLite writes. VMess templates are copied before customer-specific mutation.
    /// Legacy HTTP uses its request timeout; interrupted scheduler executions must be reviewed, never replayed wholesale.</remarks>
    public static async Task<bool> CreateUserAccount(AccountDto accountDto)
    {
        string sessionCookie = accountDto.SessionCookie;
        string selectedCountry = accountDto.SelectedCountry;
        string selectedPeriod = accountDto.SelectedPeriod;

        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();

        // var xff = "MTcxODIxMTY2OXxEWDhFQVFMX2dBQUJFQUVRQUFCMV80QUFBUVp6ZEhKcGJtY01EQUFLVEU5SFNVNWZWVk5GVWhoNExYVnBMMlJoZEdGaVlYTmxMMjF2WkdWc0xsVnpaWExfZ1FNQkFRUlZjMlZ5QWYtQ0FBRUVBUUpKWkFFRUFBRUlWWE5sY201aGJXVUJEQUFCQ0ZCaGMzTjNiM0prQVF3QUFRdE1iMmRwYmxObFkzSmxkQUVNQUFBQUd2LUNGd0VDQVFkaGJXbHljMkZ1QVFsNlpXUmlZWHBwT0RnQXzzRIGYIgPo8voWj8dpPkOlMdk5tAmN8SxAzg0YmKHqWg==";
        // cookieContainer.Add(new Uri(accountDto.ServerInfo.Url), new Cookie("session", xff));
        cookieContainer.Add(new Uri(accountDto.ServerInfo.Url), new Cookie("session", accountDto.SessionCookie));
        cookieContainer.Add(new Uri(accountDto.ServerInfo.Url), new Cookie("3x-ui", accountDto.SessionCookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;

        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        // Now you can use the httpClient to make requests with the specified cookie

        // Create the request body
        var inboundId = accountDto.ServerInfo.Inbounds.FirstOrDefault(i => i.Type == accountDto.AccType);
        if (inboundId == null) return false;
        Client client = new Client { TgId = accountDto.TelegramUserId.ToString(), TotalGB = ConvertGBToBytes(Convert.ToInt32(accountDto.TotoalGB)), ExpiryTime = DateTime.Now.AddDays(ConvertPeriodToDays(accountDto.SelectedPeriod)) };

        if (accountDto.IsColleague)
        {
            client.Email = client.Email + "_" + accountDto.AccountCounter.ToString();
        }

        var setting = Client.MakeSettingString(client);
        if (accountDto.AccType == "realityv6")
        {
            int commaIndex = setting.IndexOf(',');
            setting = setting.Insert(commaIndex, ",\"flow\":\"xtls-rprx-vision\"");
        }

        var requestBody = new
        {
            id = inboundId.Id,
            settings = setting
        };


        var apiUrl = accountDto.ServerInfo.Url + "/" + accountDto.ServerInfo.RootPath + "/" + "panel/api/inbounds/addClient";

        try
        {
            // Send the POST request with the JSON body
            HttpResponseMessage response = await httpClient.PostAsJsonAsync(apiUrl, requestBody);
            string responseBody = await response.Content.ReadAsStringAsync();
            AddClientResult result = JsonConvert.DeserializeObject<AddClientResult>(responseBody);


            // Check if the request was successful
            if (response.IsSuccessStatusCode && result.Success)
            {
                // Account created successfully
                // Read and print the response content
                if (accountDto.AccType == "tunnel")
                {

                    var configLink = RuntimeSnapshot.Copy(accountDto.ServerInfo.VmessTemplate);
                    configLink.Ps += client.Email;
                    configLink.Id = client.Id;

                    //Console.WriteLine(responseBody);
                    var _userStateStore = UserStateStore.ForConfiguredDatabase();

                    await _userStateStore.SaveUserStatus(new User { Id = accountDto.TelegramUserId, ConfigLink = configLink.ToVMessLink(), Email = client.Email, SubLink = accountDto.ServerInfo.SubLinkUrl + client.Email });
                    return true;
                }
                else if (accountDto.AccType == "realityv6")
                {
                    var vlessLink = $"vless://{client.Id}@{accountDto.ServerInfo.Vless.Domain}:443?type=tcp&security=reality&flow=xtls-rprx-vision&fp=firefox&pbk=kGzzo-8w_p6XHOyF1Pr1jiGjgqjICkWJyNw7ksML3yY&sni=www.google-analytics.com&sid=6c0eefcb#RealityMTN-{client.Email}";
                    var _userStateStore = UserStateStore.ForConfiguredDatabase();

                    await _userStateStore.SaveUserStatus(new User { Id = accountDto.TelegramUserId, ConfigLink = vlessLink, Email = client.Email });
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                Console.WriteLine($"Server Message:  isSuccessful:{result.Success} - {result.Msg}");
                return false;
            }
        }
        catch (HttpRequestException ex)
        {
            Console.WriteLine($"HttpRequestException: {ex.Message}");

        }
        return false;
    }

    /// <summary>Updates a legacy v2 account and stores the resulting delivery state for the active bot.</summary>
    /// <param name="accountDto">Required private panel request, current client, and Telegram owner; do not log cookies or links.</param>
    /// <returns>True when the panel update and state persistence succeed; false for handled transport failures.</returns>
    /// <remarks>Uses a private VMess template copy and short factory-backed state writes after HTTP completes.</remarks>
    public static async Task<bool> UpdateUserAccount(AccountDtoUpdate accountDto)
    {
        string sessionCookie = accountDto.SessionCookie;
        string selectedCountry = accountDto.SelectedCountry;
        string selectedPeriod = accountDto.SelectedPeriod;

        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();
        cookieContainer.Add(new Uri(accountDto.ServerInfo.Url), new Cookie("session", accountDto.SessionCookie));
        cookieContainer.Add(new Uri(accountDto.ServerInfo.Url), new Cookie("3x-ui", accountDto.SessionCookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;

        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        // Now you can use the httpClient to make requests with the specified cookie

        // Create the request body
        var inboundId = accountDto.ServerInfo.Inbounds.FirstOrDefault(i => i.Type == accountDto.AccType);
        if (inboundId == null) return false;
        if (accountDto.Client.ExpiryTime <= DateTime.UtcNow)
            accountDto.Client.ExpiryTime = DateTime.UtcNow;
        Client client = new Client { TgId = accountDto.TelegramUserId.ToString(), Id = accountDto.Client.Id, TotalGB = ConvertGBToBytes(Convert.ToInt32(accountDto.TotoalGB)) + accountDto.Client.TotalGB, ExpiryTime = accountDto.Client.ExpiryTime.AddDays(ConvertPeriodToDays(accountDto.SelectedPeriod)), Email = accountDto.Client.Email, SubId = accountDto.Client.Email, Enable = true };
        var requestBody = new
        {
            id = inboundId.Id,
            settings = Client.MakeSettingString(client, accountDto)
        };

        //var apiUrl = accountDto.ServerInfo.Url + "/" + accountDto.ServerInfo.RootPath + "/" + "panel/api/inbounds/addClient";
        var apiUrl = $"{accountDto.ServerInfo.Url}/{accountDto.ServerInfo.RootPath}/panel/api/inbounds/updateClient/{client.Id}";

        try
        {
            // Send the POST request with the JSON body
            HttpResponseMessage response = await httpClient.PostAsJsonAsync(apiUrl, requestBody);
            string responseBody = await response.Content.ReadAsStringAsync();
            AddClientResult result = JsonConvert.DeserializeObject<AddClientResult>(responseBody);


            // Check if the request was successful
            if (response.IsSuccessStatusCode && result.Success)
            {
                // Account created successfully
                // Read and print the response content
                if (accountDto.AccType == "tunnel")
                {

                    var configLink = RuntimeSnapshot.Copy(accountDto.ServerInfo.VmessTemplate);
                    configLink.Ps += client.Email;
                    configLink.Id = client.Id;

                    //Console.WriteLine(responseBody);
                    var _userStateStore = UserStateStore.ForConfiguredDatabase();

                    await _userStateStore.SaveUserStatus(new User { Id = accountDto.TelegramUserId, SubLink = accountDto.ServerInfo.SubLinkUrl + client.Email, ConfigLink = configLink.ToVMessLink(), Email = client.Email });
                    return true;
                }
                else if (accountDto.AccType == "realityv6")
                {

                    var vlessLink = $"vless://{client.Id}@{accountDto.ServerInfo.Vless.Domain}:443?type=tcp&security=reality&fp=firefox&pbk=kGzzo-8w_p6XHOyF1Pr1jiGjgqjICkWJyNw7ksML3yY&sni=www.google-analytics.com&sid=6c0eefcb#RealityMTN-{client.Email}";
                    if (accountDto.ConfigLink.Contains("flow=xtls-rprx-vision"))
                    {
                        int commaIndex = vlessLink.IndexOf('&');
                        vlessLink = vlessLink.Insert(commaIndex, "&flow=xtls-rprx-vision");
                    }
                    var _userStateStore = UserStateStore.ForConfiguredDatabase();

                    await _userStateStore.SaveUserStatus(new User { Id = accountDto.TelegramUserId, ConfigLink = vlessLink, Email = client.Email });
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                Console.WriteLine($"Server Message:  isSuccessful:{result.Success} - {result.Msg}");
                return false;
            }
        }
        catch (HttpRequestException ex)
        {
            Console.WriteLine($"HttpRequestException: {ex.Message}");

        }
        return false;
    }

    private static bool TryExtractExpirationDate(string cookie, out DateTimeOffset expirationDate)
    {
        expirationDate = DateTimeOffset.MinValue; // Default value if extraction fails

        if (cookie.Contains("3x-ui"))
        {
            expirationDate = DateTimeOffset.Now.AddHours(6);
            return true;
        }

        var expirationDateIndex = cookie.IndexOf("Expires=");

        if (expirationDateIndex != -1)
        {

            var expirationDateString2 = cookie.Substring(expirationDateIndex + "Expires=".Length).Trim();

            Console.WriteLine("=================================");
            Console.WriteLine("This is expirationDateString :");
            Console.WriteLine(expirationDateString2);
            Console.WriteLine("=================================");


            string dateString = expirationDateString2;

            string[] dateParts = dateString.Split(';');

            // Extract the date part
            string expirationDateString = dateParts[0].Trim();

            // Declare the expirationDate variable outside the if block
            DateTimeOffset expirationDateeee;

            // Parse the date string
            if (DateTimeOffset.TryParseExact(expirationDateString, "ddd, dd MMM yyyy HH:mm:ss 'GMT'", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out expirationDateeee))
            {
                // Successfully parsed, use the expirationDate
                Console.WriteLine($"Expiration Date: {expirationDateeee}");
                expirationDate = expirationDateeee;
            }
            else
            {
                // Parsing failed, handle the error
                Console.WriteLine("Failed to parse the expiration date from the cookie.");
                // Set a default or handle the error as needed
                expirationDate = DateTimeOffset.UtcNow; // For example, set to the current UTC time
            }

            // Now, expirationDate contains the parsed or default value

        }

        return false; // Extraction failed
    }

    public static string CreateAddAccountRequestBody(string settingsSection)
    {
        // Assuming you have a class representing the settings structure
        var settings = JsonConvert.DeserializeObject<Settings>(settingsSection);

        // Assuming you have an AddAccountRequest class for the request body
        var addAccountRequest = new AddAccountRequest
        {
            // Populate properties based on the settings
            // Adjust this part according to your actual class structure
            Id = settings.Id,
            Clients = settings.Clients
        };

        // Serialize the AddAccountRequest object to JSON
        string requestBody = JsonConvert.SerializeObject(addAccountRequest);

        return requestBody;
    }

    /// <summary>Finds a legacy account across configured panels and saves a detached delivery snapshot for the active bot.</summary>
    /// <param name="email">Required exact private panel account email; do not expose another customer's configuration.</param>
    /// <param name="tgUserId">Global Telegram owner id whose bot-scoped conversation receives the result.</param>
    /// <returns>The matching client and configured country tag; the client may be null when no panel contains it.</returns>
    /// <remarks>Each panel request completes before state persistence. Mutable protocol templates are copied per result.</remarks>
    public static async Task<(ClientExtend ClientExtend, string SelectedCountry)> FetchClientByEmail(string email, long tgUserId)
    {


        Client findedClient = null;
        ClientExtend emailClient = null;

        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

        foreach (KeyValuePair<string, ServerInfo> kvp in servers)
        {
            ServerInfo serverInfo = kvp.Value;

            foreach (var si in serverInfo.Inbounds)
            {
                if (si.Type == "tunnel")
                {
                    // login
                    var sessionCookie = await LoginAndGetSessionCookie(serverInfo);
                    // if (sessionCookie == null) throw new Exception("Error in login and get session cookie");
                    if (sessionCookie == null) continue;

                    //1.fetch inbound data
                    var inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/get/" + si.Id.ToString();
                    //InboundState apiResponse = JsonConvert.DeserializeObject<InboundState>(jsonResponse);

                    // Create an HttpClientHandler
                    var handler = new HttpClientHandler();

                    // Create a CookieContainer and add your cookie
                    var cookieContainer = new CookieContainer();
                    cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("session", sessionCookie));
                    cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("3x-ui", sessionCookie));

                    // Assign the CookieContainer to the handler
                    handler.CookieContainer = cookieContainer;

                    // Create the HttpClient with the custom handler
                    using var httpClient = new HttpClient(handler);

                    // Now you can use the httpClient to make requests with the specified cookie
                    InboundState result = null;
                    try
                    {
                        // Send the Get request 
                        HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
                        string responseBody = await response.Content.ReadAsStringAsync();
                        result = JsonConvert.DeserializeObject<InboundState>(responseBody);
                        //result.ServerInfoObject.Settings;

                    }
                    catch
                    {
                        continue;
                    }
                    if (result == null) continue;


                    // Deserialize the JSON string to a JObject
                    JObject jsonObject = JsonConvert.DeserializeObject<JObject>(result.ServerInfoObject.Settings);
                    // Access the "clients" array
                    JArray clientsArray = jsonObject["clients"] as JArray;
                    if (clientsArray != null)
                    {
                        // Convert the JArray to a list of objects
                        List<Client> clients = clientsArray.ToObject<List<Client>>();
                        findedClient = clients.FirstOrDefault(c => c.Email == email);
                    }
                    if (findedClient == null) continue;

                    inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/getClientTraffics/" + findedClient.Email;
                    ClientState clientState = null;
                    //2.fetch client stat
                    try
                    {
                        // Send the Get request 
                        HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
                        string responseBody = await response.Content.ReadAsStringAsync();
                        clientState = JsonConvert.DeserializeObject<ClientState>(responseBody);
                        //result.ServerInfoObject.Settings;

                    }
                    catch
                    {
                    }
                    if (clientState == null) continue;

                    ClientExtend client = new ClientExtend
                    {
                        Id = findedClient.Id,
                        Email = findedClient.Email,
                        TotalGB = clientState.ClientStateObject.Total,
                        ExpiryTime = findedClient.ExpiryTime,
                        ExpiryTimeRaw = findedClient.ExpiryTimeRaw,
                        SubId = findedClient.SubId,
                        TgId = findedClient.TgId,
                        Enable = findedClient.Enable,
                        Down = clientState.ClientStateObject.Down,
                        Up = clientState.ClientStateObject.Up,
                        InboundId = clientState.ClientStateObject.InboundId,
                    };

                    emailClient = client;

                    var configLink = RuntimeSnapshot.Copy(kvp.Value.VmessTemplate);
                    configLink.Ps += client.Email;
                    configLink.Id = client.Id;

                    //Console.WriteLine(responseBody);
                    var _userStateStore = UserStateStore.ForConfiguredDatabase();

                    // this Is VERY IMPPRTANT  the renew method use this!
                    await _userStateStore.SaveUserStatus(new User { Id = tgUserId, ConfigLink = configLink.ToVMessLink(), Email = email, SubLink = kvp.Value.SubLinkUrl + client.Email, SelectedCountry = kvp.Key });

                    return (ClientExtend: emailClient, SelectedCountry: kvp.Key);
                }
                // return emailClient;

            }


        }


        return (ClientExtend: null, SelectedCountry: null);
    }

    public static async Task<ClientExtend> FetchClientFromServer(Guid id, ServerInfo serverInfo, int inboundId)
    {
        Client findedClient = null;
        // login
        var sessionCookie = await LoginAndGetSessionCookie(serverInfo);
        if (sessionCookie == null) throw new Exception("Error in login and get session cookie");

        //1.fetch inbound data
        var inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/get/" + inboundId.ToString();
        //InboundState apiResponse = JsonConvert.DeserializeObject<InboundState>(jsonResponse);


        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("session", sessionCookie));
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("3x-ui", sessionCookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;

        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        // Now you can use the httpClient to make requests with the specified cookie
        InboundState result = null;
        try
        {
            // Send the Get request 
            HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
            string responseBody = await response.Content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<InboundState>(responseBody);
            //result.ServerInfoObject.Settings;

        }
        catch
        {
        }
        if (result == null) return null;

        // Deserialize the JSON string to a JObject
        JObject jsonObject = JsonConvert.DeserializeObject<JObject>(result.ServerInfoObject.Settings);
        // Access the "clients" array
        JArray clientsArray = jsonObject["clients"] as JArray;
        if (clientsArray != null)
        {
            // Convert the JArray to a list of objects
            List<Client> clients = clientsArray.ToObject<List<Client>>();
            findedClient = clients.FirstOrDefault(c => c.Id == id);
        }
        if (findedClient == null) return null;


        inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/getClientTraffics/" + findedClient.Email;
        ClientState clientState = null;
        //2.fetch client stat
        try
        {
            // Send the Get request 
            HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
            string responseBody = await response.Content.ReadAsStringAsync();
            clientState = JsonConvert.DeserializeObject<ClientState>(responseBody);
            //result.ServerInfoObject.Settings;

        }
        catch
        {
        }
        if (clientState == null) return null;
        ClientExtend client = new ClientExtend
        {
            Id = findedClient.Id,
            Email = findedClient.Email,
            TotalGB = clientState.ClientStateObject.Total,
            TgId = findedClient.TgId,
            ExpiryTime = findedClient.ExpiryTime,
            ExpiryTimeRaw = findedClient.ExpiryTimeRaw,

            SubId = findedClient.SubId,
            Enable = findedClient.Enable,
            Down = clientState.ClientStateObject.Down,
            Up = clientState.ClientStateObject.Up,
            InboundId = clientState.ClientStateObject.InboundId
        };


        return client;

    }

    public static async Task<List<ClientExtend>> FetchAllClientFromServer(long telegramUserId, ServerInfo serverInfo, int inboundId)
    {

        List<Client> findedClients = null;
        List<ClientExtend> findedClientsWithTraffic = new List<ClientExtend>();

        // login
        var sessionCookie = await LoginAndGetSessionCookie(serverInfo);
        if (sessionCookie == null) throw new Exception("Error in login and get session cookie");

        //1.fetch inbound data
        var inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/get/" + inboundId.ToString();
        //InboundState apiResponse = JsonConvert.DeserializeObject<InboundState>(jsonResponse);


        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("session", sessionCookie));
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("3x-ui", sessionCookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;

        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        // Now you can use the httpClient to make requests with the specified cookie
        InboundState result = null;
        try
        {
            // Send the Get request 
            HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
            string responseBody = await response.Content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<InboundState>(responseBody);
            //result.ServerInfoObject.Settings;
        }
        catch
        {
        }
        if (result == null) return null;
        var settings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore
        };
        // Deserialize the JSON string to a JObject
        JObject jsonObject = JsonConvert.DeserializeObject<JObject>(result.ServerInfoObject.Settings);
        // Access the "clients" array
        JArray clientsArray = jsonObject["clients"] as JArray;
        if (clientsArray != null)
        {
            // Convert the JArray to a list of objects
            List<Client> clients = clientsArray.ToObject<List<Client>>(JsonSerializer.Create(settings));

            findedClients = clients.FindAll(c => c.TgId.Trim() == telegramUserId.ToString());
            //!string.IsNullOrEmpty(c.TgId) &&
        }
        if (findedClients == null) return null;


        foreach (var findedClient in findedClients)
        {
            inboundstateUrl = serverInfo.Url + "/" + serverInfo.RootPath + "/panel/api/inbounds/getClientTraffics/" + findedClient.Email;
            ClientState clientState = null;

            //2.fetch client stat
            try
            {
                // Send the Get request 
                HttpResponseMessage response = await httpClient.GetAsync(inboundstateUrl);
                string responseBody = await response.Content.ReadAsStringAsync();
                clientState = JsonConvert.DeserializeObject<ClientState>(responseBody);
                //result.ServerInfoObject.Settings;

            }
            catch
            {
            }
            if (clientState == null) return null;

            ClientExtend client = new ClientExtend
            {
                Id = findedClient.Id,
                Email = findedClient.Email,
                TotalGB = clientState.ClientStateObject.Total,
                ExpiryTime = findedClient.ExpiryTime,
                ExpiryTimeRaw = findedClient.ExpiryTimeRaw,
                SubId = serverInfo.SubLinkUrl + findedClient.SubId,
                Enable = findedClient.Enable,
                TgId = findedClient.TgId,
                Down = clientState.ClientStateObject.Down,
                Up = clientState.ClientStateObject.Up,
                InboundId = clientState.ClientStateObject.InboundId
            };
            findedClientsWithTraffic.Add(client);

        }



        return findedClientsWithTraffic;

    }


    public static long ConvertGBToBytes(int gigabytes)
    {
        const long bytesPerGB = 1024L * 1024L * 1024L;
        return gigabytes * bytesPerGB;
    }

    static long ConvertDateTimeToTimestamp(DateTime dateTime)
    {
        // Assuming the input DateTime is in UTC to match the timestamp provided
        DateTime unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        TimeSpan timeDifference = dateTime.ToUniversalTime() - unixEpoch;

        // Return the timestamp in seconds
        return (long)timeDifference.TotalSeconds;
    }
    public static int ConvertPeriodToDays(string period)
    {
        switch (period)
        {
            case "1 Day":
                return 1;
            case "0 Month":
                return 0;
            case "1 Month":
                return 30; // Assuming one month is approximately 30 days
            case "2 Months":
                return 60; // Assuming two months is approximately 60 days
            case "3 Months":
                return 90; // Assuming three months is approximately 90 days
            case "6 Months":
                return 180; // Assuming six months is approximately 180 days
            default:
                // Handle other cases or throw an exception if needed
                throw new ArgumentException($"Invalid period: {period}");
        }
    }

    internal static async Task<bool> AccountActivating(string email, long telegramUserId, bool enable)
    {
        var res = await FetchClientByEmail(email, telegramUserId);
        var client = res.ClientExtend;
        if (client == null) return false;
        if (client.TgId.Trim() != telegramUserId.ToString()) return false;
        client.Enable = enable;

        string selectedCountry = res.SelectedCountry;




        var serversJson = ReadJsonFile.ReadJsonAsString();
        var servers = JsonConvert.DeserializeObject<Dictionary<string, ServerInfo>>(serversJson);

        if (!servers.TryGetValue(selectedCountry, out ServerInfo serverInfo)) return false;


        // login
        var sessionCookie = await LoginAndGetSessionCookie(serverInfo);
        // if (sessionCookie == null) throw new Exception("Error in login and get session cookie");
        if (sessionCookie == null) return false;


        // Create an HttpClientHandler
        var handler = new HttpClientHandler();

        // Create a CookieContainer and add your cookie
        var cookieContainer = new CookieContainer();
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("session", sessionCookie));
        cookieContainer.Add(new Uri(serverInfo.Url), new Cookie("3x-ui", sessionCookie));

        // Assign the CookieContainer to the handler
        handler.CookieContainer = cookieContainer;

        // Create the HttpClient with the custom handler
        using var httpClient = new HttpClient(handler);

        // Now you can use the httpClient to make requests with the specified cookie

        // Create the request body
        var inboundId = serverInfo.Inbounds.FirstOrDefault(i => i.Type == "tunnel");
        if (inboundId == null) return false;
        Client editedClient = client;

        var requestBody = new
        {
            id = inboundId.Id,
            settings = Client.MakeSettingString(editedClient)
        };

        //var apiUrl = accountDto.ServerInfo.Url + "/" + accountDto.ServerInfo.RootPath + "/" + "panel/api/inbounds/addClient";
        var apiUrl = $"{serverInfo.Url}/{serverInfo.RootPath}/panel/api/inbounds/updateClient/{client.Id}";

        try
        {
            // Send the POST request with the JSON body
            HttpResponseMessage response = await httpClient.PostAsJsonAsync(apiUrl, requestBody);
            string responseBody = await response.Content.ReadAsStringAsync();
            AddClientResult result = JsonConvert.DeserializeObject<AddClientResult>(responseBody);


            // Check if the request was successful
            if (response.IsSuccessStatusCode && result.Success)
            {
                // Account created successfully
                // Read and print the response content

                // var configLink = serverInfo.VmessTemplate;
                // configLink.Ps += client.Email;
                // configLink.Id = client.Id;

                // //Console.WriteLine(responseBody);
                // UserDbContext _userDbContext = new UserDbContext();

                // await _userStateStore.SaveUserStatus(new User { Id = telegramUserId, SubLink = accountDto.ServerInfo.SubLinkUrl + client.Email, ConfigLink = configLink.ToVMessLink(), Email = client.Email });
                // await _userDbContext.SaveChangesAsync();
                return true;

            }
            else
            {
                Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                Console.WriteLine($"Server Message:  isSuccessful:{result.Success} - {result.Msg}");
                return false;
            }
        }
        catch (HttpRequestException ex)
        {
            Console.WriteLine($"HttpRequestException: {ex.Message}");

        }
        return false;
    }
}

