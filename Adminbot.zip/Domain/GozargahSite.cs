using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using Adminbot.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Adminbot.Domain
{
    /// <summary>
    /// Identifies the website owner and the buyer separately for one Gozargah lifecycle operation.
    /// </summary>
    /// <remarks>
    /// Tenant storefronts register the order under the colleague that owns the storefront while retaining the
    /// customer's Telegram id for audit. This value never changes the corresponding 3x-ui client metadata.
    /// </remarks>
    public sealed record GozargahSyncOwnership(
        long SiteOwnerTelegramUserId,
        long BuyerTelegramUserId,
        string TenantBotId = null)
    {
        /// <summary>Gets whether the operation belongs to a tenant storefront.</summary>
        public bool IsTenant => !string.IsNullOrWhiteSpace(TenantBotId);
    }

    /// <summary>
    /// Operation names stored in <see cref="GozargahSiteSyncEvent.Operation"/> for the Gozargah site outbox.
    /// </summary>
    public static class GozargahSiteSyncOperations
    {
        /// <summary>
        /// Registers a newly created XUI v3 account in the Gozargah website orders table.
        /// </summary>
        public const string Create = "create";

        /// <summary>
        /// Updates an existing website order after renewal, account edit, or link replacement.
        /// </summary>
        public const string Update = "update";

        /// <summary>
        /// Renames an existing website order after the bot changes the XUI email, UUID, and subscription id.
        /// </summary>
        public const string Rename = "rename";

        /// <summary>
        /// Deletes an order from the Gozargah website after the matching XUI v3 account is deleted.
        /// </summary>
        public const string Delete = "delete";
    }

    /// <summary>
    /// Processing states for <see cref="GozargahSiteSyncEvent"/> rows.
    /// </summary>
    public static class GozargahSiteSyncStatuses
    {
        /// <summary>
        /// The event is waiting for the background retry worker or immediate sender.
        /// </summary>
        public const string Pending = "pending";

        /// <summary>
        /// The event was successfully accepted by the Gozargah website API.
        /// </summary>
        public const string Succeeded = "succeeded";

        /// <summary>
        /// The event failed but should be retried later.
        /// </summary>
        public const string Failed = "failed";

        /// <summary>
        /// The event was intentionally skipped because sync is disabled, the user is banned, or site user data is missing.
        /// </summary>
        public const string Skipped = "skipped";
    }

    /// <summary>
    /// Outbox row used to synchronize one XUI v3 lifecycle operation with the Gozargah website.
    /// </summary>
    /// <remarks>
    /// Rows are stored in <c>users.db</c>, not <c>credentials.db</c>. The row is tenant-aware through
    /// <see cref="BotId"/> and <see cref="TenantBotId"/> and idempotent through the combination of operation,
    /// email/name, UUID, subscription id, and optional site order id. Successful rows remain as an audit trail.
    /// </remarks>
    public class GozargahSiteSyncEvent
    {
        /// <summary>Transient result flag: an update matched saved successful state and made no insert or HTTP call.</summary>
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public bool WasUnchanged { get; set; }
        /// <summary>
        /// Internal users.db id for this outbox row.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Bot id that initiated the operation. Owned bots use their configured id; tenant sales use the tenant bot id.
        /// </summary>
        public string BotId { get; set; }

        /// <summary>
        /// Tenant storefront id when the operation belongs to a tenant sale; otherwise null for owned bots.
        /// </summary>
        public string TenantBotId { get; set; }

        /// <summary>
        /// Telegram user id of the website account that should own the order on Gozargah.
        /// For tenant sales this is the tenant owner, not the storefront customer.
        /// </summary>
        public long TelegramUserId { get; set; }

        /// <summary>
        /// Tenant owner Telegram user id when a tenant operation is being synced; null for owned-bot customer operations.
        /// </summary>
        public long? OwnerTelegramUserId { get; set; }

        /// <summary>
        /// Buyer Telegram user id when different from <see cref="TelegramUserId"/>, mainly for tenant storefront sales.
        /// </summary>
        public long? BuyerTelegramUserId { get; set; }

        /// <summary>
        /// XUI client email and Gozargah order name used by update and delete requests.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Previous XUI client email when the operation is a link replacement that renames the site order.
        /// </summary>
        public string PreviousEmail { get; set; }

        /// <summary>
        /// XUI v3 UUID for the account after creation or rename.
        /// </summary>
        public string Uuid { get; set; }

        /// <summary>
        /// XUI v3 subscription id after creation or rename.
        /// </summary>
        public string SubId { get; set; }

        /// <summary>
        /// Full subscription URL sent to the website API.
        /// </summary>
        public string SubLink { get; set; }

        /// <summary>
        /// Operation name from <see cref="GozargahSiteSyncOperations"/>.
        /// </summary>
        public string Operation { get; set; }

        /// <summary>
        /// Last known website order id returned by the API when create or update succeeds.
        /// </summary>
        public string SiteOrderId { get; set; }

        /// <summary>
        /// Current outbox status from <see cref="GozargahSiteSyncStatuses"/>.
        /// </summary>
        public string Status { get; set; } = GozargahSiteSyncStatuses.Pending;

        /// <summary>
        /// Number of send attempts already performed against the website API.
        /// </summary>
        public int RetryCount { get; set; }

        /// <summary>
        /// Last API or validation error. Secrets are never stored here.
        /// </summary>
        public string LastError { get; set; }

        /// <summary>
        /// JSON request payload sent to the website API. Stored for audit and retry.
        /// </summary>
        public string RequestJson { get; set; }

        /// <summary>
        /// Raw JSON response returned by the website API for the last attempt.
        /// </summary>
        public string ResponseJson { get; set; }

        /// <summary>
        /// UTC creation time of the outbox row.
        /// </summary>
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// UTC time of the last status or payload update.
        /// </summary>
        public DateTime? UpdatedAtUtc { get; set; }

        /// <summary>
        /// UTC time when the website API accepted this event.
        /// </summary>
        public DateTime? SucceededAtUtc { get; set; }
    }

    /// <summary>
    /// One normalized order payload sent to the Gozargah website API.
    /// </summary>
    public class GozargahSiteOrderPayload
    {
        /// <summary>
        /// Website plan id: 1 for national, 2 for normal metered, and 5 for unlimited fair-usage plans.
        /// </summary>
        [JsonProperty("plan_id")]
        public int PlanId { get; set; }

        /// <summary>
        /// Comma-separated inbound ids expected by the website.
        /// </summary>
        [JsonProperty("inbound")]
        public string Inbound { get; set; }

        /// <summary>
        /// Website arranged-plan id. Unlimited plans use 6, 7, 8, or 9; metered services use 0.
        /// </summary>
        [JsonProperty("arranged_plan_id")]
        public int ArrangedPlanId { get; set; }

        /// <summary>
        /// Current website order name, which matches the XUI client email.
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// New website order name used only for rename/link-change operations.
        /// </summary>
        [JsonProperty("new_name")]
        public string NewName { get; set; }

        /// <summary>
        /// XUI UUID for the account.
        /// </summary>
        [JsonProperty("uuid")]
        public string Uuid { get; set; }

        /// <summary>
        /// Audit comment stored on the website order.
        /// </summary>
        [JsonProperty("comment")]
        public string Comment { get; set; }

        /// <summary>
        /// Order price in Iranian toman. The website API expects this as a string.
        /// </summary>
        [JsonProperty("price")]
        public string Price { get; set; }

        /// <summary>
        /// Traffic or fair-usage volume in GB.
        /// </summary>
        [JsonProperty("volume")]
        public decimal Volume { get; set; }

        /// <summary>
        /// Account duration in days. A value of 0 represents unlimited time for metered life plans.
        /// </summary>
        [JsonProperty("date")]
        public int Date { get; set; }

        /// <summary>
        /// Gozargah website username that owns the order.
        /// </summary>
        [JsonProperty("username")]
        public string Username { get; set; }

        /// <summary>
        /// Tracking code that links the website order to a local bot operation or tenant order.
        /// </summary>
        [JsonProperty("tracking_code")]
        public string TrackingCode { get; set; }

        /// <summary>
        /// Full subscription link for the account.
        /// </summary>
        [JsonProperty("sub")]
        public string Sub { get; set; }

        /// <summary>
        /// 1 for trial/free accounts and 0 for paid accounts.
        /// </summary>
        [JsonProperty("trial")]
        public int Trial { get; set; }

        /// <summary>
        /// 1 because all payloads created by this integration come from the Telegram bot.
        /// </summary>
        [JsonProperty("bot")]
        public int Bot { get; set; } = 1;
    }

    /// <summary>
    /// Raw response wrapper returned by the Gozargah API.
    /// </summary>
    /// <typeparam name="TData">Expected shape of the <c>data</c> field.</typeparam>
    public class GozargahSiteApiResponse<TData>
    {
        /// <summary>
        /// Whether the website API accepted the request.
        /// </summary>
        [JsonProperty("success")]
        public bool Success { get; set; }

        /// <summary>
        /// Echoed action name returned by the website API.
        /// </summary>
        [JsonProperty("action")]
        public string Action { get; set; }

        /// <summary>
        /// Human-readable API message.
        /// </summary>
        [JsonProperty("message")]
        public string Message { get; set; }

        /// <summary>
        /// Order id returned by create, update, or delete actions when available.
        /// </summary>
        [JsonProperty("id")]
        public long? Id { get; set; }

        /// <summary>
        /// Action-specific response data.
        /// </summary>
        [JsonProperty("data")]
        public TData Data { get; set; }
    }

    /// <summary>
    /// User row returned by the Gozargah <c>get_user</c> action.
    /// </summary>
    public class GozargahSiteUserData
    {
        /// <summary>
        /// Website username used as the owner username in order payloads.
        /// </summary>
        [JsonProperty("username")]
        public string Username { get; set; }

        /// <summary>
        /// Telegram user id string stored on the website.
        /// </summary>
        [JsonProperty("telegram_id")]
        public string TelegramId { get; set; }

        /// <summary>
        /// User email stored on the website when available.
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Website wallet balance in Iranian toman.
        /// </summary>
        [JsonProperty("wallet")]
        public long Wallet { get; set; }

        /// <summary>
        /// Website ban flag. A value of 1 means the bot must not serve this user through site-connected flows.
        /// </summary>
        [JsonProperty("ban")]
        public int Ban { get; set; }

        /// <summary>
        /// True when the website says this user is banned.
        /// </summary>
        [JsonIgnore]
        public bool IsBanned => Ban == 1;
    }

    /// <summary>
    /// Response data returned by the Gozargah wallet deduction endpoint.
    /// </summary>
    public class GozargahSiteWalletDeductData
    {
        /// <summary>
        /// Telegram id whose website wallet was debited.
        /// </summary>
        [JsonProperty("telegram_id")]
        public string TelegramId { get; set; }

        /// <summary>
        /// Debited amount in Iranian toman.
        /// </summary>
        [JsonProperty("amount")]
        public long Amount { get; set; }

        /// <summary>
        /// Website wallet balance before debit.
        /// </summary>
        [JsonProperty("previous_wallet")]
        public long PreviousWallet { get; set; }

        /// <summary>
        /// Website wallet balance after debit.
        /// </summary>
        [JsonProperty("current_wallet")]
        public long CurrentWallet { get; set; }
    }

    /// <summary>
    /// HTTP client for the Gozargah website API.
    /// </summary>
    public class GozargahSiteApiClient
    {
        /// <summary>
        /// Overall wall-clock budget for ONE optional Gozargah website lookup performed while a Telegram user is waiting.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Foreground Gozargah call sites are the website enrichments a customer or colleague waits for: owned-bot
        /// colleague-role refresh (`PromoteToColleagueIfConnectedSiteUserAsync`), storefront wallet-button eligibility
        /// (`CheckSiteWalletEligibilityAsync`), the owned-bot profile wallet line, and the tenant access decision that
        /// depends on those. Each of them must finish inside this one budget so a slow website can never hold a strict
        /// FIFO Telegram lane the way the production incident held one for 61-104 seconds.
        /// </para>
        /// <para>
        /// Background Gozargah work — the site sync outbox, its retry worker, the storefront funding monitor, and
        /// post-commit website mirroring — deliberately does NOT use this budget. Those callers pass their own token to
        /// <see cref="SendAsync{T}" /> and keep the provider-oriented 30-second transport ceiling, because no interactive
        /// lane is waiting and a slow website must not be mistaken for a business failure.
        /// </para>
        /// </remarks>
        public static readonly TimeSpan OptionalLookupTimeout = TimeSpan.FromSeconds(4);

        /// <summary>
        /// Hard maximum for the optional foreground website-lookup budget. Never exceeded, whatever the constants say.
        /// </summary>
        public static readonly TimeSpan OptionalLookupHardMaximum = TimeSpan.FromSeconds(5);

        /// <summary>
        /// Creates the linked cancellation scope that bounds one optional foreground website lookup.
        /// </summary>
        /// <param name="outerCancellationToken">
        /// Cancellation token of the active Telegram update or background operation. Cancelling it cancels the lookup
        /// immediately as part of normal lane shutdown.
        /// </param>
        /// <returns>
        /// A linked source that cancels when the caller's token cancels or when the foreground lookup budget expires,
        /// whichever happens first. The effective budget is clamped to <see cref="OptionalLookupHardMaximum" />.
        /// </returns>
        /// <remarks>
        /// Callers must dispose the returned source and pass its token to the lookup. On expiry the existing business
        /// rule applies: colleague promotion keeps the locally known role and wallet eligibility reports the website as
        /// unavailable, so no financial state is ever mutated from an unknown website result.
        /// </remarks>
        /// <example>
        /// <code>
        /// using var lookup = GozargahSiteApiClient.CreateOptionalLookupCancellation(cancellationToken);
        /// var siteUser = await apiClient.GetUserAsync(telegramUserId, lookup.Token);
        /// </code>
        /// </example>
        public static CancellationTokenSource CreateOptionalLookupCancellation(CancellationToken outerCancellationToken)
        {
            var budget = OptionalLookupTimeout <= OptionalLookupHardMaximum ? OptionalLookupTimeout : OptionalLookupHardMaximum;
            var source = CancellationTokenSource.CreateLinkedTokenSource(outerCancellationToken);
            source.CancelAfter(budget);
            return source;
        }
        private readonly AppConfig _appConfig;
        private readonly ILogger<GozargahSiteApiClient> _logger;

        /// <summary>
        /// Creates a Gozargah website API client from application configuration.
        /// </summary>
        /// <param name="configuration">Application configuration containing API URL and bearer token.</param>
        /// <param name="logger">Logger used for safe diagnostics without writing the API key.</param>
        public GozargahSiteApiClient(IConfiguration configuration, ILogger<GozargahSiteApiClient> logger)
        {
            _appConfig = configuration.Get<AppConfig>() ?? new AppConfig();
            _logger = logger;
        }

        /// <summary>
        /// Gets whether the API has enough configuration to send requests.
        /// </summary>
        /// <returns><c>true</c> when sync is enabled and both API URL and bearer token are configured.</returns>
        public bool IsConfigured()
        {
            return _appConfig.GozargahSiteSyncEnabled &&
                   !string.IsNullOrWhiteSpace(_appConfig.GozargahSiteApiBaseUrl) &&
                   !string.IsNullOrWhiteSpace(_appConfig.GozargahSiteApiKey);
        }

        /// <summary>
        /// Gets a Gozargah website user by Telegram id.
        /// </summary>
        /// <param name="telegramUserId">Numeric Telegram user id stored on the website.</param>
        /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
        /// <returns>
        /// API response containing user data when found. The response may have <c>Success=false</c> when
        /// the user does not exist on the website or the API rejects the request.
        /// </returns>
        public Task<GozargahSiteApiResponse<GozargahSiteUserData>> GetUserAsync(
            long telegramUserId,
            CancellationToken cancellationToken = default)
        {
            return SendAsync<GozargahSiteUserData>(
                new
                {
                    action = "get_user",
                    telegram_id = telegramUserId.ToString(CultureInfo.InvariantCulture)
                },
                cancellationToken);
        }

        /// <summary>
        /// Creates a website order for a newly created XUI account.
        /// </summary>
        /// <param name="payload">Normalized website order payload.</param>
        /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
        /// <returns>Raw API response with the website order id when creation succeeds.</returns>
        public Task<GozargahSiteApiResponse<JToken>> CreateOrderAsync(
            GozargahSiteOrderPayload payload,
            CancellationToken cancellationToken = default)
        {
            return SendAsync<JToken>(BuildOrderBody("create_order", payload), cancellationToken);
        }

        /// <summary>
        /// Updates a website order for renewal, metadata edit, historical upsert, or link replacement.
        /// </summary>
        /// <param name="payload">Normalized website order payload. <see cref="GozargahSiteOrderPayload.Name"/> is the lookup key.</param>
        /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
        /// <returns>Raw API response with updated fields when available.</returns>
        public Task<GozargahSiteApiResponse<JToken>> UpdateOrderAsync(
            GozargahSiteOrderPayload payload,
            CancellationToken cancellationToken = default)
        {
            return SendAsync<JToken>(BuildOrderBody("update_order", payload), cancellationToken);
        }

        /// <summary>
        /// Deletes a website order by XUI email/name.
        /// </summary>
        /// <param name="name">Current XUI email and website order name.</param>
        /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
        /// <returns>Raw delete response from the website API.</returns>
        public Task<GozargahSiteApiResponse<JToken>> DeleteOrderAsync(
            string name,
            CancellationToken cancellationToken = default)
        {
            return SendAsync<JToken>(
                new
                {
                    action = "delete_order",
                    name
                },
                cancellationToken);
        }

        /// <summary>
        /// Deducts an amount from the user's website wallet after the bot has already confirmed XUI success.
        /// </summary>
        /// <param name="telegramUserId">Telegram id of the website wallet owner.</param>
        /// <param name="amountToman">Debit amount in Iranian toman. Must be greater than zero.</param>
        /// <param name="cancellationToken">Cancellation token for the HTTP request.</param>
        /// <returns>Wallet balances returned by the website API.</returns>
        /// <remarks>
        /// The website endpoint itself can make the wallet negative, so callers must run <see cref="GetUserAsync"/>
        /// first and compare wallet balance before calling this method.
        /// </remarks>
        public Task<GozargahSiteApiResponse<GozargahSiteWalletDeductData>> DeductWalletAsync(
            long telegramUserId,
            long amountToman,
            CancellationToken cancellationToken = default)
        {
            return SendAsync<GozargahSiteWalletDeductData>(
                new
                {
                    action = "deduct_wallet",
                    telegram_id = telegramUserId.ToString(CultureInfo.InvariantCulture),
                    amount = amountToman
                },
                cancellationToken);
        }

        /// <summary>
        /// Sends one JSON action request to the Gozargah website API and deserializes the standard response wrapper.
        /// </summary>
        /// <typeparam name="T">Expected response data type for the requested action.</typeparam>
        /// <param name="body">Request body containing the <c>action</c> field and action-specific arguments.</param>
        /// <param name="cancellationToken">Cancellation token for the outbound HTTP request.</param>
        /// <returns>
        /// Parsed API response. HTTP errors, non-JSON content types, HTML/error-page bodies, empty bodies, and invalid
        /// JSON are all converted to unsuccessful responses so callers can persist retry state and the Telegram update
        /// flow never crashes with an unhandled <see cref="JsonReaderException"/>. Expected <c>get_user</c> misses are
        /// returned without warning logs because most bot users do not have a Gozargah website account.
        /// </returns>
        /// <remarks>
        /// The API key is sent only in the Authorization header and is never written to logs. Configuration errors throw
        /// because callers should not enqueue website traffic when the API endpoint or key is missing.
        ///
        /// Response validation:
        /// Before any JSON deserialization the method checks the HTTP status, the Content-Type media type, and the
        /// leading characters of the body. A reverse proxy or maintenance page commonly returns HTML with a 200 status;
        /// those bodies are rejected with a sanitized diagnostic instead of being parsed. Diagnostic previews are
        /// truncated and whitespace-collapsed so logs and retry states never receive huge markup or control characters.
        ///
        /// Logging rule:
        /// A missing website user during wallet-button eligibility checks is a normal business outcome, not an
        /// operational API failure. Other HTTP and response-shape failures still emit warnings so sync, wallet debit,
        /// and order lifecycle problems remain visible to operators.
        /// </remarks>
        private async Task<GozargahSiteApiResponse<T>> SendAsync<T>(object body, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(_appConfig.GozargahSiteApiBaseUrl))
                throw new InvalidOperationException("GozargahSiteApiBaseUrl is not configured.");
            if (string.IsNullOrWhiteSpace(_appConfig.GozargahSiteApiKey))
                throw new InvalidOperationException("GozargahSiteApiKey is not configured.");

            var action = GetActionName(body);
            // Attribute this outbound site lookup to the closed-vocabulary site_lookup stage when it happens inside a
            // Telegram update lane. Background sync callers run without a latency scope, so the measurement is a no-op
            // for them. The site base URL and API key are never part of the stage name.
            using var stageMeasurement = TelegramUpdateLatencyScope.Current?.Measure(TelegramUpdateStage.SiteLookup) ?? default;
            using var httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            using var request = new HttpRequestMessage(HttpMethod.Post, _appConfig.GozargahSiteApiBaseUrl);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _appConfig.GozargahSiteApiKey);
            request.Content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");

            using var response = await httpClient.SendAsync(request, cancellationToken);
            var responseText = await response.Content.ReadAsStringAsync(cancellationToken);
            var contentType = response.Content.Headers.ContentType?.MediaType;

            if (!response.IsSuccessStatusCode)
            {
                if (!IsExpectedMissingUserResponse(action, response.StatusCode, responseText) &&
                    !IsExpectedMissingOrderResponse(action, response.StatusCode, responseText))
                {
                    _logger.LogWarning(
                        "Gozargah site API returned HTTP {StatusCode} with content type {ContentType}. Body={BodyPreview}",
                        (int)response.StatusCode,
                        contentType ?? "unknown",
                        SanitizeBodyPreview(responseText));
                }

                return new GozargahSiteApiResponse<T>
                {
                    Success = false,
                    Message = $"HTTP {(int)response.StatusCode}: {SanitizeBodyPreview(responseText)}"
                };
            }

            if (!HasJsonCompatibleContentType(contentType) || StartsWithMarkup(responseText))
            {
                _logger.LogWarning(
                    "Gozargah site API returned a non-JSON success response with content type {ContentType}. Body={BodyPreview}",
                    contentType ?? "unknown",
                    SanitizeBodyPreview(responseText));

                return new GozargahSiteApiResponse<T>
                {
                    Success = false,
                    Message = $"Non-JSON response (content type {contentType ?? "unknown"}): {SanitizeBodyPreview(responseText)}"
                };
            }

            try
            {
                return JsonConvert.DeserializeObject<GozargahSiteApiResponse<T>>(responseText) ??
                       new GozargahSiteApiResponse<T>
                       {
                           Success = false,
                           Message = "Gozargah site API returned an empty response."
                       };
            }
            catch (JsonException ex)
            {
                _logger.LogWarning(
                    ex,
                    "Gozargah site API returned invalid JSON with content type {ContentType}. Body={BodyPreview}",
                    contentType ?? "unknown",
                    SanitizeBodyPreview(responseText));

                return new GozargahSiteApiResponse<T>
                {
                    Success = false,
                    Message = $"Invalid JSON response (content type {contentType ?? "unknown"}): {SanitizeBodyPreview(responseText)}"
                };
            }
        }

        /// <summary>
        /// Checks whether a response body is safe to pass to JSON deserialization based on its content type.
        /// </summary>
        /// <param name="contentType">
        /// Media type returned by the Gozargah website, or null when the response has no Content-Type header.
        /// </param>
        /// <returns>
        /// <c>true</c> when the media type is missing, JSON, or plain text (which some PHP APIs use for JSON bodies);
        /// otherwise <c>false</c> so HTML/octet-stream/other binary responses are rejected before parsing.
        /// </returns>
        /// <remarks>
        /// Missing and plain-text content types are allowed because the documented API endpoint can serve JSON without
        /// a precise <c>application/json</c> header. Explicit HTML or binary content types are never parsed.
        /// </remarks>
        private static bool HasJsonCompatibleContentType(string contentType)
        {
            if (string.IsNullOrWhiteSpace(contentType))
                return true;

            return contentType.Contains("json", StringComparison.OrdinalIgnoreCase) ||
                   contentType.Contains("text/plain", StringComparison.OrdinalIgnoreCase) ||
                   contentType.Contains("text/json", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Detects HTML or XML error-page bodies that must never be handed to JSON deserialization.
        /// </summary>
        /// <param name="responseText">Raw response body returned by the Gozargah website API.</param>
        /// <returns>
        /// <c>true</c> when the trimmed body starts with a markup character such as <c>&lt;</c>, which is typical of
        /// reverse-proxy, framework, or maintenance error pages; otherwise <c>false</c>.
        /// </returns>
        private static bool StartsWithMarkup(string responseText)
        {
            var trimmed = (responseText ?? string.Empty).TrimStart();
            return trimmed.Length > 0 && trimmed[0] == '<';
        }

        /// <summary>
        /// Produces a bounded, whitespace-collapsed preview of an API response body for logs and retry state.
        /// </summary>
        /// <param name="responseText">Raw response body returned by the Gozargah website API.</param>
        /// <returns>
        /// A single-line preview of at most <see cref="MaxBodyPreviewLength"/> characters, or an empty string when the
        /// body is null. Control characters and surrounding whitespace are removed so markup or binary data cannot
        /// flood the private logger channel or a persisted retry row.
        /// </returns>
        private static string SanitizeBodyPreview(string responseText)
        {
            const int MaxBodyPreviewLength = 500;

            if (string.IsNullOrWhiteSpace(responseText))
                return string.Empty;

            var collapsed = new string(
                responseText.Where(character => !char.IsControl(character)).ToArray())
                .Trim();

            return collapsed.Length <= MaxBodyPreviewLength
                ? collapsed
                : collapsed[..MaxBodyPreviewLength] + "...";
        }

        /// <summary>
        /// Reads the Gozargah API action name from an anonymous request body or dictionary body.
        /// </summary>
        /// <param name="body">
        /// Request body passed to <see cref="SendAsync{T}"/>. It should contain an <c>action</c> property, but may be
        /// null or malformed when a caller is incorrectly wired.
        /// </param>
        /// <returns>
        /// The action name as sent to the website API, or an empty string when it cannot be resolved. The value is only
        /// used for logging decisions and is never sent to users.
        /// </returns>
        /// <remarks>
        /// The client accepts both anonymous objects and dictionaries because order payloads are normalized through
        /// <see cref="BuildOrderBody"/> while user and wallet calls are anonymous objects.
        /// </remarks>
        private static string GetActionName(object body)
        {
            if (body == null)
                return string.Empty;

            if (body is IDictionary<string, object> dictionary &&
                dictionary.TryGetValue("action", out var dictionaryAction))
                return dictionaryAction?.ToString() ?? string.Empty;

            var action = JObject.FromObject(body)["action"];
            return action?.ToString() ?? string.Empty;
        }

        /// <summary>
        /// Detects the normal "site user does not exist" response from the Gozargah <c>get_user</c> endpoint.
        /// </summary>
        /// <param name="action">Action name extracted from the request body.</param>
        /// <param name="statusCode">HTTP status code returned by the website API.</param>
        /// <param name="responseText">Raw response body returned by the website API.</param>
        /// <returns>
        /// <c>true</c> when the response is the expected missing-user result for <c>get_user</c>; otherwise
        /// <c>false</c>, meaning the caller should keep normal warning logs.
        /// </returns>
        /// <remarks>
        /// Wallet eligibility checks run before showing the Gozargah website wallet button. Most Telegram users are not
        /// registered on the website, so logging every 404 would flood the private logger channel without indicating a
        /// broken integration.
        /// </remarks>
        private static bool IsExpectedMissingUserResponse(string action, HttpStatusCode statusCode, string responseText)
        {
            return string.Equals(action, "get_user", StringComparison.OrdinalIgnoreCase) &&
                   statusCode == HttpStatusCode.NotFound &&
                   responseText?.IndexOf("not found", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>
        /// Detects the normal "order does not exist" response from the Gozargah order endpoints.
        /// </summary>
        /// <param name="action">Action name extracted from the request body.</param>
        /// <param name="statusCode">HTTP status code returned by the website API.</param>
        /// <param name="responseText">Raw response body returned by the website API.</param>
        /// <returns>
        /// <c>true</c> when the response is the expected missing-order result for <c>delete_order</c> or
        /// <c>update_order</c>; otherwise <c>false</c>, meaning the caller should keep normal warning logs.
        /// </returns>
        /// <remarks>
        /// A delete re-issued after the order is already gone has reached its goal, and an update about to fall back
        /// to create is a handled business path. Both would otherwise flood the private logger channel on every retry,
        /// mirroring why the missing <c>get_user</c> result is not treated as an operational failure.
        /// </remarks>
        private static bool IsExpectedMissingOrderResponse(string action, HttpStatusCode statusCode, string responseText)
        {
            if (statusCode != HttpStatusCode.NotFound)
                return false;
            if (responseText?.IndexOf("not found", StringComparison.OrdinalIgnoreCase) < 0)
                return false;
            return string.Equals(action, "delete_order", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(action, "update_order", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Converts a normalized order payload into the action-shaped dictionary required by the website API.
        /// </summary>
        /// <param name="action">Website API action name such as <c>create_order</c> or <c>update_order</c>.</param>
        /// <param name="payload">Normalized order payload. Null-valued properties are omitted from the request.</param>
        /// <returns>A case-sensitive dictionary that can be serialized directly as the JSON request body.</returns>
        /// <remarks>
        /// The website API treats missing and null fields differently for updates, so null values are intentionally
        /// removed before sending the request.
        /// </remarks>
        private static IDictionary<string, object> BuildOrderBody(string action, GozargahSiteOrderPayload payload)
        {
            var json = JObject.FromObject(payload ?? new GozargahSiteOrderPayload());
            json["action"] = action;
            var body = json.Properties()
                .Where(property => property.Value.Type != JTokenType.Null)
                .ToDictionary(
                    property => property.Name,
                    property => ((JValue)property.Value).Value ?? property.Value.ToString(),
                    StringComparer.Ordinal);
            return body;
        }
    }

    /// <summary>
    /// Builds and sends Gozargah website sync events for XUI v3 account lifecycle changes.
    /// </summary>
    public class GozargahSiteSyncService
    {
        private const int NationalPlanId = 1;
        private const int NormalPlanId = 2;
        private const int UnlimitedPlanId = 5;
        /// <summary>
        /// Overall wall-clock budget for one optional, interactive Gozargah website lookup.
        /// </summary>
        /// <remarks>
        /// This is the single source of truth for the foreground site-lookup bound used by both this sync service and
        /// the owned-bot profile line. Four seconds covers the whole logical lookup (one POST, no retries).
        /// </remarks>
        private static readonly TimeSpan OptionalWebsiteLookupTimeout = GozargahSiteApiClient.OptionalLookupTimeout;
        private readonly UserDbContextFactory _userDbContextFactory;
        /// <summary>Prevents immediate send and recovery from sending the same outbox event concurrently; idle ids are removed.</summary>
        private static readonly AsyncKeyedGate EventGate = new();
        /// <summary>Serializes actual website sends and retries for one UUID (email fallback), removing idle keys.</summary>
        private static readonly AsyncKeyedGate AccountGate = new();
        /// <summary>Serializes only short queue-admission decisions for one UUID (email fallback), never website I/O.</summary>
        private static readonly AsyncKeyedGate QueueGate = new();
        private readonly CredentialsStore _credentialsDbContext;
        private readonly GozargahSiteApiClient _apiClient;
        private readonly AppConfig _appConfig;
        private readonly ILogger<GozargahSiteSyncService> _logger;

        /// <summary>
        /// Creates the sync service that owns mapping, outbox creation, immediate send, and site-wallet debits.
        /// </summary>
        /// <param name="userDbContext">Factory for operation-owned users.db contexts. Detached input rows are reloaded before writes.</param>
        /// <param name="credentialsDbContext">credentials.db context used only for reading bot-side block status and balances.</param>
        /// <param name="apiClient">Gozargah website API client.</param>
        /// <param name="configuration">Application configuration containing sync flags.</param>
        /// <param name="logger">Logger used for diagnostics.</param>
        /// <remarks>Each retry execution resolves its own scope. Website requests occur outside local write transactions and retain their existing operation keys.</remarks>
        /// <exception cref="InvalidOperationException">Terminal event retention days are not positive.</exception>
        public GozargahSiteSyncService(
            UserDbContextFactory userDbContext,
            CredentialsStore credentialsDbContext,
            GozargahSiteApiClient apiClient,
            IConfiguration configuration,
            ILogger<GozargahSiteSyncService> logger)
        {
            _userDbContextFactory = userDbContext;
            if ((configuration.Get<AppConfig>() ?? new AppConfig()).GozargahSiteSyncRetentionDays <= 0)
                throw new InvalidOperationException("GozargahSiteSyncRetentionDays must be positive.");
            _credentialsDbContext = credentialsDbContext;
            _apiClient = apiClient;
            _appConfig = configuration.Get<AppConfig>() ?? new AppConfig();
            _logger = logger;
        }

        /// <summary>
        /// Checks whether a user can use the Gozargah site wallet for a bot purchase or renewal.
        /// </summary>
        /// <param name="telegramUserId">Telegram id of the wallet owner on the website.</param>
        /// <param name="amountToman">Required payment amount in Iranian toman.</param>
        /// <param name="cancellationToken">Cancellation token for database and API operations.</param>
        /// <returns>
        /// Eligibility result. <c>CanUse</c> is true only when config is enabled, the bot user is not blocked,
        /// the site user exists, the site user is not banned, and the website wallet balance covers the amount.
        /// </returns>
        public async Task<GozargahSiteWalletEligibility> CheckSiteWalletEligibilityAsync(
            long telegramUserId,
            long amountToman,
            CancellationToken cancellationToken = default)
        {
            if (!_appConfig.GozargahSiteWalletPaymentsEnabled || !_apiClient.IsConfigured())
                return GozargahSiteWalletEligibility.Disabled();

            var botUser = await _credentialsDbContext.GetUserStatusWithId(telegramUserId);
            if (botUser?.IsBlocked == true)
                return GozargahSiteWalletEligibility.Blocked("کاربر در ربات مسدود است.");

            GozargahSiteApiResponse<GozargahSiteUserData> siteUser;
            try
            {
                using var lookupTimeout = CreateOptionalWebsiteLookupCancellation(cancellationToken);
                siteUser = await _apiClient.GetUserAsync(telegramUserId, lookupTimeout.Token);
            }
            catch (Exception ex) when (IsTransientWebsiteLookupFailure(ex, cancellationToken))
            {
                _logger.LogWarning(
                    "Gozargah site wallet eligibility lookup failed transiently. telegramUserId={TelegramUserId}, amountToman={AmountToman}, error={ErrorMessage}",
                    telegramUserId,
                    amountToman,
                    ex.Message);
                return GozargahSiteWalletEligibility.Unavailable("در حال حاضر اتصال به کیف پول سایت گذرگاه برقرار نشد.");
            }

            if (!siteUser.Success || siteUser.Data == null)
                return GozargahSiteWalletEligibility.Unavailable(siteUser.Message ?? "کاربر در سایت گذرگاه پیدا نشد.");
            if (siteUser.Data.IsBanned)
                return GozargahSiteWalletEligibility.Blocked("کاربر در سایت گذرگاه مسدود است.");
            if (siteUser.Data.Wallet < amountToman)
                return GozargahSiteWalletEligibility.Insufficient(siteUser.Data.Wallet);

            return GozargahSiteWalletEligibility.Available(siteUser.Data);
        }

        /// <summary>
        /// Promotes a bot user to colleague pricing when the same Telegram id exists on the Gozargah website.
        /// </summary>
        /// <param name="credUser">
        /// Shared credentials profile for the Telegram user currently using an owned bot. The instance is updated in
        /// memory when the database role changes so later price calculations in the same update use colleague prices.
        /// </param>
        /// <param name="cancellationToken">Cancellation token for the website lookup and credentials database update.</param>
        /// <returns>
        /// <c>true</c> when the website user exists, is not banned, and the local credentials profile is now marked as
        /// a colleague; otherwise <c>false</c>. A missing website user is a normal result and is not logged as a warning.
        /// </returns>
        /// <remarks>
        /// This method is used only by owned-bot customer flows before tariff, purchase, or renewal pricing is
        /// calculated. Tenant storefront customers must not call it because tenant sales use the owner storefront
        /// pricing model rather than direct colleague pricing for the buyer.
        /// </remarks>
        public async Task<bool> PromoteToColleagueIfConnectedSiteUserAsync(
            CredUser credUser,
            CancellationToken cancellationToken = default)
        {
            if (credUser == null || credUser.TelegramUserId <= 0)
                return false;
            if (!_appConfig.GozargahSiteWalletPaymentsEnabled || !_apiClient.IsConfigured())
                return credUser.IsColleague;

            GozargahSiteApiResponse<GozargahSiteUserData> siteUser;
            try
            {
                using var lookupTimeout = CreateOptionalWebsiteLookupCancellation(cancellationToken);
                siteUser = await _apiClient.GetUserAsync(credUser.TelegramUserId, lookupTimeout.Token);
            }
            catch (Exception ex) when (IsTransientWebsiteLookupFailure(ex, cancellationToken))
            {
                _logger.LogWarning(
                    "Gozargah colleague role lookup failed transiently; keeping current bot role. telegramUserId={TelegramUserId}, isColleague={IsColleague}, error={ErrorMessage}",
                    credUser.TelegramUserId,
                    credUser.IsColleague,
                    ex.Message);
                return credUser.IsColleague;
            }

            if (!siteUser.Success || siteUser.Data == null || siteUser.Data.IsBanned)
                return false;

            if (!credUser.IsColleague)
            {
                var changed = await _credentialsDbContext.PromotOrDemote(credUser.TelegramUserId, true);
                if (changed)
                    credUser.IsColleague = true;
            }

            return credUser.IsColleague;
        }

        /// <summary>
        /// Detects temporary website lookup failures that must not block owned-bot purchase, tariff, or renewal flows.
        /// </summary>
        /// <param name="exception">Exception thrown while checking the Gozargah website user or wallet state.</param>
        /// <param name="cancellationToken">
        /// Cancellation token for the active Telegram update. A cancelled shutdown token is not treated as a recoverable
        /// website outage.
        /// </param>
        /// <returns>
        /// <c>true</c> for timeout, HTTP transport, DNS/socket, and temporary cancellation failures; otherwise
        /// <c>false</c>.
        /// </returns>
        /// <remarks>
        /// The website lookup is an optional pricing/wallet enrichment step for owned bots. If the website is slow, the
        /// bot must keep serving the user with the locally known role instead of showing the generic panel timeout
        /// message before the user can even pick a plan.
        /// </remarks>
        private static bool IsTransientWebsiteLookupFailure(Exception exception, CancellationToken cancellationToken)
        {
            if (exception == null || cancellationToken.IsCancellationRequested)
                return false;

            return exception is TimeoutException or TaskCanceledException or HttpRequestException;
        }

        /// <summary>
        /// Creates a short-lived cancellation scope for optional Gozargah website user lookups.
        /// </summary>
        /// <param name="outerCancellationToken">
        /// Cancellation token from the Telegram update or background operation. If it is cancelled, the linked lookup is
        /// cancelled immediately as part of normal shutdown or request cancellation.
        /// </param>
        /// <returns>
        /// A linked cancellation token source that cancels after a short timeout suitable for optional pricing and
        /// wallet-button enrichment calls.
        /// </returns>
        /// <remarks>
        /// Website user lookup is not the source of truth for XUI account creation. Keeping this timeout short prevents
        /// a slow website API from delaying owned-bot tariff and purchase menus for every Telegram user.
        /// </remarks>
        private static CancellationTokenSource CreateOptionalWebsiteLookupCancellation(CancellationToken outerCancellationToken)
        {
            // Delegates to the shared helper so the foreground site-lookup budget has exactly one definition and cannot
            // drift past the documented hard maximum.
            return GozargahSiteApiClient.CreateOptionalLookupCancellation(outerCancellationToken);
        }

        /// <summary>
        /// Deducts the website wallet after XUI v3 account creation or renewal has already succeeded.
        /// </summary>
        /// <param name="telegramUserId">Telegram id of the website wallet owner.</param>
        /// <param name="amountToman">Debit amount in Iranian toman.</param>
        /// <param name="referenceType">Audit reference type, such as <c>xui-v3-bulk</c> or <c>xui-v3-client</c>.</param>
        /// <param name="referenceId">Audit reference id, such as bulk order id or account email.</param>
        /// <param name="description">Human-readable audit description used only for diagnostics.</param>
        /// <param name="cancellationToken">Cancellation token for API and database precheck operations.</param>
        /// <returns>Debit result including website before/after balances.</returns>
        /// <remarks>
        /// This method intentionally validates the wallet again before calling <c>deduct_wallet</c> because the
        /// website endpoint can make balances negative. A successful debit mutates only the Gozargah website wallet;
        /// this method never changes <c>credentials.db</c>. Debt repayment callers separately credit the bot wallet
        /// only after the persisted website receipt proves this transfer, using an idempotent linked credit key.
        /// Admission is keyed by owner across every bot. A users.db receipt pins the business event before POST;
        /// ambiguous results throw and must never trigger another debit or bot-wallet compensation.
        /// </remarks>
        /// <exception cref="SiteWalletDebitUncertainException">The persisted debit requires operator reconciliation.</exception>
        /// <param name="authorizeDebit">Optional fresh business authorization inside website owner admission, before the sending marker. False makes no remote attempt.</param>
        public async Task<GozargahSiteWalletDebitResult> DeductSiteWalletAfterPanelSuccessAsync(
            long telegramUserId,
            long amountToman,
            string referenceType,
            string referenceId,
            string description,
            CancellationToken cancellationToken = default,
            Func<CancellationToken, Task<bool>> authorizeDebit = null)
        {
            return await new SiteWalletDebitStore(_userDbContextFactory).ExecuteAsync(
                $"site:{telegramUserId}:{referenceType}:{referenceId}", telegramUserId, amountToman,
                async ct =>
                {
                    var eligibility = await CheckSiteWalletEligibilityAsync(telegramUserId, amountToman, ct);
                    if (eligibility.CanUse && authorizeDebit != null && !await authorizeDebit(ct))
                        return GozargahSiteWalletEligibility.Unavailable("Business authorization changed before debit.");
                    return eligibility;
                }, async ct =>
            {
                var response = await _apiClient.DeductWalletAsync(telegramUserId, amountToman, ct);
                if (!response.Success || response.Data == null)
                    return GozargahSiteWalletDebitResult.Failed(response.Message ?? "کسر کیف پول سایت ناموفق بود.");

                _logger.LogInformation(
                    "Gozargah site wallet debit response received. telegramUserId={TelegramUserId}, amountToman={AmountToman}, before={BeforeWallet}, after={AfterWallet}, referenceType={ReferenceType}, referenceId={ReferenceId}, description={Description}",
                    telegramUserId,
                    amountToman,
                    response.Data.PreviousWallet,
                    response.Data.CurrentWallet,
                    referenceType,
                    referenceId,
                    description);

                return GozargahSiteWalletDebitResult.Applied(response.Data.PreviousWallet, response.Data.CurrentWallet);
            }, cancellationToken);
        }

        /// <summary>
        /// Queues and immediately attempts to send a create-order event for a newly created XUI account.
        /// </summary>
        /// <param name="siteOwnerTelegramUserId">Telegram id of the website user that should own the order.</param>
        /// <param name="buyerTelegramUserId">Actual Telegram buyer. This differs from owner for tenant sales.</param>
        /// <param name="created">XUI v3 creation result.</param>
        /// <param name="trackingCode">Local operation or order id used for audit.</param>
        /// <param name="tenantBotId">Tenant bot id when the event belongs to a tenant storefront.</param>
        /// <param name="cancellationToken">Cancellation token for database and API work.</param>
        /// <returns>The outbox event row, or null when sync is disabled or payload cannot be built.</returns>
        public async Task<GozargahSiteSyncEvent> QueueCreateAsync(
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            XuiV3AccountCreationResult created,
            string trackingCode,
            string tenantBotId = null,
            CancellationToken cancellationToken = default,
            bool deferSend = false)
        {
            if (!_appConfig.GozargahSiteRealtimeCreateSyncEnabled)
                return null;

            var payload = deferSend
                ? BuildPayloadDraft(
                    siteOwnerTelegramUserId, buyerTelegramUserId, created?.Email, null,
                    ResolveSyncUuid(created?.Uuid, created?.ConfigLink, created?.SubLink), created?.SubId, created?.SubLink,
                    created?.Comment, created?.TrafficBytes ?? 0, created?.TrafficGb ?? 0, created?.DurationDays ?? 0, trackingCode)
                : await BuildPayloadAsync(
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                created?.Email,
                null,
                ResolveSyncUuid(created?.Uuid, created?.ConfigLink, created?.SubLink),
                created?.SubId,
                created?.SubLink,
                created?.Comment,
                created?.TrafficBytes ?? 0,
                created?.TrafficGb ?? 0,
                created?.DurationDays ?? 0,
                trackingCode,
                cancellationToken);

            return await QueueAndSendAsync(
                GozargahSiteSyncOperations.Create,
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                created?.Email,
                null,
                ResolveSyncUuid(created?.Uuid, created?.ConfigLink, created?.SubLink),
                created?.SubId,
                created?.SubLink,
                payload,
                tenantBotId,
                cancellationToken,
                deferSend);
        }

        /// <summary>
        /// Queues and sends an update-order event after renewal or metadata edit succeeds on XUI.
        /// </summary>
        /// <param name="siteOwnerTelegramUserId">Telegram id of the website user that owns the order.</param>
        /// <param name="buyerTelegramUserId">Actual Telegram buyer or actor.</param>
        /// <param name="client">Updated XUI client.</param>
        /// <param name="serverInfo">Panel descriptor used to build subscription links.</param>
        /// <param name="trackingCode">Optional local operation id for audit; blank generates an id only after a real mutation is required.</param>
        /// <param name="tenantBotId">Tenant bot id when applicable.</param>
        /// <param name="cancellationToken">Cancellation token for database and API work.</param>
        /// <returns>The sent/reused row, or the previous successful row with WasUnchanged when no mutation is needed; null when disabled.</returns>
        /// <remarks>All semantic fields and ownership are compared under account admission; tracking code does not affect equality.</remarks>
        public async Task<GozargahSiteSyncEvent> QueueUpdateAsync(
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            XuiV3Client client,
            ServerInfo serverInfo,
            string trackingCode,
            string tenantBotId = null,
            CancellationToken cancellationToken = default,
            bool deferSend = false)
        {
            if (!_appConfig.GozargahSiteRealtimeUpdateSyncEnabled)
                return null;

            var subId = string.IsNullOrWhiteSpace(client?.SubId) ? client?.Email : client.SubId;
            var payload = deferSend
                ? BuildPayloadDraft(
                    siteOwnerTelegramUserId, buyerTelegramUserId, client?.Email, null, client?.Uuid, subId,
                    ApiServicev3.BuildSubscriptionLink(serverInfo, subId), client?.Comment, ReadTotalBytes(client), 0,
                    CalculateDurationDays(client), trackingCode)
                : await BuildPayloadAsync(
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                client?.Email,
                null,
                client?.Uuid,
                subId,
                ApiServicev3.BuildSubscriptionLink(serverInfo, subId),
                client?.Comment,
                ReadTotalBytes(client),
                0,
                CalculateDurationDays(client),
                trackingCode,
                cancellationToken);

            return await QueueAndSendAsync(
                GozargahSiteSyncOperations.Update,
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                client?.Email,
                null,
                client?.Uuid,
                subId,
                payload?.Sub,
                payload,
                tenantBotId,
                cancellationToken,
                deferSend);
        }

        /// <summary>
        /// Queues and sends a rename/update event after an XUI account link replacement succeeds.
        /// </summary>
        /// <param name="siteOwnerTelegramUserId">Telegram id of the website user that owns the order.</param>
        /// <param name="buyerTelegramUserId">Actual Telegram actor or tenant buyer.</param>
        /// <param name="oldEmail">Previous XUI email used as the website lookup key.</param>
        /// <param name="client">Updated XUI client with the new email, UUID, and subscription id.</param>
        /// <param name="serverInfo">Panel descriptor used to build the new subscription link.</param>
        /// <param name="trackingCode">Local operation id for audit.</param>
        /// <param name="tenantBotId">Tenant bot id when applicable.</param>
        /// <param name="cancellationToken">Cancellation token for database and API work.</param>
        /// <returns>The outbox event row, or null when update sync is disabled.</returns>
        public async Task<GozargahSiteSyncEvent> QueueRenameAsync(
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            string oldEmail,
            XuiV3Client client,
            ServerInfo serverInfo,
            string trackingCode,
            string tenantBotId = null,
            CancellationToken cancellationToken = default)
        {
            if (!_appConfig.GozargahSiteRealtimeUpdateSyncEnabled)
                return null;

            var subId = string.IsNullOrWhiteSpace(client?.SubId) ? client?.Email : client.SubId;
            var payload = await BuildPayloadAsync(
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                oldEmail,
                client?.Email,
                client?.Uuid,
                subId,
                ApiServicev3.BuildSubscriptionLink(serverInfo, subId),
                client?.Comment,
                ReadTotalBytes(client),
                0,
                CalculateDurationDays(client),
                trackingCode,
                cancellationToken);

            return await QueueAndSendAsync(
                GozargahSiteSyncOperations.Rename,
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                client?.Email,
                oldEmail,
                client?.Uuid,
                subId,
                payload?.Sub,
                payload,
                tenantBotId,
                cancellationToken);
        }

        /// <summary>
        /// Queues and sends a delete-order event after XUI deletion succeeds.
        /// </summary>
        /// <param name="siteOwnerTelegramUserId">Telegram id of the website user that owns the order.</param>
        /// <param name="buyerTelegramUserId">Actual buyer or actor Telegram id.</param>
        /// <param name="client">Deleted XUI client as it existed before deletion.</param>
        /// <param name="trackingCode">Local operation id for audit.</param>
        /// <param name="tenantBotId">Tenant bot id when applicable.</param>
        /// <param name="cancellationToken">Cancellation token for database and API work.</param>
        /// <returns>The outbox event row, or null when delete sync is disabled.</returns>
        public async Task<GozargahSiteSyncEvent> QueueDeleteAsync(
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            XuiV3Client client,
            string trackingCode,
            string tenantBotId = null,
            CancellationToken cancellationToken = default)
        {
            if (!_appConfig.GozargahSiteRealtimeDeleteSyncEnabled || siteOwnerTelegramUserId <= 0)
                return null;

            var payload = new GozargahSiteOrderPayload
            {
                Name = client?.Email,
                TrackingCode = trackingCode
            };

            return await QueueAndSendAsync(
                GozargahSiteSyncOperations.Delete,
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                client?.Email,
                null,
                client?.Uuid,
                client?.SubId,
                null,
                payload,
                tenantBotId,
                cancellationToken);
        }

        /// <summary>
        /// Sends one pending outbox row to the website API.
        /// </summary>
        /// <param name="syncEvent">Detached persisted outbox row; its internal id is reloaded under the per-event gate before sending.</param>
        /// <param name="cancellationToken">Cancellation token for API and database work.</param>
        /// <returns><c>true</c> when the event reached a terminal succeeded or skipped state.</returns>
        /// <remarks>Remote send serialization is acquired inside <see cref="SendEventCoreAsync"/> so queue admission never
        /// waits behind website I/O. Equivalent queued updates are marked skipped before HTTP; website I/O holds no
        /// write transaction and terminal rows return without another send.</remarks>
        public async Task<bool> TrySendEventAsync(GozargahSiteSyncEvent syncEvent, CancellationToken cancellationToken = default)
        {
            if (syncEvent == null) return false;
            return await SendEventCoreAsync(syncEvent, cancellationToken);
        }

        /// <summary>Sends or retries one event while serializing remote website I/O per account.</summary>
        /// <param name="syncEvent">Detached persisted event; reloaded under its event gate.</param>
        /// <param name="cancellationToken">Cancellation for storage and website I/O.</param>
        /// <returns>Whether the event reached a terminal state.</returns>
        /// <remarks>Account gate precedes event gate. No write transaction spans HTTP. The account gate is never held
        /// by queue admission, so deferred enqueues for the same account complete without waiting for this send.</remarks>
        private async Task<bool> SendEventCoreAsync(GozargahSiteSyncEvent syncEvent, CancellationToken cancellationToken)
        {
            var _workflow = new UserWorkflowStore(_userDbContextFactory);
            if (syncEvent == null)
                return false;

            using var accountLease = await AccountGate.EnterAsync(AccountKey(syncEvent.Uuid, syncEvent.Email), cancellationToken);
            using var eventLease = await EventGate.EnterAsync(syncEvent.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
            syncEvent = await _workflow.ReadAsync(async db => await db.GozargahSiteSyncEvents.SingleOrDefaultAsync(x => x.Id == syncEvent.Id, cancellationToken));
            if (syncEvent == null) return true; // A retained terminal event may have been compacted after the caller loaded it.
            if (syncEvent.Status is GozargahSiteSyncStatuses.Succeeded or GozargahSiteSyncStatuses.Skipped) return true;

            if (syncEvent.Operation == GozargahSiteSyncOperations.Update)
            {
                await using var db = _userDbContextFactory.CreateDbContext();
                var previous = await db.GozargahSiteSyncEvents.AsNoTracking().Where(x => (x.Status == GozargahSiteSyncStatuses.Succeeded
                    || (x.Status == GozargahSiteSyncStatuses.Skipped && x.Operation == GozargahSiteSyncOperations.Delete))
                    && (!string.IsNullOrEmpty(syncEvent.Uuid) ? x.Uuid == syncEvent.Uuid
                        : (x.Uuid == null || x.Uuid == "") && x.Email == syncEvent.Email))
                    .OrderByDescending(x => x.SucceededAtUtc ?? x.UpdatedAtUtc ?? x.CreatedAtUtc).ThenByDescending(x => x.Id).FirstOrDefaultAsync(cancellationToken);
                if (previous != null && GozargahSyncSemantics.Equivalent(previous, syncEvent))
                {
                    MarkSkipped(syncEvent, "Unchanged semantic account state.");
                    await _workflow.SaveAsync(cancellationToken);
                    return true;
                }
            }

            if (!_apiClient.IsConfigured())
            {
                MarkSkipped(syncEvent, "Gozargah site sync is disabled or not configured.");
                await _workflow.SaveAsync(cancellationToken);
                return true;
            }

            try
            {
                if (syncEvent.TelegramUserId <= 0)
                {
                    MarkSkipped(syncEvent, "Telegram user id is missing.");
                    await _workflow.SaveAsync(cancellationToken);
                    return true;
                }

                var siteUser = await _apiClient.GetUserAsync(syncEvent.TelegramUserId, cancellationToken);
                switch (ClassifyGetUserResponse(siteUser))
                {
                    case GetUserLookupOutcome.Found:
                        break;
                    case GetUserLookupOutcome.MissingUser:
                        MarkSkipped(syncEvent, "Gozargah site user was not found.");
                        await _workflow.SaveAsync(cancellationToken);
                        return true;
                    case GetUserLookupOutcome.Banned:
                        MarkSkipped(syncEvent, "Gozargah site user is banned.");
                        await _workflow.SaveAsync(cancellationToken);
                        return true;
                    default:
                        // Operational/transient failure (HTTP 5xx, timeout, invalid JSON, HTML/non-JSON body, or an
                        // undocumented 4xx): keep the durable event for the retry worker instead of terminally
                        // skipping it, because the same request may succeed once the upstream recovers.
                        syncEvent.Status = GozargahSiteSyncStatuses.Failed;
                        syncEvent.RetryCount++;
                        syncEvent.LastError = BoundSyncErrorMessage(
                            siteUser?.Message ?? "Gozargah site user lookup failed transiently.");
                        syncEvent.UpdatedAtUtc = DateTime.UtcNow;
                        await _workflow.SaveAsync(cancellationToken);
                        return false;
                }

                var payload = JsonConvert.DeserializeObject<GozargahSiteOrderPayload>(syncEvent.RequestJson ?? "{}") ??
                              new GozargahSiteOrderPayload();
                payload.Username = siteUser.Data.Username;

                if (RequiresUuid(syncEvent.Operation) && string.IsNullOrWhiteSpace(payload.Uuid))
                {
                    MarkSkipped(syncEvent, "XUI UUID is missing. Re-run the super-admin sync so the account is read fresh from the 3x-ui panel.");
                    await _workflow.SaveAsync(cancellationToken);
                    return true;
                }

                GozargahSiteApiResponse<JToken> response;
                if (syncEvent.Operation == GozargahSiteSyncOperations.Delete)
                {
                    response = await _apiClient.DeleteOrderAsync(payload.Name ?? syncEvent.Email, cancellationToken);

                    // A website order that does not exist is the desired end state for a delete: the order is already
                    // absent. Treat it as a completed (skipped) event instead of a retryable failure that would resend
                    // the same request and flood the logger channel every two minutes.
                    if (!response.Success && LooksLikeMissingOrder(response.Message))
                    {
                        MarkSkipped(syncEvent, "Gozargah site order was already absent; delete treated as completed.");
                        await _workflow.SaveAsync(cancellationToken);
                        return true;
                    }
                }
                else if (syncEvent.Operation == GozargahSiteSyncOperations.Create)
                {
                    response = await _apiClient.CreateOrderAsync(payload, cancellationToken);
                }
                else
                {
                    response = await _apiClient.UpdateOrderAsync(payload, cancellationToken);
                    if (!response.Success && LooksLikeMissingOrder(response.Message))
                        response = await _apiClient.CreateOrderAsync(payload, cancellationToken);
                }

                syncEvent.ResponseJson = JsonConvert.SerializeObject(response);
                syncEvent.RetryCount++;
                syncEvent.UpdatedAtUtc = DateTime.UtcNow;
                if (response.Success)
                {
                    syncEvent.Status = GozargahSiteSyncStatuses.Succeeded;
                    syncEvent.SiteOrderId = response.Id?.ToString(CultureInfo.InvariantCulture) ?? syncEvent.SiteOrderId;
                    syncEvent.SucceededAtUtc = DateTime.UtcNow;
                    syncEvent.LastError = null;
                    await _workflow.SaveAsync(cancellationToken);
                    return true;
                }

                if (IsPermanentValidationFailure(response.Message))
                    MarkSkipped(syncEvent, response.Message ?? "Permanent validation failure from Gozargah site API.");
                else
                {
                    syncEvent.Status = GozargahSiteSyncStatuses.Failed;
                    syncEvent.LastError = response.Message;
                }
                await _workflow.SaveAsync(cancellationToken);
                return false;
            }
            catch (Exception ex)
            {
                syncEvent.Status = GozargahSiteSyncStatuses.Failed;
                syncEvent.RetryCount++;
                syncEvent.LastError = ex.Message;
                syncEvent.UpdatedAtUtc = DateTime.UtcNow;
                await _workflow.SaveAsync(cancellationToken);
                _logger.LogWarning(ex, "Gozargah site sync event failed. eventId={EventId}", syncEvent.Id);
                return false;
            }
        }

        /// <summary>
        /// Persists one sync outbox event and immediately attempts to send it to the website API.
        /// </summary>
        /// <param name="operation">Lifecycle operation stored in the outbox row.</param>
        /// <param name="siteOwnerTelegramUserId">Telegram id of the Gozargah website user that owns the order.</param>
        /// <param name="buyerTelegramUserId">Telegram id of the actual buyer; different from owner for tenant storefronts.</param>
        /// <param name="email">Current XUI email/name for the account.</param>
        /// <param name="previousEmail">Previous XUI email when the operation is a rename/link change.</param>
        /// <param name="uuid">Current XUI UUID for idempotency and diagnostics.</param>
        /// <param name="subId">Current XUI subscription id for idempotency and diagnostics.</param>
        /// <param name="subLink">Current subscription link sent to the website when available.</param>
        /// <param name="payload">Website order payload serialized into the outbox row.</param>
        /// <param name="tenantBotId">Tenant bot id when the event belongs to a colleague storefront; otherwise null.</param>
        /// <param name="cancellationToken">Cancellation token for users.db and API work.</param>
        /// <returns>
        /// Detached reused or newly sent event, previous successful state with WasUnchanged for a no-op update, or null when disabled.
        /// </returns>
        /// <remarks>
        /// The database row is written before the first API attempt. This preserves the operation for retry if the
        /// website API is unavailable after a successful 3x-ui operation.
        /// UUID/email queue admission covers semantic comparison and dedupe only; remote sends are serialized per
        /// account by the send gate, so a deferred enqueue never waits behind website I/O of the same account.
        /// Tracking identity is excluded; successful create/rename state can suppress an unchanged update, while
        /// delete tombstones force a real subsequent update.
        /// </remarks>
        private async Task<GozargahSiteSyncEvent> QueueAndSendAsync(
            string operation,
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            string email,
            string previousEmail,
            string uuid,
            string subId,
            string subLink,
            GozargahSiteOrderPayload payload,
            string tenantBotId,
            CancellationToken cancellationToken,
            bool deferSend = false)
        {
            var _workflow = new UserWorkflowStore(_userDbContextFactory);
            if (!_appConfig.GozargahSiteSyncEnabled || payload == null)
                return null;

            var ownership = new GozargahSyncOwnership(
                siteOwnerTelegramUserId,
                buyerTelegramUserId,
                string.IsNullOrWhiteSpace(tenantBotId) ? null : tenantBotId.Trim());
            if (ownership.SiteOwnerTelegramUserId <= 0)
                return null;

            // Queue admission is a short database-only section: it inspects unresolved/latest state, performs
            // semantic dedupe, and inserts or reuses the durable row without ever waiting for website I/O. Remote
            // sends for the same account are serialized later inside SendEventCoreAsync under AccountGate.
            GozargahSiteSyncEvent queued;
            using (var queueLease = await QueueGate.EnterAsync(AccountKey(uuid, email), cancellationToken))
            {
                var syncEvent = new GozargahSiteSyncEvent
                {
                    BotId = BotContextAccessor.CurrentBotId,
                    TenantBotId = ownership.TenantBotId,
                    TelegramUserId = ownership.SiteOwnerTelegramUserId,
                    OwnerTelegramUserId = ownership.IsTenant ? ownership.SiteOwnerTelegramUserId : null,
                    BuyerTelegramUserId = ownership.BuyerTelegramUserId <= 0 || ownership.BuyerTelegramUserId == ownership.SiteOwnerTelegramUserId ? null : ownership.BuyerTelegramUserId,
                    Email = email,
                    PreviousEmail = previousEmail,
                    Uuid = uuid,
                    SubId = subId,
                    SubLink = subLink,
                    Operation = operation,
                    RequestJson = JsonConvert.SerializeObject(payload),
                    Status = GozargahSiteSyncStatuses.Pending,
                    CreatedAtUtc = DateTime.UtcNow
                };
                // Compare successful state, not operation identity: creates and renames also establish account state.
                await using (var db = _userDbContextFactory.CreateDbContext())
                {
                    var account = db.GozargahSiteSyncEvents.AsNoTracking().Where(x =>
                        !string.IsNullOrEmpty(uuid) ? x.Uuid == uuid : (x.Uuid == null || x.Uuid == "") && x.Email == email);
                    var unresolved = await account.Where(x => x.Status != GozargahSiteSyncStatuses.Succeeded
                        && x.Status != GozargahSiteSyncStatuses.Skipped).OrderByDescending(x => x.Id).FirstOrDefaultAsync(cancellationToken);
                    var previous = await account.Where(x => x.Status == GozargahSiteSyncStatuses.Succeeded
                        || (x.Status == GozargahSiteSyncStatuses.Skipped && x.Operation == GozargahSiteSyncOperations.Delete))
                        .OrderByDescending(x => x.SucceededAtUtc ?? x.UpdatedAtUtc ?? x.CreatedAtUtc).ThenByDescending(x => x.Id).FirstOrDefaultAsync(cancellationToken);
                    if (unresolved == null && previous != null
                        && (operation == GozargahSiteSyncOperations.Update || (previous.Operation == operation && previous.PreviousEmail == previousEmail))
                        && GozargahSyncSemantics.Equivalent(previous, syncEvent))
                    {
                        previous.WasUnchanged = operation == GozargahSiteSyncOperations.Update;
                        return previous;
                    }
                    if (unresolved != null && unresolved.Operation == operation && unresolved.PreviousEmail == previousEmail
                        && GozargahSyncSemantics.Equivalent(unresolved, syncEvent))
                    {
                        // Reuse the existing durable row; sending happens after the short queue gate is released.
                        queued = unresolved;
                    }
                    else
                    {
                        if (string.IsNullOrWhiteSpace(payload.TrackingCode))
                            payload.TrackingCode = $"bot-sync-{Guid.NewGuid():N}";
                        syncEvent.RequestJson = JsonConvert.SerializeObject(payload);
                        _workflow.Add(syncEvent);
                        await _workflow.SaveAsync(cancellationToken);
                        queued = syncEvent;
                    }
                }
            }

            // Queue admission released. A deferred enqueue returns immediately after waking the retry worker and
            // never waits for get_user/create_order/update_order/delete_order of the same account.
            if (deferSend)
                GozargahSiteSyncRetryService.Wake();
            else
                await SendEventCoreAsync(queued, cancellationToken);
            return await _workflow.ReadAsync(async db => await db.GozargahSiteSyncEvents.AsNoTracking()
                .SingleAsync(x => x.Id == queued.Id, cancellationToken));
        }

        /// <summary>Builds process-wide account admission identity independently from mutable ownership.</summary>
        /// <param name="uuid">Preferred stable XUI account UUID, or empty when unavailable.</param>
        /// <param name="email">Account name used only when UUID is unavailable.</param>
        /// <returns>Internal gate key; never log it because it identifies a customer account.</returns>
        private static string AccountKey(string uuid, string email) => !string.IsNullOrEmpty(uuid) ? "uuid:" + uuid : "email:" + email;

        /// <summary>Compacts one bounded batch of expired terminal outbox events, retaining each account's latest successful state.</summary>
        /// <param name="cancellationToken">Cancellation of the short SQLite cleanup statement.</param>
        /// <returns>Number removed, at most 100. Pending, failed and other unresolved states are never candidates.</returns>
        /// <remarks>UUID is preferred, email is the fallback. Successful deletes remain tombstones. No financial tables or VACUUM are touched.</remarks>
        public async Task<int> CompactTerminalEventsAsync(CancellationToken cancellationToken)
        {
            if (_appConfig.GozargahSiteSyncRetentionDays <= 0)
                throw new InvalidOperationException("GozargahSiteSyncRetentionDays must be positive.");
            var cutoff = DateTime.UtcNow.AddDays(-Math.Min(_appConfig.GozargahSiteSyncRetentionDays, 36500));
            return await SqliteOperation.RunAsync(async ct =>
            {
                await using var db = _userDbContextFactory.CreateDbContext();
                // The candidate subquery and deletion share one statement; a newly completed state cannot be
                // deleted based on an earlier read. Latest success is retained even for a deleted account.
                var candidates = db.GozargahSiteSyncEvents.Where(x =>
                    (x.UpdatedAtUtc ?? x.CreatedAtUtc) < cutoff &&
                    ((x.Status == GozargahSiteSyncStatuses.Skipped && x.Operation != GozargahSiteSyncOperations.Delete) ||
                     ((x.Status == GozargahSiteSyncStatuses.Succeeded || (x.Status == GozargahSiteSyncStatuses.Skipped && x.Operation == GozargahSiteSyncOperations.Delete))
                      && db.GozargahSiteSyncEvents.Any(y =>
                         (y.Status == GozargahSiteSyncStatuses.Succeeded || (x.Status == GozargahSiteSyncStatuses.Skipped && y.Status == GozargahSiteSyncStatuses.Skipped && y.Operation == GozargahSiteSyncOperations.Delete)) &&
                         ((x.Uuid != null && x.Uuid != "") ? y.Uuid == x.Uuid : (y.Uuid == null || y.Uuid == "") && y.Email == x.Email) &&
                         ((y.SucceededAtUtc ?? y.UpdatedAtUtc ?? y.CreatedAtUtc) > (x.SucceededAtUtc ?? x.UpdatedAtUtc ?? x.CreatedAtUtc) ||
                          ((y.SucceededAtUtc ?? y.UpdatedAtUtc ?? y.CreatedAtUtc) == (x.SucceededAtUtc ?? x.UpdatedAtUtc ?? x.CreatedAtUtc) && y.Id > x.Id))))))
                    .OrderBy(x => x.Id).Select(x => x.Id).Take(100);
                return await db.GozargahSiteSyncEvents.Where(x => candidates.Contains(x.Id)).ExecuteDeleteAsync(ct);
            }, cancellationToken);
        }

        /// <summary>
        /// Resolves the XUI UUID that should be sent to the Gozargah website sync API.
        /// </summary>
        /// <param name="uuid">
        /// UUID already known from the 3x-ui client payload or panel client row. This value is preferred when present.
        /// </param>
        /// <param name="configLink">
        /// Optional direct VLESS or VMess configuration link sent to the Telegram user. It is used as a fallback when
        /// older creation results did not persist the UUID separately.
        /// </param>
        /// <param name="subLink">
        /// Optional subscription link. It is not treated as a UUID because its final path segment is normally the
        /// subscription id, not the VLESS or VMess UUID.
        /// </param>
        /// <returns>
        /// UUID string safe to send in the website payload, or <c>null</c> when no UUID can be resolved.
        /// </returns>
        /// <remarks>
        /// New v3 account creation now assigns a UUID before sending the payload to 3x-ui. This fallback protects
        /// existing code paths and older results where the panel accepted a client but the local result had a blank
        /// <c>Uuid</c> field.
        /// </remarks>
        private static string ResolveSyncUuid(string uuid, string configLink, string subLink)
        {
            if (Guid.TryParse(uuid, out var parsed))
                return parsed.ToString();

            if (TryExtractUuidFromConfigLink(configLink, out var linkUuid))
                return linkUuid;

            return null;
        }

        /// <summary>
        /// Extracts a UUID from a direct VLESS or VMess configuration link.
        /// </summary>
        /// <param name="configLink">
        /// Direct configuration link. VLESS links contain the UUID before <c>@</c>; VMess links contain a base64 JSON
        /// document whose <c>id</c> field is the UUID.
        /// </param>
        /// <param name="uuid">Resolved UUID when the method returns <c>true</c>; otherwise <c>null</c>.</param>
        /// <returns><c>true</c> when a valid UUID was found; otherwise <c>false</c>.</returns>
        private static bool TryExtractUuidFromConfigLink(string configLink, out string uuid)
        {
            uuid = null;
            if (string.IsNullOrWhiteSpace(configLink))
                return false;

            var value = configLink.Trim();
            if (value.StartsWith("vless://", StringComparison.OrdinalIgnoreCase))
            {
                var rest = value["vless://".Length..];
                var atIndex = rest.IndexOf('@');
                if (atIndex > 0 && Guid.TryParse(rest[..atIndex], out var parsed))
                {
                    uuid = parsed.ToString();
                    return true;
                }
            }

            if (value.StartsWith("vmess://", StringComparison.OrdinalIgnoreCase))
            {
                var encoded = value["vmess://".Length..].Trim();
                try
                {
                    encoded = encoded.PadRight(encoded.Length + ((4 - encoded.Length % 4) % 4), '=');
                    var json = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
                    var token = JObject.Parse(json);
                    var candidate = token["id"]?.ToString();
                    if (Guid.TryParse(candidate, out var parsed))
                    {
                        uuid = parsed.ToString();
                        return true;
                    }
                }
                catch
                {
                    return false;
                }
            }

            return false;
        }

        /// <summary>
        /// Determines whether a website sync operation must include an XUI UUID.
        /// </summary>
        /// <param name="operation">Outbox operation key stored on <see cref="GozargahSiteSyncEvent.Operation"/>.</param>
        /// <returns>
        /// <c>true</c> for create, update, and rename events that write account details to the website; otherwise
        /// <c>false</c> for delete events that can be matched by account name.
        /// </returns>
        /// <remarks>
        /// Missing UUID is a permanent payload problem, not a transient network failure. Such rows are skipped so the
        /// retry worker does not keep sending the same invalid event. Super-admin historical sync can recreate a fresh
        /// event after reading the account from 3x-ui again.
        /// </remarks>
        private static bool RequiresUuid(string operation)
        {
            return string.Equals(operation, GozargahSiteSyncOperations.Create, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(operation, GozargahSiteSyncOperations.Update, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(operation, GozargahSiteSyncOperations.Rename, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>Classifies a website get_user response into terminal business outcomes versus retryable operational failures.</summary>
        private enum GetUserLookupOutcome { Found, MissingUser, Banned, TransientFailure }

        /// <summary>
        /// Classifies a website get_user response so transient upstream failures are retried instead of terminally skipped.
        /// </summary>
        /// <param name="siteUser">Raw API response returned by <see cref="GozargahSiteApiClient.GetUserAsync"/>.</param>
        /// <returns>
        /// <see cref="GetUserLookupOutcome.Found"/> when the user exists and is not banned; MissingUser or Banned for
        /// the documented permanent results; TransientFailure for HTTP 5xx, timeouts, invalid JSON, HTML/non-JSON
        /// bodies, and undocumented 4xx responses that may succeed on a later retry.
        /// </returns>
        /// <remarks>
        /// A <c>success=false</c> flag alone is not a terminal condition: the site API reports reverse-proxy pages,
        /// invalid JSON, and 5xx errors through the same unsuccessful response shape, and skipping those would
        /// silently lose the durable website mirror event.
        /// </remarks>
        private static GetUserLookupOutcome ClassifyGetUserResponse(GozargahSiteApiResponse<GozargahSiteUserData> siteUser)
        {
            if (siteUser == null)
                return GetUserLookupOutcome.TransientFailure;
            if (siteUser.Success && siteUser.Data != null)
                return siteUser.Data.IsBanned ? GetUserLookupOutcome.Banned : GetUserLookupOutcome.Found;
            if (siteUser.Success)
                return GetUserLookupOutcome.TransientFailure;

            var message = siteUser.Message ?? string.Empty;
            if (LooksLikeMissingUser(message))
                return GetUserLookupOutcome.MissingUser;
            if (LooksLikeBannedUser(message))
                return GetUserLookupOutcome.Banned;
            return GetUserLookupOutcome.TransientFailure;
        }

        /// <summary>
        /// Detects the documented permanent "site user does not exist" result of get_user.
        /// </summary>
        /// <param name="message">Sanitized failure message produced by the website API client.</param>
        /// <returns>
        /// <c>true</c> only for the documented HTTP 404 missing-user result or a plain business not-found message;
        /// other HTTP failures such as 5xx are never classified as a missing user.
        /// </returns>
        /// <remarks>
        /// The client composes the documented missing-user result as <c>HTTP 404: &lt;body&gt;</c>; any other HTTP
        /// prefix (for example a 500 error page whose preview happens to contain "not found") stays retryable.
        /// </remarks>
        private static bool LooksLikeMissingUser(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return false;
            if (message.StartsWith("HTTP ", StringComparison.OrdinalIgnoreCase))
            {
                return message.Contains("HTTP 404", StringComparison.OrdinalIgnoreCase) &&
                       message.Contains("not found", StringComparison.OrdinalIgnoreCase);
            }

            return message.Contains("not found", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("پیدا نشد", StringComparison.Ordinal) ||
                   message.Contains("یافت نشد", StringComparison.Ordinal) ||
                   message.Contains("وجود ندارد", StringComparison.Ordinal);
        }

        /// <summary>
        /// Detects an explicit banned-user failure returned by the website API.
        /// </summary>
        /// <param name="message">Sanitized failure message produced by the website API client.</param>
        /// <returns><c>true</c> when the message clearly states the user is banned or blocked.</returns>
        private static bool LooksLikeBannedUser(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return false;
            return message.Contains("banned", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("مسدود", StringComparison.Ordinal);
        }

        /// <summary>
        /// Bounds a sanitized API failure message for the durable LastError column.
        /// </summary>
        /// <param name="message">Failure message produced by the website API client, already preview-bounded.</param>
        /// <returns>A trimmed message of at most 512 characters, or a fixed safe fallback when blank.</returns>
        private static string BoundSyncErrorMessage(string message)
        {
            var value = string.IsNullOrWhiteSpace(message)
                ? "Gozargah site API failure."
                : message.Trim();
            return value.Length <= 512 ? value : value[..512];
        }

        /// <summary>
        /// Detects non-retryable validation errors returned by the Gozargah website API.
        /// </summary>
        /// <param name="message">API failure message or HTTP wrapper message from <see cref="GozargahSiteApiClient"/>.</param>
        /// <returns><c>true</c> when retrying the same payload cannot succeed without rebuilding the event.</returns>
        /// <remarks>
        /// The most important case is HTTP 422 with "Field 'uuid' is required". These events were created from incomplete
        /// local data and must be recreated by a super-admin sync that reads the real account state from the panel.
        /// </remarks>
        private static bool IsPermanentValidationFailure(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return false;

            return message.Contains("HTTP 422", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("Field 'uuid' is required", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("uuid", StringComparison.OrdinalIgnoreCase) &&
                   message.Contains("required", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Builds the website order payload from XUI metadata, panel values, and the owning Gozargah user.
        /// </summary>
        /// <param name="siteOwnerTelegramUserId">Telegram id used by <c>get_user</c> to resolve the website username.</param>
        /// <param name="buyerTelegramUserId">Telegram id of the actual buyer, included in the website comment for tenant sales.</param>
        /// <param name="name">Current or lookup XUI email/name for the website order.</param>
        /// <param name="newName">Replacement XUI email/name for link-change operations; null for create/update/delete.</param>
        /// <param name="uuid">Current XUI UUID.</param>
        /// <param name="subId">Current XUI subscription id.</param>
        /// <param name="subLink">Current subscription URL.</param>
        /// <param name="comment">XUI JSON comment containing service, plan, price, and ownership metadata.</param>
        /// <param name="trafficBytes">Traffic allowance in bytes when metadata does not provide a GB value.</param>
        /// <param name="fallbackTrafficGb">Traffic allowance in GB when metadata and bytes are incomplete.</param>
        /// <param name="fallbackDurationDays">Duration in days when metadata does not provide a plan duration.</param>
        /// <param name="trackingCode">Local order id or operation id passed to the website for audit.</param>
        /// <param name="cancellationToken">Cancellation token for the website <c>get_user</c> lookup.</param>
        /// <returns>
        /// Normalized payload ready for create/update, or null when the site user does not exist, is banned, or name is empty.
        /// </returns>
        /// <remarks>
        /// Website ownership is resolved before queueing so missing or banned site users are skipped instead of being retried forever.
        /// Blank tracking codes remain blank here; queue admission generates one only after semantic comparison requires a mutation.
        /// </remarks>
        private static GozargahSiteOrderPayload BuildPayloadDraft(
            long siteOwnerTelegramUserId, long buyerTelegramUserId, string name, string newName, string uuid,
            string subId, string subLink, string comment, long trafficBytes, int fallbackTrafficGb,
            int fallbackDurationDays, string trackingCode)
        {
            if (siteOwnerTelegramUserId <= 0 || string.IsNullOrWhiteSpace(name)) return null;
            var metadata = TryReadMetadata(comment);
            var map = MapPlan(metadata, fallbackTrafficGb);
            var volumeGb = ResolveVolumeGb(metadata, trafficBytes, fallbackTrafficGb);
            var durationDays = metadata?.DurationDays ?? fallbackDurationDays;
            var priceToman = metadata?.PriceToman ?? 0;
            var buyerText = buyerTelegramUserId > 0 && buyerTelegramUserId != siteOwnerTelegramUserId
                ? $"; buyer={buyerTelegramUserId}" : string.Empty;
            return new GozargahSiteOrderPayload
            {
                PlanId = map.PlanId, Inbound = map.Inbound, ArrangedPlanId = map.ArrangedPlanId,
                Name = name, NewName = newName, Uuid = uuid,
                Comment = $"Synced from Telegram bot; owner={siteOwnerTelegramUserId}{buyerText}; {comment}",
                Price = priceToman.ToString(CultureInfo.InvariantCulture), Volume = volumeGb,
                Date = Math.Max(0, durationDays), Username = null, TrackingCode = trackingCode, Sub = subLink,
                Trial = metadata?.IsTrial == true ? 1 : 0, Bot = 1
            };
        }

        private async Task<GozargahSiteOrderPayload> BuildPayloadAsync(
            long siteOwnerTelegramUserId,
            long buyerTelegramUserId,
            string name,
            string newName,
            string uuid,
            string subId,
            string subLink,
            string comment,
            long trafficBytes,
            int fallbackTrafficGb,
            int fallbackDurationDays,
            string trackingCode,
            CancellationToken cancellationToken)
        {
            if (siteOwnerTelegramUserId <= 0 || string.IsNullOrWhiteSpace(name))
                return null;

            var siteUser = await _apiClient.GetUserAsync(siteOwnerTelegramUserId, cancellationToken);
            if (!siteUser.Success || siteUser.Data == null || siteUser.Data.IsBanned)
                return null;

            var metadata = TryReadMetadata(comment);
            var map = MapPlan(metadata, fallbackTrafficGb);
            var volumeGb = ResolveVolumeGb(metadata, trafficBytes, fallbackTrafficGb);
            var durationDays = metadata?.DurationDays ?? fallbackDurationDays;
            var priceToman = metadata?.PriceToman ?? 0;
            var buyerText = buyerTelegramUserId > 0 && buyerTelegramUserId != siteOwnerTelegramUserId
                ? $"; buyer={buyerTelegramUserId}"
                : string.Empty;

            return new GozargahSiteOrderPayload
            {
                PlanId = map.PlanId,
                Inbound = map.Inbound,
                ArrangedPlanId = map.ArrangedPlanId,
                Name = name,
                NewName = newName,
                Uuid = uuid,
                Comment = $"Synced from Telegram bot; owner={siteOwnerTelegramUserId}{buyerText}; {comment}",
                Price = priceToman.ToString(CultureInfo.InvariantCulture),
                Volume = volumeGb,
                Date = Math.Max(0, durationDays),
                Username = siteUser.Data.Username,
                TrackingCode = trackingCode,
                Sub = subLink,
                Trial = metadata?.IsTrial == true ? 1 : 0,
                Bot = 1
            };
        }

        /// <summary>
        /// Maps bot service metadata to the plan and inbound identifiers expected by the website database.
        /// </summary>
        /// <param name="metadata">Parsed XUI JSON comment metadata, or null for older accounts.</param>
        /// <param name="fallbackTrafficGb">Traffic in GB used to map older unlimited accounts without metadata.</param>
        /// <returns>Website plan id, inbound string, and arranged unlimited-plan id.</returns>
        /// <remarks>
        /// The mapping follows the site contract: national is plan 1/inbound 156, normal is plan 2/inbounds
        /// 166,188,189, and unlimited is plan 5 with arranged ids based on fair-usage GB.
        /// </remarks>
        private static GozargahPlanMap MapPlan(XuiV3ClientMetadata metadata, int fallbackTrafficGb)
        {
            if (string.Equals(metadata?.ServiceKey, "national", StringComparison.OrdinalIgnoreCase))
                return new GozargahPlanMap(NationalPlanId, "156", 0);

            if (string.Equals(metadata?.ServiceKey, "unlimited", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(metadata?.ServiceKind, XuiV3ServiceKinds.Unlimited, StringComparison.OrdinalIgnoreCase))
            {
                return new GozargahPlanMap(UnlimitedPlanId, "166, 188, 189", MapUnlimitedArrangedPlan(metadata?.TrafficGb ?? fallbackTrafficGb));
            }

            return new GozargahPlanMap(NormalPlanId, "166, 188, 189", 0);
        }

        /// <summary>
        /// Maps unlimited fair-usage volume to the website arranged plan id.
        /// </summary>
        /// <param name="fairUsageGb">Fair-usage allowance in GB from the bot plan metadata.</param>
        /// <returns>Website arranged plan id: 6 for 100GB, 7 for 170GB, 8 for 230GB, and 9 for larger plans.</returns>
        private static int MapUnlimitedArrangedPlan(int fairUsageGb)
        {
            return fairUsageGb switch
            {
                <= 100 => 6,
                <= 170 => 7,
                <= 230 => 8,
                _ => 9
            };
        }

        /// <summary>
        /// Resolves the website volume field in GB from metadata, bytes, or fallback plan data.
        /// </summary>
        /// <param name="metadata">Parsed XUI metadata, preferred when it contains <c>TrafficGb</c>.</param>
        /// <param name="trafficBytes">Traffic allowance in bytes from the panel or creation result.</param>
        /// <param name="fallbackTrafficGb">Fallback traffic in GB when metadata and bytes are missing.</param>
        /// <returns>Traffic volume in GB, rounded to two decimals when calculated from bytes.</returns>
        private static decimal ResolveVolumeGb(XuiV3ClientMetadata metadata, long trafficBytes, int fallbackTrafficGb)
        {
            if (metadata?.TrafficGb > 0)
                return metadata.TrafficGb;
            if (trafficBytes > 0)
                return Math.Round(trafficBytes / 1024m / 1024m / 1024m, 2);
            return Math.Max(0, fallbackTrafficGb);
        }

        /// <summary>
        /// Reads total traffic bytes from a potentially sparse XUI v3 client object.
        /// </summary>
        /// <param name="client">XUI client returned by the panel; <c>Traffic</c> may be null.</param>
        /// <returns>Total bytes from top-level fields, nested traffic, or raw <c>Extra</c>; otherwise zero.</returns>
        private static long ReadTotalBytes(XuiV3Client client)
        {
            if (client == null)
                return 0;
            if (client.TotalGB > 0)
                return client.TotalGB;
            if (client.Traffic?.TotalGB > 0)
                return client.Traffic.TotalGB;
            if (client.Traffic?.Total > 0)
                return client.Traffic.Total;
            return ReadLongExtra(client, "totalGB");
        }

        /// <summary>
        /// Calculates the remaining or first-use duration in days for website sync.
        /// </summary>
        /// <param name="client">XUI client whose expiry can be positive, zero, or negative first-use milliseconds.</param>
        /// <returns>Duration in whole days rounded up, or zero for expired/unlimited/unknown values.</returns>
        private static int CalculateDurationDays(XuiV3Client client)
        {
            var expiryTime = client?.ExpiryTime ?? client?.Traffic?.ExpiryTime ?? ReadLongExtra(client, "expiryTime");
            if (expiryTime < 0)
                return (int)Math.Ceiling(Math.Abs(expiryTime) / (double)TimeSpan.FromDays(1).TotalMilliseconds);
            if (expiryTime <= 0)
                return 0;
            var remaining = expiryTime - DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            return remaining <= 0 ? 0 : (int)Math.Ceiling(remaining / (double)TimeSpan.FromDays(1).TotalMilliseconds);
        }

        /// <summary>
        /// Reads a numeric value from the raw XUI <c>Extra</c> bag.
        /// </summary>
        /// <param name="client">XUI client that may contain raw JSON properties in <c>Extra</c>.</param>
        /// <param name="key">Case-sensitive JSON key to read.</param>
        /// <returns>Parsed long value, or zero when the key is missing or not numeric.</returns>
        private static long ReadLongExtra(XuiV3Client client, string key)
        {
            if (client?.Extra == null || !client.Extra.TryGetValue(key, out var token) || token == null)
                return 0;
            if (token.Type == JTokenType.Integer)
                return token.Value<long>();
            return long.TryParse(token.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var value) ? value : 0;
        }

        /// <summary>
        /// Parses the bot JSON metadata stored in the XUI comment field.
        /// </summary>
        /// <param name="comment">Raw XUI comment text.</param>
        /// <returns>Parsed metadata, or null when the comment is empty or not valid bot JSON.</returns>
        private static XuiV3ClientMetadata TryReadMetadata(string comment)
        {
            if (string.IsNullOrWhiteSpace(comment))
                return null;
            try
            {
                return JsonConvert.DeserializeObject<XuiV3ClientMetadata>(comment);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Determines whether a failed website update likely means the order does not exist yet.
        /// </summary>
        /// <param name="message">Website API message returned from <c>update_order</c>.</param>
        /// <returns><c>true</c> when create-order fallback should be attempted.</returns>
        /// <remarks>
        /// The site API currently has no separate get-order endpoint, so historical sync relies on this check to
        /// upsert old records by trying update first and create second.
        /// </remarks>
        private static bool LooksLikeMissingOrder(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
                return false;
            return message.Contains("not found", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("no order", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("پیدا", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("وجود", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Marks a sync event as skipped with a durable reason.
        /// </summary>
        /// <param name="syncEvent">Tracked outbox event to update.</param>
        /// <param name="reason">Reason the event should no longer be retried.</param>
        private static void MarkSkipped(GozargahSiteSyncEvent syncEvent, string reason)
        {
            syncEvent.Status = GozargahSiteSyncStatuses.Skipped;
            syncEvent.LastError = reason;
            syncEvent.UpdatedAtUtc = DateTime.UtcNow;
        }

        /// <summary>
        /// Internal value object containing website plan mapping fields for one bot service.
        /// </summary>
        /// <param name="PlanId">Website plan id.</param>
        /// <param name="Inbound">Comma-separated inbound ids expected by the website API.</param>
        /// <param name="ArrangedPlanId">Website arranged plan id for unlimited plans; zero for regular plans.</param>
        private readonly record struct GozargahPlanMap(int PlanId, string Inbound, int ArrangedPlanId);
    }

    /// <summary>
    /// Eligibility result for showing and using the Gozargah website wallet payment method.
    /// </summary>
    public class GozargahSiteWalletEligibility
    {
        /// <summary>
        /// Whether the wallet can be used for the requested amount.
        /// </summary>
        public bool CanUse { get; set; }

        /// <summary>
        /// User-facing reason when <see cref="CanUse"/> is false.
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Indicates that eligibility failed because the user is blocked in the bot or banned on the website.
        /// </summary>
        /// <remarks>
        /// Callers may fall back to another wallet for unavailable or insufficient website wallets, but must not use
        /// that fallback to bypass an explicit bot-side block or website ban.
        /// </remarks>
        public bool IsBlocked { get; set; }

        /// <summary>
        /// Current website wallet balance in toman when available.
        /// </summary>
        public long WalletToman { get; set; }

        /// <summary>
        /// Website user data returned by <c>get_user</c>.
        /// </summary>
        public GozargahSiteUserData User { get; set; }

        /// <summary>
        /// Creates an available eligibility result.
        /// </summary>
        /// <param name="user">Website user data with enough wallet balance.</param>
        /// <returns>Eligibility result that allows site-wallet payment.</returns>
        public static GozargahSiteWalletEligibility Available(GozargahSiteUserData user)
            => new() { CanUse = true, User = user, WalletToman = user?.Wallet ?? 0 };

        /// <summary>
        /// Creates a disabled eligibility result.
        /// </summary>
        /// <returns>Eligibility result for disabled config or missing API setup.</returns>
        public static GozargahSiteWalletEligibility Disabled()
            => new() { Message = "پرداخت با کیف پول سایت فعال نیست." };

        /// <summary>
        /// Creates a blocked eligibility result.
        /// </summary>
        /// <param name="message">Reason returned to the caller.</param>
        /// <returns>Eligibility result for bot-side or site-side ban.</returns>
        public static GozargahSiteWalletEligibility Blocked(string message)
            => new() { Message = message, IsBlocked = true };

        /// <summary>
        /// Creates an unavailable eligibility result.
        /// </summary>
        /// <param name="message">Reason returned to the caller.</param>
        /// <returns>Eligibility result for missing site user or API failure.</returns>
        public static GozargahSiteWalletEligibility Unavailable(string message)
            => new() { Message = message };

        /// <summary>
        /// Creates an insufficient-balance eligibility result.
        /// </summary>
        /// <param name="walletToman">Current site wallet balance in toman.</param>
        /// <returns>Eligibility result containing the current wallet balance.</returns>
        public static GozargahSiteWalletEligibility Insufficient(long walletToman)
            => new() { WalletToman = walletToman, Message = "موجودی کیف پول سایت کافی نیست." };
    }

    /// <summary>
    /// Result of a Gozargah website wallet debit.
    /// </summary>
    public class GozargahSiteWalletDebitResult
    {
        /// <summary>
        /// Whether the website wallet was debited successfully.
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Website wallet balance before debit.
        /// </summary>
        public long BeforeWallet { get; set; }

        /// <summary>
        /// Website wallet balance after debit.
        /// </summary>
        public long AfterWallet { get; set; }

        /// <summary>
        /// Error message when <see cref="Success"/> is false.
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Creates a successful debit result.
        /// </summary>
        /// <param name="beforeWallet">Website wallet before debit.</param>
        /// <param name="afterWallet">Website wallet after debit.</param>
        /// <returns>Successful debit result.</returns>
        public static GozargahSiteWalletDebitResult Applied(long beforeWallet, long afterWallet)
            => new() { Success = true, BeforeWallet = beforeWallet, AfterWallet = afterWallet };

        /// <summary>
        /// Creates a failed debit result.
        /// </summary>
        /// <param name="errorMessage">Reason the debit was not applied.</param>
        /// <returns>Failed debit result.</returns>
        public static GozargahSiteWalletDebitResult Failed(string errorMessage)
            => new() { ErrorMessage = errorMessage };
    }

    /// <summary>
    /// Background worker that retries failed or pending Gozargah site sync events.
    /// </summary>
    public class GozargahSiteSyncRetryService : BackgroundService
    {
        private static readonly SemaphoreSlim WakeSignal = new(0, 1);
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<GozargahSiteSyncRetryService> _logger;

        internal static void Wake()
        {
            try { WakeSignal.Release(); }
            catch (SemaphoreFullException) { }
        }

        /// <summary>
        /// Creates the retry worker.
        /// </summary>
        /// <param name="serviceProvider">Root service provider used to resolve the singleton sync service.</param>
        /// <param name="logger">Logger for retry diagnostics.</param>
        public GozargahSiteSyncRetryService(IServiceProvider serviceProvider, ILogger<GozargahSiteSyncRetryService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        /// <summary>
        /// Periodically retries pending and failed Gozargah sync events.
        /// </summary>
        /// <param name="stoppingToken">Cancellation token triggered when the host is shutting down.</param>
        /// <returns>A task that completes when the background worker stops.</returns>
        /// <remarks>Each retry execution resolves its own scope. Website requests occur outside local write transactions and retain their existing operation keys.
        /// Each cycle also compacts at most 100 expired terminal events, keeping latest successful state and deletion tombstones.</remarks>
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await using var scope = _serviceProvider.CreateAsyncScope();
                    var db = scope.ServiceProvider.GetRequiredService<UserDbContext>();
                    var syncService = scope.ServiceProvider.GetRequiredService<GozargahSiteSyncService>();
                    var events = await db.GozargahSiteSyncEvents
                        .Where(x => x.Status == GozargahSiteSyncStatuses.Pending || x.Status == GozargahSiteSyncStatuses.Failed)
                        .OrderBy(x => x.CreatedAtUtc).Take(25).ToListAsync(stoppingToken);
                    foreach (var syncEvent in events) await syncService.TrySendEventAsync(syncEvent, stoppingToken);
                    var compacted = await syncService.CompactTerminalEventsAsync(stoppingToken);
                    if (compacted > 0) _logger.LogInformation("Gozargah terminal outbox compacted. Deleted={Deleted}", compacted);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { return; }
                catch (Exception ex) { _logger.LogWarning(ex, "Gozargah site sync retry loop failed."); }

                try { await WakeSignal.WaitAsync(TimeSpan.FromMinutes(2), stoppingToken); }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { return; }
            }
        }
    }
}
