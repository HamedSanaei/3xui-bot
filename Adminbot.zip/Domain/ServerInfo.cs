using Adminbot.Domain;

public class ServerInfo
{
    public string ApiVersion { get; set; } = "auto";
    public int? PanelMajorVersion { get; set; }
    public string ApiToken { get; set; }
    public string Username { get; set; }
    public string Name { get; set; }
    public string Password { get; set; }
    public string SubLinkUrl { get; set; }
    public string Url { get; set; }
    public string RootPath { get; set; }
    public long Chance { get; set; }
    public VMessConfiguration VmessTemplate { get; set; }
    public Vless Vless { get; set; }
    public List<Inbound> Inbounds { get; set; }
}


