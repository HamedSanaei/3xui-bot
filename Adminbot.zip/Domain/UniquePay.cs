using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using Adminbot.Domain.Logging;
using Adminbot.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Telegram.Bot;

namespace Adminbot.Domain;

/// <summary>
/// Durable users.db record for one UniquePay owned-wallet charge or tenant storefront invoice.
/// </summary>
/// <remarks>
/// <see cref="HashId"/> is the merchant idempotency and lookup identity sent to UniquePay. The bearer token is never
/// persisted. Settlement requires a fresh authoritative inquiry whose identity, toman amount, configured fee-payer
/// contract, and paid flag pass <see cref="UniquePayPaymentVerifier"/>.
/// </remarks>
public sealed class UniquePayPaymentInfo
{
    /// <summary>Internal users.db primary key.</summary>
    [Key]
    public int Id { get; set; }

    /// <summary>Globally unique merchant hash sent to both UniquePay create and check operations.</summary>
    public string HashId { get; set; }

    /// <summary>Provider reference returned after invoice creation; stored as text because the API returns numeric and string forms.</summary>
    public string RefId { get; set; }

    /// <summary>UniquePay-hosted payment URL delivered only to the intended customer.</summary>
    public string PaymentLink { get; set; }

    /// <summary>Local source-of-truth wallet credit or tenant order amount in Iranian toman, excluding gateway fees.</summary>
    public long BaseAmountToman { get; set; }

    /// <summary>Invoice amount most recently reported by UniquePay in Iranian toman.</summary>
    public long? ProviderAmountToman { get; set; }

    /// <summary>Gateway fee in Iranian toman most recently reported by UniquePay.</summary>
    public long? ProviderFeeToman { get; set; }

    /// <summary>Fee percentage snapshotted when the invoice was created; expected to be 12 for current business rules.</summary>
    public decimal FeePercent { get; set; } = 12m;

    /// <summary>
    /// Provider fee payer; verified responses may report buyer aliases <c>user</c>/<c>buyer</c> or <c>owner</c>.
    /// </summary>
    public string FeePayer { get; set; }

    /// <summary>Provider invoice currency; verified responses may use <c>IRT</c> or <c>toman</c>.</summary>
    public string Currency { get; set; }

    /// <summary>Latest local provider payment state: pending, paid, or failed verification.</summary>
    public string PaymentStatus { get; set; } = UniquePayStatuses.Pending;

    /// <summary>
    /// Durable lifecycle state of the single allowed mutating create-invoice attempt.
    /// </summary>
    /// <remarks>
    /// This state is independent of <see cref="PaymentStatus"/>. In particular, an ambiguous HTTP 5xx or transport
    /// result remains read-only-inquiry eligible while never authorizing another create POST.
    /// </remarks>
    public string CreationState { get; set; } = UniquePayCreationStates.Ambiguous;

    /// <summary>
    /// Number of create-invoice POST attempts reserved for this merchant hash; safe rows must never exceed one.
    /// </summary>
    public int CreationAttemptCount { get; set; }

    /// <summary>UTC time persisted before the one permitted create-invoice POST can reach the provider.</summary>
    public DateTime? CreationAttemptedAtUtc { get; set; }

    /// <summary>
    /// UTC time when creation became definitively created or failed; null means the POST outcome remains ambiguous.
    /// </summary>
    public DateTime? CreationResolvedAtUtc { get; set; }

    /// <summary>
    /// Sanitized create-only result code retained even when later inquiry attempts update <see cref="ErrorCode"/>.
    /// </summary>
    public string CreationErrorCode { get; set; }

    /// <summary>Latest value of UniquePay's informational <c>isVerified</c> field.</summary>
    public bool IsProviderVerified { get; set; }

    /// <summary>Telegram user id of the owned-wallet payer or tenant customer.</summary>
    public long TelegramUserId { get; set; }

    /// <summary>Telegram chat id used for invoice and best-effort settlement notifications.</summary>
    public long ChatId { get; set; }

    /// <summary>Optional Telegram message id containing the payment buttons.</summary>
    public long? TelMsgId { get; set; }

    /// <summary>Internal owned or tenant bot id that originated the invoice.</summary>
    public string BotId { get; set; } = BotContextAccessor.DefaultBotId;

    /// <summary>Originating bot username captured for safe audit attribution.</summary>
    public string BotUsername { get; set; } = BotContextAccessor.DefaultBotId;

    /// <summary>Payment target: owned wallet charge or tenant purchase/renew order.</summary>
    public string PaymentPurpose { get; set; } = TenantBotPaymentPurposes.WalletCharge;

    /// <summary>Nullable users.db tenant order primary key used only for tenant storefront payments.</summary>
    public int? TenantBotOrderId { get; set; }

    /// <summary>Nullable Telegram id of the tenant owner whose profit is credited after fulfillment.</summary>
    public long? TenantOwnerTelegramUserId { get; set; }

    /// <summary>
    /// Sanitized bot-gateway form payload retained for audit, including merchant hash, amount, return, and callback
    /// URLs; it never contains the bearer token.
    /// </summary>
    public string RawRequestJson { get; set; }

    /// <summary>Latest provider JSON response retained for protected diagnostics.</summary>
    public string RawResponseJson { get; set; }

    /// <summary>UTC time of the latest authoritative <c>check-invoice</c> attempt.</summary>
    public DateTime? LastInquiryAtUtc { get; set; }

    /// <summary>
    /// UTC time when bounded recovery polling should next inspect this pending row; null means automatic polling has
    /// stopped while explicit callback, return, customer, and admin checks remain allowed.
    /// </summary>
    public DateTime? NextInquiryAtUtc { get; set; }

    /// <summary>
    /// Total number of read-only provider inquiries recorded for the invoice across worker and explicit triggers; the
    /// configured recovery cap uses this value only to stop future automatic scans.
    /// </summary>
    public int InquiryAttemptCount { get; set; }

    /// <summary>UTC time when the local payment row was first persisted.</summary>
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>UTC time of the latest local payment state change.</summary>
    public DateTime? UpdatedAtUtc { get; set; }

    /// <summary>UTC time when an authoritative UniquePay inquiry first passed all paid checks.</summary>
    public DateTime? PaidAtUtc { get; set; }

    /// <summary>UTC time when owned-wallet credit or tenant fulfillment completed.</summary>
    public DateTime? SettledAtUtc { get; set; }

    /// <summary>Exactly-once settlement marker; for tenant rows it represents successful shared fulfillment.</summary>
    public bool IsAddedToBalance { get; set; }

    /// <summary>
    /// Whether a configured super-admin credited this owned wallet before UniquePay officially confirmed payment.
    /// Tenant orders can never set this flag.
    /// </summary>
    public bool IsProvisionallyApproved { get; set; }

    /// <summary>UTC time when the owned-wallet provisional credit was durably recorded.</summary>
    public DateTime? ProvisionalApprovedAtUtc { get; set; }

    /// <summary>Telegram user id of the configured super-admin who approved the provisional wallet credit.</summary>
    public long? ProvisionalApprovedByTelegramUserId { get; set; }

    /// <summary>
    /// UTC time when an authoritative inquiry later confirmed a provisionally credited payment without applying a
    /// second wallet or ledger mutation.
    /// </summary>
    public DateTime? ProviderConfirmedAfterProvisionalAtUtc { get; set; }

    /// <summary>
    /// Durable settlement claim state used to prevent concurrent worker, return, and customer-check processors from
    /// repeating wallet credit or tenant fulfillment.
    /// </summary>
    public string SettlementState { get; set; } = UniquePaySettlementStates.Pending;

    /// <summary>Non-secret unique id of the current settlement attempt, retained for crash and operator diagnosis.</summary>
    public string SettlementAttemptId { get; set; }

    /// <summary>UTC time when the current durable settlement claim was acquired.</summary>
    public DateTime? SettlementStartedAtUtc { get; set; }

    /// <summary>Wallet balance in toman before owned credit or tenant-owner profit settlement.</summary>
    public long? BalanceBefore { get; set; }

    /// <summary>Wallet balance in toman after owned credit or tenant-owner profit settlement.</summary>
    public long? BalanceAfter { get; set; }

    /// <summary>Stable, non-secret provider or verification error code.</summary>
    public string ErrorCode { get; set; }

    /// <summary>Protected operational error detail that must not be copied verbatim to customer messages.</summary>
    public string ErrorMessage { get; set; }

    /// <summary>UTC time when the current repeated reconciliation error was last sent to the logger channel.</summary>
    public DateTime? LastErrorLoggedAtUtc { get; set; }

    /// <summary>UTC time when successful payment settlement was reported to the central payment logger.</summary>
    public DateTime? SuccessLoggedAtUtc { get; set; }

    /// <summary>
    /// Creates an unsaved pending UniquePay row for an owned-bot wallet charge.
    /// </summary>
    /// <param name="telegramUserId">Numeric Telegram id of the shared wallet owner.</param>
    /// <param name="chatId">Telegram chat id to receive the payment link and settlement message.</param>
    /// <param name="baseAmountToman">Wallet credit amount in Iranian toman, excluding the 12% gateway fee; must be positive.</param>
    /// <param name="feePercent">Fee percentage snapshotted from global configuration, normally 12.</param>
    /// <returns>An unsaved row with a unique merchant hash and no provider credential.</returns>
    /// <exception cref="ArgumentOutOfRangeException">Thrown when amount or fee is outside its valid financial range.</exception>
    public static UniquePayPaymentInfo CreateWalletCharge(
        long telegramUserId,
        long chatId,
        long baseAmountToman,
        decimal feePercent)
    {
        if (baseAmountToman <= 0)
            throw new ArgumentOutOfRangeException(nameof(baseAmountToman), "UniquePay wallet charge must be positive.");
        if (feePercent < 0 || feePercent > 100)
            throw new ArgumentOutOfRangeException(nameof(feePercent), "UniquePay fee percent must be between zero and 100.");

        var payment = new UniquePayPaymentInfo
        {
            HashId = CreateHashId(telegramUserId),
            TelegramUserId = telegramUserId,
            ChatId = chatId,
            BaseAmountToman = baseAmountToman,
            FeePercent = feePercent,
            PaymentPurpose = TenantBotPaymentPurposes.WalletCharge,
            BotId = BotContextAccessor.CurrentBotId,
            BotUsername = BotContextAccessor.CurrentBotUsername,
            PaymentStatus = UniquePayStatuses.Pending,
            NextInquiryAtUtc = DateTime.UtcNow,
            CreatedAtUtc = DateTime.UtcNow
        };
        payment.BeginCreationAttempt(payment.CreatedAtUtc);
        return payment;
    }

    /// <summary>
    /// Generates the merchant hash used as UniquePay's create/check identity.
    /// </summary>
    /// <param name="telegramUserId">Telegram payer id used only for operational correlation, never authentication.</param>
    /// <returns>A globally unique, non-secret ASCII hash id.</returns>
    public static string CreateHashId(long telegramUserId)
        => $"TelBotUnique-{DateTime.UtcNow:yyyyMMddHHmmss}-{telegramUserId}-{Guid.NewGuid():N}";

    /// <summary>
    /// Applies a successful create response without marking the invoice paid.
    /// </summary>
    /// <param name="response">UniquePay response containing the matching hash, reference, and hosted link.</param>
    public void Apply(UniquePayCreateInvoiceResponse response)
    {
        if (response == null)
            return;
        RefId = response.RefId ?? RefId;
        PaymentLink = response.PaymentLink ?? PaymentLink;
        RawResponseJson = response.RawResponseJson ?? RawResponseJson;
        var now = DateTime.UtcNow;
        CreationState = UniquePayCreationStates.Created;
        CreationResolvedAtUtc = now;
        CreationErrorCode = null;
        UpdatedAtUtc = now;
    }

    /// <summary>
    /// Records one authoritative inquiry observation and schedules the next pending scan.
    /// </summary>
    /// <param name="response">UniquePay check response, which may represent pending or paid state.</param>
    /// <param name="nextInquiryAtUtc">
    /// Optional UTC time for the next bounded recovery inquiry. Pass <c>null</c> after the configured automatic-attempt
    /// limit; callback, browser-return, and explicit customer/admin checks can still inspect the invoice.
    /// </param>
    /// <remarks>
    /// This method records provider observations only. It never credits a wallet or fulfills a tenant order; callers
    /// must run <see cref="UniquePayPaymentVerifier"/> and the appropriate idempotent settlement service afterward.
    /// </remarks>
    /// <example>
    /// <code>
    /// payment.Apply(checkResponse, nextInquiryAtUtc: null);
    /// </code>
    /// </example>
    public void Apply(UniquePayCheckInvoiceResponse response, DateTime? nextInquiryAtUtc)
    {
        InquiryAttemptCount++;
        LastInquiryAtUtc = DateTime.UtcNow;
        NextInquiryAtUtc = nextInquiryAtUtc;
        RawResponseJson = response?.RawResponseJson ?? RawResponseJson;
        if (response?.Invoice != null)
        {
            // A hash-addressed GET that returns a concrete invoice proves that the earlier ambiguous POST committed.
            CreationState = UniquePayCreationStates.Created;
            CreationResolvedAtUtc ??= DateTime.UtcNow;
            CreationErrorCode = null;
            // Public check-invoice responses normally identify the invoice through invoice.id, not root refId.
            RefId ??= !string.IsNullOrWhiteSpace(response.RefId)
                ? response.RefId
                : response.Invoice.InvoiceId;
            ProviderAmountToman = response.Invoice.Amount;
            ProviderFeeToman = response.Invoice.Fee;
            Currency = response.Invoice.Currency;
            FeePayer = response.Invoice.FeePayer;
            IsProviderVerified = response.Invoice.IsVerified;
            PaymentStatus = response.Invoice.IsPaid ? UniquePayStatuses.Paid : UniquePayStatuses.Pending;
        }
        UpdatedAtUtc = DateTime.UtcNow;
    }

    /// <summary>
    /// Durably reserves the one permitted create-invoice mutation before any provider network call can begin.
    /// </summary>
    /// <param name="attemptedAtUtc">
    /// UTC time recorded in users.db before the POST. The caller must save the payment row before invoking UniquePay.
    /// </param>
    /// <exception cref="InvalidOperationException">
    /// Thrown when a create attempt was already reserved for this payment, preventing accidental mutation replay.
    /// </exception>
    /// <remarks>
    /// A crash after this state is saved but before bytes reach the provider is intentionally treated as ambiguous.
    /// Recovery may use only <c>check-invoice</c>; it must never guess that the POST was not sent.
    /// </remarks>
    /// <example>
    /// <code>
    /// payment.BeginCreationAttempt(DateTime.UtcNow);
    /// context.Add(payment);
    /// await context.SaveChangesAsync(cancellationToken);
    /// // Only now may the single create-invoice POST be called.
    /// </code>
    /// </example>
    public void BeginCreationAttempt(DateTime attemptedAtUtc)
    {
        if (CreationAttemptCount != 0 || CreationAttemptedAtUtc.HasValue)
            throw new InvalidOperationException("UniquePay create-invoice mutation has already been reserved.");

        CreationState = UniquePayCreationStates.Attempting;
        CreationAttemptCount = 1;
        CreationAttemptedAtUtc = attemptedAtUtc;
        CreationResolvedAtUtc = null;
        CreationErrorCode = null;
        UpdatedAtUtc = attemptedAtUtc;
    }

    /// <summary>
    /// Records the result classification of the one create-invoice POST without ever scheduling another POST.
    /// </summary>
    /// <param name="definitiveFailure">
    /// <c>true</c> only when local configuration or an authoritative non-transient provider rejection proves that no
    /// usable invoice was created; <c>false</c> for timeout, disconnect, 5xx, rate limit, or malformed success data.
    /// </param>
    /// <param name="sanitizedErrorCode">
    /// Credential-free HTTP/provider or local error category. Response bodies, hashes, and tokens must not be passed.
    /// </param>
    /// <param name="observedAtUtc">UTC time when the single attempt returned or failed locally.</param>
    /// <remarks>
    /// Ambiguous results remain locked to GET-only reconciliation and keep <see cref="CreationResolvedAtUtc"/> null.
    /// Definitive failures terminate automatic reconciliation through the caller's payment/schedule transition.
    /// </remarks>
    public void RecordCreationFailure(
        bool definitiveFailure,
        string sanitizedErrorCode,
        DateTime observedAtUtc)
    {
        CreationState = definitiveFailure
            ? UniquePayCreationStates.Failed
            : UniquePayCreationStates.Ambiguous;
        CreationErrorCode = string.IsNullOrWhiteSpace(sanitizedErrorCode)
            ? (definitiveFailure ? "create_failed" : "create_ambiguous")
            : sanitizedErrorCode.Trim();
        CreationResolvedAtUtc = definitiveFailure ? observedAtUtc : null;
        UpdatedAtUtc = observedAtUtc;
    }
}

/// <summary>
/// Durable lifecycle values for the exactly-once UniquePay invoice-creation mutation.
/// </summary>
/// <remarks>
/// These values describe only the create POST. Payment proof remains exclusively in authoritative inquiry data and
/// <see cref="UniquePayStatuses"/>; a <see cref="Created"/> value does not mean paid.
/// </remarks>
public static class UniquePayCreationStates
{
    /// <summary>The single POST was reserved durably and may have reached the provider.</summary>
    public const string Attempting = "attempting";

    /// <summary>A valid create response or a later hash inquiry proved that the provider invoice exists.</summary>
    public const string Created = "created";

    /// <summary>The single POST had a timeout, disconnect, 5xx, rate-limit, or malformed/incomplete success result.</summary>
    public const string Ambiguous = "ambiguous";

    /// <summary>An authoritative non-transient rejection proved that automatic inquiry should stop.</summary>
    public const string Failed = "failed";

    /// <summary>GET-only reconciliation exhausted its configured budget without proving invoice existence.</summary>
    public const string ManualReview = "manual_review";

    /// <summary>
    /// Determines whether an explicit read-only inquiry is safe for a creation lifecycle.
    /// </summary>
    /// <param name="state">Persisted creation state; null legacy values are treated as ambiguous and recoverable.</param>
    /// <returns>
    /// <c>false</c> only for a definitive failed create. Manual-review rows remain explicitly GET-checkable but are
    /// excluded from the automatic worker query.
    /// </returns>
    public static bool IsReadOnlyInquiryAllowed(string state)
        => !string.Equals(state, Failed, StringComparison.Ordinal);
}

/// <summary>
/// Local UniquePay status constants used by settlement and reconciliation guards.
/// </summary>
public static class UniquePayStatuses
{
    /// <summary>Invoice exists locally but has not passed an authoritative paid inquiry.</summary>
    public const string Pending = "pending";

    /// <summary>Authoritative inquiry passed all identity, toman amount, fee-payer, fee, and payment checks.</summary>
    public const string Paid = "paid";

    /// <summary>Invoice creation or authoritative verification failed and no financial side effect is permitted.</summary>
    public const string Failed = "failed";

    /// <summary>Provider explicitly reported that the unpaid invoice expired.</summary>
    public const string Expired = "expired";

    /// <summary>Provider explicitly reported that the unpaid invoice was cancelled.</summary>
    public const string Cancelled = "cancelled";

    /// <summary>Compatibility alias for verification failures, which are represented by terminal <c>failed</c>.</summary>
    public const string VerificationFailed = Failed;

    /// <summary>
    /// Checks whether the local status represents an authoritatively verified paid invoice.
    /// </summary>
    /// <param name="status">Local payment status; null and unknown values are rejected.</param>
    /// <returns><c>true</c> only for exact case-insensitive <c>paid</c>.</returns>
    public static bool IsPaid(string status)
        => string.Equals(status?.Trim(), Paid, StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Determines whether a local UniquePay status must no longer be polled automatically.
    /// </summary>
    /// <param name="status">Local status stored in users.db; null and unknown values remain non-terminal.</param>
    /// <returns><c>true</c> for failed, expired, or cancelled; otherwise <c>false</c>.</returns>
    public static bool IsTerminal(string status)
        => string.Equals(status?.Trim(), Failed, StringComparison.OrdinalIgnoreCase) ||
           string.Equals(status?.Trim(), Expired, StringComparison.OrdinalIgnoreCase) ||
           string.Equals(status?.Trim(), Cancelled, StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Maps optional provider lifecycle fields to a safe terminal local state without treating them as payment proof.
    /// </summary>
    /// <param name="invoice">
    /// Invoice returned by the official inquiry. Current public documentation omits lifecycle fields, so null/unknown
    /// values remain pending; only explicit terminal values are recognized.
    /// </param>
    /// <returns>Expired, cancelled, failed, or <c>null</c> when the invoice should remain pending.</returns>
    public static string GetProviderTerminalStatus(UniquePayInvoiceData invoice)
    {
        if (invoice == null || invoice.IsPaid)
            return null;
        if (invoice.IsExpired == true)
            return Expired;
        if (invoice.IsCancelled == true || invoice.IsCanceled == true)
            return Cancelled;

        var providerStatus = (invoice.PaymentStatus ?? invoice.ProviderStatus)?.Trim();
        if (string.Equals(providerStatus, "expired", StringComparison.OrdinalIgnoreCase))
            return Expired;
        if (string.Equals(providerStatus, "cancelled", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(providerStatus, "canceled", StringComparison.OrdinalIgnoreCase))
        {
            return Cancelled;
        }
        if (string.Equals(providerStatus, "failed", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(providerStatus, "rejected", StringComparison.OrdinalIgnoreCase))
        {
            return Failed;
        }

        return null;
    }
}

/// <summary>
/// Durable UniquePay settlement-claim states used across owned-wallet and tenant-order financial boundaries.
/// </summary>
public static class UniquePaySettlementStates
{
    /// <summary>No settlement processor currently owns the paid row.</summary>
    public const string Pending = "pending";

    /// <summary>A processor durably claimed the row before performing an external wallet or XUI side effect.</summary>
    public const string Processing = "processing";

    /// <summary>All required local financial or fulfillment effects were persisted.</summary>
    public const string Settled = "settled";

    /// <summary>A processor crashed or became ambiguous after claiming the row; automatic replay is fail-closed.</summary>
    public const string ManualReview = "manual_review";
}

/// <summary>
/// Verifies UniquePay inquiry identity, toman currency, configured fee-payer amount model, fee, and paid state.
/// </summary>
public static class UniquePayPaymentVerifier
{
    /// <summary>
    /// Applies the fail-closed financial verification rules for one UniquePay inquiry.
    /// </summary>
    /// <param name="payment">
    /// Local users.db invoice containing immutable merchant hash, base amount in toman, and fee percentage snapshot.
    /// </param>
    /// <param name="response">Authoritative provider response returned by <c>/api/check-invoice</c>.</param>
    /// <param name="errorCode">Stable non-secret rejection code, or <c>null</c> when verification succeeds.</param>
    /// <returns><c>true</c> only when the invoice is paid and every financial/identity invariant matches.</returns>
    /// <remarks>
    /// <c>isVerified</c> is intentionally informational because UniquePay documentation marks it as a future feature.
    /// The root <c>hashId</c> echo is compared whenever present, while production responses that omit it remain bound
    /// to the locally persisted create-time reference through <c>invoice.id</c>.
    /// UniquePay production responses use both <c>IRT</c>/<c>toman</c> and buyer aliases <c>buyer</c>/<c>user</c>.
    /// Current responses keep <c>amount</c> equal to the base and expose the charged total through
    /// <c>payableAmount = base + buyer fee + uniqueAmount</c>. Legacy <c>buyer</c> responses without payable fields
    /// remain valid only when <c>amount - fee</c> equals the base. Owner-paid invoices never add the fee to payable.
    /// The allowed one-toman fee difference accounts only for provider rounding; no other mismatch is tolerated.
    /// </remarks>
    public static bool IsVerifiedPaid(
        UniquePayPaymentInfo payment,
        UniquePayCheckInvoiceResponse response,
        out string errorCode)
    {
        if (payment == null || response == null || !response.Status || response.Code != 200 || response.Invoice == null)
        {
            errorCode = "provider_inquiry_unsuccessful";
            return false;
        }

        if (string.IsNullOrWhiteSpace(payment.HashId) ||
            (!string.IsNullOrWhiteSpace(response.HashId) &&
             !string.Equals(payment.HashId.Trim(), response.HashId.Trim(), StringComparison.Ordinal)))
        {
            errorCode = "provider_hash_id_mismatch";
            return false;
        }

        // Production check-invoice responses can omit the root hashId even though the inquiry was made with the
        // persisted merchant hash. Reject a conflicting returned hash, and bind the result to the create-time RefId
        // through invoice.id so an omitted optional echo cannot either block or weaken financial verification.
        var providerInvoiceIdentity = !string.IsNullOrWhiteSpace(response.RefId)
            ? response.RefId.Trim()
            : response.Invoice.InvoiceId;
        if (!string.IsNullOrWhiteSpace(payment.RefId) &&
            !string.Equals(payment.RefId.Trim(), providerInvoiceIdentity, StringComparison.Ordinal))
        {
            errorCode = "provider_ref_id_mismatch";
            return false;
        }
        if (string.IsNullOrWhiteSpace(payment.RefId) && string.IsNullOrWhiteSpace(providerInvoiceIdentity))
        {
            errorCode = "provider_invoice_identity_missing";
            return false;
        }

        var currency = response.Invoice.Currency?.Trim();
        if (!string.Equals(currency, "IRT", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(currency, "toman", StringComparison.OrdinalIgnoreCase))
        {
            errorCode = "provider_currency_mismatch";
            return false;
        }

        var feePayer = response.Invoice.FeePayer?.Trim();
        var legacyBuyerPaysFee = string.Equals(feePayer, "buyer", StringComparison.OrdinalIgnoreCase);
        var userPaysFee = string.Equals(feePayer, "user", StringComparison.OrdinalIgnoreCase);
        var buyerPaysFee = legacyBuyerPaysFee || userPaysFee;
        var ownerPaysFee = string.Equals(feePayer, "owner", StringComparison.OrdinalIgnoreCase);
        if (!buyerPaysFee && !ownerPaysFee)
        {
            errorCode = "provider_fee_payer_mismatch";
            return false;
        }

        var expectedFee = decimal.Round(
            payment.BaseAmountToman * payment.FeePercent / 100m,
            decimals: 0,
            MidpointRounding.AwayFromZero);
        if (Math.Abs(response.Invoice.Fee - expectedFee) > 1m)
        {
            errorCode = "provider_fee_mismatch";
            return false;
        }

        var hasPayableAmount = response.Invoice.PayableAmount.HasValue;
        var hasUniqueAmount = response.Invoice.UniqueAmount.HasValue;
        if (userPaysFee || hasPayableAmount || hasUniqueAmount)
        {
            if (response.Invoice.Amount != payment.BaseAmountToman)
            {
                errorCode = "provider_base_amount_mismatch";
                return false;
            }
            if (!hasPayableAmount ||
                !hasUniqueAmount ||
                response.Invoice.UniqueAmount.Value < 0)
            {
                errorCode = "provider_payable_amount_mismatch";
                return false;
            }

            // The live API separates the immutable merchant base from the actual card-transfer total. Validate the
            // complete equation so neither an altered buyer fee nor an altered unique amount can settle a wallet.
            var expectedPayableAmount = (decimal)payment.BaseAmountToman +
                                        (buyerPaysFee ? response.Invoice.Fee : 0L) +
                                        response.Invoice.UniqueAmount.Value;
            if (response.Invoice.PayableAmount.Value != expectedPayableAmount)
            {
                errorCode = "provider_payable_amount_mismatch";
                return false;
            }
        }
        else
        {
            // Backward compatibility for the documented legacy shape, which placed a buyer-paid fee inside amount
            // and did not return payableAmount/uniqueAmount.
            var providerBaseAmount = legacyBuyerPaysFee
                ? response.Invoice.Amount - response.Invoice.Fee
                : response.Invoice.Amount;
            if (providerBaseAmount != payment.BaseAmountToman)
            {
                errorCode = "provider_base_amount_mismatch";
                return false;
            }
        }

        // A provisional decision may use only a structurally and financially consistent pending invoice. Validate
        // every immutable provider field before returning provider_not_paid to the super-admin flow.
        if (!response.Invoice.IsPaid)
        {
            errorCode = "provider_not_paid";
            return false;
        }

        errorCode = null;
        return true;
    }
}

/// <summary>
/// UniquePay HTTP client for generic form-encoded invoice creation and authoritative polling.
/// </summary>
/// <remarks>
/// Creation is executed once because duplicate/ambiguous requests must be resolved by their merchant hash. Only
/// read-only inquiries retry transient HTTP and transport failures. The bearer token is never logged or persisted.
/// </remarks>
public sealed class UniquePay
{
    private readonly AppConfig _configuration;
    private readonly HttpClient _httpClient;

    /// <summary>
    /// Creates the production UniquePay client from application configuration.
    /// </summary>
    /// <param name="configuration">Configuration containing UniquePay host, bearer token, timeout, and inquiry retry count.</param>
    public UniquePay(IConfiguration configuration)
        : this(configuration, new HttpClient())
    {
    }

    /// <summary>
    /// Creates a UniquePay client with an injected HTTP transport for tests or custom runtime transport.
    /// </summary>
    /// <param name="configuration">Configuration containing startup UniquePay values; the token may be empty while disabled.</param>
    /// <param name="httpClient">HTTP client whose ownership remains with the caller.</param>
    public UniquePay(IConfiguration configuration, HttpClient httpClient)
    {
        _configuration = configuration.Get<AppConfig>() ?? new AppConfig();
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        var baseUrl = (_configuration.UniquePayBaseUrl ?? string.Empty).TrimEnd('/') + "/";
        if (_httpClient.BaseAddress == null &&
            Uri.TryCreate(baseUrl, UriKind.Absolute, out var baseAddress) &&
            (baseAddress.Scheme == Uri.UriSchemeHttp || baseAddress.Scheme == Uri.UriSchemeHttps))
        {
            _httpClient.BaseAddress = baseAddress;
        }
    }

    /// <summary>
    /// Creates one UniquePay invoice without automatic retry.
    /// </summary>
    /// <param name="hashId">Globally unique merchant hash already persisted in users.db.</param>
    /// <param name="amountToman">
    /// Base amount in Iranian toman/IRT, excluding the gateway fee. It must be greater than 50,000 toman; exactly
    /// 50,000 is not accepted by the current provider contract.
    /// </param>
    /// <param name="redirectUrl">
    /// Absolute platform return URL containing the merchant hash only as a lookup hint; it is not payment proof.
    /// </param>
    /// <param name="callbackUrl">
    /// Absolute platform callback URL containing the merchant hash. UniquePay's unsigned notification only triggers
    /// an authoritative inquiry and must never be interpreted as proof of payment.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for the single create request.</param>
    /// <returns>A validated response containing matching hash id, provider reference, and payment link.</returns>
    /// <exception cref="ArgumentOutOfRangeException">
    /// Thrown before request construction when <paramref name="amountToman"/> is 50,000 toman or less.
    /// </exception>
    /// <exception cref="UniquePayApiException">Thrown for provider rejection or malformed/incomplete response.</exception>
    /// <remarks>
    /// Uses UniquePay's documented bot-compatible <c>/api/ddbot/create-invoice</c> route because the generic route
    /// reserves callback delivery for future use. Creation is never retried, preventing duplicate invoices after an
    /// ambiguous transport failure. The callback remains unsigned and cannot settle without <c>check-invoice</c>.
    /// </remarks>
    /// <example>
    /// <code>
    /// var invoice = await uniquePay.CreateInvoiceAsync(
    ///     payment.HashId,
    ///     amountToman: 50001,
    ///     redirectUrl: "https://merchant.example/uniquepay-return?hashId=example",
    ///     callbackUrl: "https://merchant.example/uniquepay-callback?hashId=example",
    ///     cancellationToken);
    /// </code>
    /// </example>
    public async Task<UniquePayCreateInvoiceResponse> CreateInvoiceAsync(
        string hashId,
        long amountToman,
        string redirectUrl,
        string callbackUrl,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(hashId);
        UniquePayAmountPolicy.EnsureValid(amountToman);

        var fields = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["hashId"] = hashId,
            ["amount"] = amountToman.ToString(CultureInfo.InvariantCulture)
        };
        if (!string.IsNullOrWhiteSpace(redirectUrl))
            fields["redirectUrl"] = redirectUrl;
        if (!string.IsNullOrWhiteSpace(callbackUrl))
            fields["callbackUrl"] = callbackUrl;
        fields["orderId"] = hashId;

        var response = await SendFormAsync<UniquePayCreateInvoiceResponse>(
            "api/ddbot/create-invoice",
            fields,
            retryInquiry: false,
            cancellationToken);

        if (!response.Status ||
            response.Code != 200 ||
            !string.Equals(response.HashId?.Trim(), hashId.Trim(), StringComparison.Ordinal) ||
            string.IsNullOrWhiteSpace(response.RefId) ||
            string.IsNullOrWhiteSpace(response.PaymentLink))
        {
            throw new UniquePayApiException(
                response.Code,
                response.RawResponseJson,
                "UniquePay returned an incomplete or mismatched invoice response.");
        }

        return response;
    }

    /// <summary>
    /// Reads the authoritative state and financial fields for one saved merchant hash.
    /// </summary>
    /// <param name="hashId">Exact merchant hash persisted before invoice creation.</param>
    /// <param name="cancellationToken">Cancellation token for bounded retry delays and HTTP attempts.</param>
    /// <returns>
    /// Parsed provider response. Callers must pass it through <see cref="UniquePayPaymentVerifier"/> before settlement.
    /// </returns>
    public Task<UniquePayCheckInvoiceResponse> CheckInvoiceAsync(
        string hashId,
        CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(hashId);
        return SendFormAsync<UniquePayCheckInvoiceResponse>(
            "api/check-invoice",
            new Dictionary<string, string>(StringComparer.Ordinal) { ["hashId"] = hashId },
            retryInquiry: true,
            cancellationToken);
    }

    /// <summary>
    /// Sends one authenticated form request and parses its JSON response.
    /// </summary>
    /// <typeparam name="T">Expected UniquePay response DTO type.</typeparam>
    /// <param name="relativePath">Official provider-relative API route without credentials.</param>
    /// <param name="fields">Form fields; the collection must never include the bearer token.</param>
    /// <param name="retryInquiry">Whether transient read-only failures may be retried.</param>
    /// <param name="cancellationToken">Cancellation token for requests and backoff.</param>
    /// <returns>Deserialized response with its raw JSON attached for protected diagnostics.</returns>
    /// <exception cref="InvalidOperationException">Thrown when token or base URL is absent.</exception>
    /// <exception cref="UniquePayApiException">Thrown after a provider rejection, malformed response, or exhausted retry.</exception>
    private async Task<T> SendFormAsync<T>(
        string relativePath,
        IReadOnlyDictionary<string, string> fields,
        bool retryInquiry,
        CancellationToken cancellationToken)
        where T : UniquePayResponseBase
    {
        if (string.IsNullOrWhiteSpace(_configuration.UniquePayBusinessToken))
            throw new InvalidOperationException("UniquePay business token is not configured.");
        if (_httpClient.BaseAddress == null)
            throw new InvalidOperationException("UniquePay API base URL is not configured.");

        var attempts = retryInquiry ? Math.Max(1, _configuration.UniquePayInquiryRetryCount + 1) : 1;
        Exception lastError = null;
        for (var attempt = 1; attempt <= attempts; attempt++)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, relativePath);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _configuration.UniquePayBusinessToken);
            request.Content = new FormUrlEncodedContent(fields);

            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(Math.Clamp(_configuration.UniquePayRequestTimeoutSeconds, 5, 120)));
            try
            {
                using var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead, timeout.Token);
                var responseBody = await response.Content.ReadAsStringAsync(timeout.Token);
                if (!response.IsSuccessStatusCode)
                {
                    var error = new UniquePayApiException(
                        (int)response.StatusCode,
                        responseBody,
                        $"UniquePay returned HTTP {(int)response.StatusCode}.");
                    if (!retryInquiry || !IsTransientStatus(response.StatusCode) || attempt == attempts)
                        throw error;
                    lastError = error;
                }
                else
                {
                    T parsed;
                    try
                    {
                        parsed = JsonConvert.DeserializeObject<T>(responseBody);
                    }
                    catch (JsonException ex)
                    {
                        throw new UniquePayApiException(
                            (int)response.StatusCode,
                            responseBody,
                            "UniquePay returned malformed JSON.",
                            ex);
                    }

                    if (parsed == null)
                        throw new UniquePayApiException((int)response.StatusCode, responseBody, "UniquePay returned empty JSON.");
                    parsed.RawResponseJson = responseBody;
                    return parsed;
                }
            }
            catch (Exception ex) when (retryInquiry && IsTransientException(ex, cancellationToken))
            {
                lastError = ex;
            }

            if (attempt < attempts)
                await Task.Delay(TimeSpan.FromMilliseconds(Math.Min(500 * attempt, 2000)), cancellationToken);
        }

        throw lastError as UniquePayApiException ??
              new UniquePayApiException(0, null, "UniquePay inquiry failed after transient retries.", lastError);
    }

    /// <summary>
    /// Identifies HTTP results safe to retry for a read-only UniquePay inquiry.
    /// </summary>
    /// <param name="statusCode">Provider HTTP status.</param>
    /// <returns><c>true</c> for request timeout, rate limiting, and server errors.</returns>
    private static bool IsTransientStatus(HttpStatusCode statusCode)
        => statusCode == HttpStatusCode.RequestTimeout ||
           (int)statusCode == 429 ||
           (int)statusCode >= 500;

    /// <summary>
    /// Identifies retryable transport errors while preserving caller-requested cancellation.
    /// </summary>
    /// <param name="exception">Transport or timeout exception.</param>
    /// <param name="callerToken">Original token used to distinguish timeout from requested cancellation.</param>
    /// <returns><c>true</c> for HTTP transport failure or internal timeout.</returns>
    private static bool IsTransientException(Exception exception, CancellationToken callerToken)
        => exception is HttpRequestException ||
           (exception is OperationCanceledException && !callerToken.IsCancellationRequested);

    /// <summary>
    /// Determines whether a failed create attempt is known not to have produced a usable provider invoice.
    /// </summary>
    /// <param name="exception">Exception raised by the one allowed create attempt.</param>
    /// <returns>
    /// <c>true</c> for local configuration failures and definitive provider validation/authentication codes;
    /// <c>false</c> for transport timeouts, rate limits, server failures, malformed success responses, and duplicate
    /// hash responses that must remain inquiry-eligible because provider creation may have succeeded.
    /// </returns>
    /// <remarks>
    /// Callers use this classification only to schedule polling. It never marks an invoice paid and never retries the
    /// mutating create endpoint.
    /// </remarks>
    public static bool IsDefinitiveCreateFailure(Exception exception)
    {
        if (exception is InvalidOperationException)
            return true;
        if (exception is not UniquePayApiException providerError)
            return false;

        var code = providerError.StatusCode;
        return code is > 0 and < 500 &&
               code is not 103 and not 200 and not 408 and not 429;
    }
}

/// <summary>
/// Common fields returned by UniquePay API operations.
/// </summary>
public abstract class UniquePayResponseBase
{
    /// <summary>Whether UniquePay completed the requested API operation.</summary>
    [JsonProperty("status")]
    public bool Status { get; set; }

    /// <summary>Provider result/error code.</summary>
    [JsonProperty("code")]
    public int Code { get; set; }

    /// <summary>
    /// Optional merchant hash echo returned by the provider; production inquiry responses may omit this field.
    /// </summary>
    [JsonProperty("hashId")]
    public string HashId { get; set; }

    /// <summary>Raw numeric or string provider reference token.</summary>
    [JsonProperty("refId")]
    public JToken RefIdValue { get; set; }

    /// <summary>Provider reference normalized to invariant text for storage and comparison.</summary>
    [JsonIgnore]
    public string RefId => RefIdValue?.Type == JTokenType.Null ? null : RefIdValue?.ToString();

    /// <summary>Raw provider JSON retained for protected diagnostics; never includes the request bearer token.</summary>
    [JsonIgnore]
    public string RawResponseJson { get; set; }
}

/// <summary>
/// Successful or rejected UniquePay invoice-creation response.
/// </summary>
public sealed class UniquePayCreateInvoiceResponse : UniquePayResponseBase
{
    /// <summary>Provider-hosted payment page URL.</summary>
    [JsonProperty("paymentLink")]
    public string PaymentLink { get; set; }

    /// <summary>Optional provider diagnostic text.</summary>
    [JsonProperty("message")]
    public string Message { get; set; }
}

/// <summary>
/// Authoritative UniquePay invoice inquiry response.
/// </summary>
public sealed class UniquePayCheckInvoiceResponse : UniquePayResponseBase
{
    /// <summary>Authoritative invoice financial and payment fields.</summary>
    [JsonProperty("invoice")]
    public UniquePayInvoiceData Invoice { get; set; }

    /// <summary>Optional provider diagnostic text.</summary>
    [JsonProperty("message")]
    public string Message { get; set; }
}

/// <summary>
/// Financial fields returned inside a UniquePay <c>check-invoice</c> result.
/// </summary>
public sealed class UniquePayInvoiceData
{
    /// <summary>Provider internal invoice identifier retained only for diagnostics.</summary>
    [JsonProperty("id")]
    public JToken IdValue { get; set; }

    /// <summary>
    /// Provider invoice identifier normalized to invariant text for comparison with the create response reference.
    /// </summary>
    [JsonIgnore]
    public string InvoiceId => IdValue?.Type == JTokenType.Null ? null : IdValue?.ToString();

    /// <summary>
    /// Optional provider lifecycle value when exposed as <c>status</c>; it is never accepted as proof of payment.
    /// </summary>
    [JsonProperty("status")]
    public string ProviderStatus { get; set; }

    /// <summary>
    /// Optional provider lifecycle value when exposed as <c>paymentStatus</c>; only explicit terminal values are mapped.
    /// </summary>
    [JsonProperty("paymentStatus")]
    public string PaymentStatus { get; set; }

    /// <summary>Optional provider expiry flag; absent values remain pending.</summary>
    [JsonProperty("isExpired")]
    public bool? IsExpired { get; set; }

    /// <summary>Optional British-spelling provider cancellation flag; absent values remain pending.</summary>
    [JsonProperty("isCancelled")]
    public bool? IsCancelled { get; set; }

    /// <summary>Optional American-spelling provider cancellation flag; absent values remain pending.</summary>
    [JsonProperty("isCanceled")]
    public bool? IsCanceled { get; set; }

    /// <summary>
    /// Provider invoice amount in IRT/toman. Current responses keep this at the merchant base amount; legacy
    /// <c>buyer</c> responses may include the fee here when payable fields are absent.
    /// </summary>
    [JsonProperty("amount")]
    public long Amount { get; set; }

    /// <summary>
    /// Final card-transfer amount in IRT/toman after the applicable buyer fee and provider unique amount are added.
    /// </summary>
    [JsonProperty("payableAmount")]
    public long? PayableAmount { get; set; }

    /// <summary>
    /// Non-negative provider-selected amount in IRT/toman added to make the card transfer uniquely identifiable.
    /// </summary>
    [JsonProperty("uniqueAmount")]
    public long? UniqueAmount { get; set; }

    /// <summary>Provider currency code; settlement accepts only case-insensitive <c>IRT</c> or <c>toman</c>.</summary>
    [JsonProperty("currency")]
    public string Currency { get; set; }

    /// <summary>Provider-reported fee in Iranian toman.</summary>
    [JsonProperty("fee")]
    public long Fee { get; set; }

    /// <summary>
    /// Party paying the fee; settlement accepts <c>user</c>/<c>buyer</c> as buyer aliases or <c>owner</c>, each with
    /// its matching amount equation.
    /// </summary>
    [JsonProperty("feePayer")]
    public string FeePayer { get; set; }

    /// <summary>Authoritative provider paid flag required for settlement.</summary>
    [JsonProperty("isPaid")]
    public bool IsPaid { get; set; }

    /// <summary>Future/optional provider verification flag retained for audit but not used as a paid condition.</summary>
    [JsonProperty("isVerified")]
    public bool IsVerified { get; set; }

    /// <summary>Return URL stored by UniquePay for the invoice.</summary>
    [JsonProperty("redirectUrl")]
    public string RedirectUrl { get; set; }
}

/// <summary>
/// Sanitized UniquePay provider exception.
/// </summary>
/// <remarks>The bearer token and request headers are never retained on this exception.</remarks>
public sealed class UniquePayApiException : Exception
{
    /// <summary>HTTP or provider result code; zero represents local transport/validation failure.</summary>
    public int StatusCode { get; }

    /// <summary>Provider response body retained for protected diagnostics and never shown verbatim to customers.</summary>
    public string ResponseBody { get; }

    /// <summary>
    /// Creates an exception that contains only non-credential provider diagnostics.
    /// </summary>
    /// <param name="statusCode">HTTP/provider code, or zero for local validation and transport failures.</param>
    /// <param name="responseBody">Provider response body; it must not contain request headers or bearer token.</param>
    /// <param name="message">Safe local explanation.</param>
    /// <param name="innerException">Optional underlying transport or JSON exception.</param>
    public UniquePayApiException(
        int statusCode,
        string responseBody,
        string message,
        Exception innerException = null)
        : base(message, innerException)
    {
        StatusCode = statusCode;
        ResponseBody = responseBody;
    }
}

/// <summary>
/// Credits officially verified or explicitly provisionally approved UniquePay owned-wallet invoices exactly once.
/// </summary>
/// <remarks>
/// Tenant payments are deliberately rejected and routed through <see cref="TenantBotService"/>. Provisional approval
/// is restricted to configured super-admin flows, uses a separate ledger identity, and never creates referral rewards.
/// </remarks>
public sealed class UniquePaySettlementService
{
    private static readonly AsyncKeyedGate SettlementGate = new();
    private readonly AppConfig _configuration;
    private readonly UserDbContextFactory _userDbContextFactory;
    private readonly CredentialsStore _credentialsDbContext;
    private readonly WalletLedgerService _walletLedgerService;
    private readonly ReferralService _referralService;
    private readonly ILogger<UniquePaySettlementService> _logger;

    /// <summary>
    /// Creates the owned-wallet UniquePay settlement boundary.
    /// </summary>
    /// <param name="configuration">Startup configuration containing the immutable super-admin Telegram allow-list.</param>
    /// <param name="userDbContextFactory">
    /// Factory that creates an independent users.db context for each settlement attempt. A fresh change tracker is
    /// required because reconciliation records provider-paid state through a separate context immediately before
    /// this service claims the wallet credit.
    /// </param>
    /// <param name="credentialsDbContext">credentials.db context containing the shared wallet balance.</param>
    /// <param name="walletLedgerService">Idempotent append-only wallet-ledger writer.</param>
    /// <param name="referralService">Global owned-bot referral engine for final official wallet payments.</param>
    /// <param name="logger">Operational and payment logger; provider credentials are never included.</param>
    /// <exception cref="ArgumentNullException">
    /// Thrown when <paramref name="userDbContextFactory"/> is null because settlement cannot safely reuse the legacy
    /// singleton users.db change tracker after reconciliation.
    /// </exception>
    /// <remarks>Payment processing owns fresh database contexts; the singleton recovery worker resolves scoped settlement services only within each attempt.</remarks>
    public UniquePaySettlementService(
        IConfiguration configuration,
        UserDbContextFactory userDbContextFactory,
        CredentialsStore credentialsDbContext,
        WalletLedgerService walletLedgerService,
        ReferralService referralService,
        ILogger<UniquePaySettlementService> logger)
    {
        _configuration = configuration.Get<AppConfig>() ?? new AppConfig();
        _userDbContextFactory = userDbContextFactory ?? throw new ArgumentNullException(nameof(userDbContextFactory));
        _credentialsDbContext = credentialsDbContext;
        _walletLedgerService = walletLedgerService;
        _referralService = referralService;
        _logger = logger;
    }

    /// <summary>
    /// Applies a fully verified owned-wallet UniquePay payment exactly once.
    /// </summary>
    /// <param name="payment">Tracked payment already verified against an authoritative check response.</param>
    /// <param name="source">Safe audit source such as customer-check, return-trigger, or reconciliation-worker.</param>
    /// <param name="notifyChatId">Optional Telegram destination override; null uses the saved payment chat.</param>
    /// <param name="cancellationToken">Cancellation token for wallet, database, referral, and outbox work.</param>
    /// <returns>Applied, AlreadyAdded, ProviderNotPaid, UserNotFound, or NotFound.</returns>
    /// <remarks>
    /// The payment-keyed gate, durable wallet receipt, and persisted <see cref="UniquePayPaymentInfo.IsAddedToBalance"/> marker prevent duplicate
    /// wallet mutations when return, customer button, and worker race. The append-only ledger has a second unique key.
    /// Each attempt reloads the payment through an independent users.db context so the paid state written by the
    /// authoritative reconciliation context cannot be hidden by a stale singleton EF Core change tracker. The first
    /// credit and unique notification row are committed in one users.db save; retry delivery cannot call settlement.
    /// </remarks>
    public async Task<NowPaymentsSettlementResult> ApplyOfficialPaymentAsync(
        UniquePayPaymentInfo payment,
        string source,
        long? notifyChatId = null,
        CancellationToken cancellationToken = default)
    {
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();
        if (!IsOwnedWalletCharge(payment) ||
            !UniquePayStatuses.IsPaid(payment.PaymentStatus) ||
            !payment.PaidAtUtc.HasValue)
        {
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        using var settlementGateLease = await SettlementGate.EnterAsync(payment.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            // Reconciliation writes paid state through its own context. A new tracker here is required so a legacy
            // singleton entity cached as pending cannot suppress the durable wallet claim.
            var context = new UserWorkflowStore(_userDbContextFactory);
            var tracked = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
                .FirstOrDefaultAsync(x => x.Id == payment.Id, cancellationToken));
            if (tracked == null)
                return NowPaymentsSettlementResult.NotFound();
            if (!UniquePayStatuses.IsPaid(tracked.PaymentStatus))
                return NowPaymentsSettlementResult.ProviderNotPaid();

            var user = await _credentialsDbContext.GetUserStatusWithId(tracked.TelegramUserId);
            if (user == null)
            {
                tracked.ErrorCode = "wallet_user_not_found";
                tracked.ErrorMessage = "The credentials wallet user was not found.";
                tracked.NextInquiryAtUtc = DateTime.UtcNow.AddMinutes(1);
                tracked.UpdatedAtUtc = DateTime.UtcNow;
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.UserNotFound();
            }

            if (tracked.IsAddedToBalance)
            {
                if (!string.Equals(tracked.SettlementState, UniquePaySettlementStates.Settled, StringComparison.Ordinal))
                {
                    tracked.SettlementState = UniquePaySettlementStates.Settled;
                    tracked.SettlementAttemptId = null;
                    tracked.SettlementStartedAtUtc = null;
                    tracked.UpdatedAtUtc = DateTime.UtcNow;
                    await context.SaveAsync(cancellationToken);
                }
                if (tracked.IsProvisionallyApproved)
                {
                    await EnsureProvisionalLedgerAsync(
                        tracked,
                        tracked.BalanceBefore ?? user.AccountBalance - tracked.BaseAmountToman,
                        tracked.BalanceAfter ?? user.AccountBalance,
                        cancellationToken);
                    await RecordProviderConfirmationAfterProvisionalAsync(
                        context,
                        tracked,
                        user,
                        source,
                        cancellationToken);
                }
                else
                {
                    await EnsureLedgerAsync(
                        tracked,
                        tracked.BalanceBefore ?? user.AccountBalance - tracked.BaseAmountToman,
                        tracked.BalanceAfter ?? user.AccountBalance,
                        cancellationToken);
                    await ProcessReferralAsync(tracked, cancellationToken);
                }
                return NowPaymentsSettlementResult.AlreadyAdded(user.AccountBalance);
            }

            if (await RejectActiveOrAmbiguousClaimAsync(context, tracked, cancellationToken))
                return NowPaymentsSettlementResult.ProviderNotPaid();

            var attemptId = Guid.NewGuid().ToString("N");
            var claimedAtUtc = DateTime.UtcNow;
            var claimed = await context.WriteAsync(async db => await db.UniquePayPaymentInfos
                .Where(x => x.Id == tracked.Id &&
                            !x.IsAddedToBalance &&
                            (x.SettlementState == null || x.SettlementState == UniquePaySettlementStates.Pending))
                .ExecuteUpdateAsync(
                    setters => setters
                        .SetProperty(x => x.SettlementState, UniquePaySettlementStates.Processing)
                        .SetProperty(x => x.SettlementAttemptId, attemptId)
                        .SetProperty(x => x.SettlementStartedAtUtc, claimedAtUtc)
                        .SetProperty(x => x.UpdatedAtUtc, claimedAtUtc),
                    cancellationToken));
            if (claimed != 1)
            {
                await context.ReloadAsync(tracked, cancellationToken);
                return tracked.IsAddedToBalance
                    ? NowPaymentsSettlementResult.AlreadyAdded(tracked.BalanceAfter ?? user.AccountBalance)
                    : NowPaymentsSettlementResult.ProviderNotPaid();
            }

            await context.ReloadAsync(tracked, cancellationToken);

            var before = user.AccountBalance;
            if (!await _credentialsDbContext.AddFund(tracked.TelegramUserId, tracked.BaseAmountToman, $"payment:uniquepay:{tracked.Id}:credit", botId: tracked.BotId))
            {
                tracked.SettlementState = UniquePaySettlementStates.Pending;
                tracked.SettlementAttemptId = null;
                tracked.SettlementStartedAtUtc = null;
                tracked.NextInquiryAtUtc = DateTime.UtcNow.AddMinutes(1);
                tracked.UpdatedAtUtc = DateTime.UtcNow;
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.UserNotFound();
            }
            var walletReceipt = await _credentialsDbContext.GetWalletOperationAsync($"payment:uniquepay:{tracked.Id}:credit");
            before = walletReceipt.BeforeBalance;
            var after = walletReceipt.AfterBalance;

            tracked.IsAddedToBalance = true;
            tracked.SettlementState = UniquePaySettlementStates.Settled;
            tracked.SettlementAttemptId = null;
            tracked.SettlementStartedAtUtc = null;
            tracked.BalanceBefore = before;
            tracked.BalanceAfter = after;
            tracked.SettledAtUtc ??= DateTime.UtcNow;
            tracked.UpdatedAtUtc = DateTime.UtcNow;
            // The unique outbox row shares the same users.db save as the exactly-once settlement marker.
            var notificationChatId = notifyChatId ?? tracked.ChatId;
            context.Add(
                PaymentSettlementNotification.CreateOwnedWalletCredit(
                    provider: "uniquepay",
                    providerPaymentId: tracked.Id,
                    botId: tracked.BotId,
                    telegramUserId: tracked.TelegramUserId,
                    chatId: notificationChatId,
                    amountToman: tracked.BaseAmountToman,
                    messageText: $"اعتبار کیف پول شما به میزان {tracked.BaseAmountToman.FormatCurrency()} افزایش یافت.",
                    createdAtUtc: tracked.SettledAtUtc.Value));
            await context.SaveAsync(cancellationToken);
            await EnsureLedgerAsync(tracked, before, after, cancellationToken);
            await ProcessReferralAsync(tracked, cancellationToken);
            await LogSettlementOnceAsync(context, tracked, user, before, after, source, cancellationToken);
            return NowPaymentsSettlementResult.Applied(before, after);
        }
        finally
        {
            settlementGateLease.Dispose();
        }
    }

    /// <summary>
    /// Applies a two-stage super-admin provisional credit to one recently rechecked pending UniquePay wallet invoice.
    /// </summary>
    /// <param name="payment">Owned-wallet payment whose latest official inquiry still reports unpaid.</param>
    /// <param name="approvedByTelegramUserId">Configured super-admin Telegram id persisted for financial audit.</param>
    /// <param name="notifyChatId">Optional customer chat override; null uses the chat saved on the payment row.</param>
    /// <param name="cancellationToken">Cancellation token for claim, wallet, users.db, ledger, and outbox operations.</param>
    /// <returns>Applied for the first credit, AlreadyAdded for a duplicate decision, or a non-mutating failure status.</returns>
    /// <remarks>
    /// The amount always comes from immutable <see cref="UniquePayPaymentInfo.BaseAmountToman"/>. Tenant orders,
    /// terminal/mismatched responses, provider-check failures, and already paid rows are rejected. A persisted claim is
    /// acquired before credentials.db is changed so a crash becomes manual review instead of a duplicate wallet credit.
    /// Referral processing is permanently excluded for this provisional credit; a later official confirmation writes
    /// audit only and never retroactively creates a referral reward. The refreshed eligibility row is loaded with an
    /// independent users.db context so an older tracked status cannot authorize or reject the administrator's action.
    /// The provisional first-credit marker and customer notification are saved together; later official confirmation
    /// does not create a second notification.
    /// </remarks>
    /// <example>
    /// <code>
    /// var result = await settlement.ApplyProvisionalPaymentAsync(payment, adminTelegramId, payment.ChatId, token);
    /// </code>
    /// </example>
    public async Task<NowPaymentsSettlementResult> ApplyProvisionalPaymentAsync(
        UniquePayPaymentInfo payment,
        long approvedByTelegramUserId,
        long? notifyChatId = null,
        CancellationToken cancellationToken = default)
    {
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();
        if (approvedByTelegramUserId <= 0 ||
            _configuration.AdminsUserIds?.Contains(approvedByTelegramUserId) != true ||
            !IsOwnedWalletCharge(payment))
        {
            return NowPaymentsSettlementResult.InvalidAmount();
        }

        using var settlementGateLease = await SettlementGate.EnterAsync(payment.Id.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            // The admin decision must use the row produced by the immediately preceding inquiry, not an entity that
            // an earlier Telegram update left in the singleton users.db tracker.
            var context = new UserWorkflowStore(_userDbContextFactory);
            var tracked = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
                .FirstOrDefaultAsync(x => x.Id == payment.Id, cancellationToken));
            if (tracked == null)
                return NowPaymentsSettlementResult.NotFound();

            var user = await _credentialsDbContext.GetUserStatusWithId(tracked.TelegramUserId);
            if (user == null)
                return NowPaymentsSettlementResult.UserNotFound();

            if (tracked.IsAddedToBalance)
            {
                if (tracked.IsProvisionallyApproved)
                {
                    await EnsureProvisionalLedgerAsync(
                        tracked,
                        tracked.BalanceBefore ?? user.AccountBalance - tracked.BaseAmountToman,
                        tracked.BalanceAfter ?? user.AccountBalance,
                        cancellationToken);
                }
                return NowPaymentsSettlementResult.AlreadyAdded(user.AccountBalance);
            }

            if (!CanApplyProvisionalCredit(tracked) ||
                await RejectActiveOrAmbiguousClaimAsync(context, tracked, cancellationToken))
            {
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }

            var attemptId = Guid.NewGuid().ToString("N");
            var claimedAtUtc = DateTime.UtcNow;
            var claimed = await context.WriteAsync(async db => await db.UniquePayPaymentInfos
                .Where(x => x.Id == tracked.Id &&
                            !x.IsAddedToBalance &&
                            x.PaymentStatus == UniquePayStatuses.Pending &&
                            (x.SettlementState == null || x.SettlementState == UniquePaySettlementStates.Pending))
                .ExecuteUpdateAsync(
                    setters => setters
                        .SetProperty(x => x.SettlementState, UniquePaySettlementStates.Processing)
                        .SetProperty(x => x.SettlementAttemptId, attemptId)
                        .SetProperty(x => x.SettlementStartedAtUtc, claimedAtUtc)
                        .SetProperty(x => x.UpdatedAtUtc, claimedAtUtc),
                    cancellationToken));
            if (claimed != 1)
                return NowPaymentsSettlementResult.ProviderNotPaid();

            await context.ReloadAsync(tracked, cancellationToken);
            var before = user.AccountBalance;
            if (!await _credentialsDbContext.AddFund(tracked.TelegramUserId, tracked.BaseAmountToman, $"payment:uniquepay:{tracked.Id}:credit", botId: tracked.BotId, approvalKind: "provisional", approvedByTelegramUserId: approvedByTelegramUserId))
            {
                tracked.SettlementState = UniquePaySettlementStates.Pending;
                tracked.SettlementAttemptId = null;
                tracked.SettlementStartedAtUtc = null;
                tracked.UpdatedAtUtc = DateTime.UtcNow;
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.UserNotFound();
            }
            var walletReceipt = await _credentialsDbContext.GetWalletOperationAsync($"payment:uniquepay:{tracked.Id}:credit");
            before = walletReceipt.BeforeBalance;
            var after = walletReceipt.AfterBalance;

            tracked.IsAddedToBalance = true;
            tracked.IsProvisionallyApproved = true;
            tracked.ProvisionalApprovedAtUtc = DateTime.UtcNow;
            tracked.ProvisionalApprovedByTelegramUserId = approvedByTelegramUserId;
            tracked.SettlementState = UniquePaySettlementStates.Settled;
            tracked.SettlementAttemptId = null;
            tracked.SettlementStartedAtUtc = null;
            tracked.BalanceBefore = before;
            tracked.BalanceAfter = after;
            tracked.SettledAtUtc ??= DateTime.UtcNow;
            tracked.NextInquiryAtUtc ??= DateTime.UtcNow.AddMinutes(1);
            tracked.UpdatedAtUtc = DateTime.UtcNow;
            // Later official provider confirmation audits this credit only; it cannot enqueue another message.
            var notificationChatId = notifyChatId ?? tracked.ChatId;
            context.Add(
                PaymentSettlementNotification.CreateOwnedWalletCredit(
                    provider: "uniquepay",
                    providerPaymentId: tracked.Id,
                    botId: tracked.BotId,
                    telegramUserId: tracked.TelegramUserId,
                    chatId: notificationChatId,
                    amountToman: tracked.BaseAmountToman,
                    messageText: $"اعتبار کیف پول شما به میزان {tracked.BaseAmountToman.FormatCurrency()} به صورت موقت توسط مدیر افزایش یافت.",
                    createdAtUtc: tracked.SettledAtUtc.Value));
            await context.SaveAsync(cancellationToken);

            await EnsureProvisionalLedgerAsync(tracked, before, after, cancellationToken);
            LogProvisionalSettlement(tracked, user, before, after);
            return NowPaymentsSettlementResult.Applied(before, after);
        }
        finally
        {
            settlementGateLease.Dispose();
        }
    }

    /// <summary>
    /// Rejects an active settlement claim and converts a stale crash-ambiguous claim to manual review.
    /// </summary>
    /// <param name="context">
    /// Per-operation users.db context tracking <paramref name="payment"/> and the durable settlement claim.
    /// It must belong to this settlement operation so pre-inquiry snapshots cannot overwrite fresh payment state.
    /// </param>
    /// <param name="payment">Tracked paid UniquePay row that has not yet reached the durable settled marker.</param>
    /// <param name="cancellationToken">Cancellation token for persisting the manual-review transition.</param>
    /// <returns>
    /// <c>true</c> when automatic settlement must stop because another processor owns the claim or a stale claim is
    /// ambiguous; <c>false</c> when a new atomic claim may be attempted.
    /// </returns>
    /// <remarks>
    /// A crash after credentials.db was credited but before users.db was finalized cannot be resolved safely without
    /// a cross-database transaction. This transition fails closed instead of risking a duplicate wallet credit.
    /// </remarks>
    private async Task<bool> RejectActiveOrAmbiguousClaimAsync(
        UserWorkflowStore context,
        UniquePayPaymentInfo payment,
        CancellationToken cancellationToken)
    {
        if (string.Equals(payment.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal))
            return true;
        if (!string.Equals(payment.SettlementState, UniquePaySettlementStates.Processing, StringComparison.Ordinal))
            return false;

        if (payment.SettlementStartedAtUtc.HasValue &&
            DateTime.UtcNow - payment.SettlementStartedAtUtc.Value < TimeSpan.FromMinutes(30))
        {
            return true;
        }

        payment.SettlementState = UniquePaySettlementStates.ManualReview;
        payment.ErrorCode = "settlement_claim_ambiguous";
        payment.ErrorMessage = "A previous UniquePay wallet settlement claim became stale and requires manual review.";
        payment.NextInquiryAtUtc = null;
        payment.UpdatedAtUtc = DateTime.UtcNow;
        await context.SaveAsync(cancellationToken);
        _logger.LogError(
            "UniquePay wallet settlement stopped for manual review. paymentId={PaymentId}, attemptId={AttemptId}, userId={UserId}, amountToman={AmountToman}",
            payment.Id,
            payment.SettlementAttemptId,
            payment.TelegramUserId,
            payment.BaseAmountToman);
        return true;
    }

    /// <summary>
    /// Determines whether a refreshed UniquePay row may receive a super-admin provisional owned-wallet credit.
    /// </summary>
    /// <param name="payment">Tracked payment after the immediately preceding official inquiry.</param>
    /// <returns>
    /// <c>true</c> only for an unsettled owned-wallet invoice that remains pending without verification or transport
    /// errors and has both local and provider identities; otherwise <c>false</c>.
    /// </returns>
    /// <remarks>
    /// Paid, terminal, mismatched, network-failed, tenant, and ambiguous settlement rows are deliberately excluded.
    /// The caller must still acquire the durable settlement claim before changing credentials.db.
    /// </remarks>
    public static bool CanApplyProvisionalCredit(UniquePayPaymentInfo payment)
    {
        return payment != null &&
               IsOwnedWalletCharge(payment) &&
               !payment.IsAddedToBalance &&
               string.Equals(payment.PaymentStatus, UniquePayStatuses.Pending, StringComparison.Ordinal) &&
               string.IsNullOrWhiteSpace(payment.ErrorCode) &&
               !string.IsNullOrWhiteSpace(payment.HashId) &&
               !string.IsNullOrWhiteSpace(payment.RefId) &&
               !string.IsNullOrWhiteSpace(payment.PaymentLink) &&
               !string.Equals(payment.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal) &&
               !string.Equals(payment.SettlementState, UniquePaySettlementStates.Processing, StringComparison.Ordinal);
    }

    /// <summary>
    /// Ensures a UniquePay wallet credit has one append-only audit row.
    /// </summary>
    /// <param name="payment">Settled owned-wallet payment.</param>
    /// <param name="before">Wallet balance in toman before credit.</param>
    /// <param name="after">Wallet balance in toman after credit.</param>
    /// <param name="cancellationToken">Cancellation token for users.db work.</param>
    /// <returns>The existing or newly inserted idempotent ledger row.</returns>
    /// <remarks>Payment processing owns fresh database contexts; the singleton recovery worker resolves scoped settlement services only within each attempt.</remarks>
    private Task<WalletLedgerEntry> EnsureLedgerAsync(
        UniquePayPaymentInfo payment,
        long before,
        long after,
        CancellationToken cancellationToken)
    {
        var providerId = GetStableProviderId(payment);
        var sourceKey = ReferralService.BuildSourcePaymentKey(
            "uniquepay",
            TenantBotPaymentPurposes.WalletCharge,
            providerId);
        return _walletLedgerService.RecordAsync(
            payment.TelegramUserId,
            WalletLedgerDirections.Credit,
            payment.BaseAmountToman,
            before,
            after,
            WalletLedgerReasons.WalletCharge,
            provider: "uniquepay",
            referenceType: nameof(UniquePayPaymentInfo),
            referenceId: payment.Id.ToString(CultureInfo.InvariantCulture),
            orderId: payment.HashId,
            description: "UniquePay wallet charge",
            botId: payment.BotId,
            botUsername: payment.BotUsername,
            botType: BotInstanceTypes.Owned,
            idempotencyKey: $"payment:uniquepay:{payment.Id}:credit",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Ensures a super-admin provisional UniquePay credit has one append-only wallet-ledger row.
    /// </summary>
    /// <param name="payment">Provisionally credited owned-wallet payment containing the approving administrator.</param>
    /// <param name="before">Authoritative shared wallet balance in toman before the provisional credit.</param>
    /// <param name="after">Authoritative shared wallet balance in toman after the provisional credit.</param>
    /// <param name="cancellationToken">Cancellation token for the independent users.db ledger write.</param>
    /// <returns>The existing or newly inserted ledger entry selected by its provider-specific idempotency key.</returns>
    /// <remarks>
    /// Duplicate admin callbacks and later provider confirmation call this helper again only to repair a missing audit
    /// row. The unique key prevents a second ledger entry and this method never changes credentials.db.
    /// </remarks>
    private Task<WalletLedgerEntry> EnsureProvisionalLedgerAsync(
        UniquePayPaymentInfo payment,
        long before,
        long after,
        CancellationToken cancellationToken)
    {
        var providerId = GetStableProviderId(payment);
        return _walletLedgerService.RecordAsync(
            payment.TelegramUserId,
            WalletLedgerDirections.Credit,
            payment.BaseAmountToman,
            before,
            after,
            WalletLedgerReasons.WalletCharge,
            provider: "uniquepay_provisional_admin",
            referenceType: nameof(UniquePayPaymentInfo),
            referenceId: payment.Id.ToString(CultureInfo.InvariantCulture),
            orderId: payment.HashId,
            description: $"UniquePay provisional wallet charge approved by {payment.ProvisionalApprovedByTelegramUserId}",
            botId: payment.BotId,
            botUsername: payment.BotUsername,
            botType: BotInstanceTypes.Owned,
            idempotencyKey: $"payment:uniquepay:{payment.Id}:credit",
            cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Presents one settled official UniquePay wallet payment to the global referral engine.
    /// </summary>
    /// <param name="payment">Final owned-wallet payment with durable local credit.</param>
    /// <param name="cancellationToken">Cancellation token for referral event processing.</param>
    /// <returns>A task that completes after reward work succeeds or is durably left retryable.</returns>
    private Task ProcessReferralAsync(UniquePayPaymentInfo payment, CancellationToken cancellationToken)
        => _referralService.ProcessFinalOwnedWalletPaymentAsync(
            new ReferralPaymentSource(
                "uniquepay",
                payment.PaymentPurpose,
                GetStableProviderId(payment),
                payment.BotId,
                BotInstanceTypes.Owned,
                payment.TelegramUserId,
                payment.BaseAmountToman,
                payment.SettledAtUtc ?? payment.PaidAtUtc ?? DateTime.UtcNow,
                payment.IsAddedToBalance,
                UniquePayStatuses.IsPaid(payment.PaymentStatus),
                IsProvisional: false),
            cancellationToken);

    /// <summary>
    /// Sends the central one-time successful UniquePay payment report after durable financial work.
    /// </summary>
    /// <param name="context">
    /// Per-operation users.db context tracking <paramref name="payment"/>. It persists the one-time logging marker
    /// without consulting the stale legacy singleton change tracker.
    /// </param>
    /// <param name="payment">Settled payment identifiers and amounts.</param>
    /// <param name="user">Shared wallet owner shown in the private audit.</param>
    /// <param name="before">Wallet balance in toman before credit.</param>
    /// <param name="after">Wallet balance in toman after credit.</param>
    /// <param name="source">Safe settlement trigger label.</param>
    /// <param name="cancellationToken">Cancellation token for persisting the users.db log marker.</param>
    /// <returns>A task that completes after the durable marker and central payment audit are emitted once.</returns>
    /// <remarks>
    /// Wallet credit, settlement state, ledger, referral processing, and customer notification are already durable
    /// before this helper runs. A Telegram logging failure must not cause the financial mutation to be replayed.
    /// </remarks>
    private async Task LogSettlementOnceAsync(
        UserWorkflowStore context,
        UniquePayPaymentInfo payment,
        CredUser user,
        long before,
        long after,
        string source,
        CancellationToken cancellationToken)
    {
        if (payment.SuccessLoggedAtUtc.HasValue)
            return;
        payment.SuccessLoggedAtUtc = DateTime.UtcNow;
        payment.UpdatedAtUtc = DateTime.UtcNow;
        await context.SaveAsync(cancellationToken);

        _logger.LogPayment(
            "✅ پرداخت ریالی یونیک‌پی تایید شد\n\n" +
            TelegramUserLinkFormatter.HtmlSummary(user) + "\n\n" +
            $"💰 مبلغ پایه: <code>{Html(payment.BaseAmountToman.FormatCurrency())}</code>\n" +
            $"💸 کارمزد درگاه: <code>{Html((payment.ProviderFeeToman ?? 0).FormatCurrency())}</code>\n" +
            $"👤 پرداخت‌کننده کارمزد: <code>{Html(payment.FeePayer)}</code>\n" +
            $"💱 واحد: <code>{Html(payment.Currency)}</code>\n" +
            $"🧾 Hash ID: <code>{Html(payment.HashId)}</code>\n" +
            $"🧾 Ref ID: <code>{Html(payment.RefId)}</code>\n" +
            $"💳 موجودی قبل: <code>{Html(before.FormatCurrency())}</code>\n" +
            $"💳 موجودی بعد: <code>{Html(after.FormatCurrency())}</code>\n" +
            $"📡 منبع: <code>{Html(source)}</code>");
    }

    /// <summary>Sends the one-time central audit for a provisional UniquePay wallet credit.</summary>
    /// <param name="payment">Provisionally credited owned-wallet payment and provider identifiers.</param>
    /// <param name="user">Shared wallet owner displayed in the protected payment log.</param>
    /// <param name="before">Wallet balance in toman before the provisional credit.</param>
    /// <param name="after">Wallet balance in toman after the provisional credit.</param>
    /// <remarks>The provider status remains pending; this audit never represents an official UniquePay confirmation.</remarks>
    private void LogProvisionalSettlement(
        UniquePayPaymentInfo payment,
        CredUser user,
        long before,
        long after)
    {
        _logger.LogPayment(
            "⚠️ شارژ موقت یونیک‌پی\n\n" +
            TelegramUserLinkFormatter.HtmlSummary(user) + "\n\n" +
            $"💰 مبلغ: <code>{Html(payment.BaseAmountToman.FormatCurrency())}</code>\n" +
            $"🧾 Hash ID: <code>{Html(payment.HashId)}</code>\n" +
            $"🧾 Ref ID: <code>{Html(payment.RefId)}</code>\n" +
            $"👨‍💼 تاییدکننده: <code>{payment.ProvisionalApprovedByTelegramUserId}</code>\n" +
            $"💳 موجودی قبل: <code>{Html(before.FormatCurrency())}</code>\n" +
            $"💳 موجودی بعد: <code>{Html(after.FormatCurrency())}</code>\n" +
            "🔒 وضعیت رسمی درگاه همچنان pending است.");
    }

    /// <summary>
    /// Records a later official UniquePay confirmation for a provisionally credited wallet without crediting again.
    /// </summary>
    /// <param name="context">
    /// Per-operation users.db context that tracks the payment and persists only the provider-confirmation audit.
    /// </param>
    /// <param name="payment">Tracked row already marked paid and provisionally credited.</param>
    /// <param name="user">Shared wallet owner displayed in the protected audit.</param>
    /// <param name="source">Non-secret inquiry source that observed the official confirmation.</param>
    /// <param name="cancellationToken">Cancellation token for the users.db audit update.</param>
    /// <returns>A task that completes after a new audit is saved or an existing confirmation is left unchanged.</returns>
    /// <remarks>No wallet, referral, or ledger mutation is performed.</remarks>
    private async Task RecordProviderConfirmationAfterProvisionalAsync(
        UserWorkflowStore context,
        UniquePayPaymentInfo payment,
        CredUser user,
        string source,
        CancellationToken cancellationToken)
    {
        if (!payment.IsProvisionallyApproved ||
            !payment.IsAddedToBalance ||
            !UniquePayStatuses.IsPaid(payment.PaymentStatus) ||
            payment.ProviderConfirmedAfterProvisionalAtUtc.HasValue)
        {
            return;
        }

        payment.ProviderConfirmedAfterProvisionalAtUtc = DateTime.UtcNow;
        payment.UpdatedAtUtc = DateTime.UtcNow;
        await context.SaveAsync(cancellationToken);
        _logger.LogPayment(
            "ℹ️ یونیک‌پی پرداخت موقت را بعداً تایید کرد\n\n" +
            TelegramUserLinkFormatter.HtmlSummary(user) + "\n\n" +
            $"🧾 Hash ID: <code>{Html(payment.HashId)}</code>\n" +
            $"🧾 Ref ID: <code>{Html(payment.RefId)}</code>\n" +
            $"👨‍💼 تایید موقت توسط: <code>{payment.ProvisionalApprovedByTelegramUserId}</code>\n" +
            $"📡 منبع تایید رسمی: <code>{Html(source)}</code>\n" +
            "🔒 کیف پول و ledger دوباره تغییر نکردند.");
    }

    /// <summary>
    /// Selects the strongest provider identity used by wallet and referral idempotency keys.
    /// </summary>
    /// <param name="payment">UniquePay payment containing provider and merchant identifiers.</param>
    /// <returns>Provider reference when present; otherwise merchant hash or invariant local id.</returns>
    private static string GetStableProviderId(UniquePayPaymentInfo payment)
        => !string.IsNullOrWhiteSpace(payment.RefId)
            ? payment.RefId.Trim()
            : !string.IsNullOrWhiteSpace(payment.HashId)
                ? payment.HashId.Trim()
                : payment.Id.ToString(CultureInfo.InvariantCulture);

    /// <summary>
    /// Restricts this settlement service to owned wallet-charge rows.
    /// </summary>
    /// <param name="payment">Payment proposed for wallet settlement.</param>
    /// <returns><c>true</c> for wallet charges and <c>false</c> for tenant orders.</returns>
    private static bool IsOwnedWalletCharge(UniquePayPaymentInfo payment)
        => string.IsNullOrWhiteSpace(payment?.PaymentPurpose) ||
           string.Equals(payment.PaymentPurpose, TenantBotPaymentPurposes.WalletCharge, StringComparison.OrdinalIgnoreCase);

    /// <summary>HTML-encodes provider and audit values before Telegram delivery.</summary>
    /// <param name="value">Potentially null user/provider text.</param>
    /// <returns>Non-null HTML-safe text.</returns>
    private static string Html(string value) => WebUtility.HtmlEncode(value ?? string.Empty);
}

/// <summary>
/// Reconciles UniquePay callbacks and performs bounded recovery polling for missed provider notifications.
/// </summary>
/// <remarks>
/// The worker intentionally ignores the global creation switch: disabling UniquePay must not strand invoices that
/// customers received earlier. Automatic polling uses exponential backoff and a hard per-invoice attempt cap; callback,
/// return, customer-check, and admin triggers remain available afterward. Provider outages are logger-throttled.
/// </remarks>
public sealed class UniquePayReconciliationHostedService : BackgroundService
{
    /// <summary>Coordinates inquiries for the same invoice without blocking unrelated payment checks.</summary>
    private static readonly AsyncKeyedGate ReconciliationGate = new();
    private static readonly TimeSpan StaleSettlementClaimAge = TimeSpan.FromMinutes(30);
    private readonly AppConfig _configuration;
    /// <summary>Creates one independent users.db context per scan or authoritative inquiry.</summary>
    private readonly UserDbContextFactory _userDbContextFactory;
    private readonly UniquePay _uniquePay;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<UniquePayReconciliationHostedService> _logger;

    /// <summary>
    /// Creates the UniquePay callback coordinator and bounded recovery worker.
    /// </summary>
    /// <param name="configuration">Startup configuration containing interval, batch limits, and super-admin allow-list.</param>
    /// <param name="userDbContextFactory">
    /// Factory that creates an independent users.db context for each scan or inquiry, preventing the hosted worker
    /// from sharing EF Core operations with concurrent Telegram update handlers.
    /// </param>
    /// <param name="uniquePay">Authenticated read-only inquiry client.</param>
    /// <param name="scopeFactory">Creates an isolated service graph for each verified payment settlement.</param>
    /// <param name="logger">Operational logger used for throttled provider and verification failures.</param>
    /// <remarks>Payment processing owns fresh database contexts; the singleton recovery worker resolves scoped settlement services only within each attempt.</remarks>
    public UniquePayReconciliationHostedService(
        IConfiguration configuration,
        UserDbContextFactory userDbContextFactory,
        UniquePay uniquePay,
        IServiceScopeFactory scopeFactory,
        ILogger<UniquePayReconciliationHostedService> logger)
    {
        _configuration = configuration.Get<AppConfig>() ?? new AppConfig();
        _userDbContextFactory = userDbContextFactory ?? throw new ArgumentNullException(nameof(userDbContextFactory));
        _uniquePay = uniquePay;
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    /// <summary>
    /// Runs bounded recovery scans for callbacks that may have been lost until application shutdown.
    /// </summary>
    /// <param name="stoppingToken">Host shutdown token.</param>
    /// <returns>A task representing the worker lifetime.</returns>
    /// <remarks>
    /// An unavailable token is tolerated while UniquePay has no scheduled rows. Once rows exist, the controlled
    /// configuration error is logged with throttling. Each row stops automatic scheduling at the configured cap but
    /// remains eligible for callback, return, customer-check, and admin-triggered authoritative inquiry.
    /// </remarks>
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var interval = TimeSpan.FromSeconds(Math.Clamp(
            _configuration.UniquePayReconciliationIntervalSeconds,
            10,
            3600));

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ReconcileDueAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UniquePay reconciliation scan failed.");
            }

            await Task.Delay(interval, stoppingToken);
        }
    }

    /// <summary>
    /// Reconciles one fair batch of due unsettled rows and provisional credits awaiting a final provider outcome.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token for users.db, provider, and settlement work.</param>
    /// <returns>A task that completes after all selected rows have been inspected.</returns>
    /// <remarks>
    /// The payment-keyed gate serializes inquiries for one invoice, while each database operation owns an independent EF Core
    /// context. Before selecting due work, ambiguous create rows that exhausted the configured cap are moved once to
    /// creation-level manual review and their automatic schedule is cleared. Only rows below the cap with a due
    /// non-null schedule are selected. Callback, browser-return, customer, and admin triggers remain GET-only and
    /// available after automatic recovery polling stops.
    /// </remarks>
    /// <example>
    /// <code>
    /// await reconciliation.ReconcileDueAsync(cancellationToken);
    /// </code>
    /// </example>
    public async Task ReconcileDueAsync(CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;
        var staleClaimBefore = now.Subtract(StaleSettlementClaimAge);
        var batchSize = Math.Clamp(_configuration.UniquePayReconciliationBatchSize, 1, 500);
        var maxAttempts = Math.Clamp(_configuration.UniquePayReconciliationMaxAttempts, 1, 100);
        var context = new UserWorkflowStore(_userDbContextFactory);

        var exhaustedAmbiguousIds = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
            .AsNoTracking()
            .Where(x => (x.CreationState == UniquePayCreationStates.Attempting ||
                         x.CreationState == UniquePayCreationStates.Ambiguous ||
                         x.CreationState == null) &&
                        x.PaymentStatus != UniquePayStatuses.Paid &&
                        x.PaymentStatus != UniquePayStatuses.Failed &&
                        x.PaymentStatus != UniquePayStatuses.Expired &&
                        x.PaymentStatus != UniquePayStatuses.Cancelled &&
                        (x.InquiryAttemptCount >= maxAttempts || x.NextInquiryAtUtc == null))
            .OrderBy(x => x.Id)
            .Select(x => x.Id)
            .Take(25)
            .ToListAsync(cancellationToken));

        var exhaustedAmbiguousCount = await context.WriteAsync(async db => await db.UniquePayPaymentInfos
            .Where(x => (x.CreationState == UniquePayCreationStates.Attempting ||
                         x.CreationState == UniquePayCreationStates.Ambiguous ||
                         x.CreationState == null) &&
                        x.PaymentStatus != UniquePayStatuses.Paid &&
                        x.PaymentStatus != UniquePayStatuses.Failed &&
                        x.PaymentStatus != UniquePayStatuses.Expired &&
                        x.PaymentStatus != UniquePayStatuses.Cancelled &&
                        (x.InquiryAttemptCount >= maxAttempts || x.NextInquiryAtUtc == null))
            .ExecuteUpdateAsync(
                setters => setters
                    .SetProperty(x => x.CreationState, UniquePayCreationStates.ManualReview)
                    .SetProperty(x => x.CreationErrorCode, "create_reconciliation_exhausted")
                    .SetProperty(x => x.NextInquiryAtUtc, (DateTime?)null)
                    .SetProperty(x => x.UpdatedAtUtc, now),
                cancellationToken));

        if (exhaustedAmbiguousCount > 0)
        {
            _logger.LogWarning(
                "UniquePay ambiguous creation recovery reached manual review. count={Count}, samplePaymentIds={PaymentIds}",
                exhaustedAmbiguousCount,
                string.Join(",", exhaustedAmbiguousIds));
        }

        // Persist the stopped schedule so old deployments with thousands of attempts no longer appear due in
        // operational database inspection. Null only disables automatic scans; explicit HTTP/Telegram triggers do
        // not consult NextInquiryAtUtc and therefore remain able to reconcile these invoices.
        await context.WriteAsync(async db => await db.UniquePayPaymentInfos
            .Where(x => x.InquiryAttemptCount >= maxAttempts &&
                        x.NextInquiryAtUtc != null &&
                        x.PaymentStatus != UniquePayStatuses.Paid &&
                        x.PaymentStatus != UniquePayStatuses.Failed &&
                        x.PaymentStatus != UniquePayStatuses.Expired &&
                        x.PaymentStatus != UniquePayStatuses.Cancelled)
            .ExecuteUpdateAsync(
                setters => setters
                    .SetProperty(x => x.NextInquiryAtUtc, (DateTime?)null)
                    .SetProperty(x => x.UpdatedAtUtc, now),
                cancellationToken));

        var ids = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
            .AsNoTracking()
            .Where(x => (!x.IsAddedToBalance ||
                         (x.IsProvisionallyApproved && x.ProviderConfirmedAfterProvisionalAtUtc == null)) &&
                        x.PaymentStatus != UniquePayStatuses.Failed &&
                        x.PaymentStatus != UniquePayStatuses.Expired &&
                        x.PaymentStatus != UniquePayStatuses.Cancelled &&
                        x.CreationState != UniquePayCreationStates.Failed &&
                        x.CreationState != UniquePayCreationStates.ManualReview &&
                        x.SettlementState != UniquePaySettlementStates.ManualReview &&
                        (x.SettlementState != UniquePaySettlementStates.Processing ||
                         x.SettlementStartedAtUtc == null ||
                         x.SettlementStartedAtUtc <= staleClaimBefore) &&
                        x.InquiryAttemptCount < maxAttempts &&
                        x.NextInquiryAtUtc != null &&
                        x.NextInquiryAtUtc <= now)
            .OrderBy(x => x.NextInquiryAtUtc)
            .ThenBy(x => x.Id)
            .Select(x => x.Id)
            .Take(batchSize)
            .ToListAsync(cancellationToken));

        foreach (var id in ids)
            await ReconcilePaymentAsync(id, "reconciliation-worker", cancellationToken);
    }

    /// <summary>
    /// Authoritatively checks and, when valid, settles one UniquePay row selected by internal id.
    /// </summary>
    /// <param name="paymentId">Internal users.db UniquePay row id, never a provider proof.</param>
    /// <param name="source">Safe trigger label used in financial audit logs.</param>
    /// <param name="cancellationToken">Cancellation token for provider, database, and fulfillment work.</param>
    /// <returns>
    /// Settlement result when paid; <see cref="NowPaymentsSettlementStatus.ProviderNotPaid"/> for pending/mismatch;
    /// or <see cref="NowPaymentsSettlementStatus.NotFound"/> when the local row no longer exists.
    /// </returns>
    /// <remarks>
    /// Interactive customer checks use this non-blocking method. Provider callback and browser-return requests use
    /// <see cref="ReconcileProviderTriggerAsync"/> so their HTTP response waits for a real inquiry. Neither path trusts
    /// callback data beyond locating the local row and both perform <c>/api/check-invoice</c>.
    /// </remarks>
    public async Task<NowPaymentsSettlementResult> ReconcilePaymentAsync(
        int paymentId,
        string source,
        CancellationToken cancellationToken = default)
        => await ReconcilePaymentAsync(
            paymentId,
            source,
            allowTerminalRecheck: false,
            cancellationToken);

    /// <summary>
    /// Waits for any in-flight inquiry and authoritatively reconciles a UniquePay provider callback or browser return.
    /// </summary>
    /// <param name="paymentId">
    /// Positive internal users.db UniquePay row id resolved from the invoice-specific merchant hash. It is never
    /// accepted directly from provider status or amount fields.
    /// </param>
    /// <param name="source">Safe audit source identifying callback or browser-return processing.</param>
    /// <param name="cancellationToken">Cancellation token for gate waiting, provider inquiry, persistence, and settlement.</param>
    /// <returns>
    /// The authoritative settlement outcome. ProviderNotPaid means the fresh official inquiry remained pending or
    /// failed validation; no callback payload can directly produce an Applied result.
    /// </returns>
    /// <remarks>
    /// Unlike an interactive customer check, a provider trigger waits for the reconciliation gate so the HTTP response
    /// is based on a real inquiry rather than lock contention. Duplicate callbacks remain idempotent through durable
    /// settlement markers and unique ledger keys.
    /// </remarks>
    /// <example>
    /// <code>
    /// var result = await reconciliation.ReconcileProviderTriggerAsync(
    ///     payment.Id, "provider-callback", cancellationToken);
    /// </code>
    /// </example>
    public async Task<NowPaymentsSettlementResult> ReconcileProviderTriggerAsync(
        int paymentId,
        string source,
        CancellationToken cancellationToken = default)
    {
        using var reconciliationLease = await ReconciliationGate.EnterAsync(paymentId.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            return await ReconcilePaymentCoreAsync(
                paymentId,
                source,
                allowTerminalRecheck: false,
                cancellationToken);
        }
        finally
        {
            reconciliationLease.Dispose();
        }
    }

    /// <summary>
    /// Authoritatively checks one UniquePay row with an optional super-admin recovery override for local terminal state.
    /// </summary>
    /// <param name="paymentId">Internal users.db UniquePay row id; it is only a lookup key, never payment proof.</param>
    /// <param name="source">Safe audit label for the worker, customer, return, or admin trigger.</param>
    /// <param name="allowTerminalRecheck">
    /// <c>true</c> only for a configured super-admin status check that must recover rows rejected by an older local
    /// validator. Provider terminal results remain authoritative and no local force-paid status is created.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for provider, database, wallet, and tenant work.</param>
    /// <returns>Settlement outcome after an official inquiry, or ProviderNotPaid when no safe settlement is possible.</returns>
    /// <remarks>
    /// This overload bypasses only the local early-return guard. It still requires the current provider response to
    /// pass every identity, paid, currency, fee-payer, amount, and fee invariant before official settlement.
    /// </remarks>
    public async Task<NowPaymentsSettlementResult> ReconcilePaymentAsync(
        int paymentId,
        string source,
        bool allowTerminalRecheck,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        using var reconciliationLease = allowTerminalRecheck
            ? await ReconciliationGate.EnterAsync(paymentId.ToString(CultureInfo.InvariantCulture), cancellationToken)
            : ReconciliationGate.TryEnter(paymentId.ToString(CultureInfo.InvariantCulture));
        if (reconciliationLease == null) return NowPaymentsSettlementResult.ProviderNotPaid();
        try
        {
            return await ReconcilePaymentCoreAsync(paymentId, source, allowTerminalRecheck, cancellationToken);
        }
        finally
        {
            reconciliationLease.Dispose();
        }
    }

    /// <summary>
    /// Performs the final authoritative UniquePay inquiry and, only when it remains safely pending, applies one
    /// super-admin provisional OWNED wallet credit before releasing the reconciliation gate.
    /// </summary>
    /// <param name="paymentId">Positive internal users.db UniquePay payment id selected by the admin callback.</param>
    /// <param name="approvedByTelegramUserId">Configured super-admin Telegram id persisted with the provisional audit.</param>
    /// <param name="notifyChatId">Optional owned-customer Telegram chat id; null uses the persisted payment chat.</param>
    /// <param name="source">Non-secret audit label identifying the final admin confirmation trigger.</param>
    /// <param name="cancellationToken">Cancellation token for provider, users.db, credentials.db, ledger, and Telegram work.</param>
    /// <returns>
    /// The official settlement result when the provider reports paid; the provisional settlement result when the
    /// refreshed row remains eligible; otherwise a non-mutating ProviderNotPaid, NotFound, or InvalidAmount result.
    /// </returns>
    /// <remarks>
    /// Holding the same reconciliation gate across inquiry and provisional claim prevents the periodic worker from
    /// starting another inquiry between the admin's final check and wallet claim. The refreshed row is loaded through
    /// an independent context; tenant orders, terminal/mismatched responses, malformed responses, and transport errors
    /// always fail closed.
    /// </remarks>
    /// <example>
    /// <code>
    /// var result = await reconciliation.ReconcileAndApplyProvisionalAsync(
    ///     payment.Id, adminTelegramId, payment.ChatId, "admin-provisional-confirm", cancellationToken);
    /// </code>
    /// </example>
    public async Task<NowPaymentsSettlementResult> ReconcileAndApplyProvisionalAsync(
        int paymentId,
        long approvedByTelegramUserId,
        long? notifyChatId,
        string source,
        CancellationToken cancellationToken = default)
    {
        if (paymentId <= 0 ||
            approvedByTelegramUserId <= 0 ||
            _configuration.AdminsUserIds?.Contains(approvedByTelegramUserId) != true)
        {
            return NowPaymentsSettlementResult.InvalidAmount();
        }

        using var reconciliationLease = await ReconciliationGate.EnterAsync(paymentId.ToString(CultureInfo.InvariantCulture), cancellationToken);
        try
        {
            var official = await ReconcilePaymentCoreAsync(
                paymentId,
                source,
                allowTerminalRecheck: true,
                cancellationToken);
            var context = new UserWorkflowStore(_userDbContextFactory);
            var payment = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == paymentId, cancellationToken));
            if (payment == null)
                return NowPaymentsSettlementResult.NotFound();
            if (UniquePayStatuses.IsPaid(payment.PaymentStatus) || payment.IsAddedToBalance)
                return official;
            if (!UniquePaySettlementService.CanApplyProvisionalCredit(payment))
                return official;

            // Inquiry and claim stay serialized, while the settlement service's independent durable claim remains the
            // final exactly-once boundary against a concurrent return trigger or duplicate admin callback.
            await using var scope = _scopeFactory.CreateAsyncScope();
            return await scope.ServiceProvider.GetRequiredService<UniquePaySettlementService>().ApplyProvisionalPaymentAsync(
                payment,
                approvedByTelegramUserId,
                notifyChatId,
                cancellationToken);
        }
        finally
        {
            reconciliationLease.Dispose();
        }
    }

    /// <summary>
    /// Performs one UniquePay inquiry while the reconciliation gate for that invoice is held.
    /// </summary>
    /// <param name="paymentId">Internal users.db UniquePay payment id.</param>
    /// <param name="source">Safe settlement trigger label.</param>
    /// <param name="allowTerminalRecheck">
    /// Whether a configured super-admin may bypass only the local terminal-state early return and obtain fresh official
    /// provider data. All payment invariants remain mandatory.
    /// </param>
    /// <param name="cancellationToken">Cancellation token for provider and settlement operations.</param>
    /// <returns>Settlement result from the authoritative inquiry and downstream fulfillment.</returns>
    /// <remarks>
    /// Definitive creation failures are not queried automatically or interactively. Ambiguous and manual-review create
    /// states may be resolved only through <c>check-invoice</c>; an invoice object proves creation, while an absent or
    /// undocumented response cannot authorize another create mutation. Settlement continues through the existing
    /// wallet/tenant idempotency services only after full paid verification.
    /// </remarks>
    private async Task<NowPaymentsSettlementResult> ReconcilePaymentCoreAsync(
        int paymentId,
        string source,
        bool allowTerminalRecheck,
        CancellationToken cancellationToken)
    {
        var context = new UserWorkflowStore(_userDbContextFactory);
        var payment = await context.ReadAsync(async db => await db.UniquePayPaymentInfos
            .FirstOrDefaultAsync(x => x.Id == paymentId, cancellationToken));
        if (payment == null)
            return NowPaymentsSettlementResult.NotFound();
        if (payment.IsAddedToBalance &&
            (!payment.IsProvisionallyApproved || payment.ProviderConfirmedAfterProvisionalAtUtc.HasValue))
        {
            return NowPaymentsSettlementResult.AlreadyAdded(payment.BalanceAfter ?? 0);
        }
        if (!UniquePayCreationStates.IsReadOnlyInquiryAllowed(payment.CreationState))
            return NowPaymentsSettlementResult.ProviderNotPaid();
        if ((!allowTerminalRecheck && UniquePayStatuses.IsTerminal(payment.PaymentStatus)) ||
            string.Equals(payment.SettlementState, UniquePaySettlementStates.ManualReview, StringComparison.Ordinal))
        {
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }

        try
        {
            var response = await _uniquePay.CheckInvoiceAsync(payment.HashId, cancellationToken);
            payment.Apply(response, GetNextAutomaticInquiryAtUtc(payment.InquiryAttemptCount + 1));
            if (response.Invoice == null)
            {
                // No authoritative not-found contract is present in the checked-in provider documentation. A
                // structurally valid but invoice-less response therefore remains inconclusive and cannot prove that
                // the ambiguous POST did not commit.
                payment.ErrorCode = "provider_check_inconclusive";
                payment.ErrorMessage = "UniquePay inquiry did not return an authoritative invoice object.";
                payment.UpdatedAtUtc = DateTime.UtcNow;
                _logger.LogWarning(
                    "UniquePay inquiry retry detail: provider response was inconclusive. paymentId={PaymentId}, tenantOrderId={TenantOrderId}, attempt={Attempt}, creationState={CreationState}",
                    payment.Id,
                    payment.TenantBotOrderId,
                    payment.InquiryAttemptCount,
                    payment.CreationState);
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }

            var providerTerminalStatus = UniquePayStatuses.GetProviderTerminalStatus(response.Invoice);
            if (providerTerminalStatus != null)
            {
                payment.PaymentStatus = providerTerminalStatus;
                payment.NextInquiryAtUtc = null;
                payment.ErrorCode = $"provider_{providerTerminalStatus}";
                payment.ErrorMessage = "UniquePay reported a terminal unpaid invoice state.";
                payment.UpdatedAtUtc = DateTime.UtcNow;
                LogFailureWithThrottle(payment, "UniquePay reported a terminal unpaid invoice.", null);
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }

            var verified = UniquePayPaymentVerifier.IsVerifiedPaid(payment, response, out var errorCode);
            if (!verified)
            {
                payment.ErrorCode = string.Equals(errorCode, "provider_not_paid", StringComparison.Ordinal)
                    ? null
                    : errorCode;
                payment.ErrorMessage = payment.ErrorCode == null ? null : "UniquePay verification rejected provider data.";
                if (payment.ErrorCode != null)
                {
                    payment.PaymentStatus = UniquePayStatuses.Failed;
                    payment.NextInquiryAtUtc = null;
                    LogFailureWithThrottle(payment, "UniquePay payment verification mismatch.", null);
                }
                await context.SaveAsync(cancellationToken);
                return NowPaymentsSettlementResult.ProviderNotPaid();
            }

            // The documented check response exposes the provider identity as invoice.id and may omit root refId.
            payment.RefId ??= !string.IsNullOrWhiteSpace(response.RefId)
                ? response.RefId
                : response.Invoice.InvoiceId;
            payment.PaymentStatus = UniquePayStatuses.Paid;
            payment.PaidAtUtc ??= DateTime.UtcNow;
            payment.NextInquiryAtUtc = null;
            payment.ErrorCode = null;
            payment.ErrorMessage = null;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            await context.SaveAsync(cancellationToken);

            if (string.Equals(
                    payment.PaymentPurpose,
                    TenantBotPaymentPurposes.TenantOrder,
                    StringComparison.OrdinalIgnoreCase))
            {
                await using var scope = _scopeFactory.CreateAsyncScope();
                return await scope.ServiceProvider.GetRequiredService<TenantBotService>().ApplyPaidTenantOrderAsync(payment, source, cancellationToken);
            }

            await using var settlementScope = _scopeFactory.CreateAsyncScope();
            return await settlementScope.ServiceProvider.GetRequiredService<UniquePaySettlementService>().ApplyOfficialPaymentAsync(
                payment,
                source,
                payment.ChatId,
                cancellationToken);
        }
        catch (Exception ex) when (ex is UniquePayApiException or HttpRequestException or InvalidOperationException)
        {
            payment.InquiryAttemptCount++;
            payment.LastInquiryAtUtc = DateTime.UtcNow;
            payment.NextInquiryAtUtc = GetNextAutomaticInquiryAtUtc(payment.InquiryAttemptCount);
            payment.ErrorCode = "provider_check_failed";
            payment.ErrorMessage = ex.Message;
            payment.UpdatedAtUtc = DateTime.UtcNow;
            _logger.LogWarning(
                ex,
                "UniquePay inquiry retry detail: provider request failed. paymentId={PaymentId}, tenantOrderId={TenantOrderId}, attempt={Attempt}, creationState={CreationState}, nextInquiryAtUtc={NextInquiryAtUtc}",
                payment.Id,
                payment.TenantBotOrderId,
                payment.InquiryAttemptCount,
                payment.CreationState,
                payment.NextInquiryAtUtc);
            await context.SaveAsync(cancellationToken);
            return NowPaymentsSettlementResult.ProviderNotPaid();
        }
    }

    /// <summary>
    /// Computes the next bounded automatic UniquePay recovery inquiry using exponential backoff.
    /// </summary>
    /// <param name="completedAttempts">
    /// Total authoritative inquiries already recorded for the local invoice, including worker and explicit triggers.
    /// Values at or above the configured maximum stop automatic scheduling.
    /// </param>
    /// <returns>
    /// The next UTC inquiry time, or <c>null</c> when the automatic-attempt cap has been reached. A null schedule does
    /// not block provider callback, browser return, customer check, or super-admin inquiry paths.
    /// </returns>
    /// <remarks>
    /// The base delay is <see cref="AppConfig.UniquePayReconciliationIntervalSeconds"/> and doubles after each pending
    /// observation up to <see cref="AppConfig.UniquePayReconciliationMaxDelaySeconds"/>. This keeps short recovery for
    /// dropped callbacks without continuously querying abandoned invoices.
    /// </remarks>
    /// <example>
    /// With a 30-second base and 900-second cap, pending attempts are scheduled after approximately 60, 120, 240,
    /// 480, then at most 900 seconds until the attempt limit is reached.
    /// </example>
    private DateTime? GetNextAutomaticInquiryAtUtc(int completedAttempts)
    {
        var maxAttempts = Math.Clamp(_configuration.UniquePayReconciliationMaxAttempts, 1, 100);
        if (completedAttempts >= maxAttempts)
            return null;

        var baseDelaySeconds = Math.Clamp(
            _configuration.UniquePayReconciliationIntervalSeconds,
            10,
            3600);
        var maxDelaySeconds = Math.Clamp(
            _configuration.UniquePayReconciliationMaxDelaySeconds,
            baseDelaySeconds,
            86400);
        var exponent = Math.Clamp(completedAttempts, 0, 20);
        var delaySeconds = Math.Min(maxDelaySeconds, baseDelaySeconds * Math.Pow(2, exponent));
        return DateTime.UtcNow.AddSeconds(delaySeconds);
    }

    /// <summary>
    /// Sends a transition/hourly-throttled terminal or verification logger-channel error for one payment.
    /// </summary>
    /// <param name="payment">Payment whose safe identifiers and amount are logged.</param>
    /// <param name="message">Non-secret failure category.</param>
    /// <param name="exception">Optional sanitized provider/transport exception.</param>
    /// <remarks>
    /// Per-attempt transport/inquiry failures use a separate local-only structured message and do not call this method.
    /// Repeated terminal or verification events are limited to one report per hour. The first terminal result after a
    /// provisional credit bypasses that throttle so the operator receives the required clawback-review alert.
    /// </remarks>
    private void LogFailureWithThrottle(
        UniquePayPaymentInfo payment,
        string message,
        Exception exception)
    {
        var now = DateTime.UtcNow;
        var mustReportProvisionalTerminalOutcome = payment.IsProvisionallyApproved &&
                                                   UniquePayStatuses.IsTerminal(payment.PaymentStatus) &&
                                                   !string.Equals(
                                                       payment.ErrorCode,
                                                       "provider_check_failed",
                                                       StringComparison.Ordinal);
        if (!mustReportProvisionalTerminalOutcome &&
            payment.LastErrorLoggedAtUtc.HasValue &&
            now - payment.LastErrorLoggedAtUtc.Value < TimeSpan.FromHours(1))
        {
            return;
        }

        payment.LastErrorLoggedAtUtc = now;
        var effectiveMessage = mustReportProvisionalTerminalOutcome
            ? message + " Provisional wallet credit was not reversed; human financial review is required."
            : message;
        _logger.LogError(
            exception,
            "{Message} paymentId={PaymentId}, tenantOrderId={TenantOrderId}, botId={BotId}, amountToman={AmountToman}, errorCode={ErrorCode}, provisional={Provisional}, approvedBy={ApprovedBy}",
            effectiveMessage,
            payment.Id,
            payment.TenantBotOrderId,
            payment.BotId,
            payment.BaseAmountToman,
            payment.ErrorCode,
            payment.IsProvisionallyApproved,
            payment.ProvisionalApprovedByTelegramUserId);
    }
}
